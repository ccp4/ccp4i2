import React from "react";
import { MoorhenUIElement } from "./MoorhenUIElement";
/**
 * `<moorhen-chain-select>`: a dropdown of the chains of one loaded molecule, chosen by unique id.
 * For content placed inside `<moorhen-web-component>`.
 *
 * Attributes: `for` (the id of a `<moorhen-molecule-select>`: its molecule is followed, also its own
 * first pick), or `molecule` (the molecule's unique id),
 * `label` (default "Chain"), `value` (starting chain id), the boolean `allow-all` (adds "All") and
 * `disabled` (without it, the dropdown is disabled only while the molecule has no chain).
 *
 * Properties: `value` — the selected chain id, `null` for "All", `undefined` when there is no chain;
 * `molecule` — same as the attribute; `allowedTypes` — gemmi polymer types to list (1 PeptideL,
 * 2 PeptideD, 3 DNA, 4 RNA, 5 DNA/RNA hybrid; all by default).
 *
 * Fires `change` (bubbling) when the user picks a chain. With no valid selection — at first, or after
 * the molecule changed — the dropdown picks the first chain by itself, without an event.
 *
 * With the boolean `multiple`, a list of checkboxes with "Check all" / "Uncheck all" replaces the
 * dropdown, like a native `<select multiple>`: `values` holds the selected chain ids (all at first,
 * and all again when the molecule changes) and `value` the first of them. `change` fires for each
 * tick and for the buttons. `allow-all` does not apply.
 *
 * @example
 * moleculeSelect.addEventListener("change", () => chainSelect.molecule = moleculeSelect.value);
 * <moorhen-chain-select molecule="…" multiple></moorhen-chain-select>
 * chainSelect.addEventListener("change", () => console.log(chainSelect.values));
 */
export declare class MoorhenChainSelectElement extends MoorhenUIElement {
    static observedAttributes: string[];
    static upgradedProperties: string[];
    private _value;
    private _molecule;
    private _allowedTypes;
    /** With `multiple`: the ticked chain ids; unset until the list (all) or a script set them. */
    private _values;
    private get isMultiple();
    private get componentValue();
    protected attributeValueChanged(name: string): void;
    /** With `for`: the molecule select whose molecule this follows, and how to stop following it. */
    private _source;
    private _unfollow;
    private followSource;
    connectedCallback(): Promise<void>;
    disconnectedCallback(): void;
    get value(): string | null | undefined;
    set value(value: string | null | undefined);
    /** With `multiple`: the selected chain ids, in the molecule's order (in the given order when a script set them). Otherwise `[value]`. */
    get values(): string[];
    set values(values: string[]);
    /** The unique id of the molecule whose chains are listed. */
    get molecule(): string | null;
    set molecule(uniqueId: string | null);
    get allowedTypes(): number[] | undefined;
    set allowedTypes(types: number[] | undefined);
    protected renderComponent(): import("react/jsx-runtime").JSX.Element;
}
/** Attributes of `<moorhen-chain-select>`, for declaring it in JSX. */
export interface MoorhenChainSelectElementAttributes extends React.HTMLAttributes<MoorhenChainSelectElement> {
    /** The id of the `<moorhen-web-component>` to work with, when the element is not inside it. */
    moorhen?: string;
    /** The id of a `<moorhen-molecule-select>` whose molecule is followed. */
    for?: string;
    /** The molecule's unique id (without `for`). */
    molecule?: string;
    label?: string;
    /** Starting chain id. */
    value?: string;
    "allow-all"?: boolean;
    disabled?: boolean;
    /** Checkboxes for any number of chains instead of a dropdown. */
    multiple?: boolean;
}
//# sourceMappingURL=MoorhenChainSelectElement.d.ts.map