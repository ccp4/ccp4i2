import React from "react";
import type { MoorhenMolecule } from "../../utils/MoorhenMolecule";
import { MoorhenUIElement } from "./MoorhenUIElement";
/** Fired on a molecule select whenever its value changes, for the chain selects that follow it. */
export declare const MOLECULE_VALUE_EVENT = "moorhen-molecule-value";
/**
 * `<moorhen-molecule-select>`: a dropdown of the molecules loaded in Moorhen, kept up to date as
 * molecules are loaded and deleted. For content placed inside `<moorhen-web-component>`.
 *
 * Values are molecule unique ids (`molecule.uniqueId`), as in the rest of the API.
 *
 * Attributes: `label` (default "Select Molecule:"), `value` (starting selection, a unique id), the
 * boolean `allow-any` (adds "Any molecule") and `disabled`.
 *
 * Properties: `value` — the selected molecule's unique id, `null` for "Any molecule", `undefined`
 * when nothing is loaded; `filter` — `(molecule) => boolean` to list only some molecules.
 *
 * Fires `change` (bubbling) when the user picks a molecule. With nothing selected the dropdown picks
 * the first molecule by itself; that updates `value` without an event, as a native `<select>` does.
 *
 * With the boolean `multiple`, a list of checkboxes with "Check all" / "Uncheck all" replaces the
 * dropdown, like a native `<select multiple>`: `values` holds the selected unique ids (all at
 * first; molecules loaded later are added while all are selected) and `value` the first of them.
 * `change` fires for each tick and for the buttons. `allow-any` does not apply.
 *
 * @example
 * <moorhen-molecule-select allow-any></moorhen-molecule-select>
 * select.addEventListener("change", () => console.log(select.value));
 * <moorhen-molecule-select multiple></moorhen-molecule-select>
 * select.addEventListener("change", () => console.log(select.values));
 */
export declare class MoorhenMoleculeSelectElement extends MoorhenUIElement {
    static observedAttributes: string[];
    static upgradedProperties: string[];
    /** The component's own value (unique id, or "" for any); unset until chosen or set. */
    private _value;
    private _filter;
    /** With `multiple`: the ticked unique ids; unset until the list (all) or a script set them. */
    private _values;
    private get isMultiple();
    private get componentValue();
    protected attributeValueChanged(name: string): void;
    /**
     * Tells elements following this one (`<moorhen-chain-select for="…">`) that the value changed, also
     * when it changed by itself. An internal event: it does not bubble, and is not `change`.
     */
    private announceValue;
    get value(): string | null | undefined;
    set value(value: string | null | undefined);
    /** With `multiple`: the selected molecules' unique ids, in list order (in the given order when a script set them). Otherwise `[value]`. */
    get values(): string[];
    set values(values: string[]);
    get filter(): ((molecule: MoorhenMolecule) => boolean) | undefined;
    set filter(filter: ((molecule: MoorhenMolecule) => boolean) | undefined);
    protected renderComponent(): import("react/jsx-runtime").JSX.Element;
}
/** Attributes of `<moorhen-molecule-select>`, for declaring it in JSX. */
export interface MoorhenMoleculeSelectElementAttributes extends React.HTMLAttributes<MoorhenMoleculeSelectElement> {
    /** The id of the `<moorhen-web-component>` to work with, when the element is not inside it. */
    moorhen?: string;
    label?: string;
    /** Starting selection: a molecule unique id. */
    value?: string;
    "allow-any"?: boolean;
    disabled?: boolean;
    /** Checkboxes for any number of molecules instead of a dropdown. */
    multiple?: boolean;
}
//# sourceMappingURL=MoorhenMoleculeSelectElement.d.ts.map