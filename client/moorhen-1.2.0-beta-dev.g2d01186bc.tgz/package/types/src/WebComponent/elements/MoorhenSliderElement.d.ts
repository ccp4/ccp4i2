import React from "react";
import { MoorhenUIElement } from "./MoorhenUIElement";
type SliderLabel = {
    value: number;
    label: string;
    tick?: boolean;
    colour?: string;
};
/**
 * `<moorhen-slider>`: Moorhen's slider for content placed inside `<moorhen-web-component>`.
 *
 * Attributes: `min` (default 0), `max` (default 100), `step`, `value` (starting value), `scale`
 * ("linear" | "log" | "asinh"), `label` (title above the slider), `unit`, `decimal-places`, `colour`,
 * and the booleans `disabled`, `show-ticks`, `precise-input` (adds a number field), `hide-buttons`,
 * `hide-labels`, `hide-value` (in the title). `type="range"` gives two thumbs, with `value2`.
 *
 * Properties: `value` (and `value2` for a range), `labels` (`{ value, label, tick?, colour? }[]`) and
 * `allowedValues` (`number[]`, the slider snaps to them).
 *
 * Events, as for a native range input: `input` (bubbling) on every change while the user drags or
 * steps, `change` (bubbling) once the user lets go (pointer released — also outside the element at the
 * end of a drag —, key released, or focus leaving).
 * Setting `value` from a script fires neither.
 *
 * @example
 * <moorhen-slider label="Radius" min="1" max="30" value="12" unit="Å"></moorhen-slider>
 */
export declare class MoorhenSliderElement extends MoorhenUIElement {
    static observedAttributes: string[];
    static upgradedProperties: string[];
    private _value;
    private _value2;
    private _labels;
    private _allowedValues;
    /** The value last reported with `change`, to fire it only when the user really changed something. */
    private _committed;
    constructor();
    private get minimum();
    private get maximum();
    private get isRange();
    get value(): number;
    set value(value: number);
    /** The second thumb of a `type="range"` slider. */
    get value2(): number;
    set value2(value: number);
    get labels(): SliderLabel[] | undefined;
    set labels(labels: SliderLabel[] | undefined);
    get allowedValues(): number[] | undefined;
    set allowedValues(values: number[] | undefined);
    connectedCallback(): Promise<void>;
    protected attributeValueChanged(name: string): void;
    private snapshot;
    private commitIfChanged;
    private userChanged;
    protected renderComponent(): import("react/jsx-runtime").JSX.Element;
}
/** Attributes of `<moorhen-slider>`, for declaring it in JSX. */
export interface MoorhenSliderElementAttributes extends React.HTMLAttributes<MoorhenSliderElement> {
    /** The id of the `<moorhen-web-component>` to work with, when the element is not inside it. */
    moorhen?: string;
    min?: number;
    max?: number;
    step?: number;
    value?: number;
    value2?: number;
    type?: "default" | "range";
    scale?: "linear" | "log" | "asinh";
    label?: string;
    unit?: string;
    "decimal-places"?: number;
    colour?: string;
    disabled?: boolean;
    "show-ticks"?: boolean;
    "precise-input"?: boolean;
    "hide-buttons"?: boolean;
    "hide-labels"?: boolean;
    "hide-value"?: boolean;
}
export {};
//# sourceMappingURL=MoorhenSliderElement.d.ts.map