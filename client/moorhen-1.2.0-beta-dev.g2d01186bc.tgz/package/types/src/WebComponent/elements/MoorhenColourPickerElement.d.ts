import React from "react";
import { MoorhenUIElement } from "./MoorhenUIElement";
/**
 * `<moorhen-colour-picker>`: Moorhen's colour picker for content placed inside `<moorhen-web-component>`.
 * By default a swatch that opens the picker in a popover; `inline` shows the picker itself.
 *
 * The value is a hex colour: `#rrggbb`, or `#rrggbbaa` with `use-alpha`.
 *
 * Attributes: `value` (starting colour, `#rgb`, `#rrggbb` or `#rrggbbaa`), `label`, `tooltip`,
 * `position` ("top" | "bottom" | "left" | "right", where the popover opens), and the booleans
 * `use-alpha`, `inline` and `hide-swatches`.
 *
 * Events, as for a native colour input: `input` (bubbling) on every change while the user picks,
 * `change` (bubbling) once done — when the popover closes, or, `inline`, when the pointer or key is
 * released or focus leaves. Setting `value` from a script fires neither.
 *
 * @example
 * <moorhen-colour-picker value="#ff8800" tooltip="Ligand colour"></moorhen-colour-picker>
 */
export declare class MoorhenColourPickerElement extends MoorhenUIElement {
    static observedAttributes: string[];
    static upgradedProperties: string[];
    /** The current colour as the component uses it; unset until picked or set. */
    private _colour;
    /** The value last reported with `change`. */
    private _committed;
    constructor();
    private get useAlpha();
    private get colour();
    get value(): string;
    set value(hex: string);
    connectedCallback(): Promise<void>;
    protected attributeValueChanged(name: string): void;
    private commitIfChanged;
    protected renderComponent(): import("react/jsx-runtime").JSX.Element;
}
/** Attributes of `<moorhen-colour-picker>`, for declaring it in JSX. */
export interface MoorhenColourPickerElementAttributes extends React.HTMLAttributes<MoorhenColourPickerElement> {
    /** The id of the `<moorhen-web-component>` to work with, when the element is not inside it. */
    moorhen?: string;
    /** Starting colour: `#rgb`, `#rrggbb` or `#rrggbbaa`. */
    value?: string;
    label?: string;
    tooltip?: string;
    position?: "top" | "bottom" | "left" | "right";
    "use-alpha"?: boolean;
    inline?: boolean;
    "hide-swatches"?: boolean;
}
//# sourceMappingURL=MoorhenColourPickerElement.d.ts.map