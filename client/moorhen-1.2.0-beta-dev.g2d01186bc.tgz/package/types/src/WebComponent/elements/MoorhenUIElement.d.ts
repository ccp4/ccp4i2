import React from "react";
/**
 * Base class of the Moorhen UI elements (`<moorhen-button>`, …), which render Moorhen React
 * components for content placed inside a `<moorhen-web-component>` (typically slotted plugin content).
 *
 * Each element is its own React root, compiled into the same bundle as the web component. It finds
 * its `<moorhen-web-component>` — the one whose id is in its `moorhen` attribute, else the one it is
 * in (slotted content), else the only one in the page — waits for its instance, and provides that instance's
 * store and `MoorhenInstanceContext`, so the component reads and changes the app's live state exactly
 * as it would inside the app. It renders in its own shadow root with the host's Moorhen stylesheet.
 *
 * Subclasses list their attributes in `static observedAttributes`, their JavaScript properties in
 * `static upgradedProperties`, and implement `renderComponent`. Controls with a value keep it on the
 * element (the component is rendered controlled), call `requestRender` when it changes, and fire
 * `change` for user changes, like native inputs.
 */
export declare abstract class MoorhenUIElement extends HTMLElement {
    private _root;
    private _instance;
    private _connection;
    /**
     * Properties with accessors on the subclass. A value assigned before the element was defined (a
     * framework rendering ahead of `registerMoorhenWebComponent`) sits on the instance and would hide
     * the accessor, so it is moved onto it on connection.
     */
    static upgradedProperties: readonly string[];
    /** Renders the component from the element's current attributes and state. */
    protected abstract renderComponent(): React.ReactNode;
    /**
     * Calls `callback` when the user is done with an interaction that started on this element: the
     * pointer released (anywhere, as drags end outside the element), a key released, or focus leaving.
     * It runs on the next tick, after the `click` that follows a pointer release.
     */
    protected onUserRelease(callback: () => void): void;
    private upgradeProperties;
    connectedCallback(): Promise<void>;
    disconnectedCallback(): void;
    attributeChangedCallback(name?: string, oldValue?: string | null, newValue?: string | null): void;
    /**
     * An attribute changed. Elements with a value use it so that a changed `value` / `checked`
     * attribute becomes the current value: a framework rendering `<moorhen-toggle checked={on}>` drives
     * the element. An attribute that does not change (a re-render with the same value) does nothing,
     * so the user's own changes are kept until then.
     */
    protected attributeValueChanged(_name: string): void;
    /** Re-renders the component; does nothing until the element is connected to a ready Moorhen. */
    protected requestRender(): void;
}
/** Reads a boolean attribute the HTML way: present means true, except an explicit "false". */
export declare const booleanAttribute: (element: HTMLElement, name: string) => boolean;
/** Reads a number attribute; `undefined` when absent or not a number. */
export declare const numberAttribute: (element: HTMLElement, name: string) => number | undefined;
//# sourceMappingURL=MoorhenUIElement.d.ts.map