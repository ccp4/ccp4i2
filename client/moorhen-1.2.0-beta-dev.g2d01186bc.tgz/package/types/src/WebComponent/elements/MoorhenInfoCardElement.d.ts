import React from "react";
import { MoorhenUIElement } from "./MoorhenUIElement";
/**
 * `<moorhen-info-card>`: Moorhen's info button, opening a popover with help text. For content placed
 * inside `<moorhen-web-component>`.
 *
 * The text is the `info` attribute, or else the element's own content, which can be rich
 * (`<h1>`–`<h3>`, paragraphs, lists… styled as Moorhen's info cards; a `<template>` works too). The
 * popover is drawn in Moorhen's popup layer, outside the page, so it shows a copy of that content —
 * kept up to date when it changes — and the content itself is not shown in the page. Being a copy,
 * it is for static content: event listeners and form state are not carried over.
 *
 * Attributes: `info`, `placement` ("top" | "bottom" | "left" | "right"; default "top"), `width`
 * (maximum width, a CSS length), and the boolean `large` (a wide card in the middle of the view,
 * for longer help).
 *
 * @example
 * <moorhen-info-card info="Keeps only the residues within the radius."></moorhen-info-card>
 * <moorhen-info-card large>
 *     <h1>My plugin</h1>
 *     <p>What it does, step by step…</p>
 * </moorhen-info-card>
 */
export declare class MoorhenInfoCardElement extends MoorhenUIElement {
    static observedAttributes: string[];
    private _contentVersion;
    private _observer;
    connectedCallback(): Promise<void>;
    disconnectedCallback(): void;
    protected renderComponent(): import("react/jsx-runtime").JSX.Element;
}
/** Attributes of `<moorhen-info-card>`, for declaring it in JSX. */
export interface MoorhenInfoCardElementAttributes extends React.HTMLAttributes<MoorhenInfoCardElement> {
    /** The id of the `<moorhen-web-component>` to work with, when the element is not inside it. */
    moorhen?: string;
    /** Plain text; without it, the element's content is shown. */
    info?: string;
    placement?: "top" | "bottom" | "left" | "right";
    /** Maximum width of the card, a CSS length. */
    width?: string;
    /** A wide card in the middle of the view, for longer help. */
    large?: boolean;
}
//# sourceMappingURL=MoorhenInfoCardElement.d.ts.map