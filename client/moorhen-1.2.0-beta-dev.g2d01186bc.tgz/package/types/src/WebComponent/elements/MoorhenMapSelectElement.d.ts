import React from "react";
import type { MoorhenMap } from "../../utils/MoorhenMap";
import { MoorhenUIElement } from "./MoorhenUIElement";
/**
 * `<moorhen-map-select>`: a dropdown of the maps loaded in Moorhen, kept up to date as maps are
 * loaded and deleted. For content placed inside `<moorhen-web-component>`.
 *
 * Values are map unique ids (`map.uniqueId`), as in the rest of the API.
 *
 * Attributes: `label` (default "Map"), `value` (starting selection, a unique id) and `disabled`
 * (without it, the dropdown is disabled only while there is no map).
 *
 * Properties: `value` — the selected map's unique id, `undefined` when no map is loaded;
 * `filter` — `(map) => boolean` to list only some maps (e.g. `map => map.isDifference`).
 *
 * Fires `change` (bubbling) when the user picks a map. With nothing selected the dropdown picks the
 * first map by itself; that updates `value` without an event, as a native `<select>` does.
 *
 * @example
 * <moorhen-map-select label="Map:"></moorhen-map-select>
 * select.addEventListener("change", () => console.log(select.value));
 */
export declare class MoorhenMapSelectElement extends MoorhenUIElement {
    static observedAttributes: string[];
    static upgradedProperties: string[];
    /** The selection made by the user, the component or a script; unset until then. */
    private _value;
    private _filter;
    protected attributeValueChanged(name: string): void;
    get value(): string | undefined;
    set value(value: string | null | undefined);
    get filter(): ((map: MoorhenMap) => boolean) | undefined;
    set filter(filter: ((map: MoorhenMap) => boolean) | undefined);
    protected renderComponent(): import("react/jsx-runtime").JSX.Element;
}
/** Attributes of `<moorhen-map-select>`, for declaring it in JSX. */
export interface MoorhenMapSelectElementAttributes extends React.HTMLAttributes<MoorhenMapSelectElement> {
    /** The id of the `<moorhen-web-component>` to work with, when the element is not inside it. */
    moorhen?: string;
    label?: string;
    /** Starting selection: a map unique id. */
    value?: string;
    disabled?: boolean;
}
//# sourceMappingURL=MoorhenMapSelectElement.d.ts.map