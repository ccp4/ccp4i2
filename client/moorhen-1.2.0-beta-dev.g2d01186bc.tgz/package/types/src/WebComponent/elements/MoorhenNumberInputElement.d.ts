import React from "react";
import { MoorhenUIElement } from "./MoorhenUIElement";
/**
 * `<moorhen-number-input>`: Moorhen's number field for content placed inside `<moorhen-web-component>`.
 * While it has focus, Moorhen's keyboard shortcuts are paused, so typing does not drive the viewer.
 *
 * Attributes: `value` (starting value), `min`, `max`, `label`, `label-position` ("left" | "top"),
 * `decimal-digits` (default 2), `width` (a CSS length), `step` (of the arrow buttons; by default one
 * unit of the last decimal), `tooltip`, and the booleans `integer`, `show-buttons`, `wait-return`
 * (the value only changes on Enter or when leaving the field) and `disabled`.
 *
 * Property: `value` — a number, or `null` when empty.
 *
 * Events, as for a native number input: `input` (bubbling) on each valid value while typing (on
 * Enter only with `wait-return`) and for each step of the arrow buttons; `change` (bubbling) once the
 * value is committed — Enter, focus leaving the field, or an arrow button released. Setting `value`
 * from a script fires neither.
 *
 * @example
 * <moorhen-number-input label="Radius" value="8" min="1" max="30" decimal-digits="1" show-buttons></moorhen-number-input>
 */
export declare class MoorhenNumberInputElement extends MoorhenUIElement {
    static observedAttributes: string[];
    static upgradedProperties: string[];
    /** Set once the user or a script changed it; until then the attribute decides. */
    private _value;
    /** The value last reported with `change`. */
    private _committed;
    constructor();
    get value(): number | null;
    set value(value: number | null);
    connectedCallback(): Promise<void>;
    protected attributeValueChanged(name: string): void;
    private commitIfChanged;
    protected renderComponent(): import("react/jsx-runtime").JSX.Element;
}
/** Attributes of `<moorhen-number-input>`, for declaring it in JSX. */
export interface MoorhenNumberInputElementAttributes extends React.HTMLAttributes<MoorhenNumberInputElement> {
    /** The id of the `<moorhen-web-component>` to work with, when the element is not inside it. */
    moorhen?: string;
    value?: number;
    min?: number;
    max?: number;
    label?: string;
    "label-position"?: "left" | "top";
    "decimal-digits"?: number;
    width?: string;
    /** Step of the arrow buttons. */
    step?: number;
    tooltip?: string;
    integer?: boolean;
    "show-buttons"?: boolean;
    "wait-return"?: boolean;
    disabled?: boolean;
}
//# sourceMappingURL=MoorhenNumberInputElement.d.ts.map