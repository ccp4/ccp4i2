import React from "react";
import type { MoorhenSVG } from "../../components/icons";
import { MoorhenUIElement } from "./MoorhenUIElement";
/**
 * `<moorhen-button>`: Moorhen's button for content placed inside `<moorhen-web-component>`.
 *
 * Attributes: `label`, `icon`, `type` ("default" | "icon-only" | "toggle"), `size`, `variant`,
 * `tooltip`, `tooltip-placement`, `disabled-tooltip`, `aria-label`, and the boolean `disabled` and
 * `checked` (for `type="toggle"`). Child content is shown inside the button, after the label.
 * Listen to the native `click` event; a disabled button does not fire it.
 *
 * @example
 * <moorhen-button icon="MatSymAdd" tooltip="Add a thing">Add</moorhen-button>
 */
export declare class MoorhenButtonElement extends MoorhenUIElement {
    static observedAttributes: string[];
    protected renderComponent(): import("react/jsx-runtime").JSX.Element;
}
/** Attributes of `<moorhen-button>`, for declaring it in JSX. */
export interface MoorhenButtonElementAttributes extends React.HTMLAttributes<MoorhenButtonElement> {
    /** The id of the `<moorhen-web-component>` to work with, when the element is not inside it. */
    moorhen?: string;
    label?: string;
    icon?: MoorhenSVG;
    type?: "default" | "icon-only" | "toggle";
    size?: "small" | "medium" | "large";
    variant?: "primary" | "secondary" | "danger" | "white" | "outlined" | "light" | "default";
    tooltip?: string;
    "tooltip-placement"?: "top" | "bottom" | "left" | "right";
    "disabled-tooltip"?: string;
    disabled?: boolean;
    checked?: boolean;
}
//# sourceMappingURL=MoorhenButtonElement.d.ts.map