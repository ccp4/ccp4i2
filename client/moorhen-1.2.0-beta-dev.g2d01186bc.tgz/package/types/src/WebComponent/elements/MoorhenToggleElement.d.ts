import React from "react";
import { MoorhenUIElement } from "./MoorhenUIElement";
/**
 * `<moorhen-toggle>`: Moorhen's switch / checkbox / radio for content placed inside `<moorhen-web-component>`.
 *
 * Attributes: `label` (otherwise the child content is the label), `type` ("switch" | "checkbox" | "radio"),
 * and the boolean `disabled` and `checked`. As for a native checkbox, the `checked` attribute is the
 * starting state and the `checked` property the current one: once the user or a script has changed
 * it, the attribute no longer applies.
 *
 * Fires `change` (bubbling) when the user flips it; not when a script sets `checked`.
 *
 * @example
 * <moorhen-toggle checked>Show hydrogens</moorhen-toggle>
 * toggle.addEventListener("change", () => console.log(toggle.checked));
 */
export declare class MoorhenToggleElement extends MoorhenUIElement {
    static observedAttributes: string[];
    static upgradedProperties: string[];
    /** Set once the user or a script changed it; until then the attribute decides. */
    private _checked;
    protected attributeValueChanged(name: string): void;
    get checked(): boolean;
    set checked(value: boolean);
    protected renderComponent(): import("react/jsx-runtime").JSX.Element;
}
/** Attributes of `<moorhen-toggle>`, for declaring it in JSX. */
export interface MoorhenToggleElementAttributes extends React.HTMLAttributes<MoorhenToggleElement> {
    /** The id of the `<moorhen-web-component>` to work with, when the element is not inside it. */
    moorhen?: string;
    label?: string;
    type?: "switch" | "checkbox" | "radio";
    disabled?: boolean;
    checked?: boolean;
}
//# sourceMappingURL=MoorhenToggleElement.d.ts.map