import type { MoorhenWebComponent } from "./MoorhenWebComponent";
/**
 * The `<moorhen-web-component>` an element of the page works with:
 *  1. the one whose id is given (the `moorhen` attribute of Moorhen's UI elements),
 *  2. else the one the element is in (slotted content), also across shadow roots,
 *  3. else the only one in the page.
 * `null` when there is none, or several and nothing says which.
 */
export declare const findMoorhenHost: (element: Element, id?: string | null) => MoorhenWebComponent | null;
/**
 * As {@link findMoorhenHost}, waiting for the page to be parsed when needed (an element placed before
 * its web component in the HTML), and for `<moorhen-web-component>` to be defined.
 */
export declare const waitForMoorhenHost: (element: Element, id?: string | null) => Promise<MoorhenWebComponent | null>;
//# sourceMappingURL=findMoorhenHost.d.ts.map