import type React from "react";
import type { MoorhenInstance } from "../../InstanceManager/MoorhenInstance";
import type { LocalStorageInstance } from "../../InstanceManager/Preferences/MoorhenPreferences";
import type { MoorhenWebComponent } from "../MoorhenWebComponent";
export type MoorhenProps = {
    id?: string;
    className?: string;
    style?: React.CSSProperties;
    /** Plugins, and content for Moorhen's slots. */
    children?: React.ReactNode;
    /** Fixed size; without it, Moorhen fills the box it is in. */
    width?: number | string;
    height?: number | string;
    /** Where the Moorhen assets are served from. Default "MoorhenAssets". */
    urlPrefix?: string;
    disableFileUploads?: boolean;
    viewOnly?: boolean;
    /** Start-up setting: read when Moorhen starts, changes later are ignored. */
    monomerLibraryPath?: string;
    /** Start-up setting: read when Moorhen starts, changes later are ignored. */
    allowScripting?: boolean;
    /** Start-up setting: where time capsule backups are kept, e.g. from `createCallbackBackupStorage`. */
    backupStorage?: LocalStorageInstance;
    /** Called once Moorhen is ready, with its instance. */
    onReady?: (instance: MoorhenInstance) => void;
};
/**
 * `<moorhen-web-component>` as a React component: Moorhen in your React app, running on its own React,
 * whatever your app's version.
 *
 * Call `registerMoorhenWebComponent()` from `moorhen/web-component` once, before rendering it. A `ref`
 * is the element; `onReady` gives the `MoorhenInstance`. Children are placed inside the element:
 * plugins, and content for Moorhen's slots.
 *
 * @example
 * registerMoorhenWebComponent();
 *
 * <Moorhen id="my-moorhen" width={1000} height={800} onReady={instance => setInstance(instance)}>
 *     <MyPlugin />
 * </Moorhen>
 */
export declare const Moorhen: React.ForwardRefExoticComponent<MoorhenProps & React.RefAttributes<MoorhenWebComponent>>;
//# sourceMappingURL=Moorhen.d.ts.map