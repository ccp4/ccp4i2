import type React from "react";
import type { MoorhenSVG } from "../../components/icons";
import type { MoorhenMap } from "../../utils/MoorhenMap";
import type { MoorhenMolecule } from "../../utils/MoorhenMolecule";
import type { MoorhenButtonElement, MoorhenChainSelectElement, MoorhenColourPickerElement, MoorhenInfoCardElement, MoorhenMapSelectElement, MoorhenMoleculeSelectElement, MoorhenNumberInputElement, MoorhenSliderElement, MoorhenToggleElement } from "../elements";
/** Callback of a wrapper's `onChange` / `onInput`: the new value, and the element. */
export type MoorhenValueHandler<T, E> = (value: T, element: E) => void;
export type MoorhenButtonProps = {
    label?: string;
    icon?: MoorhenSVG;
    type?: "default" | "icon-only" | "toggle";
    size?: "small" | "medium" | "large";
    variant?: "primary" | "secondary" | "danger" | "white" | "outlined" | "light" | "default";
    tooltip?: string;
    tooltipPlacement?: "top" | "bottom" | "left" | "right";
    disabledTooltip?: string;
    disabled?: boolean;
    checked?: boolean;
};
/** Moorhen's button. Use `onClick`. */
export declare const MoorhenButton: React.ForwardRefExoticComponent<MoorhenButtonProps & {
    /** The id of the `<moorhen-web-component>` to work with, when the component is not inside it. */
    moorhen?: string;
    id?: string;
    className?: string;
    style?: React.CSSProperties;
    slot?: string;
    title?: string;
    children?: React.ReactNode;
    onClick?: React.MouseEventHandler<HTMLElement>;
} & {
    [ariaOrData: `aria-${string}`]: string | number | boolean;
    [ariaOrData: `data-${string}`]: string | number | boolean;
} & React.RefAttributes<MoorhenButtonElement>>;
export type MoorhenToggleProps = {
    /** The label; otherwise the children. */
    label?: string;
    type?: "switch" | "checkbox" | "radio";
    disabled?: boolean;
    checked?: boolean;
    onChange?: MoorhenValueHandler<boolean, MoorhenToggleElement>;
};
/** Moorhen's switch, checkbox or radio. `onChange` receives `checked`. */
export declare const MoorhenToggle: React.ForwardRefExoticComponent<MoorhenToggleProps & {
    /** The id of the `<moorhen-web-component>` to work with, when the component is not inside it. */
    moorhen?: string;
    id?: string;
    className?: string;
    style?: React.CSSProperties;
    slot?: string;
    title?: string;
    children?: React.ReactNode;
    onClick?: React.MouseEventHandler<HTMLElement>;
} & {
    [ariaOrData: `aria-${string}`]: string | number | boolean;
    [ariaOrData: `data-${string}`]: string | number | boolean;
} & React.RefAttributes<MoorhenToggleElement>>;
export type MoorhenNumberInputProps = {
    value?: number | null;
    min?: number;
    max?: number;
    label?: string;
    labelPosition?: "left" | "top";
    decimalDigits?: number;
    width?: string;
    /** Step of the arrow buttons. */
    step?: number;
    tooltip?: string;
    integer?: boolean;
    showButtons?: boolean;
    /** The value only changes on Enter or when leaving the field. */
    waitReturn?: boolean;
    disabled?: boolean;
    /** Once committed: Enter, leaving the field, an arrow button released. */
    onChange?: MoorhenValueHandler<number | null, MoorhenNumberInputElement>;
    /** On each valid value while typing, and each arrow step. */
    onInput?: MoorhenValueHandler<number | null, MoorhenNumberInputElement>;
};
/** Moorhen's number field. */
export declare const MoorhenNumberInput: React.ForwardRefExoticComponent<MoorhenNumberInputProps & {
    /** The id of the `<moorhen-web-component>` to work with, when the component is not inside it. */
    moorhen?: string;
    id?: string;
    className?: string;
    style?: React.CSSProperties;
    slot?: string;
    title?: string;
    children?: React.ReactNode;
    onClick?: React.MouseEventHandler<HTMLElement>;
} & {
    [ariaOrData: `aria-${string}`]: string | number | boolean;
    [ariaOrData: `data-${string}`]: string | number | boolean;
} & React.RefAttributes<MoorhenNumberInputElement>>;
export type MoorhenSliderProps = {
    value?: number;
    /** The second thumb, with `type="range"`. */
    value2?: number;
    min?: number;
    max?: number;
    step?: number;
    type?: "default" | "range";
    scale?: "linear" | "log" | "asinh";
    label?: string;
    unit?: string;
    decimalPlaces?: number;
    colour?: string;
    disabled?: boolean;
    showTicks?: boolean;
    preciseInput?: boolean;
    hideButtons?: boolean;
    hideLabels?: boolean;
    hideValue?: boolean;
    labels?: {
        value: number;
        label: string;
        tick?: boolean;
        colour?: string;
    }[];
    allowedValues?: number[];
    /** Once the user lets go. For a range, read `element.value2` too. */
    onChange?: MoorhenValueHandler<number, MoorhenSliderElement>;
    /** While the user drags or steps. */
    onInput?: MoorhenValueHandler<number, MoorhenSliderElement>;
};
/** Moorhen's slider. */
export declare const MoorhenSlider: React.ForwardRefExoticComponent<MoorhenSliderProps & {
    /** The id of the `<moorhen-web-component>` to work with, when the component is not inside it. */
    moorhen?: string;
    id?: string;
    className?: string;
    style?: React.CSSProperties;
    slot?: string;
    title?: string;
    children?: React.ReactNode;
    onClick?: React.MouseEventHandler<HTMLElement>;
} & {
    [ariaOrData: `aria-${string}`]: string | number | boolean;
    [ariaOrData: `data-${string}`]: string | number | boolean;
} & React.RefAttributes<MoorhenSliderElement>>;
export type MoorhenColourPickerProps = {
    /** `#rrggbb`, or `#rrggbbaa` with `useAlpha`. */
    value?: string;
    label?: string;
    tooltip?: string;
    position?: "top" | "bottom" | "left" | "right";
    useAlpha?: boolean;
    /** The picker itself instead of a swatch opening it. */
    inline?: boolean;
    hideSwatches?: boolean;
    /** Once done: the picker closed. */
    onChange?: MoorhenValueHandler<string, MoorhenColourPickerElement>;
    /** While picking. */
    onInput?: MoorhenValueHandler<string, MoorhenColourPickerElement>;
};
/** Moorhen's colour picker. */
export declare const MoorhenColourPicker: React.ForwardRefExoticComponent<MoorhenColourPickerProps & {
    /** The id of the `<moorhen-web-component>` to work with, when the component is not inside it. */
    moorhen?: string;
    id?: string;
    className?: string;
    style?: React.CSSProperties;
    slot?: string;
    title?: string;
    children?: React.ReactNode;
    onClick?: React.MouseEventHandler<HTMLElement>;
} & {
    [ariaOrData: `aria-${string}`]: string | number | boolean;
    [ariaOrData: `data-${string}`]: string | number | boolean;
} & React.RefAttributes<MoorhenColourPickerElement>>;
export type MoorhenMoleculeSelectProps = {
    /** A molecule's unique id; `null` for "Any molecule". */
    value?: string | null;
    /** With `multiple`: the selected unique ids. */
    values?: string[];
    label?: string;
    allowAny?: boolean;
    /** Checkboxes for any number of molecules. */
    multiple?: boolean;
    disabled?: boolean;
    filter?: (molecule: MoorhenMolecule) => boolean;
    /** The unique id picked (`null` for "Any molecule"), or the list of them with `multiple`. */
    onChange?: MoorhenValueHandler<string | null | undefined | string[], MoorhenMoleculeSelectElement>;
};
/** Moorhen's molecule dropdown, or checkbox list with `multiple`. */
export declare const MoorhenMoleculeSelect: React.ForwardRefExoticComponent<MoorhenMoleculeSelectProps & {
    /** The id of the `<moorhen-web-component>` to work with, when the component is not inside it. */
    moorhen?: string;
    id?: string;
    className?: string;
    style?: React.CSSProperties;
    slot?: string;
    title?: string;
    children?: React.ReactNode;
    onClick?: React.MouseEventHandler<HTMLElement>;
} & {
    [ariaOrData: `aria-${string}`]: string | number | boolean;
    [ariaOrData: `data-${string}`]: string | number | boolean;
} & React.RefAttributes<MoorhenMoleculeSelectElement>>;
export type MoorhenChainSelectProps = {
    /** The id of a molecule select whose molecule is followed. */
    for?: string;
    /** The molecule's unique id (without `for`). */
    molecule?: string | null;
    /** A chain id; `null` for "All". */
    value?: string | null;
    /** With `multiple`: the selected chain ids. */
    values?: string[];
    label?: string;
    allowAll?: boolean;
    /** Checkboxes for any number of chains. */
    multiple?: boolean;
    disabled?: boolean;
    /** gemmi polymer types: 1 PeptideL, 2 PeptideD, 3 DNA, 4 RNA, 5 DNA/RNA hybrid. */
    allowedTypes?: number[];
    /** The chain picked (`null` for "All"), or the list of them with `multiple`. */
    onChange?: MoorhenValueHandler<string | null | undefined | string[], MoorhenChainSelectElement>;
};
/** Moorhen's chain dropdown, or checkbox list with `multiple`. */
export declare const MoorhenChainSelect: React.ForwardRefExoticComponent<MoorhenChainSelectProps & {
    /** The id of the `<moorhen-web-component>` to work with, when the component is not inside it. */
    moorhen?: string;
    id?: string;
    className?: string;
    style?: React.CSSProperties;
    slot?: string;
    title?: string;
    children?: React.ReactNode;
    onClick?: React.MouseEventHandler<HTMLElement>;
} & {
    [ariaOrData: `aria-${string}`]: string | number | boolean;
    [ariaOrData: `data-${string}`]: string | number | boolean;
} & React.RefAttributes<MoorhenChainSelectElement>>;
export type MoorhenMapSelectProps = {
    /** A map's unique id. */
    value?: string | null;
    label?: string;
    disabled?: boolean;
    filter?: (map: MoorhenMap) => boolean;
    onChange?: MoorhenValueHandler<string | undefined, MoorhenMapSelectElement>;
};
/** Moorhen's map dropdown. */
export declare const MoorhenMapSelect: React.ForwardRefExoticComponent<MoorhenMapSelectProps & {
    /** The id of the `<moorhen-web-component>` to work with, when the component is not inside it. */
    moorhen?: string;
    id?: string;
    className?: string;
    style?: React.CSSProperties;
    slot?: string;
    title?: string;
    children?: React.ReactNode;
    onClick?: React.MouseEventHandler<HTMLElement>;
} & {
    [ariaOrData: `aria-${string}`]: string | number | boolean;
    [ariaOrData: `data-${string}`]: string | number | boolean;
} & React.RefAttributes<MoorhenMapSelectElement>>;
export type MoorhenInfoCardProps = {
    /** Plain text; otherwise the children, which can be rich. */
    info?: string;
    placement?: "top" | "bottom" | "left" | "right";
    width?: string;
    large?: boolean;
};
/** Moorhen's info button, opening a card with help. */
export declare const MoorhenInfoCard: React.ForwardRefExoticComponent<MoorhenInfoCardProps & {
    /** The id of the `<moorhen-web-component>` to work with, when the component is not inside it. */
    moorhen?: string;
    id?: string;
    className?: string;
    style?: React.CSSProperties;
    slot?: string;
    title?: string;
    children?: React.ReactNode;
    onClick?: React.MouseEventHandler<HTMLElement>;
} & {
    [ariaOrData: `aria-${string}`]: string | number | boolean;
    [ariaOrData: `data-${string}`]: string | number | boolean;
} & React.RefAttributes<MoorhenInfoCardElement>>;
//# sourceMappingURL=elements.d.ts.map