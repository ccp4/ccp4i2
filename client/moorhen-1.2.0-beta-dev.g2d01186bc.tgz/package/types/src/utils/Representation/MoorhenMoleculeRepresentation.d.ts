import { libcootApi } from "../../types/libcoot";
import { moorhen } from "../../types/moorhen";
import { ColourRuleType } from "../MoorhenColourRule";
import type { BuildRepresentationParams, CreateRepresentationParams, RepresentationBackup } from "./RepresentationBuilder";
import { wormOptions } from "./wormRadii";
import { gemmiAtomPairsToCylindersInfo, gemmiAtomsToCirclesSpheresInfo } from "../utils";
import { ResidueSelectionRuleType } from "../../components/card/MoleculeCard/addRepresentation/components/ResidueSelectionSection";
import { CommandCentre } from "../../InstanceManager/CommandCentre";
import { type OwnerNumbering } from "../../WebGLgComponents/ownedMeshPick";
/**
 * The styles that actually put individual atoms on the screen, and so the only ones a per-atom
 * highlight such as the hover ball can sit on.
 */
export declare const ATOM_LEVEL_STYLES: string[];
export type MeshType = libcootApi.InstancedMeshJS | libcootApi.SimpleMeshJS | ReturnType<typeof gemmiAtomsToCirclesSpheresInfo> | ReturnType<typeof gemmiAtomPairsToCylindersInfo>;
export type PickableMesh = MeshType & {
    pick_info?: {};
};
export type RepresentationStyles = "VdwSpheres" | "ligands" | "CAs" | "CBs" | "CDs" | "gaussian" | "cavities" | "allHBonds" | "rama" | "rotamer" | "CRs" | "Worm" | "Tubes" | "MolecularSurface" | "DishyBases" | "VdWSurface" | "AccessibleSurface" | "Calpha" | "unitCell" | "hover" | "environment" | "ligand_environment" | "contact_dots" | "chemical_features" | "ligand_validation" | "glycoBlocks" | "restraints" | "residueSelection" | "MetaBalls" | "bloboids" | "adaptativeBonds" | "StickBases" | "residue_environment" | "transformation" | "NEFRestraints" | "RMSF";
/**
 * Represents a molecule representation
 * @property {string} style - The style of this molecule representation instance
 * @property {string} cid - The CID selection
 * @property {string} restrictToNeighbours - Whether or not to restrict to neighbourhood
 * @property {string} neighboursCid - The CID for additional selection for neighbourhood
 * @property {MoorhenMolecule} parentMolecule - The molecule assigned to this colour rule
 * @property {string} uniqueId - A unique identifier for this colour rule
 * @property {boolean} visible - Indicates whether the molecule representation is currently visible
 * @property {moorhen.ColourRule[]} colourRules - The list of colour rules associated to this molecule representation
 * @property {moorhen.CommandCentre} commandCentre - The command centre instance
 * @property {React.RefObject<webGL.MGWebGL>} glRef - A react reference to the MGWebGL instance
 * @constructor
 * @param {moorhen.RepresentationStyles} style - The style of this molecule representation instance
 * @param {string} cid - The CID selection for this colour rule
 * @param {moorhen.CommandCentre} commandCentre - The command centre instance
 * @param {React.RefObject<webGL.MGWebGL>} glRef - A react reference to the MGWebGL instance
 * @example
 * import { MoorhenMolecule, MoorhenColourRule } from 'moorhen';
 *
 * const example = async () => {
 *    const molecule = new MoorhenMolecule(commandCentre, glRef, monomerLibraryPath);
 *
 *    const representation = new MoorhenMoleculeRepresentation(style, cid, commandCentre, glRef)
 *    representation.setParentMolecule(molecule)
 *    await representation.draw()
 * }
 */
export type m2tParameters = {
    ribbonStyleCoilThickness: number;
    ribbonStyleHelixWidth: number;
    ribbonStyleStrandWidth: number;
    ribbonStyleArrowWidth: number;
    ribbonStyleDNARNAWidth: number;
    ribbonStyleAxialSampling: number;
    cylindersStyleAngularSampling: number;
    cylindersStyleCylinderRadius: number;
    cylindersStyleBallRadius: number;
    surfaceStyleProbeRadius: number;
    ballsStyleRadiusMultiplier: number;
    nucleotideRibbonStyle: "StickBases" | "DishyBases";
    dishStyleAngularSampling: number;
    ssUsageScheme: number;
};
export type residueEnvironmentOptions = {
    maxDist: number;
    adaptiveDist: number;
    backgroundRepresentation: RepresentationStyles;
    focusRepresentation: RepresentationStyles;
    labelled: boolean;
    showHBonds: boolean;
    showContacts: boolean;
    showNEF: boolean;
};
export type gaussianSurfSettings = {
    sigma: number;
    countourLevel: number;
    boxRadius: number;
    gridScale: number;
    bFactor: number;
};
export declare class MoleculeRepresentation {
    uniqueId: string;
    style: RepresentationStyles;
    cid: string;
    neighboursCid: string;
    /** The molecule neighboursCid is in (uniqueId), if not this one: a pocket around a docked ligand */
    neighboursMoleculeUid: string;
    restrictToNeighbours: boolean;
    neighboursDistance: number;
    hbondedToCid: string;
    hbondedTo: boolean;
    excludeNeighbours: boolean;
    buffers: any;
    commandCentre: CommandCentre;
    parentMolecule: moorhen.Molecule;
    styleHasAtomBuffers: boolean;
    styleHasColourRules: boolean;
    styleHasSymmetry: boolean;
    styleIsM2tRepresentation: boolean;
    styleIsCootBondRepresentation: boolean;
    styleIsCombinedRepresentation: boolean;
    visible: boolean;
    private _colourRules;
    private _useDefaultColourRules;
    isCustom: boolean;
    useDefaultBondOptions: boolean;
    useDefaultResidueEnvironmentOptions: boolean;
    useDefaultM2tParams: boolean;
    gaussianSurfaceSettings: gaussianSurfSettings;
    useDefaultGaussianSurfaceSettings: boolean;
    bondOptions: moorhen.cootBondOptions;
    m2tParams: m2tParameters;
    /** A "Worm"'s own options: where its radii come from, how finely it is drawn (see wormRadii.ts). */
    wormOptions: wormOptions;
    /** Whether a "Worm" is drawn with the general (default) worm options rather than its own. */
    useDefaultWormOptions: boolean;
    nonCustomOpacity: number;
    residueEnvironmentOptions: residueEnvironmentOptions;
    ligandsCid: string;
    hoverColor: number[];
    residueSelectionColor: number[];
    mergeBufferObjects: (bufferObj1: PickableMesh[], bufferObj2: PickableMesh[]) => PickableMesh[];
    interfaceOption: {
        visible: boolean;
        selectionType: ResidueSelectionRuleType;
    };
    /** Snapshot of the lossy build parameters (see BuildRepresentationParams). Null for legacy/deserialized reps. */
    buildParams: BuildRepresentationParams | null;
    cavities: {
        index: number;
        mesh: libcootApi.SimpleMeshJS[];
    } | null;
    constructor(style: RepresentationStyles, cid: string, commandCentre: CommandCentre);
    /**
     * Factory method to create (and add) a new representation on the given molecule
     * from a params object. Builds the CID selection and colour rule internally,
     * adds the representation to the molecule and returns it (or null if the
     * selection is invalid).
     */
    static create(params: Omit<CreateRepresentationParams, "existingRepresentation">): Promise<MoleculeRepresentation>;
    edit(params: Omit<CreateRepresentationParams, "molecule" | "existingRepresentation">): void;
    /**
     * Snapshot everything needed to rebuild this representation as plain, JSON-serialisable data
     * (no molecule or colour rule references). Pass it to MoleculeRepresentation.create() with a
     * molecule, or to the instance API's representation.create() with the molecule uid.
     */
    backup(): RepresentationBackup;
    /**
     * A method to set M2T style parameters for this molecule representation
     * @param {m2tParameters} m2tParams - The new M2T parameters
     */
    setM2tParams(m2tParams: m2tParameters): void;
    /**
     * Give a "Worm" its own options (any not given keep their defaults), e.g.
     * `{ radiusSource: "custom", residueRadii: [{ chainId: "A", resNo: 34, radius: 2.5 }] }`, in
     * angstroms; or, with none, draw it with the general ones. Takes effect on the next draw.
     */
    setWormOptions(options: Partial<wormOptions> | null | undefined): void;
    /** The worm options a "Worm" is drawn with: its own, or the general ones. */
    get drawnWormOptions(): wormOptions;
    /** Show one model of a multi-model molecule (0: all of them). The model is kept in the CID */
    setShownMultimodel(modelIndex: number): void;
    setBufferColour(r: number, g: number, b: number): void;
    /**
     * Undo a movie fade (DisplayBuffer.setAlphaMultiplier): back to the representation's own
     * opacity. A rebuilt representation starts unfaded; a kept one (scene switch) must too.
     */
    resetFade(): void;
    /**
     * A method to set alpha for molecular representation in case of colour not picked with colour picker
     */
    setNonCustomOpacity(nonCustomOpacity: number): void;
    /**
     * A method to set bond style options for this molecule representation
     * @param {moorhen.cootBondOptions} bondOptions - The new bond options
     */
    setBondOptions(bondOptions: moorhen.cootBondOptions): void;
    /**
     * A method to set gaussian surface settings for this molecule representation
     * @param {gaussianSurfSettings} settings - The new gaussian surface settings
     */
    setGaussianSurfaceSettings(settings: gaussianSurfSettings): void;
    /**
     * A method to set res. env. options for this molecule representation
     * @param {moorhen.residueEnvironmentOptions} newOptions - The new res. env. options
     */
    setResidueEnvOptions(newOptions: residueEnvironmentOptions): void;
    /**
     * A method to set the style attribute of this molecule representation instance
     * @param {moorhen.RepresentationStyles} style - The new representation style
     */
    setStyle(style: moorhen.RepresentationStyles): void;
    /**
     * The colour rules currently applied to this representation. Default
     * * representations resolve these dynamically from their parent molecule;
     * custom representations use their own rule list.
     */
    get colourRules(): moorhen.ColourRule[];
    /**
     * Set custom rules for this representation, or pass an empty value to use
     * the parent molecule's defaults.
     */
    set colourRules(colourRules: moorhen.ColourRule[] | null | undefined);
    /** Whether this representation resolves colours from its parent molecule. */
    get useDefaultColourRules(): boolean;
    set useDefaultColourRules(useDefaultColourRules: boolean);
    /**
     * A method to associate a new colour rule to this representation
     * @param {string} ruleType - The type of this colour rule instance
     * @param {string} cid - The CID selection for this colour rule
     * @param {string} color - The colour for this rule (hex format)
     * @property {any[]} args - A list of arguments passed to libcoot API
     * @param {boolean} [isMultiColourRule=false] - Indicates whether this colour rule consists of multiple colours assigned to different residues
     * @param {boolean} [applyColourToNonCarbonAtoms=false] - Indicates if the colour rule will also be applied to non carbon atoms
     * @property {string} [label=undefined] - Label displayed in the UI for this colour rule
     */
    addColourRule(ruleType: ColourRuleType, cid: string, color: string, isMultiColourRule?: boolean, applyColourToNonCarbonAtoms?: boolean, label?: string): void;
    /**
     * Whether a mesh Coot returned is an answer or a failure, saying so if it is the latter.
     *
     * simple_mesh_t carries a status: 1 if it was built, 0 if Coot caught an exception while
     * building it - in practice a bad_alloc on a mesh too large to fit. Before that flag was
     * honoured the two were indistinguishable, because a failed mesh arrives empty and an
     * empty mesh is a perfectly good answer for a selection that matched nothing. So nothing
     * appeared, nothing was said, and the only trace was one line of Coot's stdout among
     * hundreds.
     *
     * The message hedges on the cause deliberately: the catch that sets the flag is a
     * catch(...) and cannot know it was memory, however likely that is.
     *
     * No throttling needed - the snackbar slice drops an existing entry with the same tag
     * before pushing, so a representation that fails on every redraw replaces its own toast
     * rather than stacking them.
     */
    meshFailedToBuild(mesh: {
        status?: number;
    }): boolean;
    /**
     * Set the representation buffers
     * @param {moorhen.DisplayObject[]} buffers - The new buffers
     */
    setBuffers(buffers: moorhen.DisplayObject[]): void;
    /**
     * Set the atom information in the buffers of this representation
     * @param {moorhen.AtomInfo[]} atomBuffers - The atom info objects that will be added to the representation buffers
     */
    setAtomBuffers(atomBuffers: moorhen.AtomInfo[]): void;
    /**
     * The atoms this representation is willing to be asked about, from the atoms of its selection.
     *
     * A buffer's `atoms` array is what the pick loop's atom channel searches, so it is the list of
     * things the pointer can land on and the status box can name. It is filled from
     * `gemmiAtomsForCid(this.cid)`, which for "All Chains" is every atom in the molecule - and a
     * ribbon drawn over the whole chain therefore offered up its waters, which it does not draw.
     * Hovering a surface with a ribbon also displayed reported "Hoh 1044" while highlighting a
     * patch of protein: the water was never on screen, but the ribbon was holding it.
     *
     * Only the M2T styles that keep atom buffers at all - CRs, DishyBases, StickBases, Calpha -
     * and every one of those draws polymer and nothing else. The bond representations are
     * untouched, and must be: CBs and its relatives *do* draw waters, and picking one there is
     * the whole point.
     *
     * Waters only, deliberately. A ligand sitting under a ribbon is still offered, which is not
     * right either - but the set of residues M2T will actually ribbon is not written down
     * anywhere (the ribbon styles pass "//" and let M2T decide), so narrowing further would mean
     * inventing a polymer list and risking a nucleic acid or a modified residue losing its hover.
     * This removes what is certainly wrong without guessing at what is merely probably wrong.
     */
    private atomsThisStyleDraws;
    /**
     * Set the molecule associated with this representation
     * @param {moorhen.Molecule} molecule - The molecule associated to this representation
     */
    setParentMolecule(molecule: moorhen.Molecule): void;
    /**
     * Build the buffers for this representation
     * @param {moorhen.DisplayObject[]} objects - The display objects for this representation
     */
    buildBuffers(objects: PickableMesh[]): void;
    /**
     * Draw this molecule representation (typically for the first time)
     */
    draw(): Promise<void>;
    /**
     * Redraw this molecule representation (typically not the first time)
     */
    redraw(): Promise<void>;
    /**
     * Delete the current representation buffers
     */
    deleteBuffers(): void;
    /**
     * Make the representation visible
     * @param requestDraw - Ask for the scene to be redrawn (default). Pass false when showing many at
     * once and ask once at the end: each request is a store dispatch.
     */
    show(requestDraw?: boolean): Promise<void>;
    /**
     * Make the representation not visible
     * @param requestDraw - Ask for the scene to be redrawn (default). Pass false when hiding many at
     * once and ask once at the end: each request is a store dispatch.
     */
    hide(requestDraw?: boolean): void;
    /**
     * Use libcoot API to get the buffers for this molecule representation
     * @param {moorhen.RepresentationStyles} [style=undefined] - The style of the representation (MoorhenMoleculeRepresentation.style attribute will be used if left undefined)
     * @param {string} [cid=undefined] - The CID selection (MoorhenMoleculeRepresentation.cid attribute will be used if left undefined)
     * @returns {object[]} The buffer objects for this molecule representation
     */
    getBufferObjects(style?: moorhen.RepresentationStyles, cid?: string): Promise<PickableMesh[]>;
    /**
     * A static method that can be used to merge together arrays of buffer objects
     * @param {libcootApi.InstancedMeshJS[]} bufferObj1 - The first array to be merged
     * @param {libcootApi.InstancedMeshJS[]} bufferObj2 - The second array to be merged
     * @returns {libcootApi.InstancedMeshJS[]} A merged array with the buffer objects in the second and first array
     */
    static mergeBufferObjects(bufferObj1: PickableMesh[], bufferObj2: PickableMesh[]): PickableMesh[];
    /**
     * Get the buffers objects for a representation of style residue_environment
     * @param {string} cid - The CID selection for the representation
     * @returns {object[]} An array with the buffer objects for this representation
     */
    getResidueEnvironmentBuffers(cid: string): Promise<PickableMesh[]>;
    /**
     * Get the buffers objects for a representation of style adaptiveBonds
     * @param {string} cid - The CID selection for the representation
     * @param {moorhen.RepresentationStyles} [focusRepresentation="CBs"] - The representation style for the CID at focus
     * @param {moorhen.RepresentationStyles} [backgroundRepresentation="CAs"] - The representation style for the rest of the molecule
     * @returns {object[]} An array with the buffer objects for this representation
     */
    getAdaptativeBondBuffers(cid: string, focusRepresentation?: moorhen.RepresentationStyles, backgroundRepresentation?: moorhen.RepresentationStyles): Promise<PickableMesh[]>;
    /**
     * Get buffer objects for restraints mesh representation
     * @returns {object[]} An array with the buffer objects for this representation
    */
    getRestraintsMeshBuffers(): Promise<PickableMesh[]>;
    /**
     * Get buffer objects for residue environment representation
     * @param {string} cid - The CID selection for this representation
     * @returns {object[]} An array with the buffer objects for this representation
     */
    getEnvironmentBuffers(cid: string): Promise<PickableMesh[]>;
    getNEFBuffers(cid: string): Promise<PickableMesh[]>;
    /**
     * Get arguments passed to libcoot API for M2T representations
     * @param style - The style of this representation
     * @param cidSelection - The CID selection of this representation
     * @returns {object} An object with the style name and CID selection to be passed as arguments to libcoot API
     */
    getM2tArgs(style: string, cidSelection: string, restrictSelection?: string): {
        m2tStyle: string;
        m2tSelection: string;
    };
    /**
     * The secondary structure usage flag of this representation's M2T calls: 1 (DONT_USE, so all
     * coil) for a worm, otherwise the M2T parameters' (0 header, 2 calculated).
     */
    getM2tSsUsageScheme(): number;
    /**
     * The residue properties a "Worm" is drawn with, as the JSON Coot's set_residue_properties
     * takes (each residue's radius as a multiple of the coil thickness); null for other styles.
     */
    getWormResidueProperties(): string | null;
    /** The M2T integer parameters a "Worm" is drawn with in place of the M2T parameters'; null for other styles. */
    getWormM2tIntParameters(): Record<string, number> | null;
    /**
     * Apply M2T parameters using libcoot API. This needs to be called before getting M2T buffer objects
     */
    applyM2tParams(): Promise<void>;
    /**
     * Get buffer objects for nucleotide representation
     * @param {string} cidSelection - The CID selection for this representation
     * @returns {libcootApi.InstancedMeshJS[]} The buffer objects for this representation
     */
    getNucleotideRepresentationBuffers(cidSelection: string, numbering?: OwnerNumbering): Promise<PickableMesh[]>;
    /**
     * Get representation buffers for a M2T representation
     * @param style
     * @param cidSelection
     */
    getM2TRepresentationBuffers(style: string, cidSelection?: string, restrictSelection?: string): Promise<PickableMesh[]>;
    /**
     * Get arguments passed to libcoot API to obtain bond representations
     * @param {string} name - The name of the representation style
     * @returns {any[]} An array of arguments passed to libcoot API
     */
    /**
     * The bond arguments, in the order coot's get_bonds_mesh_instanced takes them:
     * mode, isDark, bondWidth, atomRadius, showAniso, showOrtep, showAnisoAsEmpty,
     * drawHydrogens, smoothness.
     *
     * Nine, not eight. This was annotated as an eight-tuple and cast to it, so the extra one
     * was invisible to the compiler - and a consumer that spread it into a function expecting
     * eight had every later argument arrive one place early, with no error anywhere. That is
     * what stopped bonds, spheres, CAs and ligands exporting as glTF.
     */
    getBondArgs(name: string): [string, boolean, number, number, boolean, boolean, boolean, boolean, number];
    /**
     * Get bond representation buffers for a particular CID selection
     * @param {string} name - The name of the representation style
     * @param {string} cid - The CID selection for this representation
     * @returns {libcootApi.InstancedMeshJS[]} The representation buffers
     */
    getCootSelectionBondBuffers(name: string, cid: null | string): Promise<PickableMesh[]>;
    /**
     * Draw molecule representations for the symmetry mates
     */
    drawSymmetry(): void;
    /**
     * The models drawn by the parent molecule's visible atom-level representations, so a highlight
     * lands only on atoms that are on screen. A representation restricted to "/2/*" contributes
     * model 2; one with a wildcard, empty or chain-first model field shows every model, and "*"
     * is returned.
     * @returns {string[]} Model numbers, or ["*"] for all models
     */
    getDisplayedModels(): string[];
    /**
     * Get representation buffers corresponding with the residue highlight representation
     * @param {string} selectionString - The CID selection
     * @param {number[]} colour - The colour for the highlight
     * @param {boolean} [isResidueRange=false] - Indicates whether the CID selection consists of a residue range (e.g. //A/1-10)
     * @returns {object[]} Representation buffers for the residue highlight
     */
    getResidueHighlightBuffers(selectionString: string, colour: number[], isResidueRange?: boolean): Promise<PickableMesh[]>;
    /**
     * Get representation buffers for the contact dots representation
     * @param {string} cid - The CID selection for this representation
     * @returns {libcootApi.InstancedMeshJS[]} The representation buffers
     */
    getCootContactDotsCidBuffers(cid: string): Promise<PickableMesh[]>;
    /**
     * Get representation buffers for lines between pairs of atoms
     * @param {moorhen.AtomInfo[]} gemmiAtomPairs - An array describing the atom pairs
     * @param {number[]} colour - The colour for the lines
     * @param {boolean} [labelled=false] - Indicates whether the representation should include labels with the distance between the atom pairs
     * @returns {libcootApi.InstancedMeshJS[]} The representation buffers
     */
    getGemmiAtomPairsBuffers(gemmiAtomPairs: [
        {
            x: number;
            y: number;
            z: number;
            serial: number | string;
        },
        {
            x: number;
            y: number;
            z: number;
            serial: number | string;
        }
    ][], colour: number[], labelled?: boolean, NEF?: any): PickableMesh[];
    /**
     * Get representation buffers for the bloboids representation: an ellipsoid for each chain,
     * showing where its atoms are (wasm_src/bloboids.hh), in the colours this representation's
     * colour rules give the chain - passed to Coot with the request, rather than set on the
     * molecule as for bonds (applyColourRules), as a blob is coloured whole.
     * @param {string} cid - The CID selection for this representation
     * @returns {libcootApi.SimpleMeshJS[]} The representation buffers
     */
    getBloboidsBuffers(cid: string): Promise<PickableMesh[]>;
    /**
     * Get representation buffers for the glycoblocks representation
     * @param {string} cid - The CID selection for this representation
     * @returns {libcootApi.InstancedMeshJS[]} The representation buffers
     */
    getGlycoBlockBuffers(cid: string): Promise<PickableMesh[]>;
    /**
     * Get representation buffers for the H-bonds representation
     * @param {string} cid - The CID selection for this representation
     * @param {boolean} [labelled=false] - Indicates whether the representation should include labels with the distance between the atom pairs
     * @returns {libcootApi.InstancedMeshJS[]} The representation buffers
     */
    getHBondBuffers(cid: string, labelled?: boolean): Promise<PickableMesh[]>;
    /**
     * Get representation buffers for the ligand validation representation
     * @param {string} cid - The CID selection for this representation
     * @returns {libcootApi.InstancedMeshJS[]} The representation buffers
     */
    getLigandValidationBuffers(cid: string): Promise<PickableMesh[]>;
    /**
     * Get representation buffers for the chem. feat. representation
     * @param {string} cid - The CID selection for this representation
     * @returns {libcootApi.InstancedMeshJS[]} The representation buffers
     */
    getCootChemicalFeaturesCidBuffers(cid: string): Promise<PickableMesh[]>;
    /**
     * Get representation buffers for the meta-balls representation
     * @param {string} cid - The CID selection for this representation
     * @returns {libcootApi.SimpleMeshJS[]} The representation buffers
     */
    getMetaBallBuffers(cid: string): Promise<PickableMesh[]>;
    /**
     * The same MetaBalls mesh made with WebGPU compute: Coot supplies the spheres, as it does for
     * DrawMoorhenMetaBalls, and the field, marching cubes and per-vertex pass run on the GPU.
     * Null when WebGPU is not available. See WebGPUComponents/metaballs.
     */
    getMetaBallBuffersOnGpu(cid: string): Promise<PickableMesh[] | null>;
    /**
     * Get representation buffers for the rama-balls representation
     * @param {string} cid - The CID selection for this representation
     * @returns {libcootApi.SimpleMeshJS[]} The representation buffers
     */
    getRamachandranBallBuffers(): Promise<PickableMesh[]>;
    /**
     * Get representation buffers for the gaussian surf. representation
     * @param {string} cid - The CID selection for this representation
     * @returns {libcootApi.InstancedMeshJS[]} The representation buffers
     */
    getCootGaussianSurfaceBuffers(): Promise<PickableMesh[]>;
    /**
     * Get representation buffers for the cavities surf. representation
     * @returns {libcootApi.InstancedMeshJS[]} The representation buffers
     */
    getCootCavities(): Promise<void>;
    getCootCavitiesBuffers(): Promise<any[]>;
    /**
     * Get representation buffers for the molecule-wide contact dots representation
     * @returns {libcootApi.InstancedMeshJS[]} The representation buffers
     */
    getCootContactDotsBuffers(): Promise<PickableMesh[]>;
    /**
     * Get representation buffers for the molecule-wide rotamer dodec. representation
     * @returns {libcootApi.InstancedMeshJS[]} The representation buffers
     */
    getRotamerDodecahedraBuffers(): Promise<PickableMesh[]>;
    /**
     * Get representation buffers for the unit cell representation
     * @returns {object[]} The representation buffers
     */
    getUnitCellRepresentationBuffers(): PickableMesh[];
    /**
     * Apply the colour rules associated with this molecule representation
     */
    applyColourRules(): Promise<void>;
    /**
     * Export the current representation as a Wavefront Obj file
     * @returns {ArrayBuffer} - The contents of the obj file
     */
    exportAsObj(): Promise<ArrayBuffer>;
    /**
     * Export the current representation as a gltf binary file or Wavefront Obj file
     * @returns {ArrayBuffer} - The contents of the gltf binary file
     */
    exportAsMeshFile(fileType: string): Promise<ArrayBuffer>;
}
//# sourceMappingURL=MoorhenMoleculeRepresentation.d.ts.map