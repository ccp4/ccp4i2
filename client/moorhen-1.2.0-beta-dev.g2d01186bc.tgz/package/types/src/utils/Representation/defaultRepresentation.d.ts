import type { MoorhenInstance } from "../../InstanceManager/MoorhenInstance";
import type { DefaultRepresentationStyle } from "../../store/sceneSettingsSlice";
import type { MoorhenMolecule } from "../MoorhenMolecule";
/**
 * Draw a molecule in a scene's default style (sceneSettings.defaultRepresentationStyle): when it
 * is loaded, and when a scene that has not seen it is shown.
 * @param deleteExisting - Remove the molecule's existing representations first (wizard styles).
 */
export declare const drawDefaultRepresentation: (instance: MoorhenInstance, moleculeUniqueId: string, style: DefaultRepresentationStyle, deleteExisting?: boolean) => Promise<void>;
/**
 * Draw a new ligand molecule as bonds, a custom representation as every loaded molecule's (listed and
 * edited in the interface: molecule card chips, ligand list styles). For a molecule not yet in the
 * store, which instance.representation.create cannot find; its atoms are fetched first if needed.
 */
export declare const drawLigandBonds: (molecule: MoorhenMolecule) => Promise<void>;
//# sourceMappingURL=defaultRepresentation.d.ts.map