/**
 * A movie, as a thing you can save and open again.
 *
 * cameraPath holds the part that varies with time - keyframes, segments, and the arithmetic that
 * gets from one to the next. This holds the whole artefact: that path, plus the settings that do
 * not vary, plus enough about itself to appear in a list.
 *
 * WHERE THE MODES COME FROM
 *
 * A keyframe holds quantities that can be interpolated: halfway between two light positions is a
 * light position. Modes cannot - halfway between shadows-on and shadows-off is nothing at all - so
 * they are set once for the whole movie, and the place they are set is the movie's scene: a scene
 * of its own (the movie scene, `MOVIE_SCENE_ID`), created as a copy of the scene shown when the
 * first keyframe is captured, edited like any other scene, and selected whenever the movie is
 * captured, played or exported. There is one movie at a time, so one movie scene. Shadows, SSAO, edge detection, depth blur and the representations the movie fades all
 * come from it, and it travels in the session a movie file embeds.
 */
import { Movie } from "./cameraPath";
import type { VideoQuality } from "./videoBitrate";
/** How the movie is rendered out. Nothing here changes what the scene looks like. */
export interface MovieOutputSettings {
    fps: number;
    /** The drawing buffer the movie is rendered at, independent of the window. */
    width: number;
    height: number;
    /**
     * How many bits the encoder is given, as one of the three presets shared with "Record a
     * video". Optional: a movie written before this existed simply gets the default, which is
     * what it was always encoded at.
     */
    quality?: VideoQuality;
}
export interface MovieDocument {
    /** For the file and for a list of movies; not required to be unique. */
    name: string;
    /** What varies with time. */
    path: Movie;
    output: MovieOutputSettings;
}
export declare const DEFAULT_OUTPUT: MovieOutputSettings;
export declare const emptyMovie: (name?: string) => MovieDocument;
/** How long the movie runs, in seconds. */
export declare const documentDuration: (document: MovieDocument) => number;
/** How many frames it will render to, at its own frame rate. */
export declare const documentFrameCount: (document: MovieDocument) => number;
/**
 * Whether the document is coherent enough to play, and what is wrong if not.
 *
 * Checked rather than assumed because a movie is edited a keyframe at a time, and the invariant
 * that there is exactly one segment per gap is easy to break halfway through an edit.
 */
export declare function movieProblems(document: MovieDocument): string[];
//# sourceMappingURL=movieDocument.d.ts.map