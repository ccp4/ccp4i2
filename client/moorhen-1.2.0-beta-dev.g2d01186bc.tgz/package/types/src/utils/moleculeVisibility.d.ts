import type { MoorhenMolecule } from "./MoorhenMolecule";
/**
 * Show or hide a whole molecule, as the eye button of its card does: its representations (those
 * shown in the interface), its environment and NEF restraints if they are on, and its entry in
 * `molecules.visibleMolecules`.
 */
export declare const setMoleculeVisible: (molecule: MoorhenMolecule, visible: boolean, requestDraw?: boolean) => void;
/**
 * Show or hide many molecules, as setMoleculeVisible does each, in a fixed number of store dispatches:
 * one for visibleMolecules and one redraw request, whatever the number of molecules. Showing or
 * hiding a thousand ligands one dispatch at a time (each running every selector and, in development,
 * walking the whole store) took seconds.
 * @param requestDraw - Ask for the redraw (default). Pass false to ask for it once yourself after
 * several calls, saving a dispatch per call.
 */
export declare const setMoleculeListVisible: (molecules: MoorhenMolecule[], visible: boolean, requestDraw?: boolean) => void;
//# sourceMappingURL=moleculeVisibility.d.ts.map