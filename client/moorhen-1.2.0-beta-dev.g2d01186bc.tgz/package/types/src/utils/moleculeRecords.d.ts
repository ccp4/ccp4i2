import type { Store } from "@reduxjs/toolkit";
import { type MoleculeRecord } from "../store/moleculesSlice";
/** Write the queued records now, in one dispatch */
export declare const flushMoleculeRecords: (store: Store) => void;
/**
 * Keep queued records back past the end of the tick (true), until released (false) or flushed. For a
 * task whose molecules are refreshed one tick each (a batch of ligands parsed one at a time), which
 * would otherwise write one record per dispatch. Pair them (try / finally): the last release writes.
 */
export declare const holdMoleculeRecords: (store: Store, hold: boolean) => void;
/**
 * Write a molecule record (or, with `null`, drop a pending write for a molecule being deleted), with
 * the others queued in the same tick.
 */
export declare const queueMoleculeRecord: (store: Store, uniqueId: string, record: MoleculeRecord | null) => void;
/** The record queued but not yet written, if any: what the store will hold once written. */
export declare const queuedMoleculeRecord: (store: Store, uniqueId: string) => MoleculeRecord | null | undefined;
//# sourceMappingURL=moleculeRecords.d.ts.map