import type { MoorhenInstance } from "../InstanceManager/MoorhenInstance";
/**
 * Where a monomer's dictionary is looked for:
 * - "default": the dictionaries loaded in the session (store `dictionaries`), then what Coot has of
 *   its own, else the monomer libraries and PDBe, in that order (fetchMonomerDictionary);
 * - "libcoot-api": only the loaded dictionaries and what Coot has of its own;
 * - one source only: the local monomer library, the remote one (GitHub), or PDBe.
 */
export type MonomerSource = "default" | "libcoot-api" | "local-monomer-library" | "remote-monomer-library" | "pdbe";
/**
 * Make a monomer in Coot (a new Coot molecule with the monomer's ideal coordinates, placed at
 * `position`), reading its dictionary from `source` if needed: what Get Monomer does, for the Get
 * Monomer menu and for fitting a ligand by its code. The caller makes a MoorhenMolecule of it, or
 * deletes it when done.
 * @param code - The monomer's code (three letters, or more)
 * @param options.fromMolNo - Whose dictionaries to prefer, and to read a fetched one for; every molecule by
 * default. A dictionary loaded for one molecule only is found whichever molecule that is.
 * @param options.position - Where to put it (Coot coordinates)
 * @returns Its Coot molecule number and, when the dictionary came with this call or from that molecule,
 * the dictionary text (to cache on the new molecule); null if no monomer could be made
 */
export declare const getMonomerMolecule: (instance: MoorhenInstance, code: string, options?: {
    source?: MonomerSource;
    fromMolNo?: number;
    position?: [number, number, number];
}) => Promise<{
    molNo: number;
    dictionary?: string;
} | null>;
//# sourceMappingURL=monomers.d.ts.map