import type { Overlay2DShape } from "../store/overlaysSlice";
/** Turn what is drawn next by `degrees` about the point (cx, cy). The caller saves and restores. */
export declare const rotateAbout: (ctx: CanvasRenderingContext2D, cx: number, cy: number, degrees?: number) => void;
/**
 * Draw one circle, polygon or line.
 *
 * Positions are fractions of the view; sizes are pixels, multiplied by `scale` as text is, so a
 * saved picture at a higher resolution shows the same thing.
 */
export declare const drawShape: (ctx: CanvasRenderingContext2D, shape: Overlay2DShape, width: number, height: number, scale: number, defaultColour: string) => void;
//# sourceMappingURL=overlay2DDraw.d.ts.map