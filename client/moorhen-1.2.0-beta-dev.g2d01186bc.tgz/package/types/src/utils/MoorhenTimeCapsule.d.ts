import { MoorhenReduxStoreType } from "../store";
import type { Overlay2DCircle, Overlay2DLine, Overlay2DPolygon, Overlay2DFracPath, Overlay2DImageSrcFrac, Overlay2DLatexSrcFrac, Overlay2DSvgPath, Overlay2DTextFrac } from "../store/overlaysSlice";
import { MoorhenVector } from "../store/vectorsSlice";
import { MoorhenAnnotation } from "../store/annotationsSlice";
import { type LoadedDictionary } from "../store/dictionariesSlice";
import { ThreeDObject } from "../store/threeDObjectsSlice";
import { moorhen } from "../types/moorhen";
import { m2tParameters, residueEnvironmentOptions } from "./Representation/MoorhenMoleculeRepresentation";
import type { wormOptions } from "./Representation/wormRadii";
import { MoorhenInstance } from "../InstanceManager";
import type { MapStyle } from "../store/mapContourSettingsSlice";
export interface backupKey {
    name?: string;
    label?: string;
    dateTime: string;
    type: string;
    serNo: string | number;
    molNames: string[];
    mapNames?: string[];
    mtzNames?: string[];
}
export type moleculeSessionData = {
    name: string;
    molNo: number;
    coordString: string;
    coordFormat: moorhen.coorFormats;
    representations: {
        /**
         * The representation's identity, so that it survives a reload.
         *
         * Absent in sessions written before the field existed; those keep the guid minted on
         * restore, which is what has always happened.
         */
        uniqueId: string;
        cid: string;
        style: moorhen.RepresentationStyles;
        isCustom: boolean;
        colourRules: moorhen.ColourRuleObject[];
        bondOptions: moorhen.cootBondOptions;
        m2tParams: m2tParameters;
        /** A "Worm"'s own options; absent for a worm with the general ones, other styles and sessions written before them. */
        wormOptions?: Partial<wormOptions> | null;
        nonCustomOpacity: number;
        resEnvOptions: residueEnvironmentOptions;
        neighboursCid: string;
        restrictToNeighbours: boolean;
        excludeNeighbours: boolean;
        hbondedToCid: string;
        hbondedTo: boolean;
        neighboursDistance: number;
        /** The molecule neighboursCid is in, if not this one (a pocket around a docked ligand); absent in older sessions */
        neighboursMoleculeUid?: string;
    }[];
    defaultBondOptions: moorhen.cootBondOptions;
    defaultM2tParams: m2tParameters;
    defaultResEnvOptions: residueEnvironmentOptions;
    defaultColourRules: moorhen.ColourRuleObject[];
    connectedToMaps: number[];
    ligandDicts: {
        [comp_id: string]: string;
    };
    symmetryOn: boolean;
    biomolOn: boolean;
    symmetryRadius: number;
    uniqueId: string;
    /** MoorhenMolecule.metadata; absent in sessions written before it existed */
    metadata?: Record<string, string>;
};
export type mapDataSession = {
    name: string;
    molNo: number;
    uniqueId: string;
    mapData: Uint8Array;
    reflectionData: Uint8Array;
    showOnLoad: boolean;
    contourLevel: number;
    radius: number;
    rgba: {
        mapColour: {
            r: number;
            g: number;
            b: number;
        };
        positiveDiffColour: {
            r: number;
            g: number;
            b: number;
        };
        negativeDiffColour: {
            r: number;
            g: number;
            b: number;
        };
        a: number;
    };
    style: MapStyle;
    isDifference: boolean;
    /** Made from a Gaussian Cube. Optional: sessions written before cubes were readable lack it. */
    isCube?: boolean;
    /**
     * Where its 2D slice was, whether or not drawn as one now (mapSlice.ts). Absent for a map that
     * never had one, and in sessions written before slices.
     */
    slice?: {
        origin: number[];
        orientation: number[];
        nodalLines?: boolean;
        contourSpacing?: string;
    } | null;
    selectedColumns: moorhen.selectedMtzColumns;
    hasReflectionData: boolean;
    associatedReflectionFileName: string;
};
export type viewDataSession = {
    origin: [number, number, number];
    backgroundColor: [number, number, number, number];
    ambientLight: [number, number, number, number];
    diffuseLight: [number, number, number, number];
    lightPosition: [number, number, number, number];
    specularLight: [number, number, number, number];
    specularPower: number;
    fogStart: number;
    fogEnd: number;
    zoom: number;
    doDrawClickedAtomLines: boolean;
    clipStart: number;
    clipEnd: number;
    /**
     * Distance from the eye to the view centre, the renderer's old `fogClipOffset`.
     *
     * Optional because sessions written before this field exists do not have it. `fogStart` and
     * `fogEnd` are measured from the eye, so without it they could only be read back against an
     * assumed 250 - which was right until the perspective eye-distance control made it movable.
     * See LEGACY_EYE_DISTANCE: 250 is not a guess for an older file, it is the only value for
     * which that file's fog numbers ever meant what they said.
     */
    eyeDistance?: number;
    quat4: any[];
    shadows: boolean;
    ssao: {
        enabled: boolean;
        radius: number;
        bias: number;
    };
    edgeDetection: {
        enabled: boolean;
        depthScale: number;
        normalScale: number;
        depthThreshold: number;
        normalThreshold: number;
    };
    doPerspectiveProjection: boolean;
    blur: {
        enabled: boolean;
        depth: number;
        radius: number;
    };
};
export type backupSession = {
    version: string;
    includesAdditionalMapData: boolean;
    moleculeData: moleculeSessionData[];
    mapData: mapDataSession[];
    viewData: viewDataSession;
    activeMapIndex: number;
    dataIsEmbedded: boolean;
    vectorData?: MoorhenVector[];
    annotationData?: MoorhenAnnotation[];
    overlay2dData?: Overlay2DSessionData;
    threeDObjectData?: ThreeDObject[];
    /**
     * The scenes and snapshots (JSON of a UserSceneState). The fields above describe the scene shown
     * when the session was saved; sessions saved without it load into the "General" scene.
     */
    sceneData?: string;
    /**
     * Every ligand dictionary read into Coot (store `dictionaries`), including those whose molecule has
     * since been deleted. Older sessions only have each molecule's own copy (moleculeData[].ligandDicts).
     */
    dictionaries?: LoadedDictionary[];
};
export type Overlay2DSessionData = {
    fracPath2D: Overlay2DFracPath[];
    svgPath2D: Overlay2DSvgPath[];
    textFracPath2D: Overlay2DTextFrac[];
    /** Only in sessions saved before LaTeX became text with `latex` set; no longer written. */
    latexFracPath2D?: Overlay2DLatexSrcFrac[];
    imageFracPath2D: Overlay2DImageSrcFrac[];
    circle2D?: Overlay2DCircle[];
    polygon2D?: Overlay2DPolygon[];
    line2D?: Overlay2DLine[];
};
export type Moorhen3DObjectSessionData = {
    objects: ThreeDObject[];
};
/**
 * Represents a time capsule with session backups
 * @constructor
 * @param {React.RefObject<moorhen.Molecule[]>} moleculesRef - A react reference to the list of loaded molecules
 * @param {React.RefObject<moorhen.Map[]>} mapsRef - A react reference to the list of loaded maps
 * @param {React.RefObject<moorhen.Map>} activeMapRef - A react reference to the currently active map
 * @param {React.RefObject<webGL.MGWebGL>} glRef - A react reference to the molecular graphics renderer
 * @param {Store} store - The Redux store
 * @property {string} version - Version number of the current time capsule
 * @property {boolean} busy - Indicates if time capsule is busy loading from local storage
 * @property {boolean} disableBackups - Disable time capsule
 * @property {number} maxBackupCount - Maximum number of automatic backups to store in local storage
 * @property {number} modificationCountBackupThreshold - Number of modifications to trigger an automatic backup
 * @property {function} onIsBusyChange - Callback function called whenever there's a change in the `this.busy` state
 */
export declare class MoorhenTimeCapsule {
    moleculesRef: React.RefObject<moorhen.Molecule[]>;
    mapsRef: React.RefObject<moorhen.Map[]>;
    activeMapRef: React.RefObject<moorhen.Map | null>;
    busy: boolean;
    modificationCount: number;
    modificationCountBackupThreshold: number;
    maxBackupCount: number;
    version: string;
    disableBackups: boolean;
    storageInstance: LocalForage;
    store: MoorhenReduxStoreType;
    onIsBusyChange: (arg0: boolean) => void;
    /** Provides the scenes to save in sessions (set by MoorhenInstance) */
    getSceneData: (() => string) | null;
    /** Status returned by the session loaders for a session saved by a more recent version of Moorhen */
    static readonly NEWER_VERSION_STATUS = -2;
    static readonly NEWER_VERSION_MESSAGE = "This session file is for a more recent version of Moorhen, open it at moorhen.org";
    /** A session cannot be loaded while a movie plays or is exported: loading replaces what it shows */
    static readonly MOVIE_PLAYING_STATUS = -3;
    static readonly MOVIE_PLAYING_MESSAGE = "A movie is playing: stop it before loading a session";
    /**
     * Session versions older than the current one that can still be loaded. Add the outgoing
     * version here when bumping `this.version`, and drop any version whose format can no longer
     * be read.
     */
    static readonly supportedLegacyVersions: string[];
    constructor(moleculesRef: React.RefObject<moorhen.Molecule[]>, mapsRef: React.RefObject<moorhen.Map[]>, activeMapRef: React.RefObject<moorhen.Map>, store: MoorhenReduxStoreType);
    /**
     * Intiate the time capsule
     * @returns {Promise<void>}
     */
    init(): Promise<void>;
    /**
     * Toggles the time capsule disabled state
     */
    toggleDisableBackups(): void;
    /**
     * Sets instance attr. this.busy and calls this.onIsBusyChange()
     * @param {boolea} newValue - The new value for the busy attr.
     */
    setBusy(newValue: boolean): void;
    /**
     * Check if the current version is compatible with that stored in local storage
     */
    checkVersion(): Promise<void>;
    /**
     * Update metadata files currently stored in the local storage. It might be required to call this function before
     * using MoorhenTimeCapsule.fetchSession
     * @returns {Promise<string[]>} Backup keys for the new metadata files that were created if any
     */
    updateDataFiles(): Promise<(string | void)[]>;
    /**
     * Fetch a backup session
     * @param {boolean} [includeAdditionalMapData=true] - True if map data should be fetched and included in the resulting session
     * @returns {Promise<backupSession>} A backup for the current session
     */
    fetchSession(includeAdditionalMapData?: boolean, embedData?: boolean): Promise<backupSession>;
    /**
     * Add a modification to the modification counter and create a backup if the modification count has reached
     * the modification threshold
     * @returns {Promise<string>} Backup key if a backup was created
     */
    addModification(): Promise<string>;
    /**
     * Remove the oldest automatic backup if the number of backups in the local storage has reached the threshold
     */
    cleanupIfFull(): Promise<void>;
    /**
     * Remove orphan metadata files with no backup session associated
     */
    cleanupUnusedDataFiles(): Promise<void>;
    /**
     * Create a session backup
     * @param {string} key - Backup key
     * @param {string} value - JSON structure with session data
     * @returns {string} Backup key
     */
    createBackup(key: string, value: string): Promise<string>;
    /**
     * Retrieve a session backup
     * @param {string} key - Backup key
     */
    retrieveBackup(key: string): Promise<string | ArrayBuffer>;
    /**
     * Retrieve the latest backup stored in local storage
     * @returns {string} JSON structure with session data
     */
    retrieveLastBackup(): Promise<string | ArrayBuffer>;
    /**
     * Remove a specific backup
     * @param {string} key - Backup key
     */
    removeBackup(key: string): Promise<void>;
    /**
     * Remove all backups
     */
    dropAllBackups(): Promise<void>;
    /**
     * Get backup keys sorted by date
     * @returns {backupKey[]} A list of backup keys
     */
    getSortedKeys(): Promise<backupKey[]>;
    /**
     * A static function that can be used to get the backup label for a given key object
     * @param {backupKey} key - An object with the backup key data
     * @returns {string} A string corresponding with the backup label
     */
    static getBackupLabel(key: backupKey): string;
    /**
     * A static function that can be used to load a session data object
     * @param {backupSession} sessionData - An object containing session data
     * @param {string} monomerLibraryPath - Path to the monomer library
     * @param {moorhen.Molecule[]} molecules - State containing current molecules loaded in the session
     * @param {moorhen.Map[]} maps - State containing current maps loaded in the session
     * @param {React.RefObject<moorhen.CommandCentre>} commandCentre - React reference to the command centre
     * @param {React.RefObject<moorhen.TimeCapsule>} timeCapsuleRef - React reference to the time capsule
     * @param {React.RefObject<webGL.MGWebGL>} glRef - React reference to the webGL renderer
     * @param {Store} store - The Redux store
     * @param {Dispatch<AnyAction>} dispatch - Dispatch method for the MoorhenReduxStore
     * @param {Promise<string>} fetchExternalUrl - Function to fetch external file URL for non embedded data
     * @returns {number} Returns -1 if there was an error loading the session otherwise 0
     */
    static loadSessionData(sessionData: backupSession, moorhenInstance: MoorhenInstance, fetchExternalUrl?: (uniqueId: string) => Promise<string>): Promise<number>;
    /** The session restore proper, once loadSessionData has checked the session can be loaded */
    private static restoreSessionData;
    /**
     * A static function that can be used to load a session from an array buffer
     * @param {ArrayBuffer} sessionArrayBuffer - An object containing session data
     * @param {string} monomerLibraryPath - Path to the monomer library
     * @param {moorhen.Molecule[]} molecules - State containing current molecules loaded in the session
     * @param {moorhen.Map[]} maps - State containing current maps loaded in the session
     * @param {React.RefObject<moorhen.CommandCentre>} commandCentre - React reference to the command centre
     * @param {React.RefObject<moorhen.TimeCapsule>} timeCapsuleRef - React reference to the time capsule
     * @param {React.RefObject<webGL.MGWebGL>} glRef - React reference to the webGL renderer
     * @param {Store} store - The Redux store
     * @param {Dispatch<AnyAction>} dispatch - Dispatch method for the MoorhenReduxStore
     * @returns {number} Returns 0 on success, -1 if there was an error loading the session, or
     * NEWER_VERSION_STATUS if the session is from a more recent Moorhen
     */
    static loadSessionFromArrayBuffer(sessionArrayBuffer: ArrayBuffer, moorhenInstance: MoorhenInstance): Promise<number>;
    /**
     * A static function that can be used to load a session from a protobuf message
     * @param {string} sessionProtoMessage - A protobuf message for the object containing session data
     * @param {string} monomerLibraryPath - Path to the monomer library
     * @param {moorhen.Molecule[]} molecules - State containing current molecules loaded in the session
     * @param {moorhen.Map[]} maps - State containing current maps loaded in the session
     * @param {React.RefObject<moorhen.CommandCentre>} commandCentre - React reference to the command centre
     * @param {React.RefObject<moorhen.TimeCapsule>} timeCapsuleRef - React reference to the time capsule
     * @param {React.RefObject<webGL.MGWebGL>} glRef - React reference to the webGL renderer
     * @param {Store} store - The Redux store
     * @param {Dispatch<AnyAction>} dispatch - Dispatch method for the MoorhenReduxStore
     * @returns {number} Returns -1 if there was an error loading the session otherwise 0
     */
    static loadSessionFromProtoMessage(sessionProtoMessage: any, moorhenInstance: MoorhenInstance): Promise<number>;
    /**
     * A static function that can be used to load a session from a JSON string representation of a session data object
     * @param {string} sessionDataString - A JSON string representation of the object containing session data
     * @param {string} monomerLibraryPath - Path to the monomer library
     * @param {moorhen.Molecule[]} molecules - State containing current molecules loaded in the session
     * @param {moorhen.Map[]} maps - State containing current maps loaded in the session
     * @param {React.RefObject<moorhen.CommandCentre>} commandCentre - React reference to the command centre
     * @param {React.RefObject<moorhen.TimeCapsule>} timeCapsuleRef - React reference to the time capsule
     * @param {React.RefObject<webGL.MGWebGL>} glRef - React reference to the webGL renderer
     * @param {Store} store - The Redux store
     * @param {Dispatch<AnyAction>} dispatch - Dispatch method for the MoorhenReduxStore
     * @returns {number} Returns -1 if there was an error loading the session otherwise 0
     */
    static loadSessionFromJsonString(sessionDataString: string, moorhenInstance: MoorhenInstance): Promise<number>;
}
//# sourceMappingURL=MoorhenTimeCapsule.d.ts.map