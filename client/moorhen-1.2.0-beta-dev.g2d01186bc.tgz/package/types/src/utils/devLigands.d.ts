import type { MoorhenInstance } from "../InstanceManager/MoorhenInstance";
/**
 * Load `count` random ligands from the pool through files.batchLoadLigands, spread over three sites
 * 25 Å apart around the centre of the view (a few Å of jitter within a site), so grouping by
 * position has something to group.
 */
export declare const devLoadLibraryLigands: (instance: MoorhenInstance, count?: number) => Promise<import("./BatchLigandLoading").BatchLoadLigandsResult>;
/**
 * Dev tool: the contacts (utils/ligandContacts) of every ligand-only molecule with every other
 * molecule, logged to the console. Pairs without contacts are left out. Returns the number of pairs
 * logged.
 */
export declare const devLogLigandContacts: (instance: MoorhenInstance, withFlev?: boolean) => Promise<number>;
//# sourceMappingURL=devLigands.d.ts.map