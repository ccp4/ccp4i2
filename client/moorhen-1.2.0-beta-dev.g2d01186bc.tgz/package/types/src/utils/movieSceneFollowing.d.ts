/**
 * Wiring a movie to the parts of the scene that follow the view centre.
 *
 * originFollowing.ts says *what* has to be brought up to date and takes an origin to do it at.
 * This is the small amount of looking-things-up that stands between it and a renderer: which maps
 * are visible, which molecules exist, and how far the camera may travel before any of it matters.
 */
import type { OriginFollowingScene } from "./originFollowing";
import type { webGL } from "../types/mgWebGL";
/**
 * How far the camera may travel before the scene is told, for this scene as it stands now.
 *
 * Measured from the smallest visible contoured sphere, because that is the first one to stop
 * covering the view. A map with a locked origin is left out: it does not follow the centre, so it
 * has no opinion about how far the centre may go.
 */
export declare const echoDistanceFor: (gl: webGL.MGWebGL) => number;
/**
 * The scene an export drives directly, read from the store each time it is asked for.
 *
 * Read afresh rather than captured once because a movie is long enough for the scene to change
 * underneath it - a map hidden, a molecule deleted - and a stale list would contour a map that is
 * no longer drawn, or miss one that now is.
 */
export declare const sceneFollowingOrigin: (gl: webGL.MGWebGL) => (() => OriginFollowingScene | null);
//# sourceMappingURL=movieSceneFollowing.d.ts.map