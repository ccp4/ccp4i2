/**
 * Geometry of 2D overlay objects on the view: where they are, what is under the pointer, and how
 * dragging a handle changes them.
 *
 * Everything here is pure arithmetic in screen (CSS) pixels with y pointing down, so that the
 * handles, the picking and the tests all agree without a canvas.
 *
 * An object is described by a Frame: its stored position (the anchor) in pixels, a box about the
 * anchor before rotation, the point it turns about (the pivot), and the turn. A positive turn is
 * clockwise on screen, as the canvas's own rotate() is.
 */
import type { Overlay2DCircle, Overlay2DLine, Overlay2DObject, Overlay2DPolygon, Overlay2DTextFrac } from "../store/overlaysSlice";
export type Vec2 = [number, number];
export type Box = [number, number, number, number];
/** The view's size in CSS pixels. Positions stored as fractions are of this. */
export interface ViewSize {
    width: number;
    height: number;
}
export interface Frame {
    /** The stored position, in pixels: a text baseline's start, an image's top left, a shape's centre. */
    anchor: Vec2;
    /** minX, minY, maxX, maxY about the anchor, before rotation. */
    box: Box;
    /** What it turns about, relative to the anchor. */
    pivot: Vec2;
    /** Radians, clockwise. */
    rotation: number;
}
/** How far the selection box sits outside the object, in pixels. */
export declare const BOX_PADDING = 6;
/** How far above the selection box the rotate knob sits. */
export declare const ROTATE_KNOB_DISTANCE = 22;
/** Smallest radius, size or font a drag may shrink something to, in pixels. */
export declare const MIN_SIZE = 3;
export declare const boxOfPoints: (points: Vec2[]) => Box;
export declare const boxCentre: (box: Box) => Vec2;
/** Flat x, y pairs as points. */
export declare const pairsOf: (flat: number[]) => Vec2[];
export declare const localToScreen: (frame: Frame, local: Vec2) => Vec2;
export declare const screenToLocal: (frame: Frame, point: Vec2) => Vec2;
/** The pivot on screen. */
export declare const pivotOnScreen: (frame: Frame) => Vec2;
/**
 * A plain text's box about the start of its baseline, from canvas metrics: from what overhangs to
 * the left to the further of the advance and what overhangs to the right, and from the ascent to
 * the descent.
 */
export declare const textBoxFromMetrics: (m: Pick<TextMetrics, "width" | "actualBoundingBoxLeft" | "actualBoundingBoxRight" | "actualBoundingBoxAscent" | "actualBoundingBoxDescent">) => Box;
/**
 * A text's box about the start of its baseline, before rotation: what the handles draw round and
 * what it turns about. Plain text is measured; LaTeX comes from the typeset image.
 */
export type TextBoxOf = (text: Overlay2DTextFrac) => Box | null;
/**
 * The frame of an object, or null for one the handles place another way (an SVG path, whose
 * extent only the browser can work out) or that cannot be measured yet.
 */
export declare const frameOf: (obj: Overlay2DObject, view: ViewSize, textBox: TextBoxOf) => Frame | null;
/** The selection box's corners on screen, padded, in order top-left, top-right, bottom-right, bottom-left. */
export declare const boxCorners: (frame: Frame, padding?: number) => Vec2[];
/** Where the rotate knob sits on screen, and the top of its stalk. */
export declare const rotateKnob: (frame: Frame, padding?: number) => {
    knob: Vec2;
    stalk: Vec2;
};
/** The pointer's direction from the pivot, in radians: the handle turns the object by its change. */
export declare const angleFromPivot: (frame: Frame, point: Vec2) => number;
/**
 * The turn for a rotate drag, in degrees and in (-180, 180]. With `snap`, to the nearest 15.
 */
export declare const rotationForDrag: (startDegrees: number, frame: Frame, from: Vec2, to: Vec2, snap?: boolean) => number;
/**
 * How much a corner drag scales by: the pointer's progress along the line from the fixed corner
 * through where the drag began. Measured along that line rather than by distance, so moving across
 * it does nothing rather than something odd.
 */
export declare const scaleForDrag: (fixed: Vec2, from: Vec2, to: Vec2) => number;
/** Changes, in store units, that move an object by `delta` pixels. */
export declare const moveChanges: (obj: Overlay2DObject, delta: Vec2, view: ViewSize) => Record<string, unknown>;
/**
 * Changes that scale an object uniformly by `s` about the fixed screen point.
 *
 * Every frame here turns about a pivot that scales with the object, so the anchor simply scales
 * about the fixed point as any other point of the object does.
 */
export declare const scaleChanges: (obj: Overlay2DObject, frame: Frame, fixed: Vec2, s: number, view: ViewSize) => Record<string, unknown>;
/** Changes that put one corner of a polygon under the pointer. */
export declare const vertexChanges: (polygon: Overlay2DPolygon, frame: Frame, index: number, point: Vec2, view: ViewSize) => {
    points: number[];
    x: number;
    y: number;
};
/** Whether a polygon is a rectangle (four corners, all square), and so has edge handles. */
export declare const isRectangle: (flat: number[]) => boolean;
/** The middle of each edge of a rectangle (edge i runs from corner i to corner i + 1), on screen. */
export declare const rectangleEdgeHandles: (polygon: Overlay2DPolygon, frame: Frame) => Vec2[];
/**
 * Changes that move one edge of a rectangle to the pointer, square to itself, so it stays a
 * rectangle. The edge cannot be pulled through the one opposite.
 */
export declare const rectangleEdgeChanges: (polygon: Overlay2DPolygon, frame: Frame, edge: number, point: Vec2, view: ViewSize) => {
    points: number[];
    x: number;
    y: number;
};
/** The four stretch handles of a circle or ellipse, on screen: right, bottom, left, top. */
export declare const ellipseEdgeHandles: (circle: Overlay2DCircle, frame: Frame) => Vec2[];
/** Changes for dragging stretch handle `which` (as ellipseEdgeHandles) to the pointer; both sides move. */
export declare const ellipseEdgeChanges: (frame: Frame, which: number, point: Vec2) => {
    radiusX: number;
    radiusY?: undefined;
} | {
    radiusY: number;
    radiusX?: undefined;
};
/** A line's ends on screen. */
export declare const lineEnds: (line: Overlay2DLine, view: ViewSize) => [Vec2, Vec2];
/** Changes that put one end of a line (0 start, 1 end) under the pointer. */
export declare const lineEndChanges: (end: 0 | 1, point: Vec2, view: ViewSize) => {
    x1: number;
    y1: number;
    x2?: undefined;
    y2?: undefined;
} | {
    x2: number;
    y2: number;
    x1?: undefined;
    y1?: undefined;
};
/** How long an arrow head is for a line of this width, in pixels. */
export declare const arrowHeadLength: (lineWidth: number) => number;
/**
 * An arrow head at `tip`, pointing away from `from`: its three corners, tip first. The line itself
 * should stop at the head's base (the second value), or its square end shows past the point.
 */
export declare const arrowHead: (tip: Vec2, from: Vec2, lineWidth: number) => {
    corners: Vec2[];
    base: Vec2;
};
/**
 * Whether the pointer is on an object. Generous by `tolerance` pixels, so that thin lines and
 * outlines can be clicked. SVG paths are not answered here: only the browser can test those (see
 * the handles layer).
 */
export declare const hitsObject: (obj: Overlay2DObject, frame: Frame | null, point: Vec2, view: ViewSize, tolerance?: number) => boolean;
/**
 * The objects in the order a click should try them: the topmost first.
 *
 * The reverse of how drawOn2DContext paints them: by depth (zIndex) and, within a depth, text,
 * SVG paths, images, fractional paths and then shapes, each in list order.
 */
export declare const pickOrder: (lists: {
    textOverlayList: Overlay2DObject[];
    svgPathOverlayList: Overlay2DObject[];
    imageOverlayList: Overlay2DObject[];
    fracPathOverlayList: Overlay2DObject[];
    shapeOverlayList: Overlay2DObject[];
}) => Overlay2DObject[];
//# sourceMappingURL=overlay2DGeometry.d.ts.map