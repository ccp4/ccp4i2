/**
 * Loading a Gaussian Cube as one or more maps.
 *
 * The cube is parsed, each of its fields is written out as an MRC buffer and handed to the same
 * Coot entry point an ordinary map file uses. From there on it *is* a map: Coot contours it, the
 * existing draw settings apply, and a signed field is flagged as a difference map so the positive
 * and negative lobes come out as one object in two colours - which is what an orbital wants and
 * what Moorhen already knows how to draw.
 *
 * A multi-field cube becomes several maps, which is why this returns a list.
 */
import { MoorhenMap } from "./MoorhenMap";
import type { MoorhenInstance } from "../InstanceManager";
/** The extensions this reader claims. */
export declare const CUBE_EXTENSIONS: readonly [".cube", ".cub"];
/** Whether a file name is one this reader should take. Case-insensitive; writers vary. */
export declare const isCubeFileName: (name: string) => boolean;
/**
 * Read a cube file and load every field in it into Coot as a map.
 *
 * @returns one map per field, in the order the file lists them.
 */
export declare function loadCubeFile(file: File, moorhenInstance: MoorhenInstance): Promise<MoorhenMap[]>;
/**
 * A contour level for a file that suggests none.
 *
 * Two sigma, which is the sort of level a person would reach for by hand, and far better than a
 * constant: the useful level for an orbital depends on how diffuse it is, and these fields range
 * over orders of magnitude between one basis set and another.
 */
export declare const defaultLevelFor: (values: Float32Array) => number;
//# sourceMappingURL=loadCubeFile.d.ts.map