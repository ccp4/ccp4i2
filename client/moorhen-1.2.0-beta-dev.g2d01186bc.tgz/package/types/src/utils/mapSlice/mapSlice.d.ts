/**
 * A 2D contour slice through a map: a square in a plane, with the map's contour lines across it.
 *
 * The slice is placed like a 3D object - an origin (its centre) and an orientation, a column-major
 * 4x4 whose first two columns are the square's sides and third its normal - so the same handles
 * move and turn it (gizmoDraw.ts, DragHandles.tsx). A new one faces down z (identity).
 *
 * Contoured from the map's whole unit cell (get_map_unit_cell_grid) sampled smoothly
 * (mapGridSampler.ts), adaptively (sliceContour.ts). Nothing here is particular to orbitals: a
 * difference map, which is how an orbital is loaded, gets positive and negative contours in its
 * two colours; any other map gets positive ones in its own colour.
 */
import { type SliceContours } from "./sliceContour";
import type { MapGridSampler } from "./mapGridSampler";
export interface MapSlicePlacement {
    /** The centre of the square (angstroms). */
    origin: [number, number, number];
    /** Column-major 4x4: columns 0 and 1 run along the square, column 2 is its normal. */
    orientation: number[];
}
export declare const IDENTITY_ORIENTATION: number[];
/** A new slice: through `origin`, facing down z. */
export declare const newMapSlice: (origin: [number, number, number]) => MapSlicePlacement;
/** The square's two in-plane directions and its normal, unit length. */
export declare function sliceAxes(orientation: number[]): {
    u: number[];
    v: number[];
    normal: number[];
};
/**
 * Half the slice's width: the map's radius, as the map is contoured in 3D (MoorhenMapManager), so
 * an orbital's slice is as wide as its contours are drawn.
 */
export declare function sliceHalfSize(settings: {
    mapRadii: readonly {
        molNo: number;
        radius: number;
    }[];
}, molNo: number, suggestedRadius: number | null | undefined): number;
/** Each contour `SLICE_CONTOUR_RATIO` times the one outside it, and at most this many each side of zero. */
export declare const SLICE_CONTOUR_RATIO = 2;
export declare const SLICE_MAX_CONTOURS = 12;
/**
 * How a slice's contours are spaced from the outermost (the map's level) inwards:
 *  - "linear": equal steps, up to the largest value in the slice. Where the map climbs steeply - an
 *    orbital or density towards a nucleus - the contours close up, so how fast it climbs shows.
 *    The outer, diffuse parts get few.
 *  - "geometric": each double the last. An orbital falls off from a nucleus roughly exponentially,
 *    so these come out roughly evenly spaced across it: the outer structure shows as well as the
 *    inner, but not where the values are high.
 */
export type SliceContourSpacing = "linear" | "geometric";
export declare const DEFAULT_SLICE_CONTOUR_SPACING: SliceContourSpacing;
/** The largest values either side of zero in a slice: positive, and the magnitude of the most negative. */
export interface SliceRange {
    maxPositive: number;
    maxNegative: number;
}
/**
 * Linear contour levels: the map's level - the outermost - and equal steps from there, `count` of
 * them up to the slice's largest value (`range`), the innermost a step short of the peak so that
 * it rings it rather than marking a point.
 *
 * For a difference map, one step for both signs, from the larger of their peaks, so that contours
 * as close together mean as steep a climb in either: the weaker sign has fewer, not the same number
 * squeezed into less. Each sign stops at its own peak; one the slice never reaches beyond the level
 * has only its outermost, which draws nothing.
 */
export declare function sliceLinearLevels(level: number, signed: boolean, range: SliceRange, count?: number): number[];
/**
 * The contour levels: the map's level - the outermost contour, where its 3D surface at that level
 * would cut the slice - and each `ratio` times the one before, up to the largest value in the map
 * (`maxAbs`), at most `maxCount`; and their negatives for a difference map.
 *
 * A geometric series rather than equal steps, as contour plots of orbitals and densities are
 * usually drawn: their values span orders of magnitude, and equal steps up to the peak would crowd
 * the contours round the nuclei and leave one or two for the rest. And up to the map's largest
 * value, not a fixed number of them, so that a low level gives the whole range and not just the
 * outer part of it. Levels beyond what the slice reaches draw nothing, at little cost.
 */
export declare function sliceLevels(level: number, signed: boolean, maxAbs: number, maxCount?: number, ratio?: number): number[];
/**
 * A nodal line (the zero contour) is drawn only where the map, somewhere in the cell it starts
 * from, reaches this fraction of the outermost contour (sliceContour.ts, zeroLevelMinMagnitude):
 * between and round the lobes, and not on through the empty space beyond them.
 */
export declare const SLICE_NODAL_MIN_FRACTION = 0.25;
/**
 * How finely the slice starts out: twice the map's grid spacing (a cell's samples, at its corners,
 * centre and midpoints, are then a grid spacing apart), or coarser for a very large slice, so that
 * it starts from no more than about 200 cells a side. The contouring refines from there.
 */
export declare function sliceBaseSpacing(gridSpacing: number, halfSize: number): number;
/**
 * The largest values either side of zero in a slice, from the map sampled at the slice's starting
 * cell size (sliceBaseSpacing): a sharp peak between samples is missed by a little, so the
 * innermost linear contour can sit a little short of where it would - it still rings the peak.
 */
export declare function sliceRange(sampler: MapGridSampler, slice: MapSlicePlacement, halfSize: number): SliceRange;
/**
 * Contour a slice of the map: the lines across the square, in its own (s, t) coordinates. A level
 * of zero, if given, is the nodal line: contoured only where the map reaches `nodalMinMagnitude`.
 */
export declare function contourMapSlice(sampler: MapGridSampler, slice: MapSlicePlacement, halfSize: number, levels: number[], nodalMinMagnitude?: number): SliceContours;
type Rgb = {
    r: number;
    g: number;
    b: number;
};
/** The frame round the square: grey, so as to belong to neither sign. */
export declare const SLICE_FRAME_COLOUR: Rgb;
/** The nodal line: a darker grey than the frame, also of neither sign. */
export declare const SLICE_NODAL_COLOUR: Rgb;
/**
 * The slice as a lines display object (the form Coot's line meshes take, for appendOtherData):
 * each level's lines in its colour - positive levels `positive`, negative `negative`, zero (the
 * nodal line) grey - and the square's outline, all placed in the scene.
 */
export declare function sliceLinesObject(slice: MapSlicePlacement, halfSize: number, levels: number[], contours: SliceContours, colours: {
    positive: Rgb;
    negative: Rgb;
}, alpha: number): {
    prim_types: string[][];
    useIndices: boolean[][];
    idx_tri: Uint32Array<ArrayBuffer>[][];
    vert_tri: Float32Array<ArrayBuffer>[][];
    norm_tri: Float32Array<ArrayBuffer>[][];
    col_tri: Float32Array<ArrayBuffer>[][];
};
export {};
//# sourceMappingURL=mapSlice.d.ts.map