/**
 * A map's value anywhere, from the whole unit cell Coot exports (get_map_unit_cell_grid, the same
 * grid the GPU contours use), for contouring a slice through it.
 *
 * Interpolated tricubically, with Catmull-Rom weights along each grid axis: the value at each grid
 * point is kept, and between them the field is smooth (C1), so a contour of it bends smoothly
 * rather than in straight pieces from one grid cell to the next. That is what lets a slice be
 * contoured more finely than the grid where the contours curve tightly (sliceContour.ts): a
 * trilinear field sampled more finely only gives the same corners back more often. The grid is
 * all there is, so what lies between grid points is the interpolation's, not the data's - but a
 * smooth guess, not a faceted one.
 *
 * A crystal map is periodic, so the grid wraps. An EM map is not (Coot keeps only the box): the
 * grid stops at its edges instead.
 */
import type { MapUnitCellGrid } from "../../WebGPUComponents/mapContour/mapContourBox";
export interface MapGridSampler {
    /** The map's value at an orthogonal (world) point, in angstroms. */
    value(x: number, y: number, z: number): number;
    /** The smallest distance between neighbouring grid points along a grid axis (angstroms). */
    spacing: number;
    /** The largest magnitude of any grid value: no slice through the map goes beyond it. */
    maxAbs: number;
}
export declare function makeMapGridSampler(grid: MapUnitCellGrid): MapGridSampler;
//# sourceMappingURL=mapGridSampler.d.ts.map