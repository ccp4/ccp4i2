import type { LoadFilesResult, MoorhenInstance } from "../InstanceManager/MoorhenInstance";
/**
 * One ligand file: a `File`, a URL, or either with facts to attach to its molecule (`metadata`: a
 * docking score, a rank... as strings by name, see MoorhenMolecule.metadata). They are shown on the
 * ligand's card and saved in sessions.
 */
export type BatchLigandSource = File | string | URL | {
    url: string | URL;
    filename: string;
    metadata?: Record<string, string>;
} | {
    file: File;
    metadata?: Record<string, string>;
};
export type BatchLoadLigandsOptions = {
    /** Dictionaries known up front: read into Coot once, and not looked up for the comp_ids they define. */
    dictionaries?: (File | string | URL)[];
    /** Centre the view on the last loaded ligand at the end (default false). */
    centre?: boolean;
    /**
     * Ligands per chunk, i.e. per group of worker messages and per store update (default 20). The
     * worker prepares each chunk between the meshes of the others, and nothing new is drawn meanwhile:
     * larger chunks are no faster, only longer pauses.
     */
    chunkSize?: number;
    /** Called after each chunk is added to the scene. */
    onProgress?: (done: number, total: number) => void;
};
export type BatchLoadLigandsResult = {
    /** One entry per loaded file, in input order. */
    loaded: LoadFilesResult;
    /** Files that could not be loaded, and why. */
    failed: {
        fileName: string;
        error: string;
    }[];
};
export declare const batchLoadLigands: (instance: MoorhenInstance, sources: BatchLigandSource[], options?: BatchLoadLigandsOptions) => Promise<BatchLoadLigandsResult>;
//# sourceMappingURL=BatchLigandLoading.d.ts.map