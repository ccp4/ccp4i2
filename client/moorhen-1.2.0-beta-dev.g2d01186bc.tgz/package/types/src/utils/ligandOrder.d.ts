/**
 * The order of the ligand list (components/card/LigandListCard): by name, as loaded, or by one of the
 * facts the ligand-only molecules carry (MoorhenMolecule.metadata: a docking score, a rank...).
 */
/** What the list needs of a ligand to order it: its molecule and, for a ligand inside a model, which one */
type OrderedEntry = {
    molecule: {
        name: string;
        metadata?: Record<string, string>;
    };
    ligand?: {
        resName: string;
        chainName: string;
        resNum: string;
    };
};
export type LigandOrder = {
    /** "name", "load" (the order the list is given in), or a metadata key as metadataOrder(key) */
    by: string;
    descending: boolean;
};
/** The `by` of an order by a metadata key (a key may be called "name" or "load") */
export declare const metadataOrder: (key: string) => string;
/** The metadata key an order is by, or null for the name and load orders */
export declare const orderMetadataKey: (order: LigandOrder) => string | null;
/** The name a ligand is listed and ordered by */
export declare const ligandEntryName: ({ molecule, ligand }: OrderedEntry) => string;
/** A ligand's value for a metadata key: a ligand inside a model has none (its model's is not its) */
export declare const ligandMetadataValue: ({ molecule, ligand }: OrderedEntry, key: string) => string | undefined;
/** The metadata keys the ligand-only molecules of the list have, in name order */
export declare const ligandMetadataKeys: (entries: OrderedEntry[]) => string[];
/**
 * Whether a metadata key is ordered as numbers: when every value of it in the list is one. Asked of
 * the whole list, not of each group of it, so that every group is ordered the same way.
 */
export declare const isNumericMetadata: (entries: OrderedEntry[], key: string) => boolean;
/**
 * A list of ligands in the given order (a new array; the list itself for the load order). By a
 * metadata key: numbers as numbers if `numeric`, else as text; equal values by name; the ligands
 * without a value last, by name, whichever the direction.
 */
export declare const sortLigandEntries: <E extends OrderedEntry>(list: E[], order: LigandOrder, numeric?: boolean) => E[];
export {};
//# sourceMappingURL=ligandOrder.d.ts.map