/**
 * Fetch the restraints dictionary of a monomer: from the local monomer library first, then from the
 * MonomerLibrary repository on GitHub, then from PDBe.
 * @param compId - The monomer's three-letter (or longer) code
 * @param monomerLibraryPath - The local monomer library, laid out as `<path>/<first letter>/<CODE>.cif`
 * @returns The dictionary text, or undefined if no source has it
 */
export declare const fetchMonomerDictionary: (compId: string, monomerLibraryPath: string) => Promise<string | undefined>;
//# sourceMappingURL=monomerLibrary.d.ts.map