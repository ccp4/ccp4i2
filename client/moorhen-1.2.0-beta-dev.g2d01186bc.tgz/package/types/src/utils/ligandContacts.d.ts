import type { LigandInfo, MoorhenMolecule } from "./MoorhenMolecule";
/**
 * The contacts of a ligand with another molecule, from Coot's single-molecule analyses run on a
 * temporary merge of the two (moorhenInstance.cootCommand: make_merged_molecule, then
 * get_h_bonds_between, get_salt_bridges, detect_xhpi_interactions and the FLEV SVG on the merged
 * molecule, then delete_merged_molecule). The merged molecule's chains are mapped back, so every atom is named in
 * its own molecule.
 */
/** One side of a contact, named in its own molecule. */
export type ContactSide = {
    chainId: string;
    resNo: number;
    insCode: string;
    resName: string;
    atomName?: string;
    ring?: string;
    xyz: [number, number, number];
};
export type ContactType = "hbond" | "salt-bridge" | "xh-pi";
export type LigandContact = {
    type: ContactType;
    ligand: ContactSide;
    partner: ContactSide;
    distance: number;
    /** H-bond: which side gives the hydrogen; XH-π: whether the ligand gives the X-H or the ring */
    ligandRole?: "donor" | "acceptor" | "ring";
    /** Salt bridge: the ligand's charge */
    ligandCharge?: number;
};
export type LigandContactsResult = {
    contacts: LigandContact[];
    /** The FLEV SVG, empty when Coot could not draw it; absent when not asked for */
    flev?: string;
};
/**
 * A residue number as gemmi writes it (seqid.str(): "301", "301A" with an insertion code) as an mmdb cid
 * wants it ("301", "301.A").
 */
export declare const mmdbResidueNumber: (seqid: string) => string;
/**
 * A ligand's cid as mmdb (Coot's selections) reads it. Its own `cid` is as gemmi writes it, which is
 * the same thing unless the residue has an insertion code: /1/A/301A(ATP) is then /1/A/301(ATP).A for
 * mmdb, which selects nothing with gemmi's.
 */
export declare const mmdbLigandCid: (ligand: Pick<LigandInfo, "cid" | "modelName" | "chainName" | "resNum" | "resName">) => string;
/**
 * The contacts of a ligand with another molecule, or with the rest of its own: H-bonds, salt bridges
 * and, optionally, XH-π (XPID adds hydrogens from the monomer library, so the ligand's dictionaries
 * are passed to it) and the FLEV diagram.
 * @param ligand - The molecule the ligand is in.
 * @param partner - The other molecule; `ligand` itself for the rest of the ligand's own molecule.
 * @param ligandInfo - Which ligand of `ligand`: by default its first (a ligand-only molecule's).
 */
export declare const getLigandContacts: (ligand: MoorhenMolecule, partner: MoorhenMolecule, options?: {
    xhpi?: boolean;
    flev?: boolean;
}, ligandInfo?: LigandInfo | undefined) => Promise<LigandContactsResult>;
//# sourceMappingURL=ligandContacts.d.ts.map