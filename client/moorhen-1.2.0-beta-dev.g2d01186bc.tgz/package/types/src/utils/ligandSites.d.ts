import type { MoorhenReduxStoreType } from "../store/MoorhenReduxStore";
import type { MoleculeLigandRecord } from "../store/moleculesSlice";
import type { MoorhenMolecule } from "./MoorhenMolecule";
/** A ligand: a ligand-only molecule, or with `ligand` one ligand residue of a model. */
export type LigandEntry = {
    molecule: MoorhenMolecule;
    ligand?: MoleculeLigandRecord;
};
/** Ligands at the same position: they overlap one another, directly or through other ligands of the site. */
export type LigandSite = {
    ligands: LigandEntry[];
    /** Mean position of the site's heavy atoms */
    centre: [number, number, number];
    /** Extent of the site's heavy atoms, as moleculeDiameter measures it */
    diameter: number;
};
/** Two ligands overlap when a heavy atom of one is this close (Å) to a heavy atom of the other. */
export declare const SITE_CONTACT_DISTANCE = 3;
/**
 * Group ligands by position, ligand-only molecules and ligands of models alike: ligands that overlap (any heavy atoms closer than
 * `contactDistance`) are in the same site, and so are ligands that overlap through others, e.g. all
 * the docking poses in one pocket. Sites are returned largest first.
 *
 * Linear in the number of atoms: heavy atoms go in a grid of `contactDistance` cells, and each atom
 * is only compared with the atoms of its own and neighbouring cells.
 */
export declare const groupLigandsBySite: (entries: LigandEntry[], contactDistance?: number) => Promise<LigandSite[]>;
/** Centre and zoom the view on a site, as MoorhenMolecule.centreOn does for a molecule. */
export declare const centreOnSite: (site: LigandSite, store: MoorhenReduxStoreType) => void;
//# sourceMappingURL=ligandSites.d.ts.map