import { Store } from "@reduxjs/toolkit";
import "pako";
import { gemmi } from "../types/gemmi";
import { libcootApi } from "../types/libcoot";
import { moorhen } from "../types/moorhen";
import { privateer } from "../types/privateer";
import { ColourRuleType } from "./MoorhenColourRule";
import { MoleculeRepresentation, RepresentationStyles, gaussianSurfSettings, m2tParameters, residueEnvironmentOptions } from "./Representation/MoorhenMoleculeRepresentation";
import type { wormOptions } from "./Representation/wormRadii";
import { SeqElement } from "@/components/sequence-viewer/MoorhenSeqViewTypes";
import { MoorhenInstance } from "../InstanceManager/index";
import { CommandCentre } from "../InstanceManager/CommandCentre/index";
export type ResidueInfo = {
    resCode: string;
    resNum: number;
    cid: string;
};
export type LigandInfo = {
    resName: string;
    chainName: string;
    resNum: string;
    modelName: string;
    cid: string;
    svg?: string;
    flev_svg?: string;
    smiles?: string;
    chem_comp_info?: {
        first: string;
        second: string;
    }[];
};
export type Sequence = {
    name: string;
    chain: string;
    type: number;
    sequence: ResidueInfo[];
};
export type ChemShift = {
    atom: string;
    chain: string;
    element: string;
    isotope: number;
    resname: string;
    seq: number;
    chemshift: number;
    uncertainty?: number;
    ambiguityFlag: boolean;
};
export type NEFRestraint = {
    atom1: string;
    chain1: string;
    atom2: string;
    chain2: string;
    res1: string;
    res2: string;
    name1: number;
    name2: number;
    ambiguityFlag: boolean;
    restraintID: number;
};
/** The metadata key of a fitted ligand pose's correlation with the map (higher is better) */
export declare const FIT_CORRELATION_KEY = "Fit correlation";
/** The metadata key of the volume of the density blob a ligand pose was fitted into */
export declare const FIT_CLUSTER_VOLUME_KEY = "Fitted density volume";
/**
 * Represents a molecule
 * @property {string} name - The name assigned to this molecule instance
 * @property {number} molNo - The imol assigned to this molecule instance
 * @property {boolean} atomsDirty - Whether the cached atoms are outdated
 * @property {boolean} symmetryOn - Whether the symmetry is currently being displayed
 * @property {object} sequences - List of sequences present in the molecule
 * @property {object} gemmiStructure - Object representation of the cached gemmi structure for this molecule
 * @property {object} gemmiDocument - Object representation of the cached gemmi document for this molecule
 * @property {React.RefObject<moorhen.CommandCentre>} commandCentre - A react reference to the command centre instance
 * @property {React.RefObject<webGL.MGWebGL>} glRef - A react reference to the MGWebGL instance
 * @property {string} monomerLibraryPath - A string with the path to the monomer library, relative to the root of the app
 * @constructor
 * @param {React.RefObject<moorhen.CommandCentre>} commandCentre - A react reference to the command centre instance
 * @param {React.RefObject<webGL.MGWebGL>} glRef - A react reference to the MGWebGL instance
 * @param {Store} [store=undefined] - A Redux store. By default Moorhen Redux store will be used
 * @param {string} [monomerLibraryPath="./monomers"] - A string with the path to the monomer library, relative to the root of the app
 * @example
 * import { MoorhenMolecule } from 'moorhen';
 *
 * const example = async () => {
 *    // Create a new molecule
 *    const molecule = new MoorhenMolecule(commandCentre, glRef, monomerLibraryPath);
 *    const backgroundColor = useSelector((state: moorhen.State) => state.sceneSettings.backgroundColor)
 *
 *    // Set some defaults
 *    molecule.setBackgroundColour(backgroundColor)
 *
 *    // Load file from a URL
 *    await molecule.loadToCootFromURL('/uri/to/file.pdb', 'mol-1');
 *
 *    // Draw coot bond representation and centre on molecule
 *    await molecule.fetchIfDirtyAndDraw('CBs');
 *    await molecule.centreOn();
 *
 *    // Delete molecule
 *    await molecule.delete();
 * }
 */
export declare class MoorhenMolecule {
    type: string;
    atomCount: number;
    moorhenInstance: MoorhenInstance;
    commandCentre: CommandCentre;
    atomsDirty: boolean;
    name: string;
    molNo: number | null;
    gemmiStructure: gemmi.Structure;
    private _numberOfModels;
    gemmiDocument: gemmi.cifDocument;
    sequences: Sequence[];
    representations: moorhen.MoleculeRepresentation[];
    ligands: LigandInfo[];
    ligandDicts: {
        [comp_id: string]: string;
    };
    /**
     * Facts about the molecule as plain strings, by name: what a file said about it that is not a
     * structure (a docking score: "Vina score" from a PDBQT), or whatever a host wants to attach (set
     * entries on it directly). Every entry is shown under a ligand's 2D drawing on its ligand card,
     * and saved in sessions.
     */
    metadata: Record<string, string>;
    connectedToMaps: number[];
    excludedSelections: string[];
    excludedCids: string[];
    symmetryOn: boolean;
    biomolOn: boolean;
    symmetryRadius: number;
    symmetryMatrices: number[][][];
    gaussianSurfaceSettings: gaussianSurfSettings;
    isDarkBackground: boolean;
    defaultBondOptions: moorhen.cootBondOptions;
    defaultM2tParams: m2tParameters;
    defaultResidueEnvironmentOptions: residueEnvironmentOptions;
    displayObjectsTransformation: {
        origin: [number, number, number];
        quat: any;
        centre: [number, number, number];
    };
    uniqueId: string;
    monomerLibraryPath: string;
    defaultColourRules: moorhen.ColourRule[];
    adaptativeBondsRepresentation: moorhen.MoleculeRepresentation;
    hoverRepresentation: moorhen.MoleculeRepresentation;
    unitCellRepresentation: moorhen.MoleculeRepresentation;
    environmentRepresentation: moorhen.MoleculeRepresentation;
    selectionRepresentation: moorhen.MoleculeRepresentation;
    hasGlycans: boolean;
    hasDNA: boolean;
    restraints: {
        maxRadius: number;
        cid: string;
    }[];
    isLigand: boolean;
    coordsFormat: moorhen.coorFormats;
    cachedPrivateerValidation: privateer.ResultsEntry[];
    cachedPrivateerCremerPopleParameters: privateer.CremerPopleParameters[];
    cachedGemmiAtoms: moorhen.AtomInfo[];
    cachedLigandSVGs: {
        [key: string]: string;
    };
    moleculeDiameter: number;
    adaptativeBondsEnabled: boolean;
    store: Store;
    headerInfo: libcootApi.headerInfoJS;
    isMRSearchModel: boolean;
    chemShifts: ChemShift[];
    NEFRestraints: NEFRestraint[];
    NEFRestraintRepresentation: moorhen.MoleculeRepresentation;
    moleculeCardState: {
        showXpidList: boolean;
    };
    private _seqViewerData;
    moleculeChangedCallbacks: ((molecule: string, changeType: string) => void)[];
    constructor(moorhenInstance: MoorhenInstance);
    /**
     * Replace the current molecule with the model in a file
     * @param {string} fileUrl - The uri to the file with the new model
     */
    replaceModelWithFile(fileUrl: string): Promise<void>;
    /**
     * Replace the current molecule some file contents
     * @param {string} coordData - The coord data for new model
     */
    replaceModelWithCoordData(coordData: string): Promise<void>;
    /**
     * Turn on/off molecule symmetry
     */
    toggleBiomolecule(): void;
    /**
     * Turn on/off molecule symmetry
     */
    toggleSymmetry(): Promise<void>;
    /**
     * Set the radius to draw symmetry mates
     * @param {number} radius - Symmetry mates with an atom within this radius will be drawn
     */
    setSymmetryRadius(radius: number): Promise<void>;
    /**
     * Fetch the matrices representing the biomolecule of the current model from gemmi
     */
    fetchBiomoleculeMatrix(): void;
    /**
     * Fetch the symmetry matrix for the current model from libcoot api
     */
    fetchSymmetryMatrix(): Promise<void>;
    /**
     * Draw symmetry mates for the current molecule
     * @param {boolean} [fetchSymMatrix=true] - Indicates whether a new symmetry matrix must be fetched from libcoot api
     */
    drawBiomolecule(fetchSymMatrix?: boolean): void;
    /**
     * Draw symmetry mates for the current molecule
     * @param {boolean} [fetchSymMatrix=true] - Indicates whether a new symmetry matrix must be fetched from libcoot api
     */
    drawSymmetry(fetchSymMatrix?: boolean): Promise<void>;
    /**
     * Set the background colour where the molecule is being drawn. Used to detect whether the background is dark and molecule needs to be rendered using lighter colours.
     * @param {number[]} backgroundColour - The rgba indicating the background colour
     */
    setBackgroundColour(backgroundColour: [number, number, number, number]): void;
    /**
     * Tell the user that gemmi could not read this molecule's coordinates.
     *
     * Coot may still have read them, so the molecule draws, but everything Moorhen takes from the
     * gemmi copy - sequences, ligands, hovered-atom details, selections by CID - will be missing
     * or stale. That is worth a toast rather than only a line in the console.
     */
    private warnGemmiParseFailure;
    /**
     * Update the cached gemmi structure for this molecule
     */
    updateGemmiStructure(coordString: string): Promise<void>;
    /**
     * Get the unit cell parameters for the molecule
     * @returns An object with the unit cell parameters
     */
    getUnitCellParams(): {
        a: number;
        b: number;
        c: number;
        alpha: number;
        beta: number;
        gamma: number;
    };
    /**
     * Get the CIDs for all residues wihtin a distance threshold of a set of residues
     * @param {string} selectionCid - The CID indicating the selection of residues used for the search
     * @param {number} radius - The radius used in the search
     * @param {number} minDist - Minimum distance for the serch
     * @param {number} maxDist - Maximum distance for the search
     * @returns {Promise<string[]>} List of CIDs with the residues found within the radius of search
     */
    getNeighborResiduesCids(selectionCid: string, maxDist: number): Promise<string[]>;
    /**
     * Parse the sequences in the molecule
     */
    parseSequences(): void;
    updateSeqViewerData(): void;
    get seqViewerData(): SeqElement[];
    set seqViewerData(newData: SeqElement[]);
    /**
 * Check if the molecule instance consists of a ligand
 * @returns {boolean} True if the molecule is a ligand
 */
    /**
     * Whether this molecule is only ligands: no polymer residue (see checkIsLigand, a gemmi test on
     * entity types) and at least one ligand, so a molecule of waters only is not one. The Models panel
     * lists these molecules together, by name, instead of a full card each, and a molecule that is not
     * one cannot be merged into one.
     */
    isLigandOnly(): boolean;
    checkIsLigand(): boolean;
    /**
     * Delete this molecule instance
     * @param {boolean} [popBackImol=false] - Indicates whether the imol for this molecule instance should be popped back (useful for ephemeral molecules)
     * @param {boolean} [doJournal=true] - Record the deletion in the command history (false for a molecule that never made it into the session, e.g. a file a batch failed to load)
     */
    delete(popBackImol?: boolean, doJournal?: boolean): Promise<moorhen.WorkerResponse>;
    /**
     * Forget a molecule that Coot never read (e.g. a file that failed to load): its record, the
     * dictionaries recorded for it and its gemmi structure. Use delete() for a molecule Coot read.
     */
    forget(): void;
    /**
     * Free the gemmi structure and drop the reference to it.
     *
     * Dropping it matters as much as freeing it: anything still holding this molecule (an old
     * props object, a closure) would otherwise reach a freed embind object, and every property on
     * it throws "cannot call emscripten binding method ... on deleted object" when read. React's
     * development build reads them when it diffs a changed `molecules` prop for its performance
     * track - it walks inherited enumerable keys, which embind getters are.
     */
    private freeGemmiStructure;
    /** No more record for this molecule, and none written back by a refresh still in flight */
    private closeRecord;
    /**
     * Transfer metadata stored in this molecule instance to other molecule
     * @param {morhen.Molecule} otherMolecule - The molecule where the metadata will be transferred
     * @param {boolean} [transferDicts=true] - Indicates whether ligand dictionaries should also be transferred
     */
    transferMetaData(otherMolecule: moorhen.Molecule, transferDicts?: boolean): Promise<void>;
    /**
     * Transfer ligand dictionaries stored in this molecule instance to other molecule
     * @param {morhen.Molecule} toMolecule - The molecule where the metadata will be transferred
     * @param {boolean} [override=false] - Override ligand dictionaries already stored under the same ligand name in the other molecule instance
     */
    transferLigandDicts(toMolecule: moorhen.Molecule, override?: boolean): Promise<void>;
    /**
     * Copy molecule into a new instance
     * @returns {moorhen.Molecule} New molecule instance
     */
    copyMolecule(doRedraw?: boolean): Promise<moorhen.Molecule>;
    /**
     * Copy a fragment of the current model into a new molecule using a selection CID
     * @param {string} cid - The CID selection indicating the residues that will be copied into the new fragment
     * @param {boolean} [doRecentre=true] - Indicates whether the view should re-centre on the new copied fragment
     * @param {boolean} [style="CBs"] - Indicates the style used to draw the copied fragment (only takes effect if doRecentre=true)
     * @returns {Promise<moorhen.Molecule>}  New molecule instance
     */
    copyFragmentUsingCid(cid: string, doRecentre?: boolean, style?: moorhen.RepresentationStyles): Promise<moorhen.Molecule>;
    /**
     * Copy a fragment of the current model into a new molecule for refinement
     * @param {string[]} cid - The CID selection indicating the residues that will be copied into the new fragment
     * @param {moorhen.Map} refinementMap - The map instance used in the refinement
     * @param {boolean} redraw - Indicate if the molecules should be redrawn
     * @param {boolean} redrawFragmentFirst - Indicate if the fragment should be redrawn first
     * @returns {moorhen.Molecule} A new molecule instance that can be used for refinement
     */
    copyFragmentForRefinement(cid: string[], refinementMap: moorhen.Map, redraw?: boolean, redrawFragmentFirst?: boolean): Promise<moorhen.Molecule>;
    /**
     * Merge a fragment that was used for refinement into the current molecule
     * @param {string[]} cid - The CID selection used to create the fragment
     * @param {moorhen.Molecule} fragmentMolecule - The fragment molecule
     * @param {boolean} [acceptTransform=true] - Indicates whether the transformation should be accepted
     * @param {boolean} [refineAfterMerge=false] - Indicates whether another cycle of refinement should be run after merging the fragment
     */
    mergeFragmentFromRefinement(cid: string, fragmentMolecule: moorhen.Molecule, acceptTransform?: boolean, refineAfterMerge?: boolean): Promise<void>;
    /**
     * Load a new molecule from a file URL
     * @param {string} url - The url to the path with the data for the new molecule
     * @param {string} molName - The new molecule name
     * @param {object} [options] - Options passed to fetch API
     * @returns {Promise<moorhen.Molecule>} The new molecule
     */
    loadToCootFromURL(url: RequestInfo | URL, molName: string, options?: RequestInit): Promise<moorhen.Molecule>;
    /**
     * Load a new molecule from the contents of a file
     * @param {File} source - The input file
     * @returns {Promise<moorhen.Molecule>} The new molecule
     */
    loadToCootFromFile(source: File): Promise<moorhen.Molecule>;
    /**
     * Guess the coordinate format from the file contents
     * @param {string} coordDataString - The file contents
     * @returns {string} - The file format
     */
    static guessCoordFormat(coordDataString: string): moorhen.coorFormats;
    /**
     * Whether a coordinate string is a small-molecule (coreCIF) file rather than mmCIF or PDB.
     *
     * Such a file - from the COD or the CSD, say - gives its atoms as fractional coordinates in
     * _atom_site_fract_x, a tag no mmCIF or PDB file has, so that cheap test comes first and
     * gemmi's full parse is only run on files that pass it. Without it, every protein loaded
     * would be parsed twice.
     */
    static isSmallMoleculeCif(coordData: ArrayBuffer | string): boolean;
    /**
     * Turn a small-molecule CIF into an mmCIF that Coot and gemmi can read, and give Coot the
     * restraint dictionary that comes with it.
     *
     * The structure becomes one residue in chain A, named after the CIF's data block. Coot alone
     * cannot read the original: it fails, and the loader then tries the file as a monomer
     * dictionary, which fails with a gemmi binding error instead of a useful message.
     * @returns {Promise<string>} The mmCIF text
     */
    private smallMoleculeCifToMMCif;
    /**
     * Load a new molecule from a string: PDB, mmCIF, or a small-molecule CIF (made into mmCIF first)
     * @param {string} coordData - The molecule data
     * @param {string} name - The new molecule name
     * @returns {Promise<moorhen.Molecule>} The new molecule
     */
    loadToCootFromString(coordData: ArrayBuffer | string, name: string): Promise<moorhen.Molecule>;
    /**
     * Load a the missing dictionary for a monomer. First attempts to load it from the monomer library, if it fails it will load from the EBI.
     * @param {string} newTlc - Three letter code for the monomer
     * @param {number} attachToMolecule - Molecule number for which the dicitonary will be associated
     */
    loadMissingMonomer(newTlc: string, attachToMolecule: number): Promise<string>;
    /**
     * Attempt to load dictionaries for all missing monomers present in the molecule
     * @returns {Promise<moorhen.Molecule>} This molecule instance
     */
    loadMissingMonomers(): Promise<void>;
    /**
     * Set the cached molecule atoms as "dirty". This means new bond representations need to be fetched
     * next time the molecule is redrawn.
     * @param {boolean} state - Indicate whether the current atom representation is dirty
     */
    setAtomsDirty(state: boolean): void;
    /**
     * Get a string with the PDB file contents of the molecule in its current state
     * @param {string} [format='pdb'] - File format will match the one of the original file unless specified here
     * @returns {string}  A string representation file contents
     */
    getAtoms(format?: moorhen.coorFormats): Promise<string>;
    /**
     * Download the PDB file contents of the molecule in its current state
     * @param {string} [format='pdb'] - File format will match the one of the original file unless specified here
     */
    downloadAtoms(format?: moorhen.coorFormats, fileName?: string): Promise<void>;
    /**
     * Check if the current molecule has glycans
     * @returns {Promise<boolean>} - True if the current molecule has glycans
     */
    checkHasGlycans(): Promise<boolean>;
    /**
     * Get the diameter of this molecule
     * @returns {number} The molecule diameter
     */
    getMoleculeDiameter(): Promise<number>;
    /**
     * Update the cached atoms with the latest information from the libcoot api
     */
    updateAtoms(): Promise<void>;
    /**
     * Draw the molecule with a particular style. If the molecule atoms are marked as "dirty" then fetch new atoms.
     * @param {string} style - The style that will be drawn
     */
    private findDefaultRepresentation;
    fetchIfDirtyAndDraw(style: moorhen.RepresentationStyles): Promise<void>;
    /**
     * Centre the view and align it with the axis of a particular residue
     * @param {string} selectionCid - CID selection for the residue to centre the view on
     * @param {boolean} [alignWithCB=false] - Indicates whether to align with the CB atom for better view of the side chain (when present in the residue)
     * @param {number} [zoomLevel=0.3] - Indicates the zoom level to use
     */
    centreAndAlignViewOn(selectionCid: string, alignWithCB?: boolean, zoomLevel?: number): Promise<void>;
    /**
     * Centre the view on a particular residue
     * @param {string} selectionCid - CID selection for the residue to centre the view on
     * @param {boolean} [animate=true] - Indicates whether the change will be animated
     */
    centreOn(selectionCid?: string, animate?: boolean, doSetZoom?: boolean): Promise<void>;
    /**
     * Draw molecule from a given mesh
     * @param {string} style - Indicate the style to be drawn
     * @param {any[]} meshObjects - The mesh obects that will be drawn
     * @param {string} [cid] - The new buffer CID selection; if omitted, the molecule's own representation of this style is reused
     */
    drawWithStyleFromMesh(style: moorhen.RepresentationStyles, meshObjects: any[], cid?: string, fetchAtomBuffers?: boolean): Promise<void>;
    addColourRule(ruleType: ColourRuleType, cid: string, color: string, isMultiColourRule?: boolean, applyColourToNonCarbonAtoms?: boolean, label?: string): void;
    /**
     * Add a representation to the molecule
     * @param {string} style - The style of the new representation
     * @param {string} cid - The CID selection for the residues included in the new representation
     * @param {boolean} [isCustom=false] - Indicates if the representation is considered "custom"
     * @param {moorhen.ColourRule[]} [colourRules=undefined] - A list of colour rules that will be applied to the new representation
     * @param {moorhen.cootBondOptions} [bondOptions=undefined] - An object that describes bond width, atom/bond ratio and other bond settings.
     * @param {moorhen.m2tParameters} [m2tParams=undefined] - An object that describes ribbon width, nucleotide style and other ribbon settings.
     * @param {string} [neighboursMoleculeUid=""] - The molecule neighboursCid is in (uniqueId), if not this one.
     * @param {wormOptions} [wormOptions=undefined] - A "Worm"'s own options (see wormRadii.ts); none: the general ones.
     * @deprecated Use MoleculeRepresentation.create() instead.
     */
    addRepresentation(style: RepresentationStyles, cid?: string, isCustom?: boolean, colourRules?: moorhen.ColourRule[], bondOptions?: moorhen.cootBondOptions, m2tParams?: m2tParameters, residueEnvOptions?: residueEnvironmentOptions, nonCustomOpacity?: number, neighboursCid?: string, restrictToNeighbours?: boolean, excludeNeighbours?: boolean, hbondedToCid?: string, hbondedTo?: boolean, neighboursDistance?: number, neighboursMoleculeUid?: string, wormOptions?: Partial<wormOptions>): Promise<MoleculeRepresentation>;
    /**
     * Redraw a molecule representation
     * @param {string} id - Unique identifier for the representation of interest
     */
    redrawRepresentation(id: string): Promise<void>;
    /**
     * Show the representation for the molecule
     * @param {string} style - The representation style to show
     * @param {string} [cid=undefined] - The CID selection for the representation
     */
    show(style: moorhen.RepresentationStyles, cid?: string): Promise<moorhen.MoleculeRepresentation>;
    /**
     * Hide a type of representation for the molecule
     * @param {string} style - The representation style to hide
     * @param {string} [cid=undefined] - The CID selection for the representation
     */
    hide(style: moorhen.RepresentationStyles, cid?: string): moorhen.MoleculeRepresentation;
    /**
     * Clears the representation buffers for a particular style
     * @param {string} style - The style to clear
     */
    clearBuffersOfStyle(style: string): void;
    /**
     * Remove a representation for this molecule instance
     * @param {string} representationId - The unique identifier for the representation
     */
    removeRepresentation(representationId: string): void;
    /**
     * Check whether a particular buffer is included within the representation buffer for this molecule
     * @param bufferIn - The buffer with the ID to search for
     * @returns {boolean} True if the buffer is included in this molecule
     */
    buffersInclude(bufferIn: {
        id: string;
    }): boolean;
    /**
     * Draw the unit cell of this molecule
     */
    drawUnitCell(): Promise<void>;
    /**
     * Draw a hover effect over a selected residue
     * @param {string} selectionString - The CID selection for the residue that will be highlighted
     */
    drawHover(selectionString: string): Promise<void>;
    /**
     * Highlight residues in a selected CID range
     * @param {string} selectionString - The CID selection for the residues that will be highlighted
     */
    drawResidueSelection(selectionString: string): Promise<void>;
    /**
     * Get the active atom for this molecule
     * @returns {string} The active atom CID
     */
    getActiveAtom(): Promise<string>;
    /**
     * Value setter for MoorhenMolecule.adaptativeBondsEnabled
     * @param {boolean} newValue - The new value
     */
    setDrawAdaptativeBonds(newValue: boolean): Promise<void>;
    /**
     * Draw bonds for a given glRef origin
     * @param {string} selectionString - The CID selection for the residues that will be highlighted
     */
    redrawAdaptativeBonds(selectionCid?: string): Promise<void>;
    /**
     * Draw enviroment distances for a given residue
     * @param {string} [selectionCid=undefined] - The CID selection to draw the environment. If undefined then it will automatically determine the closest CID to the screen center.
     */
    drawEnvironment(selectionCid?: string): Promise<void>;
    drawNEFRestraints(selectionCid?: string): Promise<void>;
    /**
     * Redraw the molecule representations
     */
    redraw(): Promise<void>;
    /**
     * Move residues by applying a series of cached matrix transformations
     * @param {string} selectionCid - The CID selection for the set of residues that will be moved
     * @returns {moorhen.AtomInfo[][]} New atom information for the moved residues
     */
    transformedCachedAtomsAsMovedAtoms(selectionCid?: string): moorhen.AtomInfo[][];
    /**
     * Update the molecule with a set of moved residues
     * @param {moorhen.AtomInfo[][]} movedResidues - Set of moved residues
     */
    updateWithMovedAtoms(movedResidues: moorhen.AtomInfo[][]): Promise<void>;
    /**
     * Apply cached transformation matrix to molecule
     */
    applyTransform(): Promise<void>;
    /**
     * Get a list with the names of the chains in the current model
     * @returns {string[]} - A list of chain names in the current structure
     */
    getChainNames(): string[];
    /**
     * Merge a set of molecules in this molecule instance
     * @param {moorhen.Molecule} otherMolecules - A list of other molecules to merge into this instance
     * @param {boolean} [doHide=false] - Indicates whether the source molecules should be hidden when finish
     */
    mergeMolecules(otherMolecules: moorhen.Molecule[], doHide?: boolean, doRedraw?: boolean): Promise<void>;
    /**
     * Add a ligand of a given type to this molecule isntance
     * @param {string} resType - Three letter code for the ligand of interest
     * @param {number} [fromMolNo=-999999] - Indicate the molecule number to which the ligand dictionary was associated (use -999999 for "any")
     */
    addLigandOfType(resType: string, fromMolNo?: number): Promise<moorhen.WorkerResponse>;
    /**
     * Get dictionary for a ligand associated with this molecule
     * @param {string} comp_id - Three letter code for the ligand of interest
     * @returns {string} The ligand dictionary
     */
    getDict(comp_id: string): string;
    /**
     * Internal function used to store a ligand dictionary in the cache for this molecule instance
     * @param {string} fileContent - The dictionary contents
     */
    cacheLigandDict(fileContent: string): void;
    /**
     * Associate ligand dictionary with this molecule instance
     * @param {string} fileContent - The dictionary contents
     */
    addDict(fileContent: string): Promise<void>;
    /**
     * Undo last action performed on this molecule
     */
    undo(): Promise<void>;
    /**
     * Redo last action performed on this molecule
     */
    redo(): Promise<void>;
    /**
     * Update the ligand dictionaries for this molecule instance
     */
    updateLigands(): Promise<void>;
    /** Set once deleted: a refresh still in flight must not write the record back */
    private recordClosed;
    /**
     * Refresh this molecule's record in the store (molecules.moleculeRecords, see MoleculeRecord):
     * written only when a field differs from what the store holds or will hold.
     * @param missingDictionaries - New missing dictionaries; by default the record keeps its own
     */
    refreshRecord(missingDictionaries?: string[]): void;
    /**
     * Ask Coot which residue types of this molecule have no dictionary, into its record (a store sync
     * warns about new ones). Done when its atoms change and when it is given a dictionary; drawing a
     * representation does not ask.
     */
    refreshMissingDictionaries(): Promise<void>;
    /**
     * Get atom information for a given CID selection
     * @param {string} cid - The CID selection
     * @returns {Promise<moorhen.AtomInfo[]>} JS objects containing atom information
     */
    gemmiAtomsForCid(cid: string, omitExcludedCids?: boolean): Promise<moorhen.AtomInfo[]>;
    /**
     * Determine whether this molecule instance has any visible buffers
     * @param {string[]} excludeStyles - A list of representation styles that should be excluded from this check
     * @returns {boolean} True if the molecule has any visible buffers
     */
    isVisible(excludeStyles?: string[]): boolean;
    /**
     * Set the default colour rules for this molecule from libcoot API
     */
    fetchDefaultColourRules(): Promise<void>;
    /**
     * Hide representations for a given CID selection
     * @param {string} cid - The CID selection
     * @param {boolean} [redraw=true] - Indicates if the molecule should be redrawn
     */
    hideCid(cid: string, redraw?: boolean): Promise<void>;
    /**
     * Unhide all the molecule representations
     * @param {boolean} [redraw=true] - Indicates if the molecule should be redrawn
     */
    unhideAll(redraw?: boolean): Promise<void>;
    /**
     * Run rigid body fitting
     * @param {string} cidsString - Residue CID selection
     * @param {number} mapNo - Map number that should be used
     */
    rigidBodyFit(cidsString: string, mapNo: number, redraw?: boolean): Promise<void>;
    /**
     * Generate self restraints
     * @param {string} [cid="//"] The CID for local restraints
     * @param {number} [maxRadius=4.2] The maximum radius for the restraints
     */
    generateSelfRestraints(cid?: string, maxRadius?: number): Promise<void>;
    /**
     * Clear all additional restraints
     */
    clearExtraRestraints(): Promise<moorhen.WorkerResponse>;
    /**
     * Check whether a residue is partial, i.e. has atoms missing compared to its dictionary.
     * Atoms missing in only some of a residue's alt confs do not count.
     * @param {string} chainId - The chain ID of the residue
     * @param {number} resNo - The residue number
     * @param {string} [insCode=""] - The insertion code of the residue
     * @returns {Promise<boolean>} True if the residue has missing atoms
     */
    residueHasMissingAtoms(chainId: string, resNo: number, insCode?: string): Promise<boolean>;
    /**
     * Auto-fit the rotamer of a residue into a map
     *
     * With an alt conf only that conformation is fitted. libcoot's auto_fit_rotamer copies the fitted
     * coordinates onto every conformation of the residue, so the fit is done on a fragment holding only
     * that alt conf (and the atoms without one) and merged back.
     * @param {string} chainId - The chain ID of the residue
     * @param {number} resNo - The residue number
     * @param {string} insCode - The insertion code of the residue
     * @param {string} altConf - The alt conf to fit, or "" for a residue without alt confs
     * @param {moorhen.Map} map - The map to fit into
     * @returns {Promise<number>} 1 if the rotamer was fitted, 0 otherwise
     */
    autoFitRotamer(chainId: string, resNo: number, insCode: string, altConf: string, map: moorhen.Map): Promise<number>;
    /**
     * Get the residue CIDs that libcoot's refinement `mode` would select around `cid`
     * (mirrors coot::molecule_t::select_residues). Only used for alt-conf refinement, where
     * libcoot cannot be asked to do the selection itself.
     * @param {string} cid - The (multi-)CID of the central residue(s)
     * @param {string} mode - Refinement mode (SINGLE, LITERAL, TRIPLE, QUINTUPLE, HEPTUPLE, SPHERE, BIG_SPHERE, CHAIN, ALL)
     * @returns {Promise<string[]>} Residue CIDs
     */
    private getResidueCidsForRefinementMode;
    /**
     * Refine a set of residues
     *
     * If the CID ends in `:X` (e.g. `//A/42/*:B`) only alternate conformation X and the atoms without
     * an alt conf are refined, the other conformations stay fixed. libcoot's in-place refinement
     * ignores alt confs, so that case goes through a refinement fragment restricted to the alt conf.
     * @param {string} cid - The CID selection with the atoms that should be refined
     * @param {string} mode - Refinement mode (SINGLE, TRIPLE ...etc.)
     * @param {number} [ncyc=4000] - Number of refinement cycles
     * @param {boolean} [redraw=true] - Indicates if the molecule should be redrawn
     */
    refineResiduesUsingAtomCid(cid: string, mode: string, ncyc?: number, redraw?: boolean): Promise<void>;
    /**
     * Refine a residue range
     * @param {string} chainId - The chain ID for the residue range
     * @param {string} start - First residue number in the range
     * @param {string} stop - Last residue number in the range
     * @param {number} [ncyc=4000] - Number of refinement cycles
     * @param {boolean} [redraw=true] - Indicates if the molecule should be redrawn
     */
    refineResidueRange(chainId: string, start: number, stop: number, ncyc?: number, redraw?: boolean): Promise<void>;
    /**
     * Refine a residue CID with animation
     * @param {string[]} cid - The CID selection used to create the fragment
     * @param {moorhen.Map} activeMap - The map instance used in the refinement
     * @param {number} dist - The maximum distance used to get neighboring residues for the refinement. Use -1 for literal CID instead of neighbours.
     * @param {boolean} redraw - Indicate if the molecules should be redrawn
     * @param {boolean} redrawFragmentFirst - Indicate if the fragment should be redrawn first
     */
    refineResiduesUsingAtomCidAnimated(cid: string, activeMap: moorhen.Map, dist?: number, redraw?: boolean, redrawFragmentFirst?: boolean): Promise<void>;
    /**
     * Refine a molecule with animation effect
     * @param {number} n_cyc - The total number of refinement cycles for each iteration
     * @param {number} n_iteration - The number of iterations
     * @param {number} [final_n_cyc=100] - Number of refinement cycles in the last iteration
     */
    animateRefine(n_cyc: number, n_iteration: number, final_n_cyc?: number): Promise<void>;
    /**
     * Delete residues in a given CID
     * @param {string} cid - The CID to delete
     * @param {boolean} [redraw=true] - Indicates if the molecule should be redrawn
     * @returns {object} - A pair where first is the return status and second is the atom count of the molecule after deletion
     */
    deleteCid(cid: string, redraw?: boolean): Promise<libcootApi.PairType<number, number>>;
    /**
     * Use SSM to superpose this molecule (as the moving structure) with another molecule isntance
     * @param {string} movChainId - Chain ID for the moving structure
     * @param {string} refMolNo - Molecule number for the reference structure
     * @param {string} refChainId - Chain ID for the reference structure
     * @param {boolean} [redraw=true] - Indicates if the molecule should be redrawn
     */
    SSMSuperpose(movChainId: string, refMolNo: number, refChainId: string, redraw?: boolean): Promise<void>;
    /**
     * Use LSQKB to superpose this molecule (as the moving structure) with another molecule isntance
     * @param {string} refMolNo - Molecule number for the reference structure
     * @param {moorhen.lskqbResidueRangeMatch[]} residueMatches - A list of objects describing the residue matches for LSQKB
     * @param {number} [matchType=1] - The match type for LSQKB: 0 - all | 1 - main | 2 - CAs
     * @param {boolean} [redraw=true] - Indicates if the molecule should be redrawn
     */
    lsqkbSuperpose(refMolNo: number, residueMatches: moorhen.lskqbResidueRangeMatch[], matchType?: number, redraw?: boolean): Promise<void>;
    /**
     * A function to fit a given ligand
     * @param {number} mapMolNo - The map iMol that will be used for ligand fitting
     * @param {number} ligandMolNo - The ligand iMol that will be fitted
     * @param {boolean} [fitRightHere=true] - Indicates if the ligand should be fitted at the current origin
     * @param {boolean} [redraw=false] - Indicates if the fitted ligands should be drawn
     * @param {boolean} [useConformers=false] - Indicates if there is need to test multiple conformers
     * @param {number} [conformerCount=0] - Conformer count
     * @returns {Promise<moorhen.Molecule[]>} - A list of fitted ligands. When fitting anywhere, best correlation
     * with the map first, each with its correlation and the volume of its density blob in `metadata`
     * (FIT_CORRELATION_KEY, FIT_CLUSTER_VOLUME_KEY). Fitting right here gives no scores, in Coot's order.
     */
    fitLigand(mapMolNo: number, ligandMolNo: number, fitRightHere?: boolean, redraw?: boolean, useConformers?: boolean, conformerCount?: number): Promise<moorhen.Molecule[]>;
    /**
     * Get information about the residue B-factors
     * @returns {object[]} An array of objects indicating the residue CID and B-factor
     */
    getResidueBFactors(): {
        cid: string;
        bFactor: number;
        normalised_bFactor: number;
    }[];
    getResidueCAPositions(): Map<any, any>;
    /**
     * Calculate RMSF
     * @returns {object[]} An array of objects indicating the residue CID and RMSF
     */
    getRMSFs(): any[];
    /**
     * Get chain IDs that are related by NCS or molecular symmetry
     * @returns {string[][]} An array of arrays where chain IDs are grouped together
     */
    getNcsRelatedChains(): Promise<string[][]>;
    /**
     * A function to get the number of atoms in the current molecule
     * @returns {Promise<number>} The number of atoms in the molecule
     */
    getNumberOfAtoms(): Promise<number>;
    /**
     * Move the molecule to a new position
     * @param {number} x - Coordinate X
     * @param {number} y - Coordinate Y
     * @param {number} z - Coordinate Z
     */
    moveMoleculeHere(x: number, y: number, z: number): Promise<void>;
    /**
     * Parse a CID selection into a residue selection object
     * @param {string} cid - The CID selection
     * @returns {object} An object for the residue selection
     */
    parseCidIntoSelection(cid: string): Promise<moorhen.ResidueSelection>;
    /**
     * Test whether an atom selection is valid
     * @param {string} cid - The CID selection
     * @returns {boolean} Whether the selection is valid
     */
    isValidSelection(cid: string): Promise<boolean>;
    /**
     * Get the CIDs of residues not included in the input CID
     * @param {string} cid - The input CID selection
     * @returns {string[]} An array of CIDs for the residue ranges not included in the input CID
     */
    getNonSelectedCids(cid: string): string[];
    /**
     * Get the secondary structure information for the residues in the current molecule
     * @param {number} modelNumber - The model number to extract secondary structure information from
     * @returns {object[]} An array of objects containing the secondary structure information for each residue
     */
    getSecondaryStructInfo(modelNumber?: number): Promise<libcootApi.ResidueSpecJS[]>;
    /**
     * Export the current molecule as a gltf file in binary format
     * @param {string} representationId - The id of the representation to export
     * @returns {ArrayBuffer} - The contents of the gltf file in binary format
     */
    exportAsGltf(representationId: string): Promise<ArrayBuffer>;
    /**
     * Get results of privateer validation for this molecule instance
     * @param {boolean} useCache - Whether to use the cached results or not
     * @returns {Promise<privateer.ResultsEntry[]>} A list of results from privateer validation
     */
    getPrivateerValidation(useCache?: boolean): Promise<privateer.ResultsEntry[]>;
    /**
     * Get results of privateer validation for this molecule instance
     * @param {boolean} useCache - Whether to use the cached results or not
     * @returns {Promise<privateer.CremerPopleParameters[]>} A list of results from privateer validation
     */
    getPrivateerCremerPopleParameters(useCache?: boolean): Promise<privateer.CremerPopleParameters[]>;
    /**
     * Get SVG descriptions for the ligand environment
     * @param {string} cid - The selection string of the ligand to get SVG descriptions for
     */
    getFLEVSVG(cid: string): Promise<string>;
    /**
     * Get SVG descriptions for the ligands in this molecule instance
     * @param {string} resName - The name of the ligand to get SVG descriptions for
     * @param {boolean} useCache - Whether to use the cached results or not
     * @returns {Promise<string[]>} A list of SVG descriptions for the ligands in this molecule instance
     */
    getLigandSVG(resName: string, useCache?: boolean): Promise<string>;
    /**
     * Change the ID of a given chain
     * @param {string} oldId - The old chain ID
     * @param {string} newId - The new chain ID
     * @param {number} startResNo - The start residue number
     * @param {number} endResNo - The end residue number
     * @returns {number} - Status code -1 on a conflict, 1 on good, 0 on did nothing
     */
    changeChainId(oldId: string, newId: string, redraw?: boolean, startResNo?: number, endResNo?: number): Promise<number>;
    /**
     * Split a molecule with multiple models into separate molecules (one for each model)
     * @param {boolean} [draw=false] - Indicates whether the new molecules should be drawn
     * @returns {moorhen.Molecule[]} - A list with the new molecules
     */
    generateAssembly(assemblyNumber: string, draw?: boolean): Promise<moorhen.Molecule>;
    /**
     * Split a molecule with multiple models into separate molecules (one for each model)
     * @param {boolean} [draw=false] - Indicates whether the new molecules should be drawn
     * @param {boolean} [transferDicts=true] - Read this molecule's ligand dictionaries for each new molecule (false: the caller makes them available another way)
     * @returns {moorhen.Molecule[]} - A list with the new molecules
     */
    splitMultiModels(draw?: boolean, transferDicts?: boolean): Promise<moorhen.Molecule[]>;
    /**
     * Minimize the energy of a given set of residues (usually a ligand)
     * @param cid - The CID for the input residues
     * @param ncyc - The number of cycles
     * @param nIterations - The number of iterations
     * @param useRamaRestraints - Indicates whether ramachandran restraints should be used
     * @param ramaWeight - Indicates the weight assigned to ramachandran restraints
     * @param useTorsionRestraints - Indicates whether torsion restraints should be used
     * @param torsionWeight - Indicates the weight assigned to torsion restraints
     */
    minimizeEnergyUsingCidAnimated(cid: string, ncyc: number, nIterations: number, useRamaRestraints: boolean, ramaWeight: number, useTorsionRestraints: boolean, torsionWeight: number): Promise<void>;
    /**
     * Fetch header information for this molecule instance
     * @param {boolean} useCache - Whether to use the cached results or not
     * @returns {Promise<libcootApi.headerInfoJS>} Object containing header information
     */
    fetchHeaderInfo(useCache?: boolean): Promise<libcootApi.headerInfoJS>;
    /**
     * Calculate the Q-Score for a CID
     * @param {string} cid - The CID selection used to calcualte the qscore
     * @param {moorhen.Map} activeMap - The map instance used in the refinement
     */
    calculateQscore(activeMap: moorhen.Map, cid?: string): Promise<any>;
    get numberOfModels(): number;
}
//# sourceMappingURL=MoorhenMolecule.d.ts.map