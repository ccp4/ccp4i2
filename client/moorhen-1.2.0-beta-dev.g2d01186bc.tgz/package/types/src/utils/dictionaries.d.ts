import type { Store } from "@reduxjs/toolkit";
import type { CommandCentre } from "../InstanceManager/CommandCentre";
/** Record the queued dictionaries now, in one dispatch */
export declare const flushDictionaryRecords: (store: Store) => void;
/**
 * Keep queued dictionaries back past the end of the tick (true), until released (false) or flushed.
 * For a task reading many, each in its own tick (a batch of ligands of many types). Pair them
 * (try / finally): the last release records them.
 */
export declare const holdDictionaryRecords: (store: Store, hold: boolean) => void;
/** Coot's "every molecule" molecule number */
export declare const ALL_MOLECULES = -999999;
/**
 * Whether this dictionary text is already read for every molecule, as it is (each of its compounds,
 * with the same content). A molecule given it then needs no read of its own, only its cached copy
 * (cacheLigandDict): a thousand poses of one ligand share the one read.
 */
export declare const isReadForEveryMolecule: (store: Store, text: string) => boolean;
/**
 * Give molecules a dictionary that some other molecule was made with (fitted poses, from their
 * template's). One read for every molecule is theirs already: only cached on them, so that they save
 * it. One read for one molecule only is not, and is read for each of them (addDict).
 */
export declare const giveDictionary: (store: Store, molecules: {
    cacheLigandDict: (text: string) => void;
    addDict: (text: string) => Promise<void>;
}[], text: string | undefined) => Promise<void>;
/**
 * Split dictionary text into its data_comp_ blocks: [comp_id, block]. The data_comp_list block (the
 * list of what the file defines) is not a compound of its own: it stays at the start of the first one.
 */
export declare const splitDictionary: (text: string) => [string, string][];
/**
 * Read a ligand dictionary into Coot, for every molecule or for one, and record it in the instance's
 * list of loaded dictionaries (store `dictionaries`), which sessions save. Every path that loads a
 * dictionary goes through here (.roadmaps/ligand-dictionaries.md, phase 3), so the list is complete
 * whatever loaded it and whichever molecules are deleted later. Recorded at the end of the tick, with
 * the other dictionaries read in it (one dispatch). Caching on molecules
 * (molecule.ligandDicts) is still the caller's, as before.
 * @param molecule - The molecule to read it for; every molecule if omitted
 * @param source - Where it came from, for display
 */
export declare const readDictionary: (target: {
    store: Store;
    commandCentre: CommandCentre;
}, text: string, molecule?: {
    molNo: number;
    uniqueId?: string;
} | null, source?: string) => Promise<void>;
//# sourceMappingURL=dictionaries.d.ts.map