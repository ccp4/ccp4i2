/**
 * Turning a parsed cube grid into a CCP4/MRC map, in memory.
 *
 * WHY GO THROUGH A MAP AT ALL
 *
 * Moorhen already contours maps: Coot meshes them, the draw settings and colours already exist,
 * sessions already save them, and a difference map already draws a plus and a minus surface as one
 * object. A cube is the same thing - a scalar on a regular grid - so writing one out as a map buys
 * all of that instead of growing a second contouring path that would have to be kept in step.
 *
 * THREE THINGS THAT HAVE TO BE RIGHT, AND LOOK FINE WHEN THEY ARE NOT
 *
 * **The transpose.** A cube runs its last axis fastest; an MRC runs its *column* axis fastest. The
 * header can describe either, by permuting MAPC/MAPR/MAPS - which would let the data be copied
 * untouched. That is not done here. Plenty of code reads NX/NY/NZ as if they were x, y and z and
 * ignores the permutation, so a file that needs it is a file that half the world misreads. The
 * data is physically reordered into x-fastest and the mapping left at the identity, which is the
 * arrangement nothing can get wrong.
 *
 * **The cell.** MRC states a unit cell and a sampling, and the spacing is cell/sampling. With the
 * sampling set to the voxel counts, the cell is counts x step, so the two divide back to the step
 * the cube asked for. The angles come from the step vectors, so a skewed cube stays skewed.
 *
 * **The origin.** MRC can say where the grid sits in two ways - NXSTART/NYSTART/NZSTART in whole
 * voxels, or the ORIGIN words in angstrom - and readers disagree about which wins. Writing both
 * with different answers is the usual way a map ends up half a cell from its molecule. So the
 * origin is snapped to a whole number of voxels and *both* are written from that one snapped
 * value: whichever a reader honours, it gets the same answer. The snap moves the map by at most
 * half a voxel, which for these grids is a few hundredths of an angstrom, and `originShift`
 * reports it so a caller can check rather than trust.
 *
 * AND ONE THING THE MAP CANNOT SAY AT ALL
 *
 * A map is a crystal. Coot contours a sphere about a point and fills it, taking the cell to repeat
 * for ever - which for a 4 angstrom orbital box means asking for anything past 2 angstrom returns
 * the orbital *and its periodic images*, interleaved into a mess of surfaces that looks like a
 * badly positioned map rather than like a repeat. Nothing in the format can turn that off; the
 * only defence is to never ask for more than one cell's worth.
 *
 * So the conversion reports `safeRadius`, half the narrowest width of the cell less a voxel, and
 * that is the radius the map must be contoured at. A cube box is mostly empty - the writer pads it
 * around the molecule - so this is usually plenty. When it is not, the grid is padded with zeros
 * until it is: `padding` says by how much. Padding costs memory, so it is bounded, and
 * `clipsSignificantDensity` admits it when the bound bites.
 */
import type { CubeGrid } from "./cubeFile";
/** Bytes before the data in an MRC file. */
export declare const MRC_HEADER_BYTES = 1024;
export interface CubeMapResult {
    /** The file, ready for Coot's read_ccp4_map. */
    buffer: ArrayBuffer;
    /** How far the grid moved when its origin was snapped to whole voxels, in angstrom. */
    originShift: [number, number, number];
    /** Field statistics, as written into the header. */
    statistics: {
        min: number;
        max: number;
        mean: number;
        rms: number;
    };
    /** The centre of the map, in angstrom - where the contouring sphere belongs. */
    centre: [number, number, number];
    /**
     * The largest radius that can be contoured about `centre` without periodic images appearing.
     *
     * Contour past this and the cell repeats. There is no setting that prevents it, so this is a
     * limit rather than a suggestion.
     */
    safeRadius: number;
    /** Voxels of zero added at each end of each axis to make `safeRadius` reach the density. */
    padding: [number, number, number];
    /** True when the padding budget ran out and `safeRadius` still does not reach all of it. */
    clipsSignificantDensity: boolean;
}
/**
 * Write one field of a cube grid as an MRC map.
 *
 * @param grid the parsed cube.
 * @param values the field to write - one of `grid.fields[n].values`, so a multi-orbital cube can
 *     be written once per orbital without re-parsing.
 * @param options.label a line of provenance, stored in the header where a person will see it.
 * @param options.padding zero padding to add at each end of each axis, overriding what the field
 *     would choose for itself. Mostly for tests, which want the grid they wrote and not one grown
 *     underneath them.
 * @param options.asDifferenceMap the map will be loaded as a difference map, to draw its positive
 *     and negative lobes as one object. Coot will only allow that for a cell it does not read as
 *     orthogonal, so this nudges a cell angle - see EM_ANGLE_NUDGE.
 */
export declare function cubeFieldToMrc(grid: CubeGrid, values: Float32Array, options?: {
    label?: string;
    padding?: [number, number, number];
    asDifferenceMap?: boolean;
}): CubeMapResult;
/**
 * How much zero padding this field needs for its density to fit inside the contouring sphere.
 *
 * The sphere can only be as large as the cell's inscribed sphere, so the question is whether that
 * reaches the outermost density worth drawing. Usually it does - a cube writer pads the box around
 * the molecule, and an orbital occupies a small part of what it is given - and then this adds
 * nothing. When it does not, the cell is grown with zeros until it does, up to a budget.
 *
 * Measured from the field rather than from the box so an empty corner costs nothing.
 */
export declare const choosePadding: (grid: CubeGrid, values: Float32Array, steps: [number, number, number]) => {
    padding: [number, number, number];
    clipsSignificantDensity: boolean;
};
//# sourceMappingURL=cubeToMap.d.ts.map