import { type SurfaceMaps, type TextureSource } from "../WebGLgComponents/textureRegistry";
/**
 * Decodes one encoded image into raw pixels.
 *
 * Injected so the rest of this can be tested: jsdom has neither createImageBitmap nor
 * OffscreenCanvas, and a test that had to provide both would be testing the browser.
 */
export type ImageDecode = (bytes: Uint8Array, mimeType: string, use?: ImageUse) => Promise<TextureSource | null>;
/**
 * What an image is for. A base colour is a picture and is decoded as one. A normal or
 * metallic-roughness map is numbers stored as pixels: any colour-space conversion the browser
 * would make for an embedded profile or gamma chunk, and any premultiplication by alpha, changes
 * those numbers, so it is decoded with both turned off.
 */
export type ImageUse = "colour" | "data";
/**
 * The browser's own decoder.
 *
 * Row 0 of what getImageData returns is the top row, which is the convention the texture registry
 * uploads to and the one glTF's coordinates assume, so nothing is flipped on the way through.
 */
export declare const decodeImageInBrowser: ImageDecode;
/** What one material is drawn with: a base colour texture, and maps. */
export interface GltfMaterial {
    baseColour?: string;
    maps?: SurfaceMaps;
}
/**
 * Each material's textures: the base colour, and the normal and metallic-roughness maps.
 *
 * @param bytes - The .gltf or .glb as read.
 * @param available - Image and buffer files already in hand, keyed by the URI the document uses.
 * @param decode - How to turn encoded image bytes into pixels.
 * @returns material index -> what it has. Materials absent from it draw untextured.
 */
export declare const gltfMaterials: (bytes: ArrayBuffer, available: Map<string, Uint8Array>, decode?: ImageDecode) => Promise<Map<number, GltfMaterial>>;
//# sourceMappingURL=gltfTextures.d.ts.map