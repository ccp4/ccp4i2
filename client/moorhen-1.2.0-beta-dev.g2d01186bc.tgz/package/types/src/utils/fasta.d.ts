export type FastaSequence = {
    name: string;
    seq: string;
};
/**
 * Parse FASTA text into its sequences.
 *
 * Header lines start with ">" (or ";", as biojs-io-fasta accepted); every other line is appended
 * to the current sequence. Lines before the first header are ignored, and so is whitespace,
 * including the "\r" left by Windows line endings.
 */
export declare const parseFasta: (text: string) => FastaSequence[];
//# sourceMappingURL=fasta.d.ts.map