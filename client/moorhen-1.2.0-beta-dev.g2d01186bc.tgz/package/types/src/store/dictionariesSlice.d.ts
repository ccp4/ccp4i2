/**
 * A ligand dictionary read into Coot: one entry per data_comp_ block. The instance's one list of
 * them (.roadmaps/ligand-dictionaries.md, phase 1), filled by readDictionary (utils/dictionaries.ts)
 * whatever loaded it, and saved in sessions. Deleting the molecule a dictionary came with does not
 * remove it (Coot keeps it too), unless it was read for that molecule only.
 */
export type LoadedDictionary = {
    compId: string;
    /** That block only, as molecule.ligandDicts holds it */
    content: string;
    /** Read for one molecule only (its uniqueId: a molNo changes when a session is reloaded); null for every molecule */
    moleculeUid: string | null;
    /** Where it came from, for display: a file name, "monomer library", "SMILES"... */
    source?: string;
};
/** The key of an entry: the same comp_id may be read for every molecule and for one molecule */
export declare const dictionaryKey: (dictionary: Pick<LoadedDictionary, "compId" | "moleculeUid">) => string;
export declare const addDictionaries: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<LoadedDictionary[], "dictionaries/addDictionaries">, emptyDictionaries: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"dictionaries/emptyDictionaries">;
declare const _default: import("redux").Reducer<{
    loaded: {
        [x: string]: {
            compId: string;
            content: string;
            moleculeUid: string | null;
            source?: string;
        };
    };
}>;
export default _default;
//# sourceMappingURL=dictionariesSlice.d.ts.map