import { MoorhenMap } from "../utils/MoorhenMap";
import { MoorhenMolecule } from "../utils/MoorhenMolecule";
export type ResidueSelection = {
    molecule: null | MoorhenMolecule;
    first: null | string;
    second: null | string;
    cid: null | string | string[];
    isMultiCid: boolean;
    label: string;
};
export declare const setSelectedThreeDObject: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "generalStates/setSelectedThreeDObject">, setSelected2DObject: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "generalStates/setSelected2DObject">, setMovingMapSlice: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "generalStates/setMovingMapSlice">, setActiveMap: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMap, "generalStates/setActiveMap">, setViewOnly: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "generalStates/setViewOnly">, setTheme: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "generalStates/setTheme">, setIsDraggingAtoms: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "generalStates/setIsDraggingAtoms">, setAppTittle: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "generalStates/setAppTittle">, setUserPreferencesMounted: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "generalStates/setUserPreferencesMounted">, setDevMode: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "generalStates/setDevMode">, setCootInitialized: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "generalStates/setCootInitialized">, setStopResidueSelection: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "generalStates/setStopResidueSelection">, setStartResidueSelection: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "generalStates/setStartResidueSelection">, clearResidueSelection: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"generalStates/clearResidueSelection">, setMoleculeResidueSelection: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMolecule, "generalStates/setMoleculeResidueSelection">, setResidueSelection: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<ResidueSelection, "generalStates/setResidueSelection">, setCidResidueSelection: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "generalStates/setCidResidueSelection">, setIsRotatingAtoms: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "generalStates/setIsRotatingAtoms">, setIsChangingRotamers: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "generalStates/setIsChangingRotamers">, setShowResidueSelection: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "generalStates/setShowResidueSelection">, toggleCootCommandExit: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"generalStates/toggleCootCommandExit">, toggleCootCommandStart: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"generalStates/toggleCootCommandStart">, setIsAnimatingTrajectory: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "generalStates/setIsAnimatingTrajectory">, resetGeneralStates: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"generalStates/resetGeneralStates">, setIsShowingTomograms: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "generalStates/setIsShowingTomograms">, setJobProgress: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    label: string;
    done: number;
    total: number;
}, "generalStates/setJobProgress">, setLigandBatchLoading: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "generalStates/setLigandBatchLoading">, setDefaultExpandDisplayCards: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "generalStates/setDefaultExpandDisplayCards">, setTransparentModalsOnMouseOut: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "generalStates/setTransparentModalsOnMouseOut">, setUseGemmi: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "generalStates/setUseGemmi">, setShowHoverInfo: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "generalStates/setShowHoverInfo">, setAllowScripting: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "generalStates/setAllowScripting">, setAllowAddNewFittedLigand: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "generalStates/setAllowAddNewFittedLigand">, setAllowMergeFittedLigand: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "generalStates/setAllowMergeFittedLigand">, setDisableFileUpload: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "generalStates/setDisableFileUpload">;
declare const _default: import("redux").Reducer<{
    devMode: boolean;
    useGemmi: boolean;
    userPreferencesMounted: boolean;
    appTitle: string;
    cootInitialized: boolean;
    activeMap: MoorhenMap;
    theme: string;
    residueSelection: ResidueSelection;
    selectedThreeDObjectId: string | null;
    /** Which 2D overlay object is showing its handles, or none. Like selectedThreeDObjectId. */
    selected2DObjectId: string | null;
    /** Which map's 2D slice is showing manipulation handles, or none (by its molNo). */
    movingMapSlice: number | null;
    isShowingTomograms: boolean;
    /** Progress of a long task that reports it (e.g. files.batchLoadLigands), shown by the long job notification */
    jobProgress: {
        label: string;
        done: number;
        total: number;
    } | null;
    /** How many files.batchLoadLigands are running: the ligand list waits for them to end before rendering its rows */
    ligandBatchLoads: number;
    isAnimatingTrajectory: boolean;
    isChangingRotamers: boolean;
    isDraggingAtoms: boolean;
    isRotatingAtoms: boolean;
    newCootCommandExit: boolean;
    newCootCommandStart: boolean;
    useRamaRefinementRestraints: boolean;
    useTorsionRefinementRestraints: false;
    showResidueSelection: boolean;
    defaultExpandDisplayCards: boolean;
    transparentModalsOnMouseOut: boolean;
    showHoverInfo: boolean;
    viewOnly: boolean;
    allowScripting: boolean;
    /** @deprecated Read by nothing: the Fit ligand modal always offers to save a pose as a new molecule. */
    allowAddNewFittedLigand: boolean;
    /** @deprecated Read by nothing: the Fit ligand modal no longer merges a pose into the model. */
    allowMergeFittedLigand: boolean;
    disableFileUpload: boolean;
}>;
export default _default;
//# sourceMappingURL=generalStatesSlice.d.ts.map