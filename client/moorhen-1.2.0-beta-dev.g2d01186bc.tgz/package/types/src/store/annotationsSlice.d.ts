import { Tags } from "../utils/tags";
import type { MoorhenTextStyle } from "../utils/textStyle";
/** Where an annotation is: a fixed point, or the centre of the atoms a selection picks out. */
export type AnnotationPositionMode = "point" | "atom";
/**
 * A text label placed in the 3D scene, as CCP4MG's annotations.
 *
 * The text keeps a constant size on screen (fontPixelSize, in CSS pixels) whatever the zoom; only
 * its position is in the scene. The style fields are the ones 2D text overlays use, and are set
 * with the same editor.
 */
export interface MoorhenAnnotation extends MoorhenTextStyle {
    uniqueId: string;
    positionMode: AnnotationPositionMode;
    /** The position for positionMode "point", in Angstroms. */
    x: number;
    y: number;
    z: number;
    /** The molecule and selection for positionMode "atom". Several atoms give their centroid. */
    molUniqueId?: string;
    cid?: string;
    /** Draw over everything rather than hidden by what is in front of it, and without fog. */
    alwaysOnTop?: boolean;
    /** Who made this annotation, and how it should group. See utils/tags. */
    tags?: Tags;
    /** Set by an owner to mean "do not edit in place"; the API's edit leaves a locked one alone. */
    locked?: boolean;
}
/**
 * A default annotation, with any fields given in place of the defaults.
 *
 * The colour is left out, so that until one is chosen the text is white or black, whichever
 * stands out from the background.
 */
export declare const newAnnotation: (overrides?: Partial<MoorhenAnnotation>) => MoorhenAnnotation;
export declare const addAnnotation: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenAnnotation, "annotations/addAnnotation">, addAnnotations: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenAnnotation[], "annotations/addAnnotations">, updateAnnotation: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    uniqueId: string;
    changes: Partial<Omit<MoorhenAnnotation, "uniqueId">>;
}, "annotations/updateAnnotation">, removeAnnotationById: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "annotations/removeAnnotationById">, removeAnnotationsByTag: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<Tags, "annotations/removeAnnotationsByTag">, emptyAnnotations: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"annotations/emptyAnnotations">;
declare const _default: import("redux").Reducer<{
    annotationsList: MoorhenAnnotation[];
}>;
export default _default;
//# sourceMappingURL=annotationsSlice.d.ts.map