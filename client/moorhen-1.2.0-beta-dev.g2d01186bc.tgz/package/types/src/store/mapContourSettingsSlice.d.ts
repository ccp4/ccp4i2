import { MoorhenMap } from "../utils/MoorhenMap";
import type { MapSlicePlacement, SliceContourSpacing } from "../utils/mapSlice/mapSlice";
/**
 * How a map is drawn: as a mesh, a surface or lit lines in 3D, or as a contoured 2D slice through
 * it (mapSlice.ts).
 */
export type MapStyle = "solid" | "lit-lines" | "lines" | "slice";
export declare const showMap: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMap, "mapContourSettings/showMap">, hideMap: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMap, "mapContourSettings/hideMap">, setContourLevel: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    molNo: number;
    contourLevel: number;
}, "mapContourSettings/setContourLevel">, setMapRadius: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    molNo: number;
    radius: number;
}, "mapContourSettings/setMapRadius">, setMapFastRadius: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    molNo: number;
    radius: number | null;
}, "mapContourSettings/setMapFastRadius">, setMapAlpha: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    molNo: number;
    alpha: number;
}, "mapContourSettings/setMapAlpha">, setMapStyle: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    molNo: number;
    style: MapStyle;
}, "mapContourSettings/setMapStyle">, setMapSlice: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    molNo: number;
} & MapSlicePlacement, "mapContourSettings/setMapSlice">, setMapSliceNodalLines: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    molNo: number;
    show: boolean;
}, "mapContourSettings/setMapSliceNodalLines">, setMapSliceContourSpacing: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    molNo: number;
    spacing: SliceContourSpacing;
}, "mapContourSettings/setMapSliceContourSpacing">, changeMapRadius: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    molNo: number;
    factor: number;
}, "mapContourSettings/changeMapRadius">, setDefaultMapSamplingRate: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "mapContourSettings/setDefaultMapSamplingRate">, setDefaultMapLitLines: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "mapContourSettings/setDefaultMapLitLines">, setMapLineWidth: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "mapContourSettings/setMapLineWidth">, setDefaultMapSurface: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "mapContourSettings/setDefaultMapSurface">, setMapColours: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    molNo: number;
    rgb: {
        r: number;
        g: number;
        b: number;
    };
}, "mapContourSettings/setMapColours">, setNegativeMapColours: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    molNo: number;
    rgb: {
        r: number;
        g: number;
        b: number;
    };
}, "mapContourSettings/setNegativeMapColours">, setPositiveMapColours: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    molNo: number;
    rgb: {
        r: number;
        g: number;
        b: number;
    };
}, "mapContourSettings/setPositiveMapColours">, changeContourLevel: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    molNo: number;
    factor: number;
}, "mapContourSettings/changeContourLevel">, setReContourMapOnlyOnMouseUp: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "mapContourSettings/setReContourMapOnlyOnMouseUp">, resetMapContourSettings: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"mapContourSettings/resetMapContourSettings">;
declare const _default: import("redux").Reducer<{
    visibleMaps: number[];
    contourLevels: {
        molNo: number;
        contourLevel: number;
    }[];
    mapRadii: {
        molNo: number;
        radius: number;
    }[];
    mapFastRadii: {
        molNo: number;
        radius: number | null;
    }[];
    mapAlpha: {
        molNo: number;
        alpha: number;
    }[];
    mapStyles: {
        molNo: number;
        style: MapStyle;
    }[];
    /**
     * Each map's 2D slice, where it was last put: kept when the map is drawn another way, so that
     * going back to the slice finds it where it was.
     */
    mapSlices: ({
        molNo: number;
    } & MapSlicePlacement)[];
    /** The maps whose 2D slice shows its nodal lines (the zero contour), by molNo. */
    mapSliceNodalLines: number[];
    /** How each map's 2D slice spaces its contours, where not the default (mapSlice.ts). */
    mapSliceContourSpacings: {
        molNo: number;
        spacing: SliceContourSpacing;
    }[];
    defaultMapSamplingRate: number;
    defaultMapLitLines: boolean;
    mapLineWidth: number;
    defaultMapSurface: boolean;
    mapColours: {
        molNo: number;
        rgb: {
            r: number;
            g: number;
            b: number;
        };
    }[];
    negativeMapColours: {
        molNo: number;
        rgb: {
            r: number;
            g: number;
            b: number;
        };
    }[];
    positiveMapColours: {
        molNo: number;
        rgb: {
            r: number;
            g: number;
            b: number;
        };
    }[];
    reContourMapOnlyOnMouseUp: boolean;
}>;
export default _default;
//# sourceMappingURL=mapContourSettingsSlice.d.ts.map