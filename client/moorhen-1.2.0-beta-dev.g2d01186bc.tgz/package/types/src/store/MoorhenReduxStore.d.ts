import { type AnyAction, type Store } from "@reduxjs/toolkit";
import type { ThunkDispatch } from "redux-thunk";
export declare const reducers: {
    molecules: import("redux").Reducer<{
        visibleMolecules: number[];
        moleculeRecords: Record<string, import("./moleculesSlice").MoleculeRecord>;
        moleculeList: import("../utils").MoorhenMolecule[];
        customRepresentations: import("../types/moorhen").moorhen.MoleculeRepresentation[];
        generalRepresentations: import("../types/moorhen").moorhen.MoleculeRepresentation[];
    }>;
    dictionaries: import("redux").Reducer<{
        loaded: {
            [x: string]: {
                compId: string;
                content: string;
                moleculeUid: string | null;
                source?: string;
            };
        };
    }>;
    maps: import("redux").Reducer<import("../utils").MoorhenMap[]>;
    mouseSettings: import("redux").Reducer<{
        contourWheelSensitivityFactor: number;
        zoomWheelSensitivityFactor: number;
        mouseSensitivity: number;
    }>;
    backupSettings: import("redux").Reducer<{
        enableTimeCapsule: boolean;
        makeBackups: boolean;
        maxBackupCount: number;
        modificationCountBackupThreshold: number;
    }>;
    shortcutSettings: import("redux").Reducer<{
        shortcutOnHoveredAtom: boolean;
        showShortcutToast: boolean;
        shortCuts: string;
    }>;
    labelSettings: import("redux").Reducer<{
        atomLabelDepthMode: boolean;
        GLLabelsFontFamily: string;
        GLLabelsFontSize: number;
        availableFonts: string[];
    }>;
    sceneSettings: import("redux").Reducer<{
        origin: [number, number, number];
        zoom: number;
        drawScaleBar: boolean;
        drawCrosshairs: boolean;
        drawAxes: boolean;
        drawEnvBOcc: boolean;
        drawFPS: boolean;
        drawMissingLoops: boolean;
        fogClipOffset: number;
        fogStart: number;
        fogEnd: number;
        clipStart: number;
        clipEnd: number;
        doPerspectiveProjection: boolean;
        useOffScreenBuffers: boolean;
        depthBlurRadius: number;
        depthPeelLayers: number;
        peelOpaqueSeparately: boolean;
        useWebGPU: boolean;
        anaglyphColours: import("../WebGLgComponents/anaglyph").AnaglyphColours;
        depthBlurDepth: number;
        lightPosition: [number, number, number, number];
        ambient: [number, number, number, number];
        specular: [number, number, number, number];
        diffuse: [number, number, number, number];
        specularPower: number;
        ssaoBias: number;
        ssaoRadius: number;
        doShadowDepthDebug: boolean;
        doShadow: boolean;
        shadowMapQuality: import("../WebGLgComponents/shadowMapQuality").ShadowMapQuality;
        shadowSoftness: number;
        doSSAO: boolean;
        doEdgeDetect: boolean;
        edgeDetectDepthThreshold: number;
        edgeDetectNormalThreshold: number;
        edgeDetectDepthScale: number;
        edgeDetectNormalScale: number;
        doSpin: boolean;
        doThreeWayView: boolean;
        multiViewRows: number;
        multiViewColumns: number;
        threeWayViewOrder: string;
        specifyMultiViewRowsColumns: boolean;
        doSideBySideStereo: boolean;
        doMultiView: boolean;
        doCrossEyedStereo: boolean;
        doAnaglyphStereo: boolean;
        defaultBondSmoothness: number;
        autoFog: boolean;
        autoClip: boolean;
        doFog: boolean;
        doClip: boolean;
        defaultRepresentationStyle: import("./sceneSettingsSlice").DefaultRepresentationStyle;
        clipCap: boolean;
        backgroundColor: [number, number, number, number];
        height: number;
        width: number;
        GlViewportHeight: number;
        GlViewportWidth: number;
        isDark: boolean;
    }>;
    generalStates: import("redux").Reducer<{
        devMode: boolean;
        useGemmi: boolean;
        userPreferencesMounted: boolean;
        appTitle: string;
        cootInitialized: boolean;
        activeMap: import("../utils").MoorhenMap;
        theme: string;
        residueSelection: import("./generalStatesSlice").ResidueSelection;
        selectedThreeDObjectId: string | null;
        selected2DObjectId: string | null;
        movingMapSlice: number | null;
        isShowingTomograms: boolean;
        jobProgress: {
            label: string;
            done: number;
            total: number;
        } | null;
        ligandBatchLoads: number;
        isAnimatingTrajectory: boolean;
        isChangingRotamers: boolean;
        isDraggingAtoms: boolean;
        isRotatingAtoms: boolean;
        newCootCommandExit: boolean;
        newCootCommandStart: boolean;
        useRamaRefinementRestraints: boolean;
        useTorsionRefinementRestraints: false;
        showResidueSelection: boolean;
        defaultExpandDisplayCards: boolean;
        transparentModalsOnMouseOut: boolean;
        showHoverInfo: boolean;
        viewOnly: boolean;
        allowScripting: boolean;
        allowAddNewFittedLigand: boolean;
        allowMergeFittedLigand: boolean;
        disableFileUpload: boolean;
    }>;
    hoveringStates: import("redux").Reducer<{
        enableAtomHovering: boolean;
        hoveredAtom: import("./hoveringStatesSlice").HoveredAtom;
        hoveredSection: import("./hoveringStatesSlice").HoveredSection | null;
        cursorStyle: string;
    }>;
    modals: import("redux").Reducer<{
        activeModals: import("./modalsSlice").ModalCall[];
        focusHierarchy: import("../moorhen").ModalKey[];
    }>;
    mapContourSettings: import("redux").Reducer<{
        visibleMaps: number[];
        contourLevels: {
            molNo: number;
            contourLevel: number;
        }[];
        mapRadii: {
            molNo: number;
            radius: number;
        }[];
        mapFastRadii: {
            molNo: number;
            radius: number | null;
        }[];
        mapAlpha: {
            molNo: number;
            alpha: number;
        }[];
        mapStyles: {
            molNo: number;
            style: import("./mapContourSettingsSlice").MapStyle;
        }[];
        mapSlices: ({
            molNo: number;
        } & import("../utils/mapSlice/mapSlice").MapSlicePlacement)[];
        mapSliceNodalLines: number[];
        mapSliceContourSpacings: {
            molNo: number;
            spacing: import("../utils/mapSlice/mapSlice").SliceContourSpacing;
        }[];
        defaultMapSamplingRate: number;
        defaultMapLitLines: boolean;
        mapLineWidth: number;
        defaultMapSurface: boolean;
        mapColours: {
            molNo: number;
            rgb: {
                r: number;
                g: number;
                b: number;
            };
        }[];
        negativeMapColours: {
            molNo: number;
            rgb: {
                r: number;
                g: number;
                b: number;
            };
        }[];
        positiveMapColours: {
            molNo: number;
            rgb: {
                r: number;
                g: number;
                b: number;
            };
        }[];
        reContourMapOnlyOnMouseUp: boolean;
    }>;
    moleculeMapUpdate: import("redux").Reducer<{
        updatingMapsIsEnabled: boolean;
        connectedMolecule: number;
        reflectionMap: number;
        twoFoFcMap: number;
        foFcMap: number;
        uniqueMaps: number[];
        defaultUpdatingScores: string[];
        showScoresToast: boolean;
        moleculeUpdate: {
            switch: boolean;
            molNo: number;
        };
        currentScores: {
            rFactor: number;
            rFree: number;
            moorhenPoints: number;
        };
        currentScoreDiffs: {
            rFactor: number;
            rFree: number;
            moorhenPoints: number;
        };
    }>;
    sharedSession: import("redux").Reducer<{
        isInSharedSession: boolean;
        sharedSessionToken: string;
        showSharedSessionManager: boolean;
    }>;
    refinementSettings: import("redux").Reducer<{
        useRamaRefinementRestraints: boolean;
        useTorsionRefinementRestraints: boolean;
        enableRefineAfterMod: boolean;
        animateRefine: boolean;
        refinementSelection: "SINGLE" | "TRIPLE" | "SPHERE";
    }>;
    lhasa: import("redux").Reducer<{
        rdkitMoleculePickleList: {
            cid: string;
            moleculeMolNo: number;
            ligandName: string;
            pickle: string;
            id: string;
        }[];
    }>;
    sliceNDice: import("redux").Reducer<{
        paeFileIsUploaded: boolean;
        thresholdType: "b-factor-norm" | "af2-plddt";
        moleculeBfactors: {
            cid: string;
            bFactor: number;
            normalised_bFactor: number;
        }[];
        moleculeMinBfactor: number;
        moleculeMaxBfactor: number;
        bFactorThreshold: number;
        nClusters: number;
        clusteringType: string;
        slicingResults: import("../utils").MoorhenMolecule[];
        paeFileContents: {
            fileContents: string;
            fileName: string;
        }[];
    }>;
    jsonValidation: import("redux").Reducer<{
        validationJson: {
            sections: any;
            title: string;
        };
    }>;
    mrParse: import("redux").Reducer<{
        mrParseModels: import("../utils").MoorhenMolecule[];
        targetSequence: string;
        afJson: any[];
        esmJson: any[];
        homologsJson: any[];
        afSortField: string;
        homologsSortField: string;
        afSortReversed: boolean;
        homologsSortReversed: boolean;
        AFDisplaySettings: any;
        HomologsDisplaySettings: any;
    }>;
    glRef: import("redux").Reducer<{
        isWebGL2: boolean;
        glCtx: any;
        displayBuffers: import("../WebGLgComponents/displayBuffer").DisplayBuffer[];
        activeMolecule: import("../utils").MoorhenMolecule;
        draggableMolecule: import("../utils").MoorhenMolecule;
        quat: any[];
        cursorPosition: [number, number];
        shortCutHelp: string[];
        requestDrawScene: {
            count: number;
        };
        drawsThrottled: number;
        envUpdate: {
            switch: boolean;
        };
        clearLabels: {
            switch: boolean;
        };
        hoverSize: number;
        labelBuffers: any[];
        texturedShapes: any[];
        canvasSize: [number, number];
        rttFramebufferSize: [number, number];
        elementsIndicesRestrict: boolean;
    }>;
    overlays: import("redux").Reducer<{
        imageOverlayList: import("./overlaysSlice").Overlay2DImageSrcFrac[];
        textOverlayList: import("./overlaysSlice").Overlay2DTextFrac[];
        svgPathOverlayList: import("./overlaysSlice").Overlay2DSvgPath[];
        fracPathOverlayList: import("./overlaysSlice").Overlay2DFracPath[];
        shapeOverlayList: import("./overlaysSlice").Overlay2DShape[];
        callBacks: Function[];
    }>;
    threeDObjects: import("redux").Reducer<{
        objects: import("./threeDObjectsSlice").ThreeDObject[];
    }>;
    menus: import("redux").Reducer<{
        settings: Record<string, Record<string, unknown>>;
    }>;
    globalUI: import("redux").Reducer<{
        busy: boolean;
        isTimeCapsuleBusy: boolean;
        isGlobalInstanceReady: boolean;
        isMainMenuOpen: boolean;
        isSceneSelectorOpen: boolean;
        isSearchBarActive: boolean;
        areShortcutsBlocked: boolean;
        shownSidePanel: import("../moorhen").SidePanelIDs | null;
        sidePanelWidth: number;
        bottomPanelHeight: number | null;
        shownControl: import("../moorhen").ShownControl | null;
        controlLocked: number | null;
        selectionToolsActive: boolean;
        clickAwayListenerPauseCount: number;
    }>;
    bottomPanels: import("redux").Reducer<{
        shownBottomPanel: import("../moorhen").BottomPanelIDs;
        seqviewerOption: import("../moorhen").SequenceViewerOption;
        validationOption: import("../moorhen").ValidationOption;
    }>;
    vectors: import("redux").Reducer<{
        vectorsList: import("./vectorsSlice").MoorhenVector[];
    }>;
    annotations: import("redux").Reducer<{
        annotationsList: import("./annotationsSlice").MoorhenAnnotation[];
    }>;
    snackBars: import("redux").Reducer<import("./snackbarSlice").Snackbar[]>;
    userScenes: import("redux").Reducer<{
        scenes: import("./userScenesSlice").UserScene[];
        snapshots: import("./userScenesSlice").UserScene[];
        selectedScene: string;
        isSceneChanging: boolean;
        shownRevision: number;
        savedSceneSettings: Record<import("./userScenesSlice").BuiltInSceneId, import("./sceneSettingsSlice").PerSceneSettings>;
    }>;
    movie: import("redux").Reducer<import("./movieSlice").MovieState>;
};
export type RootState = {
    [K in keyof typeof reducers]: ReturnType<(typeof reducers)[K]>;
};
export type MoorhenReduxStoreType = Store<RootState, AnyAction>;
export type AppDispatch = ThunkDispatch<RootState, undefined, AnyAction>;
export declare const createMoorhenStore: () => import("@reduxjs/toolkit").EnhancedStore<{
    molecules: {
        visibleMolecules: number[];
        moleculeRecords: Record<string, import("./moleculesSlice").MoleculeRecord>;
        moleculeList: import("../utils").MoorhenMolecule[];
        customRepresentations: import("../types/moorhen").moorhen.MoleculeRepresentation[];
        generalRepresentations: import("../types/moorhen").moorhen.MoleculeRepresentation[];
    };
    dictionaries: {
        loaded: {
            [x: string]: {
                compId: string;
                content: string;
                moleculeUid: string | null;
                source?: string;
            };
        };
    };
    maps: import("../utils").MoorhenMap[];
    mouseSettings: {
        contourWheelSensitivityFactor: number;
        zoomWheelSensitivityFactor: number;
        mouseSensitivity: number;
    };
    backupSettings: {
        enableTimeCapsule: boolean;
        makeBackups: boolean;
        maxBackupCount: number;
        modificationCountBackupThreshold: number;
    };
    shortcutSettings: {
        shortcutOnHoveredAtom: boolean;
        showShortcutToast: boolean;
        shortCuts: string;
    };
    labelSettings: {
        atomLabelDepthMode: boolean;
        GLLabelsFontFamily: string;
        GLLabelsFontSize: number;
        availableFonts: string[];
    };
    sceneSettings: {
        origin: [number, number, number];
        zoom: number;
        drawScaleBar: boolean;
        drawCrosshairs: boolean;
        drawAxes: boolean;
        drawEnvBOcc: boolean;
        drawFPS: boolean;
        drawMissingLoops: boolean;
        fogClipOffset: number;
        fogStart: number;
        fogEnd: number;
        clipStart: number;
        clipEnd: number;
        doPerspectiveProjection: boolean;
        useOffScreenBuffers: boolean;
        depthBlurRadius: number;
        depthPeelLayers: number;
        peelOpaqueSeparately: boolean;
        useWebGPU: boolean;
        anaglyphColours: import("../WebGLgComponents/anaglyph").AnaglyphColours;
        depthBlurDepth: number;
        lightPosition: [number, number, number, number];
        ambient: [number, number, number, number];
        specular: [number, number, number, number];
        diffuse: [number, number, number, number];
        specularPower: number;
        ssaoBias: number;
        ssaoRadius: number;
        doShadowDepthDebug: boolean;
        doShadow: boolean;
        shadowMapQuality: import("../WebGLgComponents/shadowMapQuality").ShadowMapQuality;
        shadowSoftness: number;
        doSSAO: boolean;
        doEdgeDetect: boolean;
        edgeDetectDepthThreshold: number;
        edgeDetectNormalThreshold: number;
        edgeDetectDepthScale: number;
        edgeDetectNormalScale: number;
        doSpin: boolean;
        doThreeWayView: boolean;
        multiViewRows: number;
        multiViewColumns: number;
        threeWayViewOrder: string;
        specifyMultiViewRowsColumns: boolean;
        doSideBySideStereo: boolean;
        doMultiView: boolean;
        doCrossEyedStereo: boolean;
        doAnaglyphStereo: boolean;
        defaultBondSmoothness: number;
        autoFog: boolean;
        autoClip: boolean;
        doFog: boolean;
        doClip: boolean;
        defaultRepresentationStyle: import("./sceneSettingsSlice").DefaultRepresentationStyle;
        clipCap: boolean;
        backgroundColor: [number, number, number, number];
        height: number;
        width: number;
        GlViewportHeight: number;
        GlViewportWidth: number;
        isDark: boolean;
    };
    generalStates: {
        devMode: boolean;
        useGemmi: boolean;
        userPreferencesMounted: boolean;
        appTitle: string;
        cootInitialized: boolean;
        activeMap: import("../utils").MoorhenMap;
        theme: string;
        residueSelection: import("./generalStatesSlice").ResidueSelection;
        selectedThreeDObjectId: string | null;
        selected2DObjectId: string | null;
        movingMapSlice: number | null;
        isShowingTomograms: boolean;
        jobProgress: {
            label: string;
            done: number;
            total: number;
        } | null;
        ligandBatchLoads: number;
        isAnimatingTrajectory: boolean;
        isChangingRotamers: boolean;
        isDraggingAtoms: boolean;
        isRotatingAtoms: boolean;
        newCootCommandExit: boolean;
        newCootCommandStart: boolean;
        useRamaRefinementRestraints: boolean;
        useTorsionRefinementRestraints: false;
        showResidueSelection: boolean;
        defaultExpandDisplayCards: boolean;
        transparentModalsOnMouseOut: boolean;
        showHoverInfo: boolean;
        viewOnly: boolean;
        allowScripting: boolean;
        allowAddNewFittedLigand: boolean;
        allowMergeFittedLigand: boolean;
        disableFileUpload: boolean;
    };
    hoveringStates: {
        enableAtomHovering: boolean;
        hoveredAtom: import("./hoveringStatesSlice").HoveredAtom;
        hoveredSection: import("./hoveringStatesSlice").HoveredSection | null;
        cursorStyle: string;
    };
    modals: {
        activeModals: import("./modalsSlice").ModalCall[];
        focusHierarchy: import("../moorhen").ModalKey[];
    };
    mapContourSettings: {
        visibleMaps: number[];
        contourLevels: {
            molNo: number;
            contourLevel: number;
        }[];
        mapRadii: {
            molNo: number;
            radius: number;
        }[];
        mapFastRadii: {
            molNo: number;
            radius: number | null;
        }[];
        mapAlpha: {
            molNo: number;
            alpha: number;
        }[];
        mapStyles: {
            molNo: number;
            style: import("./mapContourSettingsSlice").MapStyle;
        }[];
        mapSlices: ({
            molNo: number;
        } & import("../utils/mapSlice/mapSlice").MapSlicePlacement)[];
        mapSliceNodalLines: number[];
        mapSliceContourSpacings: {
            molNo: number;
            spacing: import("../utils/mapSlice/mapSlice").SliceContourSpacing;
        }[];
        defaultMapSamplingRate: number;
        defaultMapLitLines: boolean;
        mapLineWidth: number;
        defaultMapSurface: boolean;
        mapColours: {
            molNo: number;
            rgb: {
                r: number;
                g: number;
                b: number;
            };
        }[];
        negativeMapColours: {
            molNo: number;
            rgb: {
                r: number;
                g: number;
                b: number;
            };
        }[];
        positiveMapColours: {
            molNo: number;
            rgb: {
                r: number;
                g: number;
                b: number;
            };
        }[];
        reContourMapOnlyOnMouseUp: boolean;
    };
    moleculeMapUpdate: {
        updatingMapsIsEnabled: boolean;
        connectedMolecule: number;
        reflectionMap: number;
        twoFoFcMap: number;
        foFcMap: number;
        uniqueMaps: number[];
        defaultUpdatingScores: string[];
        showScoresToast: boolean;
        moleculeUpdate: {
            switch: boolean;
            molNo: number;
        };
        currentScores: {
            rFactor: number;
            rFree: number;
            moorhenPoints: number;
        };
        currentScoreDiffs: {
            rFactor: number;
            rFree: number;
            moorhenPoints: number;
        };
    };
    sharedSession: {
        isInSharedSession: boolean;
        sharedSessionToken: string;
        showSharedSessionManager: boolean;
    };
    refinementSettings: {
        useRamaRefinementRestraints: boolean;
        useTorsionRefinementRestraints: boolean;
        enableRefineAfterMod: boolean;
        animateRefine: boolean;
        refinementSelection: "SINGLE" | "TRIPLE" | "SPHERE";
    };
    lhasa: {
        rdkitMoleculePickleList: {
            cid: string;
            moleculeMolNo: number;
            ligandName: string;
            pickle: string;
            id: string;
        }[];
    };
    sliceNDice: {
        paeFileIsUploaded: boolean;
        thresholdType: "b-factor-norm" | "af2-plddt";
        moleculeBfactors: {
            cid: string;
            bFactor: number;
            normalised_bFactor: number;
        }[];
        moleculeMinBfactor: number;
        moleculeMaxBfactor: number;
        bFactorThreshold: number;
        nClusters: number;
        clusteringType: string;
        slicingResults: import("../utils").MoorhenMolecule[];
        paeFileContents: {
            fileContents: string;
            fileName: string;
        }[];
    };
    jsonValidation: {
        validationJson: {
            sections: any;
            title: string;
        };
    };
    mrParse: {
        mrParseModels: import("../utils").MoorhenMolecule[];
        targetSequence: string;
        afJson: any[];
        esmJson: any[];
        homologsJson: any[];
        afSortField: string;
        homologsSortField: string;
        afSortReversed: boolean;
        homologsSortReversed: boolean;
        AFDisplaySettings: any;
        HomologsDisplaySettings: any;
    };
    glRef: {
        isWebGL2: boolean;
        glCtx: any;
        displayBuffers: import("../WebGLgComponents/displayBuffer").DisplayBuffer[];
        activeMolecule: import("../utils").MoorhenMolecule;
        draggableMolecule: import("../utils").MoorhenMolecule;
        quat: any[];
        cursorPosition: [number, number];
        shortCutHelp: string[];
        requestDrawScene: {
            count: number;
        };
        drawsThrottled: number;
        envUpdate: {
            switch: boolean;
        };
        clearLabels: {
            switch: boolean;
        };
        hoverSize: number;
        labelBuffers: any[];
        texturedShapes: any[];
        canvasSize: [number, number];
        rttFramebufferSize: [number, number];
        elementsIndicesRestrict: boolean;
    };
    overlays: {
        imageOverlayList: import("./overlaysSlice").Overlay2DImageSrcFrac[];
        textOverlayList: import("./overlaysSlice").Overlay2DTextFrac[];
        svgPathOverlayList: import("./overlaysSlice").Overlay2DSvgPath[];
        fracPathOverlayList: import("./overlaysSlice").Overlay2DFracPath[];
        shapeOverlayList: import("./overlaysSlice").Overlay2DShape[];
        callBacks: Function[];
    };
    threeDObjects: {
        objects: import("./threeDObjectsSlice").ThreeDObject[];
    };
    menus: {
        settings: Record<string, Record<string, unknown>>;
    };
    globalUI: {
        busy: boolean;
        isTimeCapsuleBusy: boolean;
        isGlobalInstanceReady: boolean;
        isMainMenuOpen: boolean;
        isSceneSelectorOpen: boolean;
        isSearchBarActive: boolean;
        areShortcutsBlocked: boolean;
        shownSidePanel: import("../moorhen").SidePanelIDs | null;
        sidePanelWidth: number;
        bottomPanelHeight: number | null;
        shownControl: import("../moorhen").ShownControl | null;
        controlLocked: number | null;
        selectionToolsActive: boolean;
        clickAwayListenerPauseCount: number;
    };
    bottomPanels: {
        shownBottomPanel: import("../moorhen").BottomPanelIDs;
        seqviewerOption: import("../moorhen").SequenceViewerOption;
        validationOption: import("../moorhen").ValidationOption;
    };
    vectors: {
        vectorsList: import("./vectorsSlice").MoorhenVector[];
    };
    annotations: {
        annotationsList: import("./annotationsSlice").MoorhenAnnotation[];
    };
    snackBars: import("./snackbarSlice").Snackbar[];
    userScenes: {
        scenes: import("./userScenesSlice").UserScene[];
        snapshots: import("./userScenesSlice").UserScene[];
        selectedScene: string;
        isSceneChanging: boolean;
        shownRevision: number;
        savedSceneSettings: Record<import("./userScenesSlice").BuiltInSceneId, import("./sceneSettingsSlice").PerSceneSettings>;
    };
    movie: import("./movieSlice").MovieState;
}, import("redux").UnknownAction, import("@reduxjs/toolkit").Tuple<[import("redux").StoreEnhancer<{
    dispatch: ThunkDispatch<{
        molecules: {
            visibleMolecules: number[];
            moleculeRecords: Record<string, import("./moleculesSlice").MoleculeRecord>;
            moleculeList: import("../utils").MoorhenMolecule[];
            customRepresentations: import("../types/moorhen").moorhen.MoleculeRepresentation[];
            generalRepresentations: import("../types/moorhen").moorhen.MoleculeRepresentation[];
        };
        dictionaries: {
            loaded: {
                [x: string]: {
                    compId: string;
                    content: string;
                    moleculeUid: string | null;
                    source?: string;
                };
            };
        };
        maps: import("../utils").MoorhenMap[];
        mouseSettings: {
            contourWheelSensitivityFactor: number;
            zoomWheelSensitivityFactor: number;
            mouseSensitivity: number;
        };
        backupSettings: {
            enableTimeCapsule: boolean;
            makeBackups: boolean;
            maxBackupCount: number;
            modificationCountBackupThreshold: number;
        };
        shortcutSettings: {
            shortcutOnHoveredAtom: boolean;
            showShortcutToast: boolean;
            shortCuts: string;
        };
        labelSettings: {
            atomLabelDepthMode: boolean;
            GLLabelsFontFamily: string;
            GLLabelsFontSize: number;
            availableFonts: string[];
        };
        sceneSettings: {
            origin: [number, number, number];
            zoom: number;
            drawScaleBar: boolean;
            drawCrosshairs: boolean;
            drawAxes: boolean;
            drawEnvBOcc: boolean;
            drawFPS: boolean;
            drawMissingLoops: boolean;
            fogClipOffset: number;
            fogStart: number;
            fogEnd: number;
            clipStart: number;
            clipEnd: number;
            doPerspectiveProjection: boolean;
            useOffScreenBuffers: boolean;
            depthBlurRadius: number;
            depthPeelLayers: number;
            peelOpaqueSeparately: boolean;
            useWebGPU: boolean;
            anaglyphColours: import("../WebGLgComponents/anaglyph").AnaglyphColours;
            depthBlurDepth: number;
            lightPosition: [number, number, number, number];
            ambient: [number, number, number, number];
            specular: [number, number, number, number];
            diffuse: [number, number, number, number];
            specularPower: number;
            ssaoBias: number;
            ssaoRadius: number;
            doShadowDepthDebug: boolean;
            doShadow: boolean;
            shadowMapQuality: import("../WebGLgComponents/shadowMapQuality").ShadowMapQuality;
            shadowSoftness: number;
            doSSAO: boolean;
            doEdgeDetect: boolean;
            edgeDetectDepthThreshold: number;
            edgeDetectNormalThreshold: number;
            edgeDetectDepthScale: number;
            edgeDetectNormalScale: number;
            doSpin: boolean;
            doThreeWayView: boolean;
            multiViewRows: number;
            multiViewColumns: number;
            threeWayViewOrder: string;
            specifyMultiViewRowsColumns: boolean;
            doSideBySideStereo: boolean;
            doMultiView: boolean;
            doCrossEyedStereo: boolean;
            doAnaglyphStereo: boolean;
            defaultBondSmoothness: number;
            autoFog: boolean;
            autoClip: boolean;
            doFog: boolean;
            doClip: boolean;
            defaultRepresentationStyle: import("./sceneSettingsSlice").DefaultRepresentationStyle;
            clipCap: boolean;
            backgroundColor: [number, number, number, number];
            height: number;
            width: number;
            GlViewportHeight: number;
            GlViewportWidth: number;
            isDark: boolean;
        };
        generalStates: {
            devMode: boolean;
            useGemmi: boolean;
            userPreferencesMounted: boolean;
            appTitle: string;
            cootInitialized: boolean;
            activeMap: import("../utils").MoorhenMap;
            theme: string;
            residueSelection: import("./generalStatesSlice").ResidueSelection;
            selectedThreeDObjectId: string | null;
            selected2DObjectId: string | null;
            movingMapSlice: number | null;
            isShowingTomograms: boolean;
            jobProgress: {
                label: string;
                done: number;
                total: number;
            } | null;
            ligandBatchLoads: number;
            isAnimatingTrajectory: boolean;
            isChangingRotamers: boolean;
            isDraggingAtoms: boolean;
            isRotatingAtoms: boolean;
            newCootCommandExit: boolean;
            newCootCommandStart: boolean;
            useRamaRefinementRestraints: boolean;
            useTorsionRefinementRestraints: false;
            showResidueSelection: boolean;
            defaultExpandDisplayCards: boolean;
            transparentModalsOnMouseOut: boolean;
            showHoverInfo: boolean;
            viewOnly: boolean;
            allowScripting: boolean;
            allowAddNewFittedLigand: boolean;
            allowMergeFittedLigand: boolean;
            disableFileUpload: boolean;
        };
        hoveringStates: {
            enableAtomHovering: boolean;
            hoveredAtom: import("./hoveringStatesSlice").HoveredAtom;
            hoveredSection: import("./hoveringStatesSlice").HoveredSection | null;
            cursorStyle: string;
        };
        modals: {
            activeModals: import("./modalsSlice").ModalCall[];
            focusHierarchy: import("../moorhen").ModalKey[];
        };
        mapContourSettings: {
            visibleMaps: number[];
            contourLevels: {
                molNo: number;
                contourLevel: number;
            }[];
            mapRadii: {
                molNo: number;
                radius: number;
            }[];
            mapFastRadii: {
                molNo: number;
                radius: number | null;
            }[];
            mapAlpha: {
                molNo: number;
                alpha: number;
            }[];
            mapStyles: {
                molNo: number;
                style: import("./mapContourSettingsSlice").MapStyle;
            }[];
            mapSlices: ({
                molNo: number;
            } & import("../utils/mapSlice/mapSlice").MapSlicePlacement)[];
            mapSliceNodalLines: number[];
            mapSliceContourSpacings: {
                molNo: number;
                spacing: import("../utils/mapSlice/mapSlice").SliceContourSpacing;
            }[];
            defaultMapSamplingRate: number;
            defaultMapLitLines: boolean;
            mapLineWidth: number;
            defaultMapSurface: boolean;
            mapColours: {
                molNo: number;
                rgb: {
                    r: number;
                    g: number;
                    b: number;
                };
            }[];
            negativeMapColours: {
                molNo: number;
                rgb: {
                    r: number;
                    g: number;
                    b: number;
                };
            }[];
            positiveMapColours: {
                molNo: number;
                rgb: {
                    r: number;
                    g: number;
                    b: number;
                };
            }[];
            reContourMapOnlyOnMouseUp: boolean;
        };
        moleculeMapUpdate: {
            updatingMapsIsEnabled: boolean;
            connectedMolecule: number;
            reflectionMap: number;
            twoFoFcMap: number;
            foFcMap: number;
            uniqueMaps: number[];
            defaultUpdatingScores: string[];
            showScoresToast: boolean;
            moleculeUpdate: {
                switch: boolean;
                molNo: number;
            };
            currentScores: {
                rFactor: number;
                rFree: number;
                moorhenPoints: number;
            };
            currentScoreDiffs: {
                rFactor: number;
                rFree: number;
                moorhenPoints: number;
            };
        };
        sharedSession: {
            isInSharedSession: boolean;
            sharedSessionToken: string;
            showSharedSessionManager: boolean;
        };
        refinementSettings: {
            useRamaRefinementRestraints: boolean;
            useTorsionRefinementRestraints: boolean;
            enableRefineAfterMod: boolean;
            animateRefine: boolean;
            refinementSelection: "SINGLE" | "TRIPLE" | "SPHERE";
        };
        lhasa: {
            rdkitMoleculePickleList: {
                cid: string;
                moleculeMolNo: number;
                ligandName: string;
                pickle: string;
                id: string;
            }[];
        };
        sliceNDice: {
            paeFileIsUploaded: boolean;
            thresholdType: "b-factor-norm" | "af2-plddt";
            moleculeBfactors: {
                cid: string;
                bFactor: number;
                normalised_bFactor: number;
            }[];
            moleculeMinBfactor: number;
            moleculeMaxBfactor: number;
            bFactorThreshold: number;
            nClusters: number;
            clusteringType: string;
            slicingResults: import("../utils").MoorhenMolecule[];
            paeFileContents: {
                fileContents: string;
                fileName: string;
            }[];
        };
        jsonValidation: {
            validationJson: {
                sections: any;
                title: string;
            };
        };
        mrParse: {
            mrParseModels: import("../utils").MoorhenMolecule[];
            targetSequence: string;
            afJson: any[];
            esmJson: any[];
            homologsJson: any[];
            afSortField: string;
            homologsSortField: string;
            afSortReversed: boolean;
            homologsSortReversed: boolean;
            AFDisplaySettings: any;
            HomologsDisplaySettings: any;
        };
        glRef: {
            isWebGL2: boolean;
            glCtx: any;
            displayBuffers: import("../WebGLgComponents/displayBuffer").DisplayBuffer[];
            activeMolecule: import("../utils").MoorhenMolecule;
            draggableMolecule: import("../utils").MoorhenMolecule;
            quat: any[];
            cursorPosition: [number, number];
            shortCutHelp: string[];
            requestDrawScene: {
                count: number;
            };
            drawsThrottled: number;
            envUpdate: {
                switch: boolean;
            };
            clearLabels: {
                switch: boolean;
            };
            hoverSize: number;
            labelBuffers: any[];
            texturedShapes: any[];
            canvasSize: [number, number];
            rttFramebufferSize: [number, number];
            elementsIndicesRestrict: boolean;
        };
        overlays: {
            imageOverlayList: import("./overlaysSlice").Overlay2DImageSrcFrac[];
            textOverlayList: import("./overlaysSlice").Overlay2DTextFrac[];
            svgPathOverlayList: import("./overlaysSlice").Overlay2DSvgPath[];
            fracPathOverlayList: import("./overlaysSlice").Overlay2DFracPath[];
            shapeOverlayList: import("./overlaysSlice").Overlay2DShape[];
            callBacks: Function[];
        };
        threeDObjects: {
            objects: import("./threeDObjectsSlice").ThreeDObject[];
        };
        menus: {
            settings: Record<string, Record<string, unknown>>;
        };
        globalUI: {
            busy: boolean;
            isTimeCapsuleBusy: boolean;
            isGlobalInstanceReady: boolean;
            isMainMenuOpen: boolean;
            isSceneSelectorOpen: boolean;
            isSearchBarActive: boolean;
            areShortcutsBlocked: boolean;
            shownSidePanel: import("../moorhen").SidePanelIDs | null;
            sidePanelWidth: number;
            bottomPanelHeight: number | null;
            shownControl: import("../moorhen").ShownControl | null;
            controlLocked: number | null;
            selectionToolsActive: boolean;
            clickAwayListenerPauseCount: number;
        };
        bottomPanels: {
            shownBottomPanel: import("../moorhen").BottomPanelIDs;
            seqviewerOption: import("../moorhen").SequenceViewerOption;
            validationOption: import("../moorhen").ValidationOption;
        };
        vectors: {
            vectorsList: import("./vectorsSlice").MoorhenVector[];
        };
        annotations: {
            annotationsList: import("./annotationsSlice").MoorhenAnnotation[];
        };
        snackBars: import("./snackbarSlice").Snackbar[];
        userScenes: {
            scenes: import("./userScenesSlice").UserScene[];
            snapshots: import("./userScenesSlice").UserScene[];
            selectedScene: string;
            isSceneChanging: boolean;
            shownRevision: number;
            savedSceneSettings: Record<import("./userScenesSlice").BuiltInSceneId, import("./sceneSettingsSlice").PerSceneSettings>;
        };
        movie: import("./movieSlice").MovieState;
    }, undefined, import("redux").UnknownAction>;
}>, import("redux").StoreEnhancer]>>;
export declare const _MoorhenReduxStore: import("@reduxjs/toolkit").EnhancedStore<{
    molecules: {
        visibleMolecules: number[];
        moleculeRecords: Record<string, import("./moleculesSlice").MoleculeRecord>;
        moleculeList: import("../utils").MoorhenMolecule[];
        customRepresentations: import("../types/moorhen").moorhen.MoleculeRepresentation[];
        generalRepresentations: import("../types/moorhen").moorhen.MoleculeRepresentation[];
    };
    dictionaries: {
        loaded: {
            [x: string]: {
                compId: string;
                content: string;
                moleculeUid: string | null;
                source?: string;
            };
        };
    };
    maps: import("../utils").MoorhenMap[];
    mouseSettings: {
        contourWheelSensitivityFactor: number;
        zoomWheelSensitivityFactor: number;
        mouseSensitivity: number;
    };
    backupSettings: {
        enableTimeCapsule: boolean;
        makeBackups: boolean;
        maxBackupCount: number;
        modificationCountBackupThreshold: number;
    };
    shortcutSettings: {
        shortcutOnHoveredAtom: boolean;
        showShortcutToast: boolean;
        shortCuts: string;
    };
    labelSettings: {
        atomLabelDepthMode: boolean;
        GLLabelsFontFamily: string;
        GLLabelsFontSize: number;
        availableFonts: string[];
    };
    sceneSettings: {
        origin: [number, number, number];
        zoom: number;
        drawScaleBar: boolean;
        drawCrosshairs: boolean;
        drawAxes: boolean;
        drawEnvBOcc: boolean;
        drawFPS: boolean;
        drawMissingLoops: boolean;
        fogClipOffset: number;
        fogStart: number;
        fogEnd: number;
        clipStart: number;
        clipEnd: number;
        doPerspectiveProjection: boolean;
        useOffScreenBuffers: boolean;
        depthBlurRadius: number;
        depthPeelLayers: number;
        peelOpaqueSeparately: boolean;
        useWebGPU: boolean;
        anaglyphColours: import("../WebGLgComponents/anaglyph").AnaglyphColours;
        depthBlurDepth: number;
        lightPosition: [number, number, number, number];
        ambient: [number, number, number, number];
        specular: [number, number, number, number];
        diffuse: [number, number, number, number];
        specularPower: number;
        ssaoBias: number;
        ssaoRadius: number;
        doShadowDepthDebug: boolean;
        doShadow: boolean;
        shadowMapQuality: import("../WebGLgComponents/shadowMapQuality").ShadowMapQuality;
        shadowSoftness: number;
        doSSAO: boolean;
        doEdgeDetect: boolean;
        edgeDetectDepthThreshold: number;
        edgeDetectNormalThreshold: number;
        edgeDetectDepthScale: number;
        edgeDetectNormalScale: number;
        doSpin: boolean;
        doThreeWayView: boolean;
        multiViewRows: number;
        multiViewColumns: number;
        threeWayViewOrder: string;
        specifyMultiViewRowsColumns: boolean;
        doSideBySideStereo: boolean;
        doMultiView: boolean;
        doCrossEyedStereo: boolean;
        doAnaglyphStereo: boolean;
        defaultBondSmoothness: number;
        autoFog: boolean;
        autoClip: boolean;
        doFog: boolean;
        doClip: boolean;
        defaultRepresentationStyle: import("./sceneSettingsSlice").DefaultRepresentationStyle;
        clipCap: boolean;
        backgroundColor: [number, number, number, number];
        height: number;
        width: number;
        GlViewportHeight: number;
        GlViewportWidth: number;
        isDark: boolean;
    };
    generalStates: {
        devMode: boolean;
        useGemmi: boolean;
        userPreferencesMounted: boolean;
        appTitle: string;
        cootInitialized: boolean;
        activeMap: import("../utils").MoorhenMap;
        theme: string;
        residueSelection: import("./generalStatesSlice").ResidueSelection;
        selectedThreeDObjectId: string | null;
        selected2DObjectId: string | null;
        movingMapSlice: number | null;
        isShowingTomograms: boolean;
        jobProgress: {
            label: string;
            done: number;
            total: number;
        } | null;
        ligandBatchLoads: number;
        isAnimatingTrajectory: boolean;
        isChangingRotamers: boolean;
        isDraggingAtoms: boolean;
        isRotatingAtoms: boolean;
        newCootCommandExit: boolean;
        newCootCommandStart: boolean;
        useRamaRefinementRestraints: boolean;
        useTorsionRefinementRestraints: false;
        showResidueSelection: boolean;
        defaultExpandDisplayCards: boolean;
        transparentModalsOnMouseOut: boolean;
        showHoverInfo: boolean;
        viewOnly: boolean;
        allowScripting: boolean;
        allowAddNewFittedLigand: boolean;
        allowMergeFittedLigand: boolean;
        disableFileUpload: boolean;
    };
    hoveringStates: {
        enableAtomHovering: boolean;
        hoveredAtom: import("./hoveringStatesSlice").HoveredAtom;
        hoveredSection: import("./hoveringStatesSlice").HoveredSection | null;
        cursorStyle: string;
    };
    modals: {
        activeModals: import("./modalsSlice").ModalCall[];
        focusHierarchy: import("../moorhen").ModalKey[];
    };
    mapContourSettings: {
        visibleMaps: number[];
        contourLevels: {
            molNo: number;
            contourLevel: number;
        }[];
        mapRadii: {
            molNo: number;
            radius: number;
        }[];
        mapFastRadii: {
            molNo: number;
            radius: number | null;
        }[];
        mapAlpha: {
            molNo: number;
            alpha: number;
        }[];
        mapStyles: {
            molNo: number;
            style: import("./mapContourSettingsSlice").MapStyle;
        }[];
        mapSlices: ({
            molNo: number;
        } & import("../utils/mapSlice/mapSlice").MapSlicePlacement)[];
        mapSliceNodalLines: number[];
        mapSliceContourSpacings: {
            molNo: number;
            spacing: import("../utils/mapSlice/mapSlice").SliceContourSpacing;
        }[];
        defaultMapSamplingRate: number;
        defaultMapLitLines: boolean;
        mapLineWidth: number;
        defaultMapSurface: boolean;
        mapColours: {
            molNo: number;
            rgb: {
                r: number;
                g: number;
                b: number;
            };
        }[];
        negativeMapColours: {
            molNo: number;
            rgb: {
                r: number;
                g: number;
                b: number;
            };
        }[];
        positiveMapColours: {
            molNo: number;
            rgb: {
                r: number;
                g: number;
                b: number;
            };
        }[];
        reContourMapOnlyOnMouseUp: boolean;
    };
    moleculeMapUpdate: {
        updatingMapsIsEnabled: boolean;
        connectedMolecule: number;
        reflectionMap: number;
        twoFoFcMap: number;
        foFcMap: number;
        uniqueMaps: number[];
        defaultUpdatingScores: string[];
        showScoresToast: boolean;
        moleculeUpdate: {
            switch: boolean;
            molNo: number;
        };
        currentScores: {
            rFactor: number;
            rFree: number;
            moorhenPoints: number;
        };
        currentScoreDiffs: {
            rFactor: number;
            rFree: number;
            moorhenPoints: number;
        };
    };
    sharedSession: {
        isInSharedSession: boolean;
        sharedSessionToken: string;
        showSharedSessionManager: boolean;
    };
    refinementSettings: {
        useRamaRefinementRestraints: boolean;
        useTorsionRefinementRestraints: boolean;
        enableRefineAfterMod: boolean;
        animateRefine: boolean;
        refinementSelection: "SINGLE" | "TRIPLE" | "SPHERE";
    };
    lhasa: {
        rdkitMoleculePickleList: {
            cid: string;
            moleculeMolNo: number;
            ligandName: string;
            pickle: string;
            id: string;
        }[];
    };
    sliceNDice: {
        paeFileIsUploaded: boolean;
        thresholdType: "b-factor-norm" | "af2-plddt";
        moleculeBfactors: {
            cid: string;
            bFactor: number;
            normalised_bFactor: number;
        }[];
        moleculeMinBfactor: number;
        moleculeMaxBfactor: number;
        bFactorThreshold: number;
        nClusters: number;
        clusteringType: string;
        slicingResults: import("../utils").MoorhenMolecule[];
        paeFileContents: {
            fileContents: string;
            fileName: string;
        }[];
    };
    jsonValidation: {
        validationJson: {
            sections: any;
            title: string;
        };
    };
    mrParse: {
        mrParseModels: import("../utils").MoorhenMolecule[];
        targetSequence: string;
        afJson: any[];
        esmJson: any[];
        homologsJson: any[];
        afSortField: string;
        homologsSortField: string;
        afSortReversed: boolean;
        homologsSortReversed: boolean;
        AFDisplaySettings: any;
        HomologsDisplaySettings: any;
    };
    glRef: {
        isWebGL2: boolean;
        glCtx: any;
        displayBuffers: import("../WebGLgComponents/displayBuffer").DisplayBuffer[];
        activeMolecule: import("../utils").MoorhenMolecule;
        draggableMolecule: import("../utils").MoorhenMolecule;
        quat: any[];
        cursorPosition: [number, number];
        shortCutHelp: string[];
        requestDrawScene: {
            count: number;
        };
        drawsThrottled: number;
        envUpdate: {
            switch: boolean;
        };
        clearLabels: {
            switch: boolean;
        };
        hoverSize: number;
        labelBuffers: any[];
        texturedShapes: any[];
        canvasSize: [number, number];
        rttFramebufferSize: [number, number];
        elementsIndicesRestrict: boolean;
    };
    overlays: {
        imageOverlayList: import("./overlaysSlice").Overlay2DImageSrcFrac[];
        textOverlayList: import("./overlaysSlice").Overlay2DTextFrac[];
        svgPathOverlayList: import("./overlaysSlice").Overlay2DSvgPath[];
        fracPathOverlayList: import("./overlaysSlice").Overlay2DFracPath[];
        shapeOverlayList: import("./overlaysSlice").Overlay2DShape[];
        callBacks: Function[];
    };
    threeDObjects: {
        objects: import("./threeDObjectsSlice").ThreeDObject[];
    };
    menus: {
        settings: Record<string, Record<string, unknown>>;
    };
    globalUI: {
        busy: boolean;
        isTimeCapsuleBusy: boolean;
        isGlobalInstanceReady: boolean;
        isMainMenuOpen: boolean;
        isSceneSelectorOpen: boolean;
        isSearchBarActive: boolean;
        areShortcutsBlocked: boolean;
        shownSidePanel: import("../moorhen").SidePanelIDs | null;
        sidePanelWidth: number;
        bottomPanelHeight: number | null;
        shownControl: import("../moorhen").ShownControl | null;
        controlLocked: number | null;
        selectionToolsActive: boolean;
        clickAwayListenerPauseCount: number;
    };
    bottomPanels: {
        shownBottomPanel: import("../moorhen").BottomPanelIDs;
        seqviewerOption: import("../moorhen").SequenceViewerOption;
        validationOption: import("../moorhen").ValidationOption;
    };
    vectors: {
        vectorsList: import("./vectorsSlice").MoorhenVector[];
    };
    annotations: {
        annotationsList: import("./annotationsSlice").MoorhenAnnotation[];
    };
    snackBars: import("./snackbarSlice").Snackbar[];
    userScenes: {
        scenes: import("./userScenesSlice").UserScene[];
        snapshots: import("./userScenesSlice").UserScene[];
        selectedScene: string;
        isSceneChanging: boolean;
        shownRevision: number;
        savedSceneSettings: Record<import("./userScenesSlice").BuiltInSceneId, import("./sceneSettingsSlice").PerSceneSettings>;
    };
    movie: import("./movieSlice").MovieState;
}, import("redux").UnknownAction, import("@reduxjs/toolkit").Tuple<[import("redux").StoreEnhancer<{
    dispatch: ThunkDispatch<{
        molecules: {
            visibleMolecules: number[];
            moleculeRecords: Record<string, import("./moleculesSlice").MoleculeRecord>;
            moleculeList: import("../utils").MoorhenMolecule[];
            customRepresentations: import("../types/moorhen").moorhen.MoleculeRepresentation[];
            generalRepresentations: import("../types/moorhen").moorhen.MoleculeRepresentation[];
        };
        dictionaries: {
            loaded: {
                [x: string]: {
                    compId: string;
                    content: string;
                    moleculeUid: string | null;
                    source?: string;
                };
            };
        };
        maps: import("../utils").MoorhenMap[];
        mouseSettings: {
            contourWheelSensitivityFactor: number;
            zoomWheelSensitivityFactor: number;
            mouseSensitivity: number;
        };
        backupSettings: {
            enableTimeCapsule: boolean;
            makeBackups: boolean;
            maxBackupCount: number;
            modificationCountBackupThreshold: number;
        };
        shortcutSettings: {
            shortcutOnHoveredAtom: boolean;
            showShortcutToast: boolean;
            shortCuts: string;
        };
        labelSettings: {
            atomLabelDepthMode: boolean;
            GLLabelsFontFamily: string;
            GLLabelsFontSize: number;
            availableFonts: string[];
        };
        sceneSettings: {
            origin: [number, number, number];
            zoom: number;
            drawScaleBar: boolean;
            drawCrosshairs: boolean;
            drawAxes: boolean;
            drawEnvBOcc: boolean;
            drawFPS: boolean;
            drawMissingLoops: boolean;
            fogClipOffset: number;
            fogStart: number;
            fogEnd: number;
            clipStart: number;
            clipEnd: number;
            doPerspectiveProjection: boolean;
            useOffScreenBuffers: boolean;
            depthBlurRadius: number;
            depthPeelLayers: number;
            peelOpaqueSeparately: boolean;
            useWebGPU: boolean;
            anaglyphColours: import("../WebGLgComponents/anaglyph").AnaglyphColours;
            depthBlurDepth: number;
            lightPosition: [number, number, number, number];
            ambient: [number, number, number, number];
            specular: [number, number, number, number];
            diffuse: [number, number, number, number];
            specularPower: number;
            ssaoBias: number;
            ssaoRadius: number;
            doShadowDepthDebug: boolean;
            doShadow: boolean;
            shadowMapQuality: import("../WebGLgComponents/shadowMapQuality").ShadowMapQuality;
            shadowSoftness: number;
            doSSAO: boolean;
            doEdgeDetect: boolean;
            edgeDetectDepthThreshold: number;
            edgeDetectNormalThreshold: number;
            edgeDetectDepthScale: number;
            edgeDetectNormalScale: number;
            doSpin: boolean;
            doThreeWayView: boolean;
            multiViewRows: number;
            multiViewColumns: number;
            threeWayViewOrder: string;
            specifyMultiViewRowsColumns: boolean;
            doSideBySideStereo: boolean;
            doMultiView: boolean;
            doCrossEyedStereo: boolean;
            doAnaglyphStereo: boolean;
            defaultBondSmoothness: number;
            autoFog: boolean;
            autoClip: boolean;
            doFog: boolean;
            doClip: boolean;
            defaultRepresentationStyle: import("./sceneSettingsSlice").DefaultRepresentationStyle;
            clipCap: boolean;
            backgroundColor: [number, number, number, number];
            height: number;
            width: number;
            GlViewportHeight: number;
            GlViewportWidth: number;
            isDark: boolean;
        };
        generalStates: {
            devMode: boolean;
            useGemmi: boolean;
            userPreferencesMounted: boolean;
            appTitle: string;
            cootInitialized: boolean;
            activeMap: import("../utils").MoorhenMap;
            theme: string;
            residueSelection: import("./generalStatesSlice").ResidueSelection;
            selectedThreeDObjectId: string | null;
            selected2DObjectId: string | null;
            movingMapSlice: number | null;
            isShowingTomograms: boolean;
            jobProgress: {
                label: string;
                done: number;
                total: number;
            } | null;
            ligandBatchLoads: number;
            isAnimatingTrajectory: boolean;
            isChangingRotamers: boolean;
            isDraggingAtoms: boolean;
            isRotatingAtoms: boolean;
            newCootCommandExit: boolean;
            newCootCommandStart: boolean;
            useRamaRefinementRestraints: boolean;
            useTorsionRefinementRestraints: false;
            showResidueSelection: boolean;
            defaultExpandDisplayCards: boolean;
            transparentModalsOnMouseOut: boolean;
            showHoverInfo: boolean;
            viewOnly: boolean;
            allowScripting: boolean;
            allowAddNewFittedLigand: boolean;
            allowMergeFittedLigand: boolean;
            disableFileUpload: boolean;
        };
        hoveringStates: {
            enableAtomHovering: boolean;
            hoveredAtom: import("./hoveringStatesSlice").HoveredAtom;
            hoveredSection: import("./hoveringStatesSlice").HoveredSection | null;
            cursorStyle: string;
        };
        modals: {
            activeModals: import("./modalsSlice").ModalCall[];
            focusHierarchy: import("../moorhen").ModalKey[];
        };
        mapContourSettings: {
            visibleMaps: number[];
            contourLevels: {
                molNo: number;
                contourLevel: number;
            }[];
            mapRadii: {
                molNo: number;
                radius: number;
            }[];
            mapFastRadii: {
                molNo: number;
                radius: number | null;
            }[];
            mapAlpha: {
                molNo: number;
                alpha: number;
            }[];
            mapStyles: {
                molNo: number;
                style: import("./mapContourSettingsSlice").MapStyle;
            }[];
            mapSlices: ({
                molNo: number;
            } & import("../utils/mapSlice/mapSlice").MapSlicePlacement)[];
            mapSliceNodalLines: number[];
            mapSliceContourSpacings: {
                molNo: number;
                spacing: import("../utils/mapSlice/mapSlice").SliceContourSpacing;
            }[];
            defaultMapSamplingRate: number;
            defaultMapLitLines: boolean;
            mapLineWidth: number;
            defaultMapSurface: boolean;
            mapColours: {
                molNo: number;
                rgb: {
                    r: number;
                    g: number;
                    b: number;
                };
            }[];
            negativeMapColours: {
                molNo: number;
                rgb: {
                    r: number;
                    g: number;
                    b: number;
                };
            }[];
            positiveMapColours: {
                molNo: number;
                rgb: {
                    r: number;
                    g: number;
                    b: number;
                };
            }[];
            reContourMapOnlyOnMouseUp: boolean;
        };
        moleculeMapUpdate: {
            updatingMapsIsEnabled: boolean;
            connectedMolecule: number;
            reflectionMap: number;
            twoFoFcMap: number;
            foFcMap: number;
            uniqueMaps: number[];
            defaultUpdatingScores: string[];
            showScoresToast: boolean;
            moleculeUpdate: {
                switch: boolean;
                molNo: number;
            };
            currentScores: {
                rFactor: number;
                rFree: number;
                moorhenPoints: number;
            };
            currentScoreDiffs: {
                rFactor: number;
                rFree: number;
                moorhenPoints: number;
            };
        };
        sharedSession: {
            isInSharedSession: boolean;
            sharedSessionToken: string;
            showSharedSessionManager: boolean;
        };
        refinementSettings: {
            useRamaRefinementRestraints: boolean;
            useTorsionRefinementRestraints: boolean;
            enableRefineAfterMod: boolean;
            animateRefine: boolean;
            refinementSelection: "SINGLE" | "TRIPLE" | "SPHERE";
        };
        lhasa: {
            rdkitMoleculePickleList: {
                cid: string;
                moleculeMolNo: number;
                ligandName: string;
                pickle: string;
                id: string;
            }[];
        };
        sliceNDice: {
            paeFileIsUploaded: boolean;
            thresholdType: "b-factor-norm" | "af2-plddt";
            moleculeBfactors: {
                cid: string;
                bFactor: number;
                normalised_bFactor: number;
            }[];
            moleculeMinBfactor: number;
            moleculeMaxBfactor: number;
            bFactorThreshold: number;
            nClusters: number;
            clusteringType: string;
            slicingResults: import("../utils").MoorhenMolecule[];
            paeFileContents: {
                fileContents: string;
                fileName: string;
            }[];
        };
        jsonValidation: {
            validationJson: {
                sections: any;
                title: string;
            };
        };
        mrParse: {
            mrParseModels: import("../utils").MoorhenMolecule[];
            targetSequence: string;
            afJson: any[];
            esmJson: any[];
            homologsJson: any[];
            afSortField: string;
            homologsSortField: string;
            afSortReversed: boolean;
            homologsSortReversed: boolean;
            AFDisplaySettings: any;
            HomologsDisplaySettings: any;
        };
        glRef: {
            isWebGL2: boolean;
            glCtx: any;
            displayBuffers: import("../WebGLgComponents/displayBuffer").DisplayBuffer[];
            activeMolecule: import("../utils").MoorhenMolecule;
            draggableMolecule: import("../utils").MoorhenMolecule;
            quat: any[];
            cursorPosition: [number, number];
            shortCutHelp: string[];
            requestDrawScene: {
                count: number;
            };
            drawsThrottled: number;
            envUpdate: {
                switch: boolean;
            };
            clearLabels: {
                switch: boolean;
            };
            hoverSize: number;
            labelBuffers: any[];
            texturedShapes: any[];
            canvasSize: [number, number];
            rttFramebufferSize: [number, number];
            elementsIndicesRestrict: boolean;
        };
        overlays: {
            imageOverlayList: import("./overlaysSlice").Overlay2DImageSrcFrac[];
            textOverlayList: import("./overlaysSlice").Overlay2DTextFrac[];
            svgPathOverlayList: import("./overlaysSlice").Overlay2DSvgPath[];
            fracPathOverlayList: import("./overlaysSlice").Overlay2DFracPath[];
            shapeOverlayList: import("./overlaysSlice").Overlay2DShape[];
            callBacks: Function[];
        };
        threeDObjects: {
            objects: import("./threeDObjectsSlice").ThreeDObject[];
        };
        menus: {
            settings: Record<string, Record<string, unknown>>;
        };
        globalUI: {
            busy: boolean;
            isTimeCapsuleBusy: boolean;
            isGlobalInstanceReady: boolean;
            isMainMenuOpen: boolean;
            isSceneSelectorOpen: boolean;
            isSearchBarActive: boolean;
            areShortcutsBlocked: boolean;
            shownSidePanel: import("../moorhen").SidePanelIDs | null;
            sidePanelWidth: number;
            bottomPanelHeight: number | null;
            shownControl: import("../moorhen").ShownControl | null;
            controlLocked: number | null;
            selectionToolsActive: boolean;
            clickAwayListenerPauseCount: number;
        };
        bottomPanels: {
            shownBottomPanel: import("../moorhen").BottomPanelIDs;
            seqviewerOption: import("../moorhen").SequenceViewerOption;
            validationOption: import("../moorhen").ValidationOption;
        };
        vectors: {
            vectorsList: import("./vectorsSlice").MoorhenVector[];
        };
        annotations: {
            annotationsList: import("./annotationsSlice").MoorhenAnnotation[];
        };
        snackBars: import("./snackbarSlice").Snackbar[];
        userScenes: {
            scenes: import("./userScenesSlice").UserScene[];
            snapshots: import("./userScenesSlice").UserScene[];
            selectedScene: string;
            isSceneChanging: boolean;
            shownRevision: number;
            savedSceneSettings: Record<import("./userScenesSlice").BuiltInSceneId, import("./sceneSettingsSlice").PerSceneSettings>;
        };
        movie: import("./movieSlice").MovieState;
    }, undefined, import("redux").UnknownAction>;
}>, import("redux").StoreEnhancer]>>;
//# sourceMappingURL=MoorhenReduxStore.d.ts.map