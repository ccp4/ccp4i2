import { moorhen } from "../types/moorhen";
import { MoorhenMolecule } from "../utils";
/** A ligand of a molecule, as gemmi lists it (get_ligand_info_for_structure) */
export type MoleculeLigandRecord = {
    resName: string;
    chainName: string;
    resNum: string;
    modelName: string;
    /** e.g. /1/A/301(ATP) */
    cid: string;
};
/**
 * What the UI groups and labels molecules by, as a plain record keyed by the molecule's uniqueId:
 * the first step of .roadmaps/serialisable-store.md. Written only by the molecule itself
 * (MoorhenMolecule.refreshRecord), from its central methods, and only when a field changes; a
 * component never computes these. Fields are added when the UI filters, sorts or groups on them.
 */
export type MoleculeRecord = {
    uniqueId: string;
    /** MoorhenMolecule.isLigandOnly(): listed in the Ligands panel, not given a card in the Models panel */
    isLigandOnly: boolean;
    ligands: MoleculeLigandRecord[];
    /** The residue types (ligands or not) Coot has no dictionary for, sorted */
    missingDictionaries: string[];
};
export declare const addMolecule: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMolecule, "molecules/addMolecule">, removeMolecule: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMolecule, "molecules/removeMolecule">, emptyMolecules: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"molecules/emptyMolecules">, addMoleculeList: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMolecule[], "molecules/addMoleculeList">, setMoleculeRecords: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoleculeRecord[], "molecules/setMoleculeRecords">, removeMoleculeRecord: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "molecules/removeMoleculeRecord">, addGeneralRepresentation: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<import("../utils").MoleculeRepresentation, "molecules/addGeneralRepresentation">, setMoleculesVisible: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    molNos: number[];
    visible: boolean;
}, "molecules/setMoleculesVisible">, showMolecule: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMolecule, "molecules/showMolecule">, hideMolecule: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMolecule, "molecules/hideMolecule">, addCustomRepresentation: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<import("../utils").MoleculeRepresentation, "molecules/addCustomRepresentation">, addCustomRepresentationList: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<import("../utils").MoleculeRepresentation[], "molecules/addCustomRepresentationList">, removeCustomRepresentation: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<import("../utils").MoleculeRepresentation, "molecules/removeCustomRepresentation">, removeGeneralRepresentation: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<import("../utils").MoleculeRepresentation, "molecules/removeGeneralRepresentation">;
declare const _default: import("redux").Reducer<{
    visibleMolecules: number[];
    moleculeRecords: Record<string, MoleculeRecord>;
    moleculeList: MoorhenMolecule[];
    customRepresentations: moorhen.MoleculeRepresentation[];
    generalRepresentations: moorhen.MoleculeRepresentation[];
}>;
export default _default;
//# sourceMappingURL=moleculesSlice.d.ts.map