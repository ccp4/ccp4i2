/**
 * The one WebGPU device the page uses: the WebGPU renderer and every compute module share it,
 * so a buffer made by one can be used by another (GPU buffers cannot cross devices).
 *
 * Made on first use and kept. It asks for what Moorhen needs beyond the defaults, as far as the
 * adapter offers it: the largest buffers and storage bindings (big meshes, a map's whole unit
 * cell) and timestamp queries (GPU frame times, for the FPS meter and the renderer report). If
 * the device is lost, the context is forgotten, and the next getGpuContext() makes a new one;
 * anything holding GPU resources from the old one should listen to `lost` and drop them (the
 * main view does, and makes a new device: MoorhenWebGPUMainView).
 *
 * Errors: use error scopes around work whose failure you want to handle (see withErrorScope).
 * Errors outside any scope reach the device's "uncapturederror" event, which is logged here, and
 * which a consumer may listen to as well (the WebGPU renderer reports them to its owner).
 */
export interface GpuContext {
    readonly device: GPUDevice;
    /** Vendor, architecture and description, as far as the browser says. */
    readonly adapterDescription: string;
    /** A software adapter (SwiftShader, WARP and the like): it works, but slowly. */
    readonly fallbackAdapter: boolean;
    /** Settles when this context's device is lost. */
    readonly lost: Promise<GPUDeviceLostInfo>;
}
/** Why WebGPU cannot be used here, or null if it can. Cheap; does not create a device. */
export declare function webGPUUnavailableReason(): string | null;
/**
 * The shared context, made on first call. Rejects with a readable message when WebGPU is not
 * there or no adapter or device is offered; a later call tries again.
 */
export declare function getGpuContext(): Promise<GpuContext>;
/**
 * Whether WebGPU can be used here and on what (the renderer report, the Dev menu): the reason it
 * cannot - no WebGPU, or no adapter offered (no GPU, a blocklisted driver) - or the adapter. The
 * shared context's adapter if there is one; otherwise one is asked for, and no device made.
 */
export declare function webGPUAdapterSummary(): Promise<{
    reason: string | null;
    adapter: string | null;
    fallback: boolean;
}>;
/**
 * Run `work` inside validation and out-of-memory error scopes, and resolve with the first error
 * either caught (null if none). The work's own commands must be submitted inside `work`; the
 * scopes catch errors from the calls made while they are open, not from later GPU execution.
 */
export declare function withErrorScope(device: GPUDevice, work: () => void): Promise<GPUError | null>;
//# sourceMappingURL=context.d.ts.map