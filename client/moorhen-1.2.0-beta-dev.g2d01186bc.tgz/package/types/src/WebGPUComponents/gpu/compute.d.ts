/**
 * Workgroup counts (x, y) for `groups` workgroups: all in x when they fit, otherwise folded into
 * rows of the most x allows. A folded dispatch can have up to x - 1 workgroups more than asked
 * for, so a kernel must check its item number (itemIndexWgsl) against the item count.
 */
export declare function dispatchSize(groups: number): [number, number];
/**
 * WGSL for a thread's item number in a dispatch made by ComputeKernel.dispatch (or dispatchSize):
 * `fn itemIndex(lid: vec3u, wid: vec3u, nwg: vec3u) -> u32`, from the local invocation id,
 * workgroup id and number of workgroups. Items beyond the count must be skipped by the kernel.
 */
export declare function itemIndexWgsl(workgroupSize: number): string;
/** What a bind group can be made from: buffers in binding order (0, 1, ...), or a group made already. */
export type Bindings = readonly (GPUBuffer | GPUBufferBinding)[] | GPUBindGroup;
export interface KernelSource {
    /** Shown in WebGPU's error messages and in GPU debuggers. */
    label: string;
    code: string;
    /** Default "main". */
    entryPoint?: string;
    /** The entry point's @workgroup_size (x only); used to turn items into workgroups. */
    workgroupSize: number;
}
/** One compute entry point, compiled, with its bind group layouts made from the shader ("auto"). */
export declare class ComputeKernel {
    readonly device: GPUDevice;
    readonly label: string;
    readonly pipeline: GPUComputePipeline;
    readonly workgroupSize: number;
    private constructor();
    /**
     * Compile asynchronously, so that the cost is not paid in the middle of the first frame that
     * needs the kernel. Rejects with the compiler's messages if the WGSL does not compile.
     */
    static create(device: GPUDevice, source: KernelSource): Promise<ComputeKernel>;
    /**
     * A bind group for `group` of this kernel, from buffers in binding order. Groups made by
     * "auto" layouts hold only the bindings the entry point uses, so the buffers given must be
     * exactly those, in order.
     */
    bindGroup(group: number, buffers: readonly (GPUBuffer | GPUBufferBinding)[]): GPUBindGroup;
    /**
     * Record one compute pass running this kernel: one thread per item (0 items records nothing),
     * or exactly `workgroups` workgroups if given (for kernels that loop over their own items).
     * `groups[i]` is bind group i.
     */
    dispatch(encoder: GPUCommandEncoder, options: {
        groups: readonly Bindings[];
        items?: number;
        workgroups?: number;
        timestampWrites?: GPUComputePassTimestampWrites;
    }): void;
}
/**
 * A buffer of at least `bytes` (rounded up to 4, and at least 16), with COPY_DST added when it is
 * filled from `data`.
 */
export declare function createBuffer(device: GPUDevice, label: string, bytes: number, usage: number, data?: ArrayBufferView): GPUBuffer;
/**
 * Copy `bytes` of `source` (which needs COPY_SRC) from `offset` back to the CPU. For tests and
 * occasional checks: it waits for the GPU, which in Firefox can take 100 ms. Never call it once
 * per frame, or between the steps of one piece of work (see ../README.md, "Do not wait").
 */
export declare function readBuffer(device: GPUDevice, source: GPUBuffer, bytes: number, offset?: number): Promise<ArrayBuffer>;
//# sourceMappingURL=compute.d.ts.map