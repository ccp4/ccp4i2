/**
 * The WebGPU flag values, by their values in the specification.
 *
 * TypeScript's DOM library has the WebGPU interfaces but not the GPUBufferUsage, GPUTextureUsage,
 * GPUShaderStage and GPUMapMode globals, and they do not exist in Node (Jest), so they are spelled
 * out here, once. (@webgpu/types would add them, but it also redeclares every interface the DOM
 * library already has.)
 */
export declare const BufferUsage: {
    readonly MAP_READ: 1;
    readonly MAP_WRITE: 2;
    readonly COPY_SRC: 4;
    readonly COPY_DST: 8;
    readonly INDEX: 16;
    readonly VERTEX: 32;
    readonly UNIFORM: 64;
    readonly STORAGE: 128;
    readonly INDIRECT: 256;
    readonly QUERY_RESOLVE: 512;
};
export declare const TextureUsage: {
    readonly COPY_SRC: 1;
    readonly COPY_DST: 2;
    readonly TEXTURE_BINDING: 4;
    readonly STORAGE_BINDING: 8;
    readonly RENDER_ATTACHMENT: 16;
};
export declare const ShaderStage: {
    readonly VERTEX: 1;
    readonly FRAGMENT: 2;
    readonly COMPUTE: 4;
};
export declare const MapMode: {
    readonly READ: 1;
    readonly WRITE: 2;
};
/** The most workgroups a dispatch may have along one dimension (a WebGPU default limit). */
export declare const MAX_WORKGROUPS_PER_DIMENSION = 65535;
//# sourceMappingURL=constants.d.ts.map