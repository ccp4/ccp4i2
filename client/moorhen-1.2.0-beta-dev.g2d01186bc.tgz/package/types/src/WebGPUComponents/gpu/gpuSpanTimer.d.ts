export type PassTimestamps = GPUComputePassTimestampWrites & GPURenderPassTimestampWrites;
/** The timestamp writes for one pass: marks at its beginning and/or end. */
export type MarkPass = (beginMark?: number, endMark?: number) => PassTimestamps;
export interface SpanTiming {
    /** Mean of the whole span (first mark to last), ms. */
    meanMs: number;
    /** The longest whole span, ms. */
    maxMs: number;
    /** Spans timed. */
    count: number;
    /** Mean of each segment, ms. */
    segmentsMs: number[];
}
export declare class GpuSpanTimer {
    private readonly marks;
    private readonly querySet;
    private readonly resolved;
    private readonly readback;
    private reading;
    private destroyed;
    private pending;
    private sum;
    private max;
    private count;
    private readonly segmentSums;
    private constructor();
    /** `marks`: at least 2, the start and the end. */
    static create(device: GPUDevice, label: string, marks?: number): GpuSpanTimer | null;
    /**
     * Time this span: gives the writes for a pass that carries marks. Every mark must be written
     * by some pass of the span. Null to leave the span untimed (a reading is still in flight).
     */
    writes(): MarkPass | null;
    /**
     * After the span's last pass, in the same encoder, if writes() gave writes. Then call
     * collect() once the encoder is submitted.
     */
    resolve(encoder: GPUCommandEncoder): void;
    /** After the submit: read the span's times in the background. */
    collect(): void;
    /** The times since the last take; then start again. */
    take(): SpanTiming;
    destroy(): void;
    private release;
}
//# sourceMappingURL=gpuSpanTimer.d.ts.map