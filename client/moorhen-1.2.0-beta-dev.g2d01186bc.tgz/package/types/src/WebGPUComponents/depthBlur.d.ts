/** What the frame's depth blur does, from the source's settings (previewScene effectSettings). */
export interface DepthBlurSettings {
    /** Taps each side of the centre: WebGL's blurSize, the depthBlurRadius setting. */
    taps: number;
    /** The 2 taps + 1 Gaussian weights. */
    weights: number[];
    /** Pixels between taps on the canvas: blurSize / 2, as WebGL's shaders step. */
    step: number;
    /** The focal plane, as a value in the depth buffer (focalPlaneDepth). */
    focus: number;
}
/**
 * The blur for a depthBlurRadius: WebGL's own table, gaussianBlurs, which has radii 2 to 16 (a
 * radius it does not have is taken to the nearest it has).
 */
export declare function depthBlurKernel(radius: number): {
    taps: number;
    weights: number[];
};
/** How far the blur reaches, in pixels of an image `scale` times the canvas across: both passes. */
export declare function depthBlurMargin(settings: DepthBlurSettings | null, scale: number): number;
/**
 * Sub-taps a tap, for an image `scale` times the canvas across: as many as it takes to keep them
 * no further apart than WebGL's taps are on the canvas. 1 on the canvas, and in anything smaller.
 */
export declare function depthBlurSubTaps(scale: number): number;
export declare const DEPTH_BLUR_WGSL = "\nstruct Blur {\n    weights: array<vec4f, 9>,\n    params: vec4f,  // step in pixels across, down; the focal plane's depth; taps each side\n    flags: vec4f,   // x: a transparent layer's depth to fall back on; z: sub-taps a tap\n};\n\n@group(0) @binding(0) var<uniform> blur: Blur;\n// What the pass reads: across, the sharp picture; down, the across pass's; the composite, sharp.\n@group(0) @binding(1) var picture: texture_2d<f32>;\n@group(0) @binding(2) var linear: sampler;\n@group(0) @binding(3) var depth: texture_depth_multisampled_2d;\n@group(0) @binding(4) var depth2: texture_depth_2d;\n// Down, the sharp picture; the composite, the blurred one.\n@group(0) @binding(5) var second: texture_2d<f32>;\n// Down, the across pass's share: the weight of its taps that blurred.\n@group(0) @binding(6) var spread: texture_2d<f32>;\n\n@vertex\nfn vs_full(@builtin(vertex_index) vertex: u32) -> @builtin(position) vec4f {\n    let xy = vec2f(f32((vertex << 1u) & 2u), f32(vertex & 2u));\n    return vec4f(xy * 2.0 - 1.0, 0.0, 1.0);\n}\n\n// Where nothing was drawn the depth is still its cleared 1.\nconst DRAWN_DEPTH = 0.9999;\n\n// The depth of the nearest thing drawn at this point, as the blur shaders' sceneDepth: the opaque\n// scene's, or where it has nothing, the nearest transparent layer's. At the texel the point is in,\n// as WebGL's NEAREST lookup, and the nearest of its samples: the antialiased edge of something in\n// focus is in focus, though some of its samples are on the background.\nfn sceneDepth(p: vec2f) -> f32 {\n    let size = vec2i(textureDimensions(depth));\n    let texel = clamp(vec2i(floor(p)), vec2i(0), size - 1);\n    var d = 1.0;\n    for (var s = 0; s < i32(textureNumSamples(depth)); s++) { d = min(d, textureLoad(depth, texel, s)); }\n    if (blur.flags.x > 0.5 && d >= DRAWN_DEPTH) { d = min(textureLoad(depth2, texel, 0), 1.0); }\n    return d;\n}\n\n// Whether a tap spreads its own colour: what is there is beyond the focal plane - the empty\n// background too, so that out-of-focus geometry softens into it, not only spreads out over it.\n// (Leaving the background out, as WebGL's shaders did for a while, left a blurred structure merely\n// fuzzy round its edges.)\nfn blurs(p: vec2f) -> bool {\n    return sceneDepth(p) > blur.params.z;\n}\n\nfn weight(i: i32) -> f32 {\n    return blur.weights[i / 4][i % 4];\n}\n\nfn at(t: texture_2d<f32>, p: vec2f, size: vec2f) -> vec4f {\n    return textureSampleLevel(t, linear, p / size, 0.0);\n}\n\n// The colour of the texel the point is in: the one whose depth decided whether the tap blurs.\n// (Filtered, a tap on the background beside something in focus would take in some of its colour,\n// and spread it.)\nfn texelAt(t: texture_2d<f32>, p: vec2f) -> vec4f {\n    let size = vec2i(textureDimensions(t));\n    return textureLoad(t, clamp(vec2i(floor(p)), vec2i(0), size - 1), 0);\n}\n\n// Where tap i's sub-tap j falls: each tap is flags.z sub-taps spread evenly over its share of the\n// line, each with its share of the weight - one, exactly WebGL's tap, on the canvas.\nfn tapOffset(i: i32, j: i32, taps: i32, sub: i32) -> f32 {\n    return f32(i - taps) + (f32(j) + 0.5) / f32(sub) - 0.5;\n}\n\nstruct Across {\n    @location(0) spread: vec4f,\n    @location(1) share: vec4f,\n};\n\n// The blur of WebGL's two passes, taken as the one round blur they stand for. blur_x sums, at each\n// pixel, the taps that blur with their own colour, and stands the centre's colour in for the rest\n// (those in front of the focal plane); blur_y does the same again down. Summing down\n// the across pass's whole result, though, a tap that does not blur gives the centre's colour in\n// place of what the across pass spread onto it - so a small blurred piece glows along its rows and\n// down its columns, in a cross, and not between them.\n//\n// Here the rule is the same, in two dimensions: every tap of the round kernel that blurs counts\n// with its own colour, and the centre's colour stands in for the weight of all the rest. Across,\n// the blurring taps' sum and their share of the weight are kept apart; down, both are summed again,\n// and the centre's sharp colour takes the share still left. Along one line it is blur_x exactly.\n@fragment\nfn fs_depth_blur_across(@builtin(position) position: vec4f) -> Across {\n    let taps = i32(blur.params.w);\n    let sub = max(1, i32(blur.flags.z));\n    var sum = vec4f(0.0);\n    var share = 0.0;\n    for (var i = 0; i <= 2 * taps; i++) {\n        let w = weight(i) / f32(sub);\n        for (var j = 0; j < sub; j++) {\n            let p = position.xy + blur.params.xy * tapOffset(i, j, taps, sub);\n            if (blurs(p)) {\n                sum += w * texelAt(picture, p);\n                share += w;\n            }\n        }\n    }\n    var out: Across;\n    out.spread = sum;\n    out.share = vec4f(share, 0.0, 0.0, 0.0);\n    return out;\n}\n\n@fragment\nfn fs_depth_blur_down(@builtin(position) position: vec4f) -> @location(0) vec4f {\n    let size = vec2f(textureDimensions(picture));\n    let taps = i32(blur.params.w);\n    let sub = max(1, i32(blur.flags.z));\n    var sum = vec4f(0.0);\n    var share = 0.0;\n    for (var i = 0; i <= 2 * taps; i++) {\n        let w = weight(i) / f32(sub);\n        for (var j = 0; j < sub; j++) {\n            let p = position.xy + blur.params.xy * tapOffset(i, j, taps, sub);\n            sum += w * at(picture, p, size);\n            share += w * at(spread, p, size).x;\n        }\n    }\n    return sum + max(0.0, 1.0 - share) * at(second, position.xy, size);\n}\n\n// The sharp picture and the blurred one mixed by depth, as render-framebuffer-fragment-shader.js.\n@fragment\nfn fs_depth_blur_composite(@builtin(position) position: vec4f) -> @location(0) vec4f {\n    let texel = vec2i(position.xy);\n    let sharp = textureLoad(picture, texel, 0);\n    let d = sceneDepth(position.xy);\n    let focus = blur.params.z;\n    if (d > focus) {\n        let soft = textureLoad(second, texel, 0);\n        var frac = (d - focus) / (1.0 - focus);\n        frac = frac / (0.01 + frac);\n        return frac * soft + (1.0 - frac) * sharp;\n    }\n    return sharp;\n}\n";
/** One frame's (or tile's) pictures: sharp, blurred across, blurred both ways. */
export interface DepthBlurTargets {
    width: number;
    height: number;
    sharp: GPUTexture;
    /** Across: the sum of the taps that blurred, in half floats, for the down pass to sum again. */
    across: GPUTexture;
    /** Across: those taps' share of the weight. */
    spread: GPUTexture;
    both: GPUTexture;
    sharpView: GPUTextureView;
    acrossView: GPUTextureView;
    spreadView: GPUTextureView;
    bothView: GPUTextureView;
}
export declare class DepthBlur {
    private readonly device;
    private readonly format;
    private readonly sampler;
    private readonly module;
    private readonly layout;
    private readonly acrossPipeline;
    private readonly downPipeline;
    private readonly compositePipeline;
    private readonly uniforms;
    private readonly data;
    private targets;
    /**
     * `format`: the frame's, which the pictures are kept in too. `sampleCount`: the frame's
     * multisampled colour, which the composite writes.
     */
    constructor(device: GPUDevice, format: GPUTextureFormat, sampleCount: number, sampler: GPUSampler);
    /** The pictures for an image of this size, made if need be. */
    ensure(width: number, height: number): DepthBlurTargets;
    /**
     * Blur `t.sharp` across and then down, and write the mix into `colour` (the frame's
     * multisampled colour, whose contents it replaces). `depth`: the scene's multisampled depth;
     * `depth2`: the nearest transparent layer's, or null when there is none. `scale`: the image's
     * pixels to the canvas's, which the taps' spacing follows.
     */
    encode(encoder: GPUCommandEncoder, t: DepthBlurTargets, settings: DepthBlurSettings, scale: number, depth: GPUTextureView, depth2: GPUTextureView | null, depth2StandIn: GPUTextureView, colour: GPUTextureView): void;
    destroy(): void;
    private release;
}
//# sourceMappingURL=depthBlur.d.ts.map