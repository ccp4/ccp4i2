import type { EffectSettings } from './previewScene';
export declare const GBUFFER_NORMAL_FORMAT: GPUTextureFormat;
export declare const GBUFFER_DEPTH_FORMAT: GPUTextureFormat;
export declare const EFFECTS_WGSL = "\nstruct FullOut {\n    @builtin(position) position: vec4f,\n};\n\n// One triangle over the whole target.\n@vertex\nfn vs_full(@builtin(vertex_index) vertex: u32) -> FullOut {\n    let xy = vec2f(f32((vertex << 1u) & 2u), f32(vertex & 2u));\n    var out: FullOut;\n    out.position = vec4f(xy * 2.0 - 1.0, 0.0, 1.0);\n    return out;\n}\n\nstruct Ssao {\n    projection: mat4x4f,\n    inverseProjection: mat4x4f,\n    params: vec4f,       // radius (A), strength (an exponent on visibility), target width, height\n    origin: vec4f,       // where the target's first texel is in the whole image's (a tile's); g-buffer texels a pixel; unused\n    samples: array<vec4f, 32>,\n    noise: array<vec4f, 16>,\n};\n\n@group(0) @binding(0) var<uniform> ssao: Ssao;\n@group(0) @binding(1) var gDepth: texture_depth_2d;\n@group(0) @binding(2) var gNormal: texture_2d<f32>;\n\n// The eye-space point drawn at a g-buffer texel, from its depth through the projection's inverse.\nfn eyeAt(texel: vec2i, inverseProjection: mat4x4f) -> vec3f {\n    let size = vec2f(textureDimensions(gDepth));\n    let uv = (vec2f(texel) + 0.5) / size;\n    let ndc = vec4f(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0, textureLoad(gDepth, texel, 0), 1.0);\n    let eye = inverseProjection * ndc;\n    return eye.xyz / eye.w;\n}\n\nfn texelOf(uv: vec2f) -> vec2i {\n    let size = vec2i(textureDimensions(gNormal));\n    return clamp(vec2i(uv * vec2f(size)), vec2i(0), size - 1);\n}\n\n// ssao-fragment-shader.js, in the same terms: a hemisphere of radius A about the outward normal,\n// occluded where drawn geometry sits in front of a sample point by more than 0.05 A, weighted by\n// a range check, visibility raised to the strength.\n@fragment\nfn fs_ssao(in: FullOut) -> @location(0) vec4f {\n    // Each occlusion texel stands for the 2 x 2 pixels from twice its own; the g-buffer texel at\n    // the first of them is the one tested, so the grid is the same whatever the image's size.\n    let gsize = vec2i(textureDimensions(gNormal));\n    let texel = min(vec2i(floor(vec2f(vec2i(in.position.xy)) * 2.0 * ssao.origin.z)), gsize - 1);\n    let normalAll = textureLoad(gNormal, texel, 0);\n    if (normalAll.a < 0.5) { return vec4f(1.0); }\n    let normal = normalize(normalAll.xyz);\n    let fragPos = eyeAt(texel, ssao.inverseProjection);\n    // The noise repeats every 4 texels of the whole image, whichever tile this is.\n    let noiseAt = (vec2u(in.position.xy) + vec2u(ssao.origin.xy)) % vec2u(4u);\n    let randomVec = ssao.noise[noiseAt.x + 4u * noiseAt.y].xyz;\n    let tangent = normalize(randomVec - normal * dot(randomVec, normal));\n    let bitangent = cross(normal, tangent);\n    let TBN = mat3x3f(tangent, bitangent, normal);\n    let radius = ssao.params.x;\n\n    var occlusion = 0.0;\n    for (var i = 0u; i < 32u; i++) {\n        let samplePos = fragPos + (TBN * ssao.samples[i].xyz) * radius;\n        let clip = ssao.projection * vec4f(samplePos, 1.0);\n        let ndc = clip.xy / clip.w;\n        let sampleUV = vec2f(ndc.x * 0.5 + 0.5, 0.5 - ndc.y * 0.5);\n        // Off the image is open sky.\n        if (any(sampleUV < vec2f(0.0)) || any(sampleUV >= vec2f(1.0))) { continue; }\n        let at = texelOf(sampleUV);\n        if (textureLoad(gNormal, at, 0).a < 0.5) { continue; }\n        let sampleEye = eyeAt(at, ssao.inverseProjection);\n        let occluded = sampleEye.z >= samplePos.z + 0.05;\n        let rangeCheck = smoothstep(0.0, 1.0, radius / max(abs(fragPos.z - sampleEye.z), 1e-4));\n        occlusion += select(0.0, 1.0, occluded) * rangeCheck;\n    }\n    occlusion /= 32.0;\n    let ao = pow(clamp(1.0 - occlusion, 0.0, 1.0), ssao.params.y);\n    return vec4f(ao, ao, ao, 1.0);\n}\n\nstruct Blur {\n    step: vec4f,         // one tap's offset (uv), unused x2\n    weights: array<vec4f, 2>,\n};\n\n@group(0) @binding(0) var<uniform> blur: Blur;\n@group(0) @binding(1) var blurSource: texture_2d<f32>;\n@group(0) @binding(2) var blurSampler: sampler;\n\n// blur_x/y_simple-fragment-shader.js with gaussianBlurs[3]: seven taps, a texel and a half apart.\n@fragment\nfn fs_blur(in: FullOut) -> @location(0) vec4f {\n    let size = vec2f(textureDimensions(blurSource));\n    let uv = in.position.xy / size;\n    var sum = vec4f(0.0);\n    for (var i = 0u; i < 7u; i++) {\n        let w = blur.weights[i / 4u][i % 4u];\n        sum += w * textureSampleLevel(blurSource, blurSampler, uv + blur.step.xy * (f32(i) - 3.0), 0.0);\n    }\n    return sum;\n}\n\nstruct Edge {\n    inverseProjection: mat4x4f,\n    params: vec4f,       // depth threshold (A), normal threshold, depth step, normal step (g-buffer texels)\n};\n\n@group(0) @binding(0) var<uniform> edge: Edge;\n@group(0) @binding(1) var eDepth: texture_depth_2d;\n@group(0) @binding(2) var eNormal: texture_2d<f32>;\n\nfn distanceAt(texel: vec2i) -> f32 {\n    let size = vec2i(textureDimensions(eDepth));\n    let t = clamp(texel, vec2i(0), size - 1);\n    let uv = (vec2f(t) + 0.5) / vec2f(size);\n    let ndc = vec4f(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0, textureLoad(eDepth, t, 0), 1.0);\n    let eye = edge.inverseProjection * ndc;\n    return -eye.z / eye.w;\n}\n\nfn normalAt(texel: vec2i) -> vec3f {\n    let size = vec2i(textureDimensions(eNormal));\n    let n = textureLoad(eNormal, clamp(texel, vec2i(0), size - 1), 0);\n    // The background has no normal: zero, so it differs from every drawn one.\n    return select(vec3f(0.0), normalize(n.xyz), n.a > 0.5);\n}\n\n// edge-detect-fragment-shader.js: Sobel on the eye distance, a step of more than the threshold\n// (in A, the Sobel's 4 divided out) is an edge; Sobel on how far the neighbours' normals turn from\n// this one's, likewise. 0 on an edge, 1 elsewhere.\n@fragment\nfn fs_edge(in: FullOut) -> @location(0) vec4f {\n    let p = vec2i(in.position.xy);\n    let ds = i32(edge.params.z);\n    let ns = i32(edge.params.w);\n\n    let tl = distanceAt(p + vec2i(-ds, -ds));\n    let t = distanceAt(p + vec2i(0, -ds));\n    let tr = distanceAt(p + vec2i(ds, -ds));\n    let l = distanceAt(p + vec2i(-ds, 0));\n    let r = distanceAt(p + vec2i(ds, 0));\n    let bl = distanceAt(p + vec2i(-ds, ds));\n    let b = distanceAt(p + vec2i(0, ds));\n    let br = distanceAt(p + vec2i(ds, ds));\n    let gx = (tr + 2.0 * r + br) - (tl + 2.0 * l + bl);\n    let gy = (bl + 2.0 * b + br) - (tl + 2.0 * t + tr);\n    let depthEdge = sqrt(gx * gx + gy * gy) * 0.25 > edge.params.x;\n\n    var normalEdge = false;\n    if (ns > 0) {\n        let n = normalAt(p);\n        let ntl = dot(n, normalAt(p + vec2i(-ns, -ns)));\n        let nt = dot(n, normalAt(p + vec2i(0, -ns)));\n        let ntr = dot(n, normalAt(p + vec2i(ns, -ns)));\n        let nl = dot(n, normalAt(p + vec2i(-ns, 0)));\n        let nr = dot(n, normalAt(p + vec2i(ns, 0)));\n        let nbl = dot(n, normalAt(p + vec2i(-ns, ns)));\n        let nb = dot(n, normalAt(p + vec2i(0, ns)));\n        let nbr = dot(n, normalAt(p + vec2i(ns, ns)));\n        let ngx = (ntr + 2.0 * nr + nbr) - (ntl + 2.0 * nl + nbl);\n        let ngy = (nbl + 2.0 * nb + nbr) - (ntl + 2.0 * nt + ntr);\n        normalEdge = sqrt(ngx * ngx + ngy * ngy) > edge.params.y;\n    }\n    let value = select(1.0, 0.0, depthEdge || normalEdge);\n    return vec4f(value, value, value, 1.0);\n}\n";
/**
 * The occlusion kernel and noise, as initializeSSAOBuffers makes them: points in the +z hemisphere,
 * their lengths stratified by ssaoSampleLength; 16 random in-plane vectors to turn it by.
 */
export declare function ssaoKernel(seed?: number): {
    samples: Float32Array;
    noise: Float32Array;
};
/**
 * How far past a tile's edge its effects must be worked out for it to join its neighbours: the
 * occlusion radius in pixels (half again, for perspective's nearer things), and the blur's,
 * FXAA's and the Sobel's reach. `pixelsPerAngstrom` at the view centre.
 */
export declare function effectMargin(settings: EffectSettings, pixelsPerAngstrom: number): number;
/** The largest g-buffer side the finer g-buffer for edges may come to; past it the scale drops. */
export declare const MAX_GBUFFER_SIDE = 4096;
/**
 * G-buffer texels to an image pixel: 2 with edges on (see the top of this file), so long as that
 * keeps the g-buffer within MAX_GBUFFER_SIDE - a 4K canvas gets about 1 - and 1 for occlusion
 * alone, which has no use for more.
 */
export declare function gbufferScale(settings: EffectSettings, width: number, height: number): number;
/** A step in pixels as whole g-buffer texels at `scale`: at least one, unless it is 0 (off). */
export declare const stepInTexels: (pixels: number, scale: number) => number;
/** What the main pass reads: the maps made this frame, or white where an effect is off. */
export interface EffectMaps {
    ao: GPUTextureView;
    edge: GPUTextureView;
    /** frame.effects.x and .y. */
    flags: [number, number];
    /** Edge map texels a pixel: frame.effects.w. */
    edgeScale: number;
}
export declare class EffectPasses {
    private readonly device;
    private readonly module;
    private readonly ssaoLayout;
    private readonly blurLayout;
    private readonly ssaoPipeline;
    private readonly blurPipeline;
    private readonly edgePipeline;
    private readonly ssaoUniform;
    private readonly blurUniforms;
    private readonly edgeUniform;
    private readonly linear;
    private readonly white;
    readonly whiteView: GPUTextureView;
    private targets;
    private readonly kernel;
    constructor(device: GPUDevice);
    /** The sampler the main pass reads the maps with. */
    get sampler(): GPUSampler;
    /** Whether the settings ask for anything, and so for a g-buffer pass. */
    static wanted(settings: EffectSettings): boolean;
    /**
     * The g-buffer pass's attachments, for an image (or tile and margin) of this size, `scale`
     * texels a pixel (gbufferScale): begin it with this, draw with fs_gbuffer pipelines.
     */
    gbufferPass(width: number, height: number, scale?: number): GPURenderPassDescriptor;
    /**
     * Make the maps the settings ask for from the g-buffer (drawn already this frame, with the
     * same projection), and say what the main pass should read. `origin`: where the g-buffer's
     * first pixel is in the whole image, for a tile.
     */
    encode(encoder: GPUCommandEncoder, settings: EffectSettings, projection: ArrayLike<number>, origin?: [number, number]): EffectMaps;
    destroy(): void;
    private fullscreen;
    private releaseTargets;
    private ensure;
}
//# sourceMappingURL=effectPasses.d.ts.map