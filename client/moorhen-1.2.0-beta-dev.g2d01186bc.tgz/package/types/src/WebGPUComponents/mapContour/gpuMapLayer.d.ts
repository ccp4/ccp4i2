/**
 * The maps in the scene, contoured on the GPU for the WebGPU main view.
 *
 * Each frame it reads the same settings Moorhen contours with (visible maps, radius, level,
 * style, colours, the origin or a map's locked origin) from the store, remakes a map's contour on
 * the GPU only when its centre, radius or level has changed, and returns what to draw. Each map's
 * unit-cell grid is fetched from the Coot worker and kept on the GPU while the layer lasts, and
 * fetched again when the map's dataRevision goes up (MoorhenMap.markDataChanged); the old
 * grid is drawn until the new one is in.
 *
 * A map too big to contour here at its radius (a large radius, a large EM map: see GpuIsosurface)
 * is contoured at the largest radius that fits, and the console says so once. Coot is no help
 * there: at the same radius it is slower still, by minutes for a large EM map.
 */
import type { RootState } from "../../store/MoorhenReduxStore";
import type { PreviewGpuDraw } from "../previewRenderer";
export declare class GpuMapLayer {
    private readonly kernels;
    private readonly requestDraw;
    private readonly maps;
    /** What was last said about a map contoured at less than its radius, so it is said once. */
    private readonly limitsSaid;
    private destroyed;
    private readonly stopListening;
    /** What is being contoured, or what went wrong, on one line (for the GPU tests and debugging). */
    status: string;
    private constructor();
    static create(device: GPUDevice, requestDraw: () => void): Promise<GpuMapLayer>;
    /**
     * Bring the contours up to date and return what to draw.
     *
     * @param liveOrigin where the camera is *now*, overriding the store's copy of it. The store is
     *     told where the camera ended up rather than where it is passing through, so during a
     *     movie its copy is stale and contouring to it leaves the map behind. This layer runs once
     *     per frame with the camera already to hand, so it can simply be told.
     */
    frame(state: RootState, liveOrigin?: readonly [number, number, number]): PreviewGpuDraw[];
    /** Say once, in the console, that `map` is contoured at less than its radius, and why. */
    private sayLimit;
    /** Contours made so far, all maps together: for timing how soon a move is contoured (report). */
    get contoursMade(): number;
    /** Triangles in the maps' contours as last made, all maps together. */
    get triangles(): number;
    /** Lines of those contours' edges (each edge once), all maps together, drawn in the line styles. */
    get lines(): number;
    /**
     * Whether some map could not be contoured here at all (its unit cell could not be fetched or
     * put on the GPU, or not even a small contour fits): then Coot contours the maps instead
     * (MoorhenWebGPUMainView).
     */
    get failed(): boolean;
    destroy(): void;
    private clear;
    private release;
    /**
     * Fetch the map's unit cell, and swap it in when it arrives. Until then the current grid, if
     * there is one, is still drawn. The revision asked for is recorded first, so that a change
     * while this is in flight is fetched again afterwards.
     */
    private load;
    /** A first fetch failing stops the map being drawn; a later one leaves the old grid drawn. */
    private fetchFailed;
}
//# sourceMappingURL=gpuMapLayer.d.ts.map