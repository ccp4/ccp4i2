/**
 * Map contours made on the GPU and left there: the compute writes vertex, index and draw-argument
 * buffers that a WebGPU renderer on the same device draws with drawIndexedIndirect. Nothing waits
 * on the GPU: a change of level or centre is one submission, and the next frame draws its result.
 *
 * The output buffers are sized by guess. The totals are read back in the background, and if the
 * guess was too small (the draw then shows only part of the surface for a frame), the buffers
 * grow and the contour is made again.
 *
 * A contour can be too big for the GPU: a large radius, or a large EM map. Then it is made at the
 * largest radius that fits, and says so (`limitedRadius`, `limitReason`): a box no bigger than
 * the device allows in one buffer, nor than a budget (`mapContourLimits`). What is asked for is
 * made inside error scopes, so running out of memory is caught too, and the radius is brought down
 * until it fits. Nothing reaches the device's uncaptured errors, which would end WebGPU for the
 * whole view. Only if nothing fits at all does the isosurface give up (`tooBig`), and Coot
 * contours the maps.
 */
import { GpuScan } from "../gpu";
import { ContourBox, MapUnitCellGrid } from "./mapContourBox";
type Kernel = "sample" | "countVertices" | "countTriangles" | "countLines" | "emitVertices" | "emitTriangles" | "emitLines" | "totals";
/** The compiled kernels for one device, shared by every map contoured on it. */
export declare class MapContourKernels {
    readonly device: GPUDevice;
    readonly scan: GpuScan;
    readonly table: GPUBuffer;
    private readonly kernels;
    private constructor();
    static create(device: GPUDevice): Promise<MapContourKernels>;
    /**
     * One pass of `kernel` over `items` threads, with the parameters at group 0 and `buffers` at
     * group 1, in binding order.
     */
    dispatch(encoder: GPUCommandEncoder, kernel: Kernel, params: GPUBuffer, buffers: GPUBuffer[], items: number): void;
    destroy(): void;
}
/**
 * How big a contour may be. `bindingBytes`: the largest buffer, in place of the device's (for
 * tests). `budgetBytes`: the most one contour's work buffers may take - beyond it a contour is
 * slow to make (about 5 ns a box point on an M1) and memory goes on one map; 1 GB is a box of
 * about 50M points, 370 a side.
 */
export declare const mapContourLimits: {
    bindingBytes: number | null;
    budgetBytes: number;
};
/** The most box points a contour may have: its per-point arrays in one buffer each, within the budget. */
export declare function maxBoxPoints(device: GPUDevice): number;
/**
 * The largest buffer a contour may ask for: every one of them is bound as storage somewhere, so
 * the smaller of the device's largest buffer and largest storage binding.
 */
export declare function largestBuffer(device: GPUDevice): number;
/** A map's unit-cell grid, uploaded once. */
export declare class GpuMapGrid {
    readonly kernels: MapContourKernels;
    readonly grid: MapUnitCellGrid;
    readonly buffer: GPUBuffer;
    readonly frac: number[];
    constructor(kernels: MapContourKernels, grid: MapUnitCellGrid);
    /**
     * Upload `grid`, or reject saying why the GPU cannot hold it: bigger than its largest buffer,
     * or out of memory. Nothing reaches the device's uncaptured errors.
     */
    static create(kernels: MapContourKernels, grid: MapUnitCellGrid): Promise<GpuMapGrid>;
    destroy(): void;
}
/** What a renderer needs to draw a contour: vertex buffers, and indices with their draw arguments. */
export interface GpuContourBuffers {
    position: GPUBuffer;
    normal: GPUBuffer;
    /** Triangle indices. */
    triangles: GPUBuffer;
    /** The triangles' edges, each once, as pairs of vertex indices: what the line styles draw. */
    lines: GPUBuffer;
    /**
     * Draw arguments: drawIndexedIndirect's for the triangles at byte 0, drawIndirect's for thick
     * lines (6 vertices per line) at byte 32.
     */
    drawArgs: GPUBuffer;
}
export interface ContourRequest {
    centre: [number, number, number];
    radius: number;
    level: number;
}
/** One contour level of one map, remade when the request changes. */
export declare class GpuIsosurface {
    private readonly kernels;
    private readonly mapGrid;
    private readonly onRemade;
    /** First guess at the room needed: vertices per box point. Tests make it tiny to force growth. */
    static vertexRoomPerPoint: number;
    private readonly device;
    private readonly params;
    private readonly counts;
    private readonly countsRead;
    private readonly drawArgs;
    private work;
    private output;
    private last;
    /** Counts requests, so that an error found after the next request has begun is not blamed on it. */
    private requestNo;
    private reading;
    private destroyed;
    /**
     * How many times the contour has been made, and the box last contoured (the layer's status and
     * the renderer report's map walk).
     */
    made: number;
    lastBox: ContourBox | null;
    /** Triangles (kept, so drawn) and the lines of their edges, as last read back (the report). */
    lastTriangles: number;
    lastLines: number;
    /**
     * The radius last contoured, if smaller than asked for, and why: the box at the radius asked
     * for was too big for the GPU's buffers, the budget, or its memory.
     */
    limitedRadius: number | null;
    limitReason: string | null;
    /**
     * Why not even a small radius could be contoured here, or null. Nothing is drawn while it is
     * set; the map layer then gives the maps to Coot.
     */
    tooBig: string | null;
    /** The largest radius the GPU's memory has taken, after it refused a larger one. */
    private radiusCap;
    /** The radius of the contour last asked of the GPU. */
    private contouredRadius;
    /** `onRemade`: the room was too small; the next update will make the contour again. */
    constructor(kernels: MapContourKernels, mapGrid: GpuMapGrid, onRemade: () => void);
    /** The buffers to draw, or null before the first contour. */
    get buffers(): GpuContourBuffers | null;
    /** Make the contour for `request`, unless it is what was made last. Returns whether it did. */
    update(request: ContourRequest): boolean;
    /**
     * The GPU could not make the contour at `radius` (out of memory, or more triangles than a
     * buffer holds): free what was made for it, and try again at a radius with about half the box.
     */
    private shrink;
    /** Encode and submit the passes that make the contour; inside update's error scopes. */
    private contour;
    /** Not even a small contour can be made here: free everything, draw nothing, and say why. */
    private refuse;
    destroy(): void;
    /** In the background: if the room was too small, make more and the contour again. */
    private checkRoom;
    /** The work buffers for a box of `points` and `cells`, or null if they would be too big. */
    private workBuffers;
    private destroyWork;
    /**
     * Room for a fifth of the box's points as vertices, two triangles per vertex and three lines
     * per vertex (a closed surface has about 2 triangles and 3 edges per vertex), at first.
     */
    private outputBuffers;
    /** Room for at least this much, with half again to spare where a buffer can hold it; a smaller radius if it cannot. */
    private grow;
    private makeOutput;
    private destroyOutput;
    private writeParams;
}
export {};
//# sourceMappingURL=gpuMapContour.d.ts.map