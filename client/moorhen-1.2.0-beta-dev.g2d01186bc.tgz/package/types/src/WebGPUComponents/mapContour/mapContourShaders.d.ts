/** Threads per workgroup. */
export declare const MAP_WORKGROUP = 64;
/** Points or cells per thread in the count and emit kernels; dispatch chunksOf(items) threads. */
export declare const CHUNK = 8;
export declare const chunksOf: (items: number) => number;
/** One thread per box point: the map value there, less the contour level. */
export declare const SAMPLE_WGSL: string;
/**
 * One thread per CHUNK box points: which of each point's three edges the surface crosses; and
 * the number of vertices in the run.
 */
export declare const COUNT_VERTICES_WGSL: string;
/**
 * One thread per CHUNK cells of the box: which of each cell's triangles are kept - Coot's rule:
 * the midpoint within the sphere and, for an EM map, inside the map's box - as a bit per
 * triangle; and the number kept in the run. Only kept triangles are written, so the ones outside
 * the sphere (nearly half of those in the box) cost nothing to draw.
 */
export declare const COUNT_TRIANGLES_WGSL: string;
/**
 * One thread per CHUNK box points: their vertices, in orthogonal coordinates, with normals from
 * the map's gradient (central differences, interpolated along the edge), pointing away from the
 * density; and where each point's vertices start (vertexOffset), for the triangles.
 */
export declare const EMIT_VERTICES_WGSL: string;
/**
 * One thread per CHUNK cells: their kept triangles (keepMask, from the count), one after another
 * from the run's offset. The line styles draw these triangles' edges, from their own list (the
 * lines kernels), so that an edge two triangles share is drawn once.
 *
 * A triangle with a vertex beyond the room for vertices is written as a degenerate one (all
 * corners vertex 0), which draws nothing; the room is then grown and the contour made again.
 */
export declare const EMIT_TRIANGLES_WGSL: string;
/**
 * One thread per CHUNK cells: which edges of the cell's kept triangles it draws as lines - each
 * edge of the surface once, as a bit (3t + k: triangle t's edge from its corner k to the next);
 * and the number in the run.
 *
 * An edge is a pair of grid edges (its ends' vertices). It borders at most two triangles: two in
 * one cell (a diagonal of the cell's polygon) or, if both grid edges lie in a face of the cell,
 * one each in the two cells that share the face. So: of a cell's triangles that share an edge,
 * the first kept one draws it; and an edge in a cell's lower face (x, y or z least) is left to
 * the cell below if a kept triangle there has it too. An edge of a dropped triangle is drawn when
 * the kept triangle beside it is, as with Coot's lines from its kept triangles.
 */
export declare const COUNT_LINES_WGSL: string;
/**
 * One thread per CHUNK cells: their lines (lineMask, from the count) as pairs of vertex indices,
 * one after another from the run's offset; the renderer's thick-line shader draws a quad for each.
 * A line with an end beyond the room for vertices is written as (0, 0), which draws nothing.
 */
export declare const EMIT_LINES_WGSL: string;
/**
 * One thread: the totals (for the CPU to check the room was enough, when it gets round to it),
 * and the draw arguments, so the draws need nothing from the CPU. At word 0, drawIndexedIndirect's
 * for the triangles: (index count, instance count, first index, base vertex, first instance). At
 * word 8, drawIndirect's for thick lines: (vertex count, instance count, first vertex, first
 * instance), six vertices - two triangles - for each line.
 */
export declare const TOTALS_WGSL: string;
//# sourceMappingURL=mapContourShaders.d.ts.map