/**
 * The CPU side of contouring a map on the GPU: the map's grid as Moorhen holds it, and the box of
 * grid points Coot contours around a point.
 */
/** A map over one whole unit cell (every symmetry copy filled in), as the Coot worker sends it. */
export interface MapUnitCellGrid {
    /** Grid points along a, b and c. */
    nu: number;
    nv: number;
    nw: number;
    /** Fractional to orthogonal coordinates, row by row: clipper's Cell::matrix_orth(). */
    orth: number[];
    /** EM maps are not periodic: only what lies inside the map's data is kept. */
    isEM: boolean;
    /**
     * For an EM map, the grid points its data covers, from `min` to `max` inclusive of the point
     * past the end (as the cell is 0 to nu): from the map file's header (`emRangeFromMrcHeader`).
     * The grid itself is periodic, so the data is there wherever the header starts it; without
     * this the cell from 0 is taken, which cuts a map whose start is not 0 in two and swaps the
     * halves (EMD-1001: 30 sections from -15). Absent, the whole cell.
     */
    emRange?: {
        min: [number, number, number];
        max: [number, number, number];
    };
    /** Value at grid point (u, v, w): data[(w * nv + v) * nu + u]. */
    data: Float32Array;
}
/** A box of grid points, which may run past the cell: indices wrap around it. */
export interface ContourBox {
    /** Grid coordinates of the box's first point. */
    min: [number, number, number];
    /** Points along each axis. */
    size: [number, number, number];
}
/** clipper's Util::intr: rint, which rounds halves to even. */
export declare function rint(x: number): number;
/** The inverse of a 3x3 matrix given row by row. */
export declare function inverse3(m: number[]): number[];
/** The lengths of the cell edges a, b and c: the columns of the orthogonalising matrix. */
export declare function cellLengths(orth: number[]): [number, number, number];
/**
 * The grid points CIsoSurface::GenerateTriangles_from_Xmap contours for a sphere of `radius`
 * about `centre`: in fractional coordinates, the centre plus and minus radius / (a, b, c), each
 * end rounded to the grid as clipper's Coord_frac::coord_grid does, inclusive. Triangles are then
 * kept only if their midpoint is within the sphere. Null if there is nothing to contour.
 *
 * For an EM map the box stops one cell past each face of the map's data (`emRange`, else the
 * cell). Triangles are kept there only if their midpoint is inside it (keepMidpoint in
 * mapContourShaders.ts), so the cells beyond
 * add nothing; and with a radius larger than the map they can be most of the box - a box too big
 * for the GPU's buffers. The one cell kept on each side keeps a triangle whose midpoint rounds onto
 * a face, so the triangles are the same as for the whole box.
 */
export declare function contourBox(grid: MapUnitCellGrid, centre: ArrayLike<number>, radius: number): ContourBox | null;
/**
 * How many items of `bytesEach` to make room for: `needed` with `slack` to spare (so that a
 * slightly larger next request fits without making the buffer again), but no more than a buffer
 * of `limitBytes` holds. Null if even `needed` would not fit: the GPU cannot do it in one buffer.
 */
export declare function roomFor(needed: number, bytesEach: number, limitBytes: number, slack?: number): number | null;
/** Bytes as a person would say them: a decimal place below 10 MB, so 1.45 MB is not "1 MB". */
export declare function formatBytes(bytes: number): string;
/**
 * Bytes of work buffers a contour needs per box point: the field, edge mask and vertex offset per
 * point, the keep and line masks per cell (about as many). The per-run sums are an eighth of that.
 */
export declare const WORK_BYTES_PER_BOX_POINT = 20;
/**
 * The largest radius, up to `radius`, whose box about `centre` has no more than `maxPoints` grid
 * points: `radius` itself if its box is small enough. The box only grows with the radius, so a
 * bisection finds it.
 */
export declare function largestRadiusWithin(grid: MapUnitCellGrid, centre: ArrayLike<number>, radius: number, maxPoints: number): number;
/** The grid points an EM map's data covers: its `emRange`, or the whole cell. */
export declare function emRangeOf(grid: MapUnitCellGrid): {
    min: [number, number, number];
    max: [number, number, number];
};
/** What emRangeFromMrcHeader reads of a CCP4/MRC header (utils/mapHeaders.ts, MRCHeaderJson). */
export interface MrcGridHeader {
    dimensions: {
        nx: number;
        ny: number;
        nz: number;
    };
    start: {
        nxstart: number;
        nystart: number;
        nzstart: number;
    };
    sampling: {
        mx: number;
        my: number;
        mz: number;
    };
    axisMapping: {
        mapc: number;
        mapr: number;
        maps: number;
    };
}
/**
 * The grid points an EM map's data covers, in the grid's own axes (a, b, c: clipper's u, v, w),
 * from its CCP4/MRC header: columns, rows and sections start at NCSTART, NRSTART, NSSTART and run
 * for NC, NR, NS points, along the axes MAPC, MAPR, MAPS. Null if the header does not describe
 * this grid (its sampling differs, or its axes are not a permutation), when the whole cell is used.
 */
export declare function emRangeFromMrcHeader(header: MrcGridHeader, grid: MapUnitCellGrid): MapUnitCellGrid["emRange"] | null;
//# sourceMappingURL=mapContourBox.d.ts.map