/** A peel layer's colour: straight colour and alpha, as WebGL's layers hold them. */
export declare const PEEL_COLOUR_FORMAT: GPUTextureFormat;
export declare const PEEL_DEPTH_FORMAT: GPUTextureFormat;
/**
 * How many transparent layers to peel: depthPeelLayers less the opaque layer, as WebGL counts
 * them, at least one. 0 when nothing calls for peeling - order-independent transparency off, or
 * nothing transparent in view but hover highlights, which never switch it on in WebGL either.
 */
export declare function transparentLayers(source: {
    doOrderIndependentTransparency?: boolean;
    store?: {
        getState(): {
            sceneSettings?: {
                depthPeelLayers?: number;
            };
        };
    };
}, anyTransparent: boolean): number;
export declare const PEEL_COMPOSITE_WGSL = "\n@group(0) @binding(0) var opaqueDepth: texture_depth_multisampled_2d;\n@group(0) @binding(1) var layerColour: texture_2d_array<f32>;\n// One more layer than the colour: the first is the cleared one the first peel compares against.\n@group(0) @binding(2) var layerDepth: texture_depth_2d_array;\n\n@vertex\nfn vs_full(@builtin(vertex_index) vertex: u32) -> @builtin(position) vec4f {\n    let xy = vec2f(f32((vertex << 1u) & 2u), f32(vertex & 2u));\n    return vec4f(xy * 2.0 - 1.0, 0.0, 1.0);\n}\n\n// Once a sample: the layers in front of this sample's opaque depth, furthest first, each over the\n// ones behind it - the blend drawPeel's composite does layer by layer - as one premultiplied colour\n// for the pipeline to blend over the opaque picture.\n@fragment\nfn fs_composite(@builtin(position) position: vec4f, @builtin(sample_index) sample: u32) -> @location(0) vec4f {\n    let p = vec2i(position.xy);\n    let opaque = textureLoad(opaqueDepth, p, sample);\n    var colour = vec4f(0.0);\n    for (var k = i32(textureNumLayers(layerColour)) - 1; k >= 0; k--) {\n        let depth = textureLoad(layerDepth, p, k + 1, 0);\n        // Nothing drawn in this layer here (cleared to 1), or behind the opaque scene at this sample.\n        if (depth >= 1.0 || depth >= opaque) { continue; }\n        let c = textureLoad(layerColour, p, k, 0);\n        colour = vec4f(c.rgb * c.a + colour.rgb * (1.0 - c.a), c.a + colour.a * (1.0 - c.a));\n    }\n    return colour;\n}\n";
/** One frame's (or tile's) peeling targets: the readable opaque depth and the layers. */
export interface PeelTargets {
    width: number;
    height: number;
    layers: number;
    opaqueDepth: GPUTexture;
    opaqueDepthView: GPUTextureView;
    colour: GPUTexture;
    depth: GPUTexture;
    /** Each transparent layer's attachments, and the depth of the layer before it to read. */
    colourViews: GPUTextureView[];
    depthViews: GPUTextureView[];
    previousViews: GPUTextureView[];
    /** The cleared layer the first peel compares against. */
    zeroView: GPUTextureView;
    composite: GPUBindGroup;
}
export declare class DepthPeel {
    private readonly device;
    private readonly sampleCount;
    private readonly depthFormat;
    private readonly module;
    private readonly layout;
    private readonly compositePipeline;
    private targets;
    /**
     * `format` and `sampleCount`: the frame's multisampled colour target, which the composite
     * blends into. `depthFormat`: the opaque depth's, which the frame's other passes draw with.
     */
    constructor(device: GPUDevice, format: GPUTextureFormat, sampleCount: number, depthFormat: GPUTextureFormat);
    /** The targets for an image of this size and `layers` transparent layers, made if need be. */
    ensure(width: number, height: number, layers: number): PeelTargets;
    /** Clear the layer the first peel compares against to 0, so that it keeps everything. */
    clearZeroLayer(encoder: GPUCommandEncoder, t: PeelTargets): void;
    /**
     * Transparent layer `k`'s pass (0 nearest): its colour cleared to nothing, its depth to 1 - or,
     * for the second and later views of a divided canvas (`clear` false), kept, as each view peels
     * only its own part of the layer and the views' parts are blurred and composited together.
     */
    layerPass(t: PeelTargets, k: number, clear?: boolean): GPURenderPassDescriptor;
    /** Blend the layers over the opaque picture, in a pass on the frame's colour target. */
    composite(pass: GPURenderPassEncoder, t: PeelTargets): void;
    destroy(): void;
    private release;
}
//# sourceMappingURL=depthPeel.d.ts.map