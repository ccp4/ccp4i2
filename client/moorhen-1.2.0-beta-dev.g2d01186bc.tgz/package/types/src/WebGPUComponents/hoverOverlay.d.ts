/**
 * The hover overlay on a smooth mesh (MetaBalls, molecular surfaces, cavities): the hovered mesh
 * drawn again in orange over itself, blended, each vertex as opaque as the hovered point's share
 * of it (vs_hover_overlay in previewShaders.ts; what to light comes from hoverHighlight.ts).
 *
 * WebGL packs a mesh's influence lists into three textures; here they are storage buffers, made
 * the first time the mesh is hovered and kept while it stays in the scene with the same lists.
 * A mesh whose lists are bigger than one storage binding goes without the overlay, with a warning.
 *
 * Only the mesh's nearest surface lights, as in WebGL. Drawn over a transparent mesh - whose depth
 * is in no depth buffer - the overlay alone would show every layer of the mesh at once, its back
 * faces (flat, paler) blended over its front ones in whatever order they come. So the mesh's depth
 * is laid down first, in the pass's depth buffer, and the overlay then draws only where it is
 * level with that. For an opaque mesh the depth is already there and nothing changes.
 */
import type { DisplayBuffer } from '../WebGLgComponents/displayBuffer';
import type { HoverOverlay } from './hoverHighlight';
/** The parts of a mesh chunk the overlay draws with (previewRenderer's ChunkResources). */
export interface OverlayChunk {
    position: GPUBuffer;
    normal: GPUBuffer;
    index: GPUBuffer;
    indexCount: number;
    baseVertex: number;
    /** The mesh vertex the chunk's vertex 0 is; null for a chunk whose vertices were gathered. */
    firstVertex: number | null;
}
export declare class HoverOverlayLayer {
    private readonly device;
    private readonly module;
    private readonly target;
    private readonly depthFormat;
    private readonly sampleCount;
    private readonly maxBufferBytes;
    readonly layout: GPUBindGroupLayout;
    private readonly pipelineLayout;
    private pipeline;
    private depthPipeline;
    private readonly uniforms;
    /** Per buffer: its lists on the GPU. */
    private readonly influences;
    /** For a whole mesh: one-element stand-ins, never read. */
    private wholeGroup;
    private readonly standIns;
    private readonly warned;
    constructor(device: GPUDevice, module: GPUShaderModule, frameLayout: GPUBindGroupLayout, drawLayout: GPUBindGroupLayout, target: GPUColorTargetState, depthFormat: GPUTextureFormat, sampleCount: number, maxBufferBytes: number);
    /**
     * Draw the overlay of `overlay.buffer`'s first sub-buffer, whose mesh is in `chunks` and whose
     * Draw block for chunk c is `drawGroups[c]` (written for this frame by the main draw).
     */
    draw(pass: GPURenderPassEncoder, overlay: HoverOverlay, chunks: readonly OverlayChunk[], drawGroups: readonly GPUBindGroup[]): boolean;
    /** Free the lists of buffers that have left the scene. */
    forget(present: ReadonlySet<DisplayBuffer>): void;
    destroy(): void;
    private influenceBindGroup;
    private wholeBindGroup;
    private bindGroup;
    /**
     * Blended over the scene, depth-tested less-equal against the mesh's own depth and writing
     * none, as drawCore draws its overlay (depthFunc LEQUAL, depthMask false, blending on).
     */
    private ensurePipeline;
    /** The mesh's depth alone, colour untouched: the same vertex shader, so the same depths. */
    private ensureDepthPipeline;
    private makePipeline;
}
//# sourceMappingURL=hoverOverlay.d.ts.map