/**
 * `moorhenInstance.webGPU`: who draws the main view, and the WebGPU renderer from tests and the
 * console.
 *
 * - mainView() says who draws the main view; setMainView() asks for WebGPU or WebGL (the
 *   preference); simulateDeviceLoss() loses the shared device, as a GPU reset would.
 * - report() and reportFacts(): how this machine draws Moorhen, for a tester to paste back. They
 *   draw frames, and with maps shown move the origin round a small square and put it back.
 * - snapshot() draws the scene the main view shows with a WebGPU renderer of its own, offscreen,
 *   from the store's DisplayBuffers and the WebGL renderer's camera, with what it cannot draw
 *   reported in `skipped` (describeSkipped); webGLSnapshot() reads the WebGL view's pixels, to
 *   compare the two.
 */
import type { DisplayBuffer } from "../WebGLgComponents/displayBuffer";
import { setUseWebGPU } from "../store/sceneSettingsSlice";
import type { WebGPUMainViewRenderer } from "../components/webMG/MoorhenWebGPUMainView";
import { type RendererReportFacts } from "./rendererReport";
/** An image: RGBA, 8 bits a channel, top row first (as ImageData has it). */
export interface RendererImage {
    width: number;
    height: number;
    data: Uint8ClampedArray;
}
/** A WebGPU image of the scene, and what went into it. */
export interface WebGPUSceneSnapshot extends RendererImage {
    /** Tiles it was drawn in: more than one for an image bigger than the largest tile. */
    tiles: number;
    /** Meshes (sub-buffers) and triangles drawn, instances included, and perfect spheres. */
    meshes: number;
    triangles: number;
    spheres: number;
    /** Line segments (LINES, NORMALLINES) drawn. */
    segments: number;
    /** Text labels drawn. */
    labels: number;
    /**
     * The scene effects drawn, as the main view's settings ask for them - the same flags the WebGL
     * view draws with, so this says what both pictures should show.
     */
    effects: {
        ssao: boolean;
        edges: boolean;
        shadow: boolean;
        depthBlur: boolean;
    };
    /** Transparent layers depth-peeled (depthPeel.ts); 0 if nothing called for peeling. */
    peelLayers: number;
    /** What is in the scene but not drawn by the WebGPU renderer yet, with sub-buffer counts. */
    skipped: Record<string, number>;
    /** The same, as a sentence; empty if nothing was left out. */
    skippedText: string;
}
/** One sub-buffer the WebGPU renderer leaves out (or draws only in part), described for a person. */
export interface SkippedSubBufferInfo {
    why: string;
    /** Whose it is: "molecule style", "map key", or the buffer's statsLabel, as far as can be told. */
    owner: string;
    bufferType: string;
    /** Array lengths, in numbers (not vertices). */
    vertices: number;
    normals: number;
    colours: number;
    indices: number;
    instanceOrigins: number;
    customColour: number[] | null;
    transparent: boolean;
    symmetryCopies: number;
    hasTransform: boolean;
    isHoverBuffer: boolean;
}
export interface WebGPUSnapshotOptions {
    /** Size in pixels. Defaults to the main view's drawing buffer, so the two can be compared. */
    width?: number;
    height?: number;
    /** Largest tile to draw in (default 2048); bigger images are drawn in tiles. */
    maxTile?: number;
}
/**
 * The parts of MoorhenInstance this uses. The store is typed by the one thing read from it: typing
 * it as Store<RootState> would make MoorhenInstance's type depend on the store's, which depends on
 * MoorhenInstance's again, and TypeScript gives up on the circle.
 */
export interface WebGPUApiHost {
    store: {
        getState(): {
            glRef: {
                displayBuffers?: DisplayBuffer[];
            };
            molecules?: {
                moleculeList?: unknown[];
            };
            maps?: unknown[];
            sceneSettings?: {
                useWebGPU?: boolean;
            };
        };
        dispatch(action: ReturnType<typeof setUseWebGPU>): unknown;
    };
    getVideoRecorderRef(): {
        readonly current: {
            glRef: {
                readonly current: unknown;
            };
        } | null;
    };
}
/** `moorhenInstance.webGPU`. Experimental; likely to change while the WebGPU renderer is built. */
export interface WebGPUApi {
    /** Why WebGPU cannot be used in this browser, or null if it can. Does not start a device. */
    unavailableReason(): string | null;
    /** Whether this browser offers WebGPU at all (a device may still fail to start). */
    available(): boolean;
    /**
     * Start the shared WebGPU device (or reuse it): null if WebGPU can draw here, otherwise why
     * not. Unlike unavailableReason() this finds browsers that offer WebGPU but no adapter, as
     * headless browsers and blocklisted GPUs do.
     */
    deviceUnavailableReason(): Promise<string | null>;
    /**
     * Draw what the main view shows with the WebGPU renderer, offscreen, with the main view's
     * camera. Rejects if WebGPU is unavailable or reports an error while drawing.
     */
    snapshot(options?: WebGPUSnapshotOptions): Promise<WebGPUSceneSnapshot>;
    /** What the main (WebGL) view shows, the size of its drawing buffer. */
    webGLSnapshot(): RendererImage;
    /** Each sub-buffer in the scene that WebGPU leaves out, or draws in part, and why. */
    describeSkipped(): SkippedSubBufferInfo[];
    /**
     * Who draws the main view: whether WebGPU is asked for (sceneSettings.useWebGPU), whether it
     * has taken the view (`active`), whether it drew the last frame (`drawing`) and, if WebGL did,
     * why (`webGLReason`), how many frames WebGPU has drawn, and whether maps are contoured on the
     * GPU (`mapsOnGpu`: while WebGPU draws, mapContour/setting.ts).
     */
    mainView(): {
        requested: boolean;
        active: boolean;
        drawing: boolean;
        webGLReason: string | null;
        framesDrawn: number;
        lastFrame: WebGPUMainViewRenderer["lastFrame"];
        mapsOnGpu: boolean;
    };
    /**
     * How this machine draws Moorhen, on one line for a tester to paste back (rendererReport.ts):
     * browser and platform, secure context, the WebGPU adapter or why there is none, who draws the
     * main view and why, where maps are contoured, the time of `frames` frames of the current
     * scene (60 by default; 0 for none), drawn one an animation frame after a few untimed, and -
     * with maps showing - a walk of `mapWalk` small moves of the origin (20 by default; 0 for
     * none), each timed until its new contours are drawn. The origin is put back after.
     */
    report(options?: {
        frames?: number;
        mapWalk?: number;
    }): Promise<string>;
    /** What report() says, as it gathered it. */
    reportFacts(options?: {
        frames?: number;
        mapWalk?: number;
    }): Promise<RendererReportFacts>;
    /** Ask for the main view to be drawn with WebGPU, or not (the preference, so it is remembered). */
    setMainView(useWebGPU: boolean): void;
    /**
     * Lose the shared WebGPU device, as a GPU reset would (device.destroy()): for testing that the
     * main view makes a new one. Resolves false if there was no device to lose.
     */
    simulateDeviceLoss(): Promise<boolean>;
}
/** Build the `webGPU` API object for one instance. */
export declare function makeWebGPUApi(host: WebGPUApiHost): WebGPUApi;
//# sourceMappingURL=instanceApi.d.ts.map