export declare const ANAGLYPH_WGSL = "\nstruct Anaglyph {\n    left: vec4f,        // 1 in the channels the left eye's picture goes into\n    right: vec4f,       // and the right's\n    background: vec4f,\n    params: vec4f,      // x: 1 for a picture on nothing (premultiplied), 0 on the background\n};\n@group(0) @binding(0) var<uniform> u: Anaglyph;\n@group(0) @binding(1) var leftEye: texture_2d<f32>;\n@group(0) @binding(2) var rightEye: texture_2d<f32>;\n\n@vertex\nfn vs_full(@builtin(vertex_index) i: u32) -> @builtin(position) vec4f {\n    let p = vec2f(f32((i << 1u) & 2u), f32(i & 2u));\n    return vec4f(p * 2.0 - 1.0, 0.0, 1.0);\n}\n\n// Premultiplied, so the grey is too.\nfn grey(c: vec4f) -> f32 {\n    return max(c.r, max(c.g, c.b));\n}\n\n@fragment\nfn fs_anaglyph(@builtin(position) position: vec4f) -> @location(0) vec4f {\n    let xy = vec2i(position.xy);\n    let l = textureLoad(leftEye, xy, 0);\n    let r = textureLoad(rightEye, xy, 0);\n    if (u.params.x > 0.5) {\n        return vec4f(u.left.rgb * grey(l) + u.right.rgb * grey(r), max(l.a, r.a));\n    }\n    let fromLeft = vec3f(grey(l)) + u.background.rgb * (1.0 - l.a);\n    let fromRight = vec3f(grey(r)) + u.background.rgb * (1.0 - r.a);\n    let rgb = select(select(u.background.rgb, fromRight, u.right.rgb > vec3f(0.5)), fromLeft, u.left.rgb > vec3f(0.5));\n    return vec4f(rgb, 1.0);\n}\n";
/** The combine's uniforms: the channel masks, the background, and whether on nothing. */
export declare function anaglyphUniforms(colours: string | undefined | null, background: ArrayLike<number>, transparent: boolean): Float32Array;
/** The two eyes' pictures and the pass that puts them together. */
export declare class AnaglyphCombine {
    private readonly device;
    private readonly format;
    private readonly layout;
    private readonly pipeline;
    private readonly uniforms;
    private eyes;
    private bindGroup;
    constructor(device: GPUDevice, format: GPUTextureFormat);
    /** The views to resolve each eye's frame into, `width` x `height`, kept while the size is. */
    eyeViews(width: number, height: number): GPUTextureView[];
    /** The eyes, after eyeViews and their frames, put together into `resolve`, and submitted. */
    combine(resolve: GPUTextureView, uniforms: Float32Array): void;
    destroy(): void;
}
//# sourceMappingURL=anaglyphCombine.d.ts.map