/**
 * What the hover lights this frame, worked out as drawCore works it out for WebGL, so that the
 * WebGPU renderer lights the same things. No GPU here.
 *
 * MGWebGL keeps the hover state whoever draws: the pick (doHover in eventHandlers.ts) writes
 * state.hoveridx (an index into glRef.displayBuffers) and state.hover_point (an index into that
 * buffer's pick_points); the sequence viewer names a residue as hoveringStates.hoveredSection;
 * and pickLevel is the grain the zoom has chosen (utils/pickLevel.ts). WebGL lights three ways:
 *
 * - **A section of a mesh** (a ribbon's residue): during the main draw, the instanced vertex
 *   shader lightens the vertices [from, to) of the hovered section halfway to white
 *   (uHighlightFrom, uHighlightTo). The range comes from the buffer's section ranges at the
 *   current level, for the pointer's pick point or for the section the sequence viewer asks for.
 * - **A whole instance** (instanced shapes without sections): the same, for gl_InstanceID equal
 *   to the hovered instance (uHoveredInstance).
 * - **A smooth mesh** (MetaBalls, molecular surfaces): an overlay, the hovered mesh drawn again
 *   in orange, blended, each vertex as opaque as the share of it the hovered point has - summed
 *   from its influence list over the points whose owner code matches the hovered one under the
 *   level's mask - with a green ring where the share is 0.45. A mesh that is one whole thing (a
 *   cavity, `highlight_whole`) lights solid. Meshes of one highlight group (a nucleic acid's
 *   backbone and base sticks: highlightGroup.ts) light together.
 *
 * The fourth, triangles of `point_triangles` drawn in black, is left out: nothing makes them.
 */
import type { DisplayBuffer } from '../WebGLgComponents/displayBuffer';
import { type InfluenceData } from '../WebGLgComponents/glResources';
/** What a renderer's camera source carries of the hover: MGWebGL has all of it. */
export interface HoverSource {
    state?: {
        hoveridx?: number;
        hover_point?: number;
    };
    pickLevel?: number;
    store?: {
        getState(): {
            hoveringStates?: {
                hoveredSection?: {
                    bufferId: string;
                    section: number;
                } | null;
            };
        };
    };
}
/** The hovered point's code that matches every vertex: drawCore's sentinel for "the whole mesh". */
export declare const WHOLE_MESH = 4294967295;
/** The smooth mesh overlay: which buffer (its first sub-buffer), and which points light. */
export interface HoverOverlay {
    buffer: DisplayBuffer;
    /** The hovered point's owner code (or index, for a mesh without codes); WHOLE_MESH for a whole mesh. */
    point: number;
    /** Which bits of a code must match; all ones for one point. */
    mask: number;
    /** Light every vertex fully: a mesh that is one whole thing. */
    whole: boolean;
    /** The influence lists; null for a whole mesh. */
    influence: InfluenceData | null;
}
/** For an instanced sub-buffer: the instance lit whole, and the vertices [from, to) lit; -1 for none. */
export interface SubBufferHighlight {
    instance: number;
    from: number;
    to: number;
}
export declare const NO_HIGHLIGHT: SubBufferHighlight;
export interface HoverHighlight {
    /**
     * The smooth mesh overlays: the hovered mesh first, then the others of its highlight group
     * (highlightGroup.ts), all with its point and mask. Empty for none.
     */
    overlays: HoverOverlay[];
    /** What to light in sub-buffers of `buffer` that are drawn instanced (the others: nothing). */
    forBuffer(buffer: DisplayBuffer): SubBufferHighlight;
}
export declare const NO_HOVER: HoverHighlight;
/**
 * The hover highlight for a frame of `displayBuffers` (the store's glRef.displayBuffers, which
 * hoveridx indexes) as `source` has it. Mirrors drawTriangles' instanced loop and the overlay at
 * the end of drawCore's GLrender, condition for condition.
 */
export declare function hoverHighlight(source: HoverSource, displayBuffers: readonly DisplayBuffer[]): HoverHighlight;
//# sourceMappingURL=hoverHighlight.d.ts.map