/**
 * The CPU-side set-up for GPU MetaBalls: the grid, and the points sorted into bins.
 *
 * The grid has to be the one metaballs/metaballs.cc builds, to the last bit, or the two meshes
 * cannot be compared vertex for vertex - and a different grid is a visibly different surface.
 * That code works in single precision, so every step here is rounded to float32 with Math.fround
 * in the same order as the C++. Float32 add, subtract, multiply and divide done in double and
 * then rounded give the correctly rounded float32 result, so this is exact, not approximate.
 */
/** The C++ constants. See GenerateMeshFromPoints and fill_field in metaballs.cc. */
export declare const METABALLS_PADDING = 4;
export declare const METABALLS_FIELD_CUTOFF = 5;
export interface MetaBallsGrid {
    /** World position of grid point (0, 0, 0). */
    min: [number, number, number];
    /** Grid points along each axis. Cells are one fewer. */
    n: [number, number, number];
    /** Spacing, the same on every axis. */
    cell: number;
}
/**
 * The grid GenerateMeshFromPoints lays over `points` (x, y, z, r per point).
 *
 * Null when there is nothing to march: no points, or a grid with fewer than two points along an
 * axis, which has no cells.
 */
export declare function metaballsGrid(points: Float32Array, gridSize: number, isoLevel: number): MetaBallsGrid | null;
export interface PointBins {
    /** World position of the corner of bin (0, 0, 0). */
    origin: [number, number, number];
    size: number;
    dims: [number, number, number];
    /** start[b] .. start[b+1] are bin b's entries in `order`. Length = bins + 1. */
    start: Uint32Array;
    /** Point indices, grouped by bin, ascending within a bin. */
    order: Uint32Array;
}
/**
 * Sort the points into a uniform grid of cubic bins covering the MetaBalls grid.
 *
 * A counting sort, so stable: within a bin the points stay in their original order. The shaders
 * work out which bins to visit from the exact reach of each calculation, so any bin size gives
 * the same answer; the size only trades bins visited against points tested.
 */
export declare function binPoints(points: Float32Array, grid: MetaBallsGrid, binSize: number): PointBins;
/**
 * The radius of a MetaBalls point for a sphere of instance size `size`, as
 * GenerateMoorhenMetaBallsCootInstancedMesh computes it: r * atomMult / 1.7f in float.
 */
export declare function metaballRadius(radius: number, size: number): number;
/**
 * How many grid planes to process at a time.
 *
 * The GPU path works through the grid a slab of planes at a time, so its memory is bounded by
 * the slab rather than by the molecule. Each slab holds two planes beyond its own (the next
 * slab's first plane and the one after, for the edges between them). Their field is handed on to
 * the next slab rather than worked out again, so the cost of those planes is memory, and the
 * minimum of 8 keeps that small.
 */
export declare function slabDepth(grid: MetaBallsGrid, maxSlabPoints: number): number;
/**
 * The grid-index box each point adds to in fill_field, for the points in `order`:
 * [ixMin | ixMax << 16, iyMin | iyMax << 16, izMin | izMax << 16] per point.
 *
 * fill_field works these out per point as (int)((x0 - cutoff - min_x) / cell_x) and so on. Doing
 * the same here, once per point and in float32, leaves the field shader integer comparisons where
 * it had six divisions and six conversions for every point it looked at, at every grid point.
 * Sixteen bits per bound is plenty: a grid that size would need terabytes.
 */
export declare function pointIndexBoxes(points: Float32Array, grid: MetaBallsGrid, order: Uint32Array): Uint32Array;
/** The most grid planes any point's index box spans (pointIndexBoxes' layout). */
export declare function boxZSpan(boxes: Uint32Array): number;
/**
 * The range of binned points ([start, end) in `bins.order` order) that can have a box reaching
 * planes z0 .. z1 - 1. Bins are numbered z-major, so that is one run. Generous at the ends: the
 * shader tests each point's box exactly.
 */
export declare function slabPointRange(bins: PointBins, grid: MetaBallsGrid, z0: number, z1: number): [number, number];
/**
 * Fractional bits for the fixed-point box sums of the split field: as many as possible (up to
 * 28) while the largest sum any voxel could have still fits a signed 32-bit integer with a
 * factor of two to spare.
 *
 * The bound: a point's box only reaches voxels within cutoff + cell of it on each axis, so a
 * voxel's points lie in the bins within that reach, plus one, of its own (7 x 7 x 7 with the
 * usual bins, (cutoff + cell) / 2 wide);
 * the largest such window sum of rr / 30 is at least every voxel's total. Usually 26-28 bits,
 * which rounds each point's w by at most 2^-27..2^-29 against the float32 field's ~1e-7.
 *
 * Returns fewer than 20 only for a pile of points far denser than any structure; the caller
 * then uses the plain field kernel instead.
 */
export declare function fieldFixedPointBits(points: Float32Array, bins: PointBins, cell: number): number;
//# sourceMappingURL=metaballsGrid.d.ts.map