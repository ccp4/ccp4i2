import { GpuMetaBalls } from "./gpuMetaBalls";
export { GpuMetaBalls } from "./gpuMetaBalls";
export type { MetaBallsInput, MetaBallsMesh, MetaBallsOptions } from "./gpuMetaBalls";
export { METABALLS_SPHERE_ARGS, metaballsInputFromSpheres, metaballsMeshData } from "./metaballsMeshData";
/**
 * The parameters getMetaBallBuffers passes to DrawMoorhenMetaBalls (grid spacing, radius,
 * isosurface level), shared so that the two paths cannot drift apart.
 */
export declare const METABALLS_GRID_SIZE = 0.2;
export declare const METABALLS_RADIUS = 0.67;
export declare const METABALLS_ISO_LEVEL = 1.8;
/** The dev-menu switch. Read when a MetaBalls representation is (re)built. */
export declare const gpuMetaBallsSetting: {
    enabled: boolean;
    splitField: boolean;
};
/**
 * The GPU MetaBalls generator, on the shared device (../gpu), made once and reused. Null when
 * WebGPU is not there or offers no adapter; the result is remembered, and forgotten again if the
 * device is lost, so that a later call can try afresh.
 */
export declare function sharedGpuMetaBalls(): Promise<GpuMetaBalls | null>;
//# sourceMappingURL=index.d.ts.map