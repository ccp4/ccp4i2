/**
 * WGSL for GPU MetaBalls: a transcription of metaballs/metaballs.cc and the marching cubes in
 * metaballs/MC.h, reorganised so that every step is one thread per grid point, cell or vertex.
 *
 * The arithmetic follows the C++ operation for operation, so that the field, the vertex
 * positions and the per-vertex normals and colours come out the same. They match to within
 * float rounding rather than exactly, for three reasons: the field is summed in a different
 * order (and partly in fixed point, see the split field below), WGSL's division is allowed to be
 * a couple of ulps out, and the compiler may fuse multiplies and adds.
 *
 * The grid is processed a slab of z planes at a time. Plane indices are global; buffers hold a
 * slab, indexed from the slab's first plane, `z0`.
 *
 * Vertices are owned by grid edges, as in MC.h: point (x, y, z) owns the edge to (x+1, y, z),
 * (x, y+1, z) and (x, y, z+1), and an edge that the surface crosses has exactly one vertex. A
 * point's vertices are numbered in axis order x, y, z, after all the vertices of the points
 * before it. That is a different order from MC.h's, which numbers vertices as it first meets
 * them, but it is the same set of vertices and - because cells are visited in the same order -
 * the same triangles in the same order.
 */
/** Threads per workgroup for the one-thread-per-item kernels. */
export declare const ITEM_WORKGROUP = 64;
/** Edge of the cube of grid points one near-field workgroup computes. */
export declare const FIELD_BRICK = 4;
/**
 * Part 1a: one thread per (point, plane of its box): the four corners of the point's rectangle
 * on that plane, into a difference array laid out like the field. A corner one past the last
 * column or row is left out: nothing after it is summed. Only the points whose box can reach the
 * slab are visited: P.kStart .. P.kStart + P.kCount - 1.
 */
export declare const FIELD_BOXES_WGSL: string;
/** Part 1b: one thread per column (x, plane), summing the difference array along y in place. */
export declare const FIELD_COLUMNS_WGSL: string;
/**
 * Part 1c: rows (y, plane), a workgroup at a time: the column sums summed along x - a scan of
 * the row in workgroup memory, a chunk of 1024 at a time - which is the boxes' total, written to
 * the field as -isoLevel + total * 2^-bits.
 *
 * Each workgroup takes every n-th row, n the number of workgroups started (ROW_WORKGROUPS in
 * gpuMetaBalls.ts) (WebGPU zeroes workgroup memory each time a
 * workgroup starts, and Firefox does that with one thread, so starting one per row was costly
 * there). Items for the dispatch are workgroups * 64, so that dispatch() makes that many.
 */
export declare const FIELD_ROWS_WGSL: string;
/**
 * Part 2: the points nearer than 3.46 A, one workgroup per 4x4x4 brick of grid points.
 *
 * The workgroup first collects the points that come that near any point of its brick into
 * workgroup memory, then every thread corrects its own voxel from that list. The list is built
 * deterministically: each thread counts what it finds in its share of the bins, the counts are
 * scanned, and each thread writes its points at its offset, so every run sums the same points in
 * the same order. A brick no point comes near - most of the box around a large structure - stops
 * after the count. One with more points than fit is done in rounds.
 *
 * Each workgroup takes every n-th brick, n being the number of workgroups (see FIELD_ROWS_WGSL
 * for why). Items for the dispatch are workgroups * 64, so that dispatch() makes that many.
 */
export declare const FIELD_NEAR_WGSL: string;
/**
 * The scalar field, one thread per grid point, as fill_field writes it: every point whose box
 * holds the voxel, the full formula, no splitting. Slower, and kept as the plain reference
 * (gpuMetaBallsSetting.splitField off), and as the fallback for a selection so dense that the
 * fixed-point box sums would lose precision.
 */
export declare const FIELD_DIRECT_WGSL: string;
/**
 * One thread per grid point of the counting planes: which of its three edges the surface
 * crosses (bit 0 x, 1 y, 2 z), and how many that is.
 */
export declare const COUNT_VERTICES_WGSL: string;
/** One thread per cell of the slab: how many triangles it contributes. */
export declare const COUNT_TRIANGLES_WGSL: string;
/**
 * One thread per grid point of the owned planes: write its vertices.
 *
 * MC.h: v = (x, y, z); v[axis] += va / (va - vb); then each coordinate * cell + min.
 */
export declare const EMIT_VERTICES_WGSL: string;
/** One thread per cell of the slab: write its triangles, as global vertex indices. */
export declare const EMIT_TRIANGLES_WGSL: string;
/**
 * One thread per vertex owned by the slab: normal and colour, and how many influences it has.
 * smooth_mesh in metaballs.cc, line for line.
 */
export declare const SMOOTH_WGSL: string;
/** One thread per vertex owned by the slab: write its influences (point index, weight). */
export declare const INFLUENCES_WGSL: string;
/**
 * The slab's totals: the vertices it owns, its triangles, its influences - moved into the
 * mesh-so-far offsets by `advance`, and read back afterwards to check they fitted the room. One
 * thread.
 *
 * totals[0] = vertices owned by the slab: the offset of the first point of the first plane it
 *             does not own, or the grand total when it owns every counted plane.
 * totals[1] = triangles.  totals[2] = influences.
 */
export declare const TOTALS_WGSL: string;
/**
 * One thread per vertex of the slab's room: each vertex's END in the whole mesh's influence list,
 * as DrawMoorhenMetaBalls packs it, written over its count. After INFLUENCES_WGSL, which needs the
 * counts.
 */
export declare const INFLUENCE_ENDS_WGSL: string;
//# sourceMappingURL=metaballsShaders.d.ts.map