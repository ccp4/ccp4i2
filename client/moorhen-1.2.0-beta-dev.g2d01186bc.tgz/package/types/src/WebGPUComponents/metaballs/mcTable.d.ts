/**
 * The marching-cubes triangle table from metaballs/MC.h (mc_internalMarching_cube_tris), split into
 * 32-bit halves because WGSL has no 64-bit integers: entry c is (lo, hi) at [2c, 2c+1].
 *
 * Each 64-bit value packs the triangle count in its low nibble and then up to 15 edge numbers,
 * one per nibble from bit 4. Nibbles never straddle the two halves, as 32 is a multiple of 4.
 * The edge numbering is MC.h's: 0-3 are x edges, 4-7 y edges, 8-11 z edges (see EDGE_POINTS in
 * metaballsShaders.ts). Generated from MC.h; do not edit by hand.
 */
export declare const MC_TRIANGLE_TABLE: Uint32Array<ArrayBuffer>;
//# sourceMappingURL=mcTable.d.ts.map