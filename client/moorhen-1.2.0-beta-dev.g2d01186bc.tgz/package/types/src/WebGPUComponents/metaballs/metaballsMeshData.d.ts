/**
 * Getting MetaBalls points out of Coot's sphere data, and the GPU mesh back into the shape
 * Moorhen's representation code expects.
 *
 * Both ends copy existing code exactly, so that the GPU path is a drop-in for DrawMoorhenMetaBalls:
 *
 *  - in: DrawMoorhenMetaBalls asks for the "VDW-BALLS" instanced spheres and gives each one a
 *    radius of radius * size / 1.7 (GenerateMoorhenMetaBallsCootInstancedMesh). The worker's
 *    "instanced_mesh_perfect_spheres" conversion carries the same spheres to JS.
 *  - out: the worker's "PickableMeshPerm" conversion reverses the normals and swaps the second
 *    and third index of every triangle (simpleMeshToMeshData with perm), and adds pick_info.
 */
import type { MetaBallsInput, MetaBallsMesh } from "./gpuMetaBalls";
/**
 * The arguments DrawMoorhenMetaBalls passes to get_bonds_mesh_for_selection_instanced, after
 * imol and cid: mode, dark background, bond width, atom/bond ratio, aniso, ortep, aniso as empty,
 * hydrogens, smoothness.
 */
export declare const METABALLS_SPHERE_ARGS: readonly ["VDW-BALLS", false, 0.1, 1, false, false, false, true, 1];
/** The subset of the worker's instanced-mesh result that the spheres arrive in. */
export interface InstancedSpheresData {
    instance_origins?: ArrayLike<number>[][];
    instance_sizes?: ArrayLike<number>[][];
    col_tri?: ArrayLike<number>[][];
}
/**
 * MetaBalls points from the worker's VDW-BALLS spheres, in the order DrawMoorhenMetaBalls
 * visits them (geometry by geometry, instance by instance), which is the order its pick points
 * and influence indices refer to.
 */
export declare function metaballsInputFromSpheres(data: InstancedSpheresData, radius: number): {
    input: MetaBallsInput;
    pickPoints: number[][];
};
/** What getMetaBallBuffers returns for one mesh: mesh data plus pick_info, as from the worker. */
export interface MetaBallsMeshData {
    prim_types: string[][];
    idx_tri: Uint32Array[][];
    vert_tri: Float32Array[][];
    norm_tri: Float32Array[][];
    col_tri: Float32Array[][];
    pick_info: {
        influence_weights: Float32Array;
        influence_index_offsets: Uint32Array;
        influence_point_indexes: Uint32Array;
        pick_points: number[][];
    };
}
/**
 * The GPU mesh as the worker would have handed it over for "PickableMeshPerm".
 *
 * A mesh made with `pickable` already has the reversed normals and winding, and its arrays are
 * used as they are; otherwise they are converted here. An empty mesh is passed through empty, as
 * the C++ leaves coot_mesh empty when there is nothing to draw.
 */
export declare function metaballsMeshData(mesh: MetaBallsMesh, pickPoints: number[][]): MetaBallsMeshData;
//# sourceMappingURL=metaballsMeshData.d.ts.map