import { MetaBallsGrid } from "./metaballsGrid";
export interface MetaBallsInput {
    /** x, y, z, radius per point. */
    points: Float32Array;
    /** r, g, b, a per point. */
    colours: Float32Array;
}
export interface MetaBallsOptions {
    gridSize: number;
    isoLevel: number;
    /** Also return each vertex's grid edge, for comparing with the C++ mesh. */
    withKeys?: boolean;
    /**
     * Grid points per slab; GPU memory is about 25 bytes per point. Default 16M (~400 MB), and
     * never more than the device's largest storage buffer allows.
     */
    maxSlabPoints?: number;
    /**
     * Which field calculation: split (default) into box sums plus a correction from the points
     * within 3.46 A (see FIELD_BOXES_WGSL), or the plain one, every point's full term at every
     * voxel of its box, a thread per voxel. The same field to within float rounding.
     */
    splitField?: boolean;
    /**
     * Hand the mesh over as Moorhen draws it - normals reversed, each triangle (a, c, b), as the
     * worker's PickableMeshPerm conversion does - rather than as metaballs.cc makes it. Done in
     * the kernels, so there is no pass over the arrays afterwards.
     */
    pickable?: boolean;
    /** For tests: start with this fraction of the usual room for each slab, to force a retry. */
    room?: number;
}
/** What GenerateMeshFromPoints returns, in typed arrays, minus the parts nothing reads. */
export interface MetaBallsMesh {
    positions: Float32Array;
    /** The field-gradient normals, as metaballs.cc leaves them - pointing into the surface. */
    normals: Float32Array;
    colours: Float32Array;
    indices: Uint32Array;
    /** CSR, as DrawMoorhenMetaBalls packs it: the END offset of each vertex's influences. */
    influenceEnds: Uint32Array;
    influencePoints: Uint32Array;
    influenceWeights: Float32Array;
    /** Grid edge of each vertex: ((z * ny + y) * nx + x) * 3 + axis. Only when asked for. */
    keys?: Uint32Array;
    /** True when normals and winding are already Moorhen's (MetaBallsOptions.pickable). */
    pickable?: boolean;
    grid: MetaBallsGrid | null;
    timings: MetaBallsTimings;
}
/** Where the time went, in ms, summed over any retries. */
export interface MetaBallsTimings {
    totalMs: number;
    slabs: number;
    /** Which field calculation ran (see MetaBallsOptions.splitField). */
    field?: "split" | "plain";
    /** Times the mesh was made again because a slab outgrew its estimated room. */
    retries?: number;
    /** Grid, binning, uploads and buffer creation. */
    setupMs: number;
    /** Recording and submitting the slabs' work. */
    encodeMs?: number;
    /** Waiting for slabs' results to be ready to read: GPU time not hidden behind the CPU's. */
    waitMs?: number;
    /** Copying the slabs' results into the output arrays (and growing them if needed). */
    copyMs?: number;
    /**
     * GPU time per kernel, summed over slabs, from timestamp queries: resolves after the mesh is
     * returned, so that reading them back is not part of making it (it is one more wait, up to
     * 100 ms in Firefox). Absent when the device does not offer timestamps; undefined if they
     * could not be read. Chrome rounds each timestamp to 0.1 ms unless told otherwise.
     */
    gpuMs?: Promise<Record<string, number> | undefined>;
}
export declare class GpuMetaBalls {
    private readonly device;
    private readonly scan;
    private readonly pipelines;
    private readonly table;
    /** Set for the duration of a generate call when the device can time passes. */
    private timer;
    /** How long compiling the pipelines took, ms: paid once, in create. */
    readonly compileMs: number;
    /**
     * Compile every pipeline before returning. Created synchronously, pipelines are often only
     * really compiled at their first dispatch, which put a one-off cost inside the first mesh.
     */
    static create(device: GPUDevice): Promise<GpuMetaBalls>;
    private constructor();
    destroy(): void;
    /**
     * Make the mesh. Rejects if WebGPU reported a validation or out-of-memory error on the way,
     * rather than returning whatever the buffers held, so a caller can fall back to the C++.
     */
    generate(input: MetaBallsInput, options: MetaBallsOptions): Promise<MetaBallsMesh>;
    /**
     * One go at the mesh, with `room` times the usual estimate of each slab's output. Returns how
     * many times too small the room was instead of a mesh, if a slab outgrew it.
     */
    private makeMesh;
    private upload;
    private storage;
    private dispatch;
    /** The one-thread totals kernels, whose bindings are sparse. */
    private dispatchTotals;
}
//# sourceMappingURL=gpuMetaBalls.d.ts.map