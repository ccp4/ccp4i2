import React from "react";
import type { SelectorOption } from "../Selector/useSelectorOptions";
import "./check-list.css";
export type MoorhenCheckListProps = {
    /** What can be ticked. */
    options: SelectorOption[];
    /** The ticked values. Leave undefined to let the list keep its own selection (all at first). */
    selected?: string[];
    /** Called with the new selection, whether the user or the list itself changed it. */
    setSelected?: (selected: string[]) => void;
    /** Called with the new selection when the user changed it (a tick, check all, uncheck all). */
    onChange?: (selected: string[]) => void;
    /** When it changes (e.g. another molecule), everything is ticked again. */
    resetKey?: string | null;
    label?: string;
    disabled?: boolean;
    /** Shown when there is nothing to tick. */
    emptyText?: string;
    /** Height above which the list scrolls. */
    maxHeight?: string | number;
    style?: React.CSSProperties;
};
/**
 * A list of checkboxes, one per option, with "Check all" and "Uncheck all".
 *
 * Everything is ticked at first, and again when `resetKey` changes. When the options change
 * otherwise, values no longer offered are dropped and new ones are ticked only if everything was
 * ticked before — so a list left on "all" stays on all as items are added.
 *
 * The selection is kept in option order. Pass `selected` / `setSelected` to keep it in the caller.
 */
export declare const MoorhenCheckList: (props: MoorhenCheckListProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenCheckList.d.ts.map