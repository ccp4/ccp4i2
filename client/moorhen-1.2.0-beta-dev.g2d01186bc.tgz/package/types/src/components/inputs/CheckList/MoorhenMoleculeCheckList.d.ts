import type { MoorhenMolecule } from "../../../utils/MoorhenMolecule";
import { type MoorhenCheckListProps } from "./MoorhenCheckList";
export type MoorhenMoleculeCheckListProps = Omit<MoorhenCheckListProps, "options"> & {
    /** Lists only the molecules it returns true for. Keep it stable (module level or useCallback). */
    filter?: (molecule: MoorhenMolecule) => boolean;
    /** Molecules to list. Defaults to the molecules loaded in Moorhen. */
    molecules?: MoorhenMolecule[];
};
/**
 * Checkboxes for the loaded molecules, by unique id: any number of molecules can be selected.
 * All are ticked at first; molecules loaded later are ticked too while everything is ticked.
 */
export declare const MoorhenMoleculeCheckList: (props: MoorhenMoleculeCheckListProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenMoleculeCheckList.d.ts.map