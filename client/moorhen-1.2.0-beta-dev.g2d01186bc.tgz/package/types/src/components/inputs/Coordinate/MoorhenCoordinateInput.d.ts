import type { ReactNode } from "react";
type MoorhenCoordinateInputProps = {
    /** Shown above the numbers, e.g. "Position" or "End". */
    title?: string;
    /** The numbers, one box each. Usually x, y, z; a 2D position or a size has two. */
    value: number[];
    /** Called with the whole array whenever one box changes to a valid number. */
    onChange: (value: number[]) => void;
    /** One per box, shown as "x:" and so on. Defaults to x, y, z. */
    labels?: string[];
    decimalDigits?: number;
    allowNegativeValues?: boolean;
    disabled?: boolean;
    /** Anything to go under the numbers, such as a "Current origin" button. */
    children?: ReactNode;
};
/**
 * A point (or size) as separate number boxes in an outlined section, as the vectors panel lays
 * out its ends.
 *
 * Spans the whole row when placed in an inputGrid, so a panel can mix these with label/input
 * pairs without the grid's columns going out of step.
 */
export declare const MoorhenCoordinateInput: (props: MoorhenCoordinateInputProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoorhenCoordinateInput.d.ts.map