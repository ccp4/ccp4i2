import type { MoorhenMolecule } from "../../../utils/MoorhenMolecule";
type MoorhenChainSelectPropsType = {
    allowedTypes?: number[];
    height?: string;
    width?: string;
    margin?: string;
    label?: string;
    /** Molecules to look the selected one up in. Defaults to the molecules loaded in Moorhen. */
    molecules?: MoorhenMolecule[];
    /** The molecule whose chains are listed, by unique id. */
    moleculeUniqueId?: string | null;
    /** @deprecated Use `moleculeUniqueId`: molNo is being phased out of the API. */
    selectedCoordMolNo?: number | null;
    onChange?: (arg0: React.ChangeEvent<HTMLSelectElement>) => void;
    defaultValue?: string;
    disabled?: boolean;
    ref?: React.Ref<HTMLSelectElement>;
    allowAll?: boolean;
    value?: string;
    setValue?: React.Dispatch<React.SetStateAction<string>> | ((newValue: string) => void);
};
export declare const MoorhenChainSelect: (props: MoorhenChainSelectPropsType) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoorhenChainSelect.d.ts.map