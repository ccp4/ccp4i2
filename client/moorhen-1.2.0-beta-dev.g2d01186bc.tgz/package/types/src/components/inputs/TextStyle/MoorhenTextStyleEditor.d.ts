import { type MoorhenTextStyle } from "../../../utils/textStyle";
type MoorhenTextStyleEditorProps = {
    value: MoorhenTextStyle;
    /** Called with just the fields that changed. */
    onChange: (changes: Partial<MoorhenTextStyle>) => void;
    /** Label for the text box; "Text" if not given. */
    textLabel?: string;
};
/**
 * The text and its look, as set for a 2D text overlay or a 3D annotation.
 *
 * Laid out as label/input pairs, for a MoorhenStack with inputGrid.
 *
 * One switch picks plain text or LaTeX. The font family and filled/outline choice only apply to
 * plain text, so they are hidden for LaTeX; the colour applies to both.
 */
export declare const MoorhenTextStyleEditor: (props: MoorhenTextStyleEditorProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoorhenTextStyleEditor.d.ts.map