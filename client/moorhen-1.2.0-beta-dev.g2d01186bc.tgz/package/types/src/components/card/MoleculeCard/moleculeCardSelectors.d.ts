import type { RootState } from "../../../store";
export declare const selectIsMoleculeVisible: (state: RootState, molNo: number) => boolean;
/** The molecule's custom representations. Use with shallowEqual, so the card only re-renders when they change. */
export declare const selectCustomRepresentations: (state: RootState, molNo: number) => import("../../../utils").MoleculeRepresentation[];
/** The molecule's general representations. Use with shallowEqual, so the card only re-renders when they change. */
export declare const selectGeneralRepresentations: (state: RootState, molNo: number) => import("../../../utils").MoleculeRepresentation[];
//# sourceMappingURL=moleculeCardSelectors.d.ts.map