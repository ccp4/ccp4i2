import { MoorhenMolecule } from "../../../../utils/MoorhenMolecule";
export declare const MoorhenCarbohydrateList: (props: {
    setBusy?: React.Dispatch<React.SetStateAction<boolean>>;
    molecule: MoorhenMolecule;
    height?: number | string;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenCarbohydrateList.d.ts.map