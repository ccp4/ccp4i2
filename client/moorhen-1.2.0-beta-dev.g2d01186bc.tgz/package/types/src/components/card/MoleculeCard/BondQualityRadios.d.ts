/**
 * The draw quality of bonds, as three radio buttons rather than a slider: three settings, each
 * with a name.
 * @param name - The radio group's name: unique on the page (several cards may be open at once)
 */
export declare const BondQualityRadios: (props: {
    value: number;
    onChange: (smoothness: number) => void;
    name: string;
    disabled?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=BondQualityRadios.d.ts.map