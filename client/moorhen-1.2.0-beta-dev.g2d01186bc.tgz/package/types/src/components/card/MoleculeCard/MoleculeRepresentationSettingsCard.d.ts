import { MoleculeRepresentation, MoorhenMolecule } from "../../../utils";
import { moorhen } from "../../../types/moorhen";
type MoleculeSettingPanelProps = {
    molecule: MoorhenMolecule;
    representation?: never;
} | {
    molecule?: never;
    representation: MoleculeRepresentation;
};
export declare const BondSettingsPanel: (props: MoleculeSettingPanelProps) => import("react/jsx-runtime").JSX.Element;
export declare const SymmetrySettingsPanel: (props: {
    symmetryRadius: number;
    setSymmetryRadius: React.Dispatch<React.SetStateAction<number>>;
    molecule: moorhen.Molecule;
}) => import("react/jsx-runtime").JSX.Element;
export declare const RibbonSettingsPanel: (props: MoleculeSettingPanelProps) => import("react/jsx-runtime").JSX.Element;
/**
 * Where a "Worm"'s radii come from (see wormRadii.ts): each residue's B-factor, scaled, or one
 * radius for all; or radii set through the API, which can only be kept or replaced here. And how
 * finely it is drawn, along and around. Sets the representation's wormOptions, which the dialog
 * applies.
 */
export declare const WormSettingsPanel: (props: {
    representation: MoleculeRepresentation;
}) => import("react/jsx-runtime").JSX.Element;
/**
 * The probe radius and atom radius multiplier of the M2T surfaces. `surfaceStyle`, when given, is
 * the surface being set up: a van der Waals surface has no probe, so then only the multiplier.
 */
export declare const MolSurfSettingsPanel: (props: MoleculeSettingPanelProps & {
    surfaceStyle?: moorhen.RepresentationStyles;
}) => import("react/jsx-runtime").JSX.Element;
export declare const ResidueEnvironmentSettingsPanel: (props: MoleculeSettingPanelProps) => import("react/jsx-runtime").JSX.Element;
export declare const MoorhenMoleculeRepresentationSettingsCard: (props: {
    molecule: moorhen.Molecule;
}) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoleculeRepresentationSettingsCard.d.ts.map