import type { MoorhenMolecule } from "../../../utils/MoorhenMolecule";
import "./ligand-list-card.css";
/**
 * The ligands of the Ligands panel, each with its ligand card (2D view, centre-on, representation,
 * contacts...):
 * - the ligands inside models, one group per model, open by default;
 * - the ligand-only molecules (MoorhenMolecule.isLigandOnly), listed by name instead of a full
 *   molecule card each (which does not scale to the hundreds or thousands of ligands
 *   files.batchLoadLigands can load).
 * Or, grouped by position, only sites: one sub-card per set of overlapping ligands, whichever
 * molecule each is in.
 */
export declare const LigandListCard: (props: {
    molecules: MoorhenMolecule[];
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=LigandListCard.d.ts.map