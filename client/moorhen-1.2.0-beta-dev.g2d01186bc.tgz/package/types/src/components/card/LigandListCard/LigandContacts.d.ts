import type { LigandInfo, MoorhenMolecule } from "../../../utils/MoorhenMolecule";
/**
 * The Contacts section of a ligand card. Its vectors outlive it: they stay drawn when the card or
 * the panel is closed (it unmounts), and go when the section itself is closed by the user. Opened
 * again (the panel reopened), it starts open if they are still drawn.
 */
export declare const LigandContactsSection: (props: {
    molecule: MoorhenMolecule;
    ligand?: LigandInfo;
}) => import("react/jsx-runtime").JSX.Element;
/**
 * The contacts of a ligand-only molecule with one other molecule (its protein, typically): H-bonds,
 * salt bridges and XH-π, drawn as dashed vectors (each type switched and coloured on its own),
 * listed, and the FLEV diagram. Mounted only while its accordion is open: Coot is asked when it opens
 * or the other molecule changes. The vectors are left drawn when it unmounts (see
 * LigandContactsSection).
 */
export declare const LigandContacts: (props: {
    molecule: MoorhenMolecule;
    ligand?: LigandInfo;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=LigandContacts.d.ts.map