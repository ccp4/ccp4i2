import type { MoleculeLigandRecord } from "../../../store/moleculesSlice";
import type { MoorhenMolecule } from "../../../utils/MoorhenMolecule";
/**
 * The Pocket section of a ligand card: open by default when the ligand has its pocket, so it is seen
 * (and can be changed or deleted) when the card is opened.
 */
export declare const LigandPocketSection: (props: {
    molecule: MoorhenMolecule;
    ligand?: MoleculeLigandRecord;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=LigandPocket.d.ts.map