/**
 * The card for a map that came from a Gaussian Cube.
 *
 * A cut-down map card, and cut down on purpose rather than for want of time. Three of the map
 * card's controls mean nothing here:
 *
 * - **Active.** The active map is the one refinement and the scroll wheel act on. An orbital is
 *   not something to refine against, so there is no choice to offer - and leaving the toggle in
 *   would invite someone to take the active map away from the map they are actually working on.
 * - **The histogram.** It is there to find a level in a map whose values have no absolute meaning.
 *   A cube states the level that covers most of the orbital, and that is a better answer than one
 *   read off a plot.
 * - **The radius.** The grid is a few angstrom across and is drawn whole. A radius control here
 *   would be a slider where every setting large enough looks the same.
 *
 * What is left is what an orbital actually needs: a colour (two of them, for the two lobes), a
 * visibility toggle, somewhere to put the view, a level, and the draw settings.
 */
import { moorhen } from "../../../types/moorhen";
type MoorhenOrbitalCardPropsInterface = {
    map: moorhen.Map;
    initialContour?: number;
    isOpen?: boolean;
    onCollapseToggle?: (key: number, isOpen: boolean) => void;
};
export declare const MoorhenOrbitalCard: (props: MoorhenOrbitalCardPropsInterface) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoorhenOrbitalCard.d.ts.map