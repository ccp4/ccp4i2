import { moorhen } from "../../../types/moorhen";
interface MoorhenMapCardSettings {
    map: moorhen.Map;
    mapIsVisible: boolean;
    mapStyle: string;
    mapRadius: number;
    mapOpacity: number;
    /**
     * Leave out the radius slider and the full-map/local-map pair.
     *
     * Both only make sense for something larger than the view. An orbital's grid is a few angstrom
     * across and is always drawn whole, so a radius here would be a control with nothing to do -
     * every setting large enough to show the orbital looks the same.
     */
    hideRadiusControls?: boolean;
    /**
     * Offer drawing the map as a 2D contour slice (mapSlice.ts). Only orbitals offer it for now;
     * nothing about the slice itself is particular to them.
     */
    offerSlice?: boolean;
}
export declare const MapSettingsAccordion: (props: MoorhenMapCardSettings) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MapSettingsAccordion.d.ts.map