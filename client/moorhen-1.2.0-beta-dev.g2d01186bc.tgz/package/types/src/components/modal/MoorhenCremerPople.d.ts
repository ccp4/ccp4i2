import { moorhen } from "../../types/moorhen";
export declare const MoorhenCremerPople: (props: {
    stackDirection: "horizontal" | "vertical";
    width?: number;
    molecule: moorhen.Molecule;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenCremerPople.d.ts.map