/** All the cards in one column, each a direct child so they share the same gap */
export declare const MoorhenSceneSettings: () => import("react/jsx-runtime").JSX.Element;
export declare const MoorhenSceneSettingsModal: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenSceneSettingsModal.d.ts.map