import { ModalComponentProps } from "../interface-base/ModalBase/ModalsContainer";
/** Dev-only playground for the multi-select check lists, before they are used in real tools. */
export declare const MoorhenCheckListTestModal: (props: ModalComponentProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenCheckListTestModal.d.ts.map