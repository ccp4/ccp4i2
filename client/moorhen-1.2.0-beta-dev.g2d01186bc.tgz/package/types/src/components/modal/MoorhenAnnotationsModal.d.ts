/**
 * Create and edit 3D annotations: text placed in the scene at a point or on atoms.
 *
 * Laid out as the vectors panel is: choose one (or New), change it, Apply.
 */
export declare const MoorhenAnnotations: () => import("react/jsx-runtime").JSX.Element;
export declare const MoorhenAnnotationsModal: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenAnnotationsModal.d.ts.map