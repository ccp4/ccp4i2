import type { MGWebGL } from "../../WebGLgComponents/mgWebGL";
import { type ExternalRenderer } from "../../WebGLgComponents/externalRenderer";
/** What the main view's WebGPU renderer says about itself, for the instance API and tests. */
export interface WebGPUMainViewRenderer extends ExternalRenderer {
    /** Why WebGL drew the last frame offered, or null if WebGPU drew it. */
    readonly webGLReason: string | null;
    /** Frames WebGPU has drawn. */
    readonly framesDrawn: number;
    /**
     * What the last frame WebGPU drew had in it; mapTriangles, the maps contoured on the GPU, and
     * mapLines, the lines of their edges (each once), which the line styles draw.
     */
    readonly lastFrame: {
        meshes: number;
        triangles: number;
        spheres: number;
        segments: number;
        mapTriangles: number;
        mapLines: number;
        peelLayers: number;
    } | null;
    /** The GPU time of the frames drawn since the last call (and of the FPS meter's), or null if not timed. */
    takeGpuTime(): {
        meanMs: number;
        maxMs: number;
        count: number;
    } | null;
    /** Map contours made on the GPU so far (the report's map walk). */
    mapContoursMade(): number;
    /** Resolves when the GPU has finished what has been submitted so far. */
    gpuIdle(): Promise<void>;
}
/**
 * The main view drawn by WebGPU (sceneSettings.useWebGPU, on by default where the browser offers
 * WebGPU), on a canvas laid over the WebGL one.
 *
 * MGWebGL keeps everything but the drawing - camera, mouse and keys, picking, labels, the frame
 * loop - and offers it each frame (externalRenderer.ts). This canvas takes no input: events go
 * through to the WebGL canvas underneath, as before. It is hidden whenever WebGL draws a frame
 * itself (webGLOnlyReason: the shadow map debug view, a recording of the WebGL canvas), so the
 * WebGL picture shows.
 *
 * While WebGPU draws, maps are contoured on the GPU and drawn from there (GpuMapLayer); whenever
 * WebGL draws, Coot contours them as before (mapContour/setting.ts).
 *
 * While it shows the view, MGWebGL.getCanvasRef gives this canvas, so movie export, recordings
 * and keyframe thumbnails take their pictures from it; screenshots are drawn offscreen by the same
 * renderer (snapshot), at the size WebGL's would be.
 *
 * While it is in use, WebGL's uploads - buffers and label atlases - wait until WebGL draws
 * (deferWebGLUploads).
 *
 * A lost device (a GPU or driver reset, the browser's GPU process restarting, a switch of GPU) is
 * replaced: a new device and renderer are made, and everything is uploaded again from the scene
 * (DisplayBuffers) and the maps; WebGL draws in the meantime. Only if no new device can be made,
 * or devices keep being lost (more than MAX_LOSSES in a minute), does WebGL take the view for
 * good - as it does on any other WebGPU error. Where WebGPU will not start at all (no adapter),
 * WebGL draws, and the console says so quietly.
 */
export declare const MoorhenWebGPUMainView: (props: {
    glRef: React.RefObject<MGWebGL>;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenWebGPUMainView.d.ts.map