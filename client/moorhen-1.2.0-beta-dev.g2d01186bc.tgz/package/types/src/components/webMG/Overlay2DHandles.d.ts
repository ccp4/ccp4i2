/**
 * Handles for moving, resizing, turning and reshaping the 2D overlay objects, and picking one by
 * clicking it.
 *
 * An SVG layer over the view. Only the handles themselves take the pointer, so everywhere else a
 * press still reaches the 3D view underneath; and picking listens for a click (a press and release
 * without moving), so that turning the molecule from on top of an object still turns it.
 *
 * All of it is live only while the 2D objects panel is open, so that a picture full of labels
 * behaves exactly as it always has while it is being looked at rather than edited.
 */
export declare const Overlay2DHandles: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Overlay2DHandles.d.ts.map