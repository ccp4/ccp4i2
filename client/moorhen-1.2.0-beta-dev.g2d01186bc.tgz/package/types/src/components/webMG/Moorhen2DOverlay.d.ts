import * as quat4 from 'gl-matrix/quat';
import type { Overlay2DTextFrac } from '../../store/overlaysSlice';
import { RootState } from '../../store/MoorhenReduxStore';
import { Store } from '@reduxjs/toolkit';
import "./UoY-legal.css";
interface ImageFrac2D {
    x: number;
    y: number;
    width: number;
    height: number;
    img: HTMLImageElement;
    zIndex: number;
    /** Pixels from the top of the image to its baseline, which is what sits at y. 0 puts the top at y. */
    ascent?: number;
    /** Clockwise turn in degrees, about the middle of the image. */
    rotation?: number;
}
/**
 * The LaTeX text overlays, typeset as images to draw beside the image overlays.
 *
 * Placed by their baseline, as plain text is, so switching a string between text and LaTeX leaves
 * it where it was.
 *
 * @param resolution - Device pixels per CSS pixel the images will be drawn at.
 */
export declare const latexOverlayImages: (textOverlays: Overlay2DTextFrac[], backgroundColor: number[], resolution: number) => Promise<ImageFrac2D[]>;
export declare const drawOn2DContext: (canvas2D_ctx: CanvasRenderingContext2D, width: number, height: number, scale: number, helpText: string[], images: ImageFrac2D[], drawQuat: quat4, zIndex: number, store: Store<RootState>) => void;
export declare const Moorhen2DOverlay: (props: any) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Moorhen2DOverlay.d.ts.map