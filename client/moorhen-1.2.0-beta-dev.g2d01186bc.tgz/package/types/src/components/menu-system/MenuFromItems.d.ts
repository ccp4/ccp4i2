import React from "react";
import type { MenuItemType } from "./subMenuConfig";
/**
 * A menu's items as menu entries.
 * @param popoverPlacement - Where popover items open: right of the menu by default; "left" for a menu
 * shown at the right edge (a side panel).
 */
export declare const MenuFromItems: (props: {
    menuItemList: MenuItemType[];
    title?: string;
    popoverPlacement?: "left" | "right";
}) => React.JSX.Element;
//# sourceMappingURL=MenuFromItems.d.ts.map