/**
 * Give a scene the settings, and optionally the representations, of another scene or snapshot.
 * Not for snapshots, which cannot be changed.
 * @param sceneId - The scene that changes.
 * @param withLabel - A labelled button (scene settings) instead of an icon (scene selector).
 */
export declare const CopySceneButton: (props: {
    sceneId: string;
    withLabel?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=CopySceneButton.d.ts.map