/**
 * The Ligands panel, opened by the main menu's Ligand button: the ligand menu's items in a Tools
 * accordion at the top (the "ligand" submenu, which stays in the menu system, so its items are still found by search
 * and can be extended through it), then every ligand, those inside models and the ligand-only
 * molecules, each with its ligand card.
 */
export declare const LigandsPanel: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=LigandsPanel.d.ts.map