import React from "react";
import { MoorhenInstance } from "../../InstanceManager";
import { CommandCentre } from "../../InstanceManager/CommandCentre";
import { webGL } from "../../types/mgWebGL";
import { moorhen } from "../../types/moorhen";
import { MoorhenMenuSystem } from "../menu-system/MenuSystem";
import "./container.css";
import "../../global.css";
interface ContainerRefs {
    glRef?: React.RefObject<null | webGL.MGWebGL>;
    timeCapsuleRef?: React.RefObject<null | moorhen.TimeCapsule>;
    commandCentre?: React.RefObject<null | CommandCentre>;
    videoRecorderRef?: React.RefObject<null | moorhen.ScreenRecorder>;
    moleculesRef?: React.RefObject<null | moorhen.Molecule[]>;
    mapsRef?: React.RefObject<null | moorhen.Map[]>;
    activeMapRef?: React.RefObject<moorhen.Map>;
    lastHoveredAtomRef?: React.RefObject<null | moorhen.HoveredAtom>;
    moorhenInstanceRef?: React.RefObject<null | MoorhenInstance>;
    moorhenMenuSystemRef?: React.RefObject<null | MoorhenMenuSystem>;
    parentElementRef?: React.RefObject<null | HTMLElement>;
}
interface ContainerOptionalProps {
    onUserPreferencesChange?: (key: string, value: unknown) => void;
    onInitialisationCompleted?: () => void;
    disableFileUploads?: boolean;
    urlPrefix?: string;
    viewOnly: boolean;
    /**
     * Extra modals for React hosts, added to `instance.uiExtensions` (web component hosts call
     * `instance.uiExtensions.addModal` instead). Each element is rendered all the time and decides
     * itself when to show; its `modalId` prop is its id.
     */
    extraDraggableModals?: React.JSX.Element[];
    /**
     * Extra side panels for React hosts, keyed by id and added to `instance.uiExtensions` (web
     * component hosts call `instance.uiExtensions.addSidePanel` instead).
     */
    extraSidePanels?: Record<string, import("../panels").MoorhenPanel>;
    monomerLibraryPath?: string;
    allowScripting?: boolean;
    backupStorageInstance?: moorhen.LocalStorageInstance;
    aceDRGInstance?: moorhen.AceDRGInstance | null;
    /** @deprecated No effect: the Fit ligand modal always offers to save a pose as a new molecule. */
    allowAddNewFittedLigand?: boolean;
    /** @deprecated No effect: the Fit ligand modal no longer merges a pose into the model. */
    allowMergeFittedLigand?: boolean;
    webComponentMode?: boolean;
    size?: [number, number];
    /** The built-in scene Moorhen opens on: "General" (default) or "Model Building" */
    startupScene?: string;
}
export interface ContainerProps extends Partial<ContainerRefs>, Partial<ContainerOptionalProps> {
}
export declare const MoorhenContainer: (props: ContainerProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MainContainer.d.ts.map