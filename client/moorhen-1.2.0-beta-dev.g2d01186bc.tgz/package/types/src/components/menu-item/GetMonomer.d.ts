import { type MonomerSource } from "../../utils/monomers";
/** What MonomerPicker reports: the monomer's code (resolved from its name if searched by name) and where to look */
export type MonomerChoice = {
    code: string;
    source: MonomerSource;
};
/**
 * Choose a monomer as Get Monomer does: where to look (Source), by three-letter code or compound
 * name, with the monomer library's list as autocomplete (with the compound's picture). Reports the
 * code and source through onChange. `afterSource` is shown right after the source choice (Get
 * Monomer's molecule choice).
 */
export declare const MonomerPicker: (props: {
    onChange: (choice: MonomerChoice) => void;
    afterSource?: (source: MonomerSource) => React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
export declare const GetMonomer: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=GetMonomer.d.ts.map