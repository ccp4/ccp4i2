import type { MapStyle } from "../../store/mapContourSettingsSlice";
import { moorhen } from "../../types/moorhen";
export declare const MapSettings: (props: {
    map: moorhen.Map;
    mapStyle: MapStyle;
    mapOpacity: number;
    setPopoverIsShown: React.Dispatch<React.SetStateAction<boolean>>;
    disabled: boolean;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MapSettings.d.ts.map