/**
 * Which nucleotide each vertex of a nucleic acid ribbon belongs to, put right.
 *
 * Coot's ribbon (MoleculesToTriangles) threads a nucleic acid through each residue's C3' with a
 * natural cubic spline, the residues' C3' atoms at parameters 0, 1, 2 ... along each stretch of
 * chain, and gives residue i the ribbon over parameters [i - 0.5, i + 0.5): the stretch centred
 * on its C3'. For a protein the same rule, centred on CA, puts the boundaries on the peptide
 * bonds, which is right. For a nucleic acid C3' sits near the 3' end of the backbone, so the
 * boundaries come about a quarter of a residue too late - around O5' rather than at the O3'-P
 * link - and every residue's phosphate was lit, and labelled, as the residue before it.
 * Measured on the DNA of 3L1P: P, OP1 and OP2 fell in the previous residue's stretch every time.
 *
 * Here the same spline is rebuilt from the C3' atoms, each residue's stretch made to start where
 * the spline passes its O3'-P link (the point of the spline nearest the middle of the bond from
 * the previous residue's O3' to its P), and each vertex given to the stretch its point on the
 * spline falls in. A ribbon's cross-sections are perpendicular to the spline, so every vertex of
 * one finds the same point and goes to the same residue: the boundary is a clean cut across the
 * ribbon, as Coot's own boundaries are. (Asking instead which residue has the nearest atom gave
 * each vertex its own answer, and the highlight's edge a staircase.) On 3L1P: P owned by its own
 * residue 100%, OP1 93%, OP2 91%, the rest of the backbone 100%.
 *
 * Vertices only move between their owner and its neighbours along the chain; proteins, and
 * anything not a nucleotide, are left alone.
 *
 * A stop-gap: the right place for this is the ownership rule in MoleculesToTriangles itself
 * (MolecularRepresentation.cpp, the atom each ribbon point is given), after which this goes.
 */
import type { moorhen } from "../types/moorhen";
type Atom = Pick<moorhen.AtomInfo, "x" | "y" | "z" | "name" | "mol_name" | "chain_id" | "res_no">;
type Vec = [number, number, number];
/** A residue key from a CID as Coot writes owners: "/1/A/23(G)" or, with an insertion code, "/1/A/23(G).B". */
export declare const ownerResidueKey: (cid: string) => string;
/**
 * Samples of the natural cubic spline through `points` at parameters 0 .. n - 1, as Coot's
 * coordSpline (second derivatives zero at both ends), `SAMPLES_PER_RESIDUE` to a unit, flat x,y,z.
 */
export declare function naturalSplineSamples(points: readonly Vec[]): Float64Array;
/**
 * `vertexOwners` (indices into `owners`, the residue CIDs) with each nucleotide vertex given to
 * the residue whose stretch of the C3' spline, started at its O3'-P link, holds the vertex's
 * nearest point on the spline. The owner table is in the order the ribbon met its residues, so
 * consecutive nucleotides of one model and chain in it, C3' atoms within 8 A, are consecutive
 * along the ribbon, as Coot strings them. Returns the input unchanged (the same array) when there
 * is nothing to do.
 */
export declare function reassignNucleotideOwners(vertices: ArrayLike<number>, vertexOwners: ArrayLike<number>, owners: readonly string[], atoms: readonly Atom[]): ArrayLike<number>;
export {};
//# sourceMappingURL=nucleotideOwners.d.ts.map