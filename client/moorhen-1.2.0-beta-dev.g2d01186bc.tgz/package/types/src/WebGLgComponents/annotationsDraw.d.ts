import { Store } from "@reduxjs/toolkit";
import type { RootState } from "../store/MoorhenReduxStore";
import type { MoorhenAnnotation } from "../store/annotationsSlice";
/** One annotation, ready for a TextCanvasTexture's addBigTextureTextImage. */
export interface AnnotationLabel {
    label: {
        imgData: ImageData;
        font: string;
        text: string;
        x: number;
        y: number;
        z: number;
    };
    uuid: string;
}
/**
 * Where an annotation is, or null if it is on atoms that cannot be found (a molecule since
 * closed, or a selection that no longer picks anything out).
 */
export declare const annotationPosition: (annotation: MoorhenAnnotation, molecules: {
    uniqueId: string;
    gemmiStructure: unknown;
}[]) => [number, number, number] | null;
/**
 * Rasterise the annotations, split by how they are drawn: depth-tested and fogged with the
 * scene, or over everything.
 *
 * Each is drawn into pixels here rather than handed to the atlas as text, because the atlas only
 * fills glyphs, in one colour picked from the background, and annotations have their own colour,
 * may be outlined, and may be LaTeX.
 *
 * @param atlasWidth - The atlases' width in pixels; nothing wider can be placed in one.
 */
export declare const getAnnotationLabels: (store: Store<RootState>, atlasWidth?: number) => Promise<{
    inScene: AnnotationLabel[];
    onTop: AnnotationLabel[];
}>;
//# sourceMappingURL=annotationsDraw.d.ts.map