import { DisplayBuffer } from './displayBuffer';
export declare const createWebGLBuffers: (jsondata: any, idat: number) => DisplayBuffer;
//# sourceMappingURL=createWebGLBuffers.d.ts.map