/**
 * The WebGL objects behind a DisplayBuffer, created when the buffer is first uploaded rather than
 * when its data arrives.
 *
 * A DisplayBuffer used to be born holding WebGL handles: createWebGLBuffers called
 * gl.createBuffer() for every sub-buffer as it copied the data in, and appendOtherData refused to
 * produce anything at all without a context. So the scene data could not exist without WebGL,
 * which rules out drawing it any other way - a WebGPU canvas, say - and ties every buffer to the
 * one context that happened to be current when it was made.
 *
 * Now ingestion leaves a placeholder in each handle slot, carrying the numItems and itemSize that
 * the draw code reads, and buildBuffers swaps each placeholder for a real buffer just before its
 * first upload. Everything that draws goes through buildBuffers first (drawScene builds whatever
 * is dirty, and every buffer starts dirty), so a placeholder never reaches gl.bindBuffer.
 *
 * The slot arrays keep their lengths, which matters: several loops count sub-buffers by
 * triangleVertexIndexBuffer.length.
 *
 * The influence textures used for hover highlighting are deferred in the same way. Their source
 * arrays wait in pick_info.pending_influence until there is a context to make textures in. The
 * same arrays are kept in pick_info.influence for good, whatever WebGL does: the WebGPU renderer
 * draws the highlight from them (as storage buffers), and may take over the view from WebGL at
 * any time, after WebGL has made its textures.
 *
 * Renderer-owned buffers that never pass through ingestion (the text and click-line buffers, the
 * image disc in mgWebGL) still create their handles directly. They belong to the WebGL renderer
 * and nothing else needs to read them.
 */
export interface MGWebGLBuffer {
    itemSize: number;
    numItems: number;
}
/** A handle slot whose WebGL buffer has not been created yet. */
export interface PendingGLBuffer extends MGWebGLBuffer {
    pendingGL: true;
}
export declare const pendingGLBuffer: (numItems?: number, itemSize?: number) => PendingGLBuffer;
export declare const isPendingGLBuffer: (slot: unknown) => slot is PendingGLBuffer;
/**
 * Every per-sub-buffer handle array that ingestion fills.
 *
 * Kept in one list so that realising, cloning and testing cannot disagree about which they are.
 */
export declare const GL_SLOT_ARRAYS: readonly ["triangleVertexRealNormalBuffer", "triangleVertexNormalBuffer", "triangleVertexPositionBuffer", "triangleVertexIndexBuffer", "triangleVertexTextureBuffer", "triangleInstanceOriginBuffer", "triangleInstanceOrientationBuffer", "triangleInstanceSizeBuffer", "triangleColourBuffer"];
export type GLSlotArrayName = typeof GL_SLOT_ARRAYS[number];
/**
 * The influence lists of a smooth mesh, as CSR: for vertex v, the points that influence it are
 * point_indexes[begin..end) with weights[begin..end), where end = index_offsets[v] and begin is
 * the previous vertex's end (0 for the first). Used for the hover highlight; WebGL packs each into
 * a texture, WebGPU binds them as storage.
 */
export interface PendingInfluence {
    weights: ArrayLike<number>;
    point_indexes: ArrayLike<number>;
    index_offsets: ArrayLike<number>;
}
/** The influence lists, by their other name: they are kept after WebGL has its textures. */
export type InfluenceData = PendingInfluence;
/**
 * A buffer's influence lists, whichever renderer has or has not used them yet: null for a mesh
 * without them.
 */
export declare const influenceOf: (pickInfo: {
    influence?: PendingInfluence;
    pending_influence?: PendingInfluence;
} | null | undefined) => PendingInfluence | null;
type SlotHolder = {
    [K in GLSlotArrayName]: MGWebGLBuffer[];
} & {
    pick_info?: {
        pending_influence?: PendingInfluence;
        influence?: PendingInfluence;
        influence_weights_texture?: unknown;
        influence_weights_width?: number;
        influence_point_indexes_texture?: unknown;
        influence_point_indexes_width?: number;
        influence_index_offsets_texture?: unknown;
        influence_index_offsets_width?: number;
    };
};
/** The few calls this module makes. A real WebGL2RenderingContext satisfies it. */
export interface GLForResources {
    createBuffer(): unknown;
    createTexture?(): unknown;
    bindTexture?(target: number, texture: unknown): void;
    texParameteri?(target: number, pname: number, param: number): void;
    texImage2D?(...args: unknown[]): void;
    getParameter?(pname: number): unknown;
    [constant: string]: unknown;
}
export declare const hasPendingGLResources: (buffer: SlotHolder) => boolean;
/**
 * Swap every placeholder in `buffer` for a real WebGL buffer, and make any deferred textures.
 *
 * Idempotent: slots that already hold a buffer are left alone, so calling it on a buffer that is
 * already realised costs a scan and nothing else. Returns how many buffers it created.
 *
 * If the context cannot create a buffer (createBuffer returns null after a context loss) the
 * placeholder stays where it is and will be tried again next time.
 */
export declare function realiseGLResources(gl: GLForResources, buffer: SlotHolder): number;
export {};
//# sourceMappingURL=glResources.d.ts.map