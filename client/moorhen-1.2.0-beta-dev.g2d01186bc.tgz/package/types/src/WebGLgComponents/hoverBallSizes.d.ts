/**
 * How big each golden hover ball is. The hover highlight (getResidueHighlightBuffers) is one
 * PERFECT_SPHERES instance per hovered atom, all made at HOVER_BALL_SIZE. That is right over
 * thin sticks, but an atom drawn as a big sphere - a VdW ball, an ion in bonds mode - swallows
 * it. So each ball is grown to the biggest sphere drawn at its atom, plus a margin.
 *
 * A sphere is any instance whose three sizes are equal: PERFECT_SPHERES (VdW balls), and the
 * instanced triangle spheres Coot's bonds meshes draw atoms with (its "atoms" geometry, which
 * CootWorker leaves as TRIANGLES - only "spherical-atoms" become PERFECT_SPHERES). Bond
 * cylinders also start at atoms, but their length makes their sizes unequal.
 *
 * This used to be one size for the whole highlight, taken from the first sphere of a buffer
 * that held all the hovered atoms: in VdW spheres one atom's radius did for all (a carbon's
 * ball came out the size of a hydrogen's, inside the carbon), and an ion among small spheres
 * was missed because the buffer's first sphere was small.
 */
import type { DisplayBuffer } from './displayBuffer';
/** The size the hover highlight is made at: a ball over a stick-sized atom. */
export declare const HOVER_BALL_SIZE = 0.3;
/** Spheres up to this size are bond-mode atoms, which HOVER_BALL_SIZE already covers. */
export declare const STICK_ATOM_SIZE = 0.27;
/** How far a ball reaches past a bigger sphere. */
export declare const HOVER_BALL_MARGIN = 0.4;
type SphereSource = Pick<DisplayBuffer, "bufferTypes" | "triangleInstanceOrigins" | "triangleInstanceSizes"> & Partial<Pick<DisplayBuffer, "visible" | "isHoverBuffer">>;
/**
 * The size of the ball for each atom at `origins` (x, y, z per atom), as instance sizes (three
 * per atom): HOVER_BALL_SIZE, or - where a visible buffer draws a sphere there bigger than a
 * stick atom - that sphere's size plus HOVER_BALL_MARGIN.
 */
export declare function hoverBallSizes(origins: ArrayLike<number>, displayBuffers: readonly SphereSource[]): Float32Array;
export {};
//# sourceMappingURL=hoverBallSizes.d.ts.map