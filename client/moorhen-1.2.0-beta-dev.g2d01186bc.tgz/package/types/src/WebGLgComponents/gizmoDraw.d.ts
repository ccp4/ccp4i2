import { ThreeDObject } from '../store/threeDObjectsSlice';
import { RootState } from '../store';
import { Store } from '@reduxjs/toolkit';
import { MapSlicePlacement } from '../utils/mapSlice/mapSlice';
/**
 * What the handles are on: a 3D object, or a map's 2D slice (mapSlice.ts), which is placed the same
 * way - an origin and, for turning, an orientation - and so moves and turns by the same handles.
 *
 * At most one of them at a time (setSelectedThreeDObject and setMovingMapSlice each clear the other).
 */
export type HandleTarget = {
    kind: 'object';
    object: ThreeDObject;
    centre: [number, number, number];
    extent: number;
    turnable: boolean;
} | {
    kind: 'mapSlice';
    molNo: number;
    slice: MapSlicePlacement;
    centre: [number, number, number];
    extent: number;
    turnable: true;
};
export declare const handleTargetOf: (state: RootState) => HandleTarget | null;
/**
 * The handles for one object, or a map's slice.
 *
 * One buffer per axis rather than one for the whole gizmo, because colour is a per-instance
 * attribute: three buffers is what lets x, y and z be told apart. Within each, the arrow and the
 * ring are sections, so hovering lights the one under the pointer and its label says which it is.
 */
export declare const getGizmoBuffers: (store: Store<RootState>) => Promise<any>;
//# sourceMappingURL=gizmoDraw.d.ts.map