import { CameraFrame } from './projection';
import type { MGWebGL } from '../mgWebGL';
/**
 * How far, in model units, the triangle shaders move the point a vertex is looked up at in the
 * shadow map out along its normal (shadowNormalOffset in triangle-vertex-shader.js): a texel and a
 * half of a map `width` texels wide. The texture matrix maps model space to the map's 0..1, so the
 * length of its first row is map units per model unit (the light's projection is orthographic and
 * the same scale across). WebGPU does the same in previewShaders.ts (finish).
 */
export declare function shadowNormalOffset(textureMatrix: ArrayLike<number>, width: number): number;
export declare function drawPeel(self: MGWebGL, theShaders: any, doClear?: boolean, ratioMult?: number): any;
export declare function drawTriangles(self: MGWebGL, calculatingShadowMap: any, invMat: any): void;
export declare function drawScene(self: MGWebGL): void;
export declare function applySymmetryMatrix(self: MGWebGL, theShader: any, symmetryMatrix: any, tempMVMatrix: any, tempMVInvMatrix: any, doTransform?: boolean): void;
export declare function bindFramebufferDrawBuffers(self: MGWebGL): void;
export declare function getMultiViewInfo(self: MGWebGL): {
    multiViewOrigins: any;
    multiViewGroupsKeys: any;
    quats: any;
    viewports: any;
    ratioMult: any;
    multi_rows_cols: any;
};
export declare function textureBlur(self: MGWebGL, width: any, height: any, inputTexture: any): void;
export declare function depthBlur(self: MGWebGL, invMat: any): void;
/**
 * The renderer's camera state as projection.ts wants it, for the view GLrender is about to draw.
 *
 * The one place that says which MGWebGL fields mean what, so that anything else drawing the
 * scene (viewProjection) can be handed the same frame and get the same matrices.
 *
 * @param ratio  GLrender's ratio: gl.viewportWidth / gl.viewportHeight * ratioMult
 */
export declare function cameraFrame(self: MGWebGL, ratio: number): CameraFrame;
export declare function GLrender(self: MGWebGL, calculatingShadowMap: any, doClear?: boolean, ratioMult?: number): any;
//# sourceMappingURL=drawCore.d.ts.map