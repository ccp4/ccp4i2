import { vec3 } from 'gl-matrix';
import { moorhen } from '../types/moorhen';
import type { MeshIndex } from './rayMesh';
import type { BufferMaterial } from './textureRegistry';
import type { MGWebGLBuffer, PendingInfluence } from './glResources';
/**
 * Per-vertex data for one sub-buffer.
 *
 * Ingestion (createWebGLBuffers) always stores typed arrays now. Plain arrays are still allowed
 * because a few producers build buffers by hand; anything reading these should index them rather
 * than use Array methods.
 */
export type VertexData = Float32Array | number[];
/** Indices for one sub-buffer. See VertexData. */
export type IndexData = Uint32Array | number[];
export declare class DisplayBuffer {
    pick_info: {
        influence_weights_width?: number;
        influence_index_offsets_width?: number;
        influence_point_indexes_width?: number;
        influence_weights_texture?: number;
        influence_index_offsets_texture?: number;
        influence_point_indexes_texture?: number;
        pick_points?: [];
        point_triangles?: number[][];
        pick_point_instances?: number[];
        pick_point_sections?: number[];
        section_ranges?: number[][];
        section_level_ranges?: number[][][];
        section_level_points?: number[][][];
        pick_spans?: number[][];
        pick_radius?: number;
        pick_point_tags?: string[];
        pick_tag_kind?: string;
        instance_tags?: string[];
        instance_tag_kind?: string;
        claims_pointer?: boolean;
        pick_priority?: number;
        highlight_whole?: boolean;
        highlight_group?: string | null;
        pick_exact?: boolean;
        pick_bounds?: {
            low: [number, number, number];
            high: [number, number, number];
        };
        vertex_pick_points?: Uint32Array;
        mesh_index?: MeshIndex;
        owner_codes?: Uint32Array;
        influence_weights?: Float32Array;
        influence_point_indexes?: Uint32Array;
        influence_index_offsets?: Uint32Array;
        pending_influence?: PendingInfluence;
        influence?: PendingInfluence;
    };
    origin: number[];
    visible: boolean;
    name_label: string;
    display_class: string;
    transparent: boolean;
    /**
     * A fade applied to the whole buffer, from 0 to 1, multiplied into the fragment alpha.
     *
     * Distinct from the vertex colours' own alpha, which says what the object is made of. This
     * says how much of it is there at this moment, which is a movie's business and changes per
     * frame - so it is a uniform rather than a rewrite of every vertex. See objectFade.
     *
     * Ignored on a WebGL1 context, where the uniform is not registered and objects stay solid.
     */
    alphaMultiplier: number;
    alphaChanged: boolean;
    atoms: moorhen.AtomInfo[];
    symmetryAtoms: {
        chain_id: string;
        has_altloc: boolean;
        mol_name: string;
        serial: number;
        res_no: string;
        res_name: string;
        name: string;
        charge: number;
        tempFactor: number;
        pos: vec3;
        element: string;
    }[][];
    symmetryMatrices: number[];
    changeColourWithSymmetry: boolean;
    triangleVertexRealNormalBuffer: MGWebGLBuffer[];
    triangleVertexNormalBuffer: MGWebGLBuffer[];
    triangleVertexPositionBuffer: MGWebGLBuffer[];
    triangleVertexIndexBuffer: MGWebGLBuffer[];
    triangleVertexTextureBuffer: MGWebGLBuffer[];
    triangleInstanceOriginBuffer: MGWebGLBuffer[];
    triangleInstanceOrientationBuffer: MGWebGLBuffer[];
    triangleInstanceSizeBuffer: MGWebGLBuffer[];
    triangleColourBuffer: MGWebGLBuffer[];
    triangleIndexs: IndexData[];
    triangleVertices: VertexData[];
    triangleInstanceOrigins: VertexData[];
    triangleInstanceSizes: VertexData[];
    triangleInstanceOrientations: VertexData[];
    triangleColours: VertexData[];
    triangleNormals: VertexData[];
    /**
     * Flat u,v per vertex, one array per sub-buffer.
     *
     * The GL buffer for these (triangleVertexTextureBuffer) and the attribute they feed
     * (aVertexTexture, bound to location 3) both long predate anything filling them.
     */
    triangleTextureCoords: VertexData[];
    /**
     * What each sub-buffer is drawn with, beyond its vertex colours.
     *
     * Per sub-buffer rather than per buffer because that is the grain a material has: a glTF
     * primitive carries exactly one, and a file with several becomes several sub-buffers of one
     * object. Sparse - most sub-buffers have no entry, and that means "vertex colours alone".
     */
    materials: (BufferMaterial | undefined)[];
    primitiveSizes: number[][];
    bufferTypes: string[];
    customColour: [number, number, number, number] | null;
    transformMatrix: number[];
    transformMatrixInteractive: number[];
    transformOriginInteractive: number[];
    symopnums: number[];
    supplementary: any;
    /**
     * Counts the times this buffer has been marked dirty: bumped by every `isDirty = true`.
     *
     * isDirty itself belongs to the WebGL renderer, which clears it once it has uploaded the new
     * data, so anything else drawing the same buffers cannot tell from it that the data changed.
     * This lets it: keep the number you last uploaded at, and upload again when it moves.
     */
    dataVersion: number;
    private _isDirty;
    get isDirty(): boolean;
    set isDirty(dirty: boolean);
    textNormalBuffer: MGWebGLBuffer[] | null;
    textPositionBuffer: MGWebGLBuffer[] | null;
    textColourBuffer: MGWebGLBuffer[] | null;
    textTexCoordBuffer: MGWebGLBuffer[] | null;
    textIndexesBuffer: MGWebGLBuffer[] | null;
    clickLinePositionBuffer: MGWebGLBuffer[] | null;
    clickLineColourBuffer: MGWebGLBuffer[] | null;
    clickLineIndexesBuffer: MGWebGLBuffer[] | null;
    textNormals: number[];
    textColours: number[];
    isHoverBuffer: boolean;
    id: string;
    /**
     * What made this buffer, for attributing a frame's cost back to a representation.
     *
     * Descriptive only: nothing in the renderer branches on it, and a buffer without one is
     * still drawn exactly the same. It exists because the draw loop sees a flat list of
     * buffers and cannot say which of them is the ribbons, so "1.1M triangles" is a number
     * with nowhere to go. Set where buffers are produced rather than derived at draw time,
     * since that is the only place that still knows.
     */
    statsLabel?: string;
    multiViewGroup: number;
    clickTol: number;
    alwaysOnTop: boolean;
    constructor();
    setCustomColour(col: any): void;
    /**
     * Fade the whole buffer.
     *
     * A faded buffer has to be drawn as a transparent one, or it writes depth as though solid and
     * everything behind it disappears instead of showing through. That is why this touches
     * `transparent` rather than only storing a number.
     */
    setAlphaMultiplier(alphaMultiplier: number): void;
    updateSymmetryAtoms(): void;
    /**
     * Retire this buffer: free its WebGL buffers and drop its geometry.
     *
     * The WebGL buffers must be deleted here, not left to the garbage collector. A WebGLBuffer
     * wrapper is tiny, so collecting it is driven by JS heap pressure while the GPU memory behind
     * it is not counted at all: every redraw of a representation or map contour used to leave its
     * old buffers on the GPU, and after editing a few dozen residues the app slowed to a crawl.
     *
     * @param gl - The context the buffers were created in. Pass null only when it has already
     * been lost, in which case its buffers went with it.
     */
    clearBuffers(gl: WebGLRenderingContext | WebGL2RenderingContext | null): void;
    setTransformMatrix(transformMatrix: any): void;
}
//# sourceMappingURL=displayBuffer.d.ts.map