/**
 * Anaglyph stereo: the two eyes' pictures in one, each in its own colour channels, for glasses
 * with a filter of each colour. Shared by both renderers and the preferences.
 *
 * Each eye's picture is grey, and goes into the channels its filter passes; a channel neither
 * eye has keeps the background. So through each filter one eye's picture shows, on the
 * background, and the other's does not. The left eye is the first of MGWebGL's stereoQuats (as
 * side-by-side stereo's left view), the one WebGL has always drawn red.
 */
/** The pairs of colours, left eye first. */
export type AnaglyphColours = "red-green" | "red-cyan" | "red-blue" | "green-magenta";
/** Red and green: what WebGL has always drawn. */
export declare const DEFAULT_ANAGLYPH_COLOURS: AnaglyphColours;
/** Which of red, green and blue each eye's picture goes into. */
export interface AnaglyphChannels {
    label: string;
    left: [boolean, boolean, boolean];
    right: [boolean, boolean, boolean];
}
export declare const ANAGLYPH_COLOURS: Record<AnaglyphColours, AnaglyphChannels>;
/** The channels for a setting, red and green for anything not known. */
export declare function anaglyphChannels(colours: string | undefined | null): AnaglyphChannels;
//# sourceMappingURL=anaglyph.d.ts.map