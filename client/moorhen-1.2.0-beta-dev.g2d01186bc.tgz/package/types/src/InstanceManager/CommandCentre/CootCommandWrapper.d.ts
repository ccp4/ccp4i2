import { WorkerResponse, cootCommandKwargs } from "./MoorhenCommandCentre";
export type CootValidationData = {
    chainId: string;
    seqNum: number;
    restype: string;
    value: number;
}[];
export type ResidueValidationData = {
    seqNum: number;
    insCode?: string;
    resName?: string;
} & Record<string, number | null>;
export type ValidationData = Record<string, ResidueValidationData[]>;
/** An atom as the selection contacts give it (wasm_src/selection-contacts.h). */
export type CootContactAtom = {
    /** Relative to the molecule analysed, e.g. "//A/45/NZ" */
    cid: string;
    chainId: string;
    resNo: number;
    insCode: string;
    resName: string;
    atomName: string;
    altLoc: string;
    xyz: [number, number, number];
};
/** A molecule made by make_merged_molecule, and where each of its chains came from. */
export type MergedMolecule = {
    imol: number;
    chains: {
        chainId: string;
        imol: number;
        sourceChainId: string;
    }[];
};
export type SelectionHBond = {
    /** Null when the bond was found from its hydrogen only (McDonald & Thornton) */
    donor: CootContactAtom | null;
    hydrogen: CootContactAtom | null;
    acceptor: CootContactAtom;
    /** H...A when the bond has its hydrogen, else D...A */
    distance: number;
    /** The selection the donor is in */
    donorSelection: 1 | 2;
};
export type SaltBridge = {
    /** From the first selection */
    atom1: CootContactAtom;
    /** From the second selection */
    atom2: CootContactAtom;
    distance: number;
    /** The charge of atom1; atom2 has the opposite one */
    charge1: -1 | 1;
};
/** One XH-π interaction found by XPID (checkout/xpid_moorhen/interface.h). */
export type XhpiInteraction = {
    pdb: string;
    model: string;
    pi_chain: string;
    pi_res: string;
    pi_id: number;
    pi_seqid: string;
    pi_ring: string;
    X_chain: string;
    X_res: string;
    X_id: number;
    X_seqid: string;
    X_atom: string;
    H_atom: string;
    dist_X_Pi: number;
    is_plevin: number;
    is_hudson: number;
    remark: string;
    pi_center_x: number;
    pi_center_y: number;
    pi_center_z: number;
    X_xyz_x: number;
    X_xyz_y: number;
    X_xyz_z: number;
    method: string;
    theta: number;
    angle_xh_pi: number;
    angle_xpcn: number;
    proj_dist: number;
} & Record<string, string | number | null>;
/**
 * CootCommand wrapper allowing the execution of web worker commands.
 *
 * It is not destined to be used directly, but attached to the
 * `moorhenInstance` as `moorhenInstance.cootCommand` and used as
 * `moorhenInstance.cootCommandWrapper.command(params)`.
 *
 * Its goal is to provide fully typed methods for each command, with proper argument and return types.
 * It *will* also manage the queue of commands and their execution, as well as the journal of commands executed.
 * It is very incomplete, and slowly growing, you can open a github issue or PR for any commands you need to be wrapped.
 * @remarks
 * Each method corresponds to a Coot web worker command and forwards its
 * arguments to the internal `cootCommand` handler, returning the
 * resulting {@link WorkerResponse}.
 */
export declare class CootCommandWrapper {
    private cootCommand;
    constructor(cootCommand: (kwargs: cootCommandKwargs, doJournal: boolean) => Promise<WorkerResponse>);
    /** Run a command and return its result; throw a CootCommandError if coot threw. */
    private run;
    /** Run a command that returns JSON and parse it; throw a CootCommandError on {"error": ...}. */
    private runJson;
    /**
     * The residue types of a molecule for which Coot has no dictionary (no restraints in its
     * geometry store): such residues are drawn from guessed bonds and cannot be refined.
     */
    get_residue_names_with_no_dictionary(imol: number): Promise<string[]>;
    /**
     * Make a temporary molecule holding the atoms of `cid1` in molecule `imol1` and of `cid2` in
     * `imol2`, so that analyses of one molecule (H-bonds, salt bridges, XH-π, FLEV...) can look
     * across two. The first selection keeps its chain ids; a chain of the second gets a new id if
     * the first already uses its own (`chains` says where each came from). Residue numbers are
     * kept. Delete it with {@link delete_merged_molecule} when done.
     *
     * @param imol1 - The molecule of the first selection.
     * @param cid1 - The first selection; several CIDs can be joined with "||".
     * @param imol2 - The molecule of the second selection.
     * @param cid2 - The second selection.
     */
    make_merged_molecule(imol1: number, cid1: string, imol2: number, cid2: string): Promise<MergedMolecule>;
    /**
     * Delete a molecule made by {@link make_merged_molecule}, and any closed molecules after it,
     * so that their indices are reused.
     */
    delete_merged_molecule(imol: number): Promise<void>;
    /**
     * Hydrogen bonds between two selections of a molecule. The second selection never includes
     * atoms of the first, so "/*" as the second means "everything else".
     *
     * @param mcdonaldAndThornton - Use explicit hydrogens (McDonald & Thornton). Otherwise donors and
     * acceptors come from the dictionaries and no hydrogens are needed.
     */
    get_h_bonds_between(imol: number, cid1: string, cid2: string, mcdonaldAndThornton?: boolean): Promise<SelectionHBond[]>;
    /**
     * Salt bridges between two selections of a molecule: oppositely charged N / O / S atoms within
     * `maxDistance`, once per pair of charged groups. Standard residues use a fixed table, other
     * residues the formal charges of their dictionaries. "/*" as the second selection means
     * "everything else".
     */
    get_salt_bridges(imol: number, cid1: string, cid2: string, maxDistance?: number): Promise<SaltBridge[]>;
    /**
     * XH-π interactions in a molecule, by XPID. XPID adds hydrogens from the monomer library, so
     * dictionaries it would not find there (ligands) are passed by comp id.
     */
    detect_xhpi_interactions(imol: number, ligandDictionaries?: Record<string, string>): Promise<XhpiInteraction[]>;
    /**
     * Coot's 2D ligand environment diagram (FLEV) as SVG; empty when Coot cannot draw it. The
     * ligand's dictionary must be loaded.
     *
     * @param residueCid - The ligand residue, e.g. "//B/1".
     */
    get_svg_for_2d_ligand_environment_view(imol: number, residueCid: string, addKey?: boolean): Promise<string>;
    /**
     * Sets the maximum number of vertices allowed for simple mesh rendering in Coot.
     * This parameter controls the complexity of meshes that can be displayed, affecting
     * both rendering performance and visual quality.
     *
     * @param maxVertices - The maximum number of vertices allowed for simple meshes.
     *                     Default is 1,000,000,000. Higher values allow more detailed
     *                     meshes but may impact performance.
     */
    set_max_number_of_simple_mesh_vertices(maxVertices?: number): Promise<WorkerResponse>;
    /**
     * Adds water molecules to the specified molecule using the provided map.
     *
     * @param moleculeMolNo - The molecule number to which water molecules will be added.
     * @param mapMolNo - The map molecule number used for water placement.
     * @returns A promise that resolves to a {@link WorkerResponse} indicating the status of the operation.
     */
    add_water(moleculeMolNo: any, mapMolNo: any): Promise<WorkerResponse>;
    /**
     * Sets the sigma cutoff value for adding water molecules.
     *
     * @param sigma - The sigma cutoff threshold used to determine water placement criteria.
     * @returns A promise that resolves to a {@link WorkerResponse} indicating the status of the operation.
     */
    set_add_waters_sigma_cutoff(sigma: number): Promise<WorkerResponse>;
    /**
     * Removes dust artifacts from the specified map.
     *
     * This method sends a 'dedust_map' command to the Coot backend, which processes the map
     * identified by the given `imol` parameter to eliminate dust or noise artifacts.
     *
     * @param imol - The identifier of the map to be dedusted.
     */
    dedust_map(imol: any): Promise<WorkerResponse>;
    /**
     * Retrieves density fit analysis data for a molecule against a selected map.
     * Density fit values represent the average map value at atomic centres and can be
     * converted to Z-scores by dividing by the map RMS.
     *
     * @param imol - The molecule identifier for which to analyze density fit.
     * @param selectedMap - The map to use for density fit analysis.
     * @param mapRMS - Optional map RMS value to convert density fit values to Z-scores.
     * @returns A promise that resolves to {@link CootValidationData} containing the density fit analysis results.
     */
    getDensityFitAnalysis(imol: any, selectedMap: any, mapRMS?: number): Promise<CootValidationData>;
    /**
     * Retrieves density correlation analysis data for a molecule against a selected map.
     *
     * @param imol - The molecule identifier for which to analyze density correlation.
     * @param selectedMap - The map to use for density correlation analysis.
     * @returns A promise that resolves to {@link CootValidationData} containing the density correlation analysis results.
     */
    getDensityCorrelationAnalysis(imol: any, selectedMap: any): Promise<CootValidationData>;
    /**
     * Retrieves geometric validation data for a molecule.
     *
     * @param imol - The molecule identifier for which to retrieve validation data.
     * @returns A promise that resolves to {@link ValidationData} containing the geometric validation results organized by chain.
     */
    getGeoValidationData(imol: any): Promise<ValidationData>;
    /**
     * Retrieves per-residue B-factor validation data for a molecule.
     *
     * For each residue it provides the average B-factor of the main chain
     * atoms and the average B-factor of the side chain atoms.
     *
     * @param imol - The molecule identifier for which to retrieve B-factor data.
     * @returns A promise that resolves to {@link ValidationData} containing the
     * per-residue B-factor averages organized by chain.
     */
    getBValidationData(imol: any): Promise<ValidationData>;
    /**
     * Retrieves Q-score validation data for a model against a selected map.
     *
     * @param selectedModel - The model molecule identifier to score.
     * @param selectedMap - The map to use for Q-score calculation.
     * @returns A promise that resolves to {@link CootValidationData} containing the Q-score results.
     */
    getQScore(selectedModel: any, selectedMap: any): Promise<CootValidationData>;
    getPeptideOmegaAnalysis(selectedModel: any): Promise<CootValidationData>;
    get_map_bounding_sphere(imol: number, thresold: number): Promise<{
        center: [number, number, number];
        radius: number;
    }>;
    get_pdb_from_smiles(smiles: string, name: string, conformers: number, iterations: number): Promise<string>;
}
//# sourceMappingURL=CootCommandWrapper.d.ts.map