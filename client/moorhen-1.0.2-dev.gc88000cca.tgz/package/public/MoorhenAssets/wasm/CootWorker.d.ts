export {};
//# sourceMappingURL=CootWorker.d.ts.map