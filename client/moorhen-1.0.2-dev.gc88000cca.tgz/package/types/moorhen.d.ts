import React from "react";
import { libcootApi } from "./libcoot";

/**
 * @deprecated This declarations file and the ambient `moorhen` namespace are deprecated and will be removed.
 *
 * Inside the moorhen package:
 * - Prefer creating/defining types locally and importing them directly from their source modules (utils, store, etc.).
 * - Avoid referencing types through the ambient `moorhen` namespace.
 *
 * Outside the moorhen package (when using `moorhen` as a module):
 * - Import the needed types explicitly from the package entry:
 *   import type { Molecule, Map, CommandCentre } from 'moorhen';
 * - Or import the whole module namespace and reference types from it:
 *   import type * as Moorhen from 'moorhen';
 *   const f = (m: Moorhen.Molecule, map: Moorhen.Map) => {};
 *
 *
 * @example Outside the moorhen package — specific imports
 * import type { Molecule, Map } from 'moorhen';
 * const fit = (mol: Molecule, map: Map) => {
 *   // ...
 * };
 *
 * @example Outside the moorhen package — module namespace
 * import Moorhen from 'moorhen';
 * const draw = (mol: Moorhen.Molecule) => {
 *   // ...
 * };
 *
 * Examples:
 * @example Inside the moorhen package
 * import type { Molecule } from '../utils/MoorhenMolecule';
 * import type { Map } from '../utils/MoorhenMap';
 * const fit = (mol: Molecule, map: Map) => {
 *   // ...
 * };
 */
export namespace moorhen {
    type Molecule = import("./src/utils/MoorhenMolecule").MoorhenMolecule;
    type Map = import("./src/utils/MoorhenMap").MoorhenMap;
    type CommandCentre = import("./src/InstanceManager/CommandCentre").CommandCentre;
    type MoleculeRepresentation = import("./src/utils/Representation/MoorhenMoleculeRepresentation").MoleculeRepresentation;
    type State = import("./src/store/MoorhenReduxStore").RootState;
    type HoveredAtom = import("./src/store/hoveringStatesSlice").HoveredAtom;
    type PreferencesValues = import("./src/InstanceManager/Preferences").PreferencesValues;
    type Sequence = import("./src/utils/MoorhenMolecule").Sequence;
    type ResidueInfo = import("./src/utils/MoorhenMolecule").ResidueInfo;
    type LigandInfo = import("./src/utils/MoorhenMolecule").LigandInfo;
    type TimeCapsule = import("./src/utils/MoorhenTimeCapsule").MoorhenTimeCapsule;
    type backupKey = import("./src/utils/MoorhenTimeCapsule").backupKey;
    type backupSession = import("./src/utils/MoorhenTimeCapsule").backupSession;
    type Preferences = import("./src/InstanceManager/Preferences").Preferences;
    type HistoryEntry = import("./src/utils/MoorhenHistory").HistoryEntry;
    type moleculeSessionData = import("./src/utils/MoorhenTimeCapsule").moleculeSessionData;
    type mapDataSession = import("./src/utils/MoorhenTimeCapsule").mapDataSession;
    type viewDataSession = import("./src/utils/MoorhenTimeCapsule").viewDataSession;
    type Shortcut = import("./src/InstanceManager/Preferences/DefaultShortcuts").Shortcut;
    type actionButtonSettings = import("./src/components/context-menu/MoorhenContextMenu").ActionButtonSettings;
    type LocalStorageInstance = import("./src/InstanceManager/Preferences/MoorhenPreferences").LocalStorageInstance;
    type WorkerResponse<T = any> = import("./src/InstanceManager/CommandCentre").WorkerResponse;
    type cootCommandKwargs = import("./src/InstanceManager/CommandCentre").cootCommandKwargs;
    type ResidueSelection = import("./src/store/generalStatesSlice").ResidueSelection;
    type RepresentationStyles = import("./src/utils/Representation/MoorhenMoleculeRepresentation").RepresentationStyles;

    //type ContextButtonProps = import("./src/components/ContextButton").ContextButtonProps;

    type PAE = {
        predicted_aligned_error: number[][];
    };

    type ResidueSpec = {
        mol_name: string;
        mol_no: string;
        chain_id: string;
        res_no: number;
        res_name: string;
        atom_name: string;
        ins_code: string;
        alt_conf: string;
        cid: string;
    };

    type AtomInfo = {
        x: number;
        y: number;
        z: number;
        charge: number;
        element: string;
        tempFactor: number;
        serial: number;
        occupancy: number;
        name: string;
        has_altloc: boolean;
        alt_loc?: string;
        mol_name: string;
        chain_id: string;
        res_no: string;
        res_name: string;
    };

    type DisplayObject = {
        symmetryMatrices: any;
        updateSymmetryAtoms(): void;
        changeColourWithSymmetry: boolean;
        atoms: any[];
        origin: number[];
        [attr: string]: any;
    };

    type cootBondOptions = {
        smoothness: number;
        width: number;
        atomRadiusBondRatio: number;
        showAniso: boolean;
        showOrtep: boolean;
        showHs: boolean;
    };

    type ColourRuleObject = {
        cid: string;
        color: string;
        applyColourToNonCarbonAtoms: boolean;
        isMultiColourRule: boolean;
        ruleType: string;
        args: (string | number)[];
        label: string;
        uniqueId: string;
        parentMoleculeMolNo: number;
        parentRepresentationUniqueId: string;
    };

    type ColourRule = import("./src/utils/MoorhenColourRule").ColourRule;

    type coorFormats = "pdb" | "mmcif" | "unk" | "mmjson" | "xml";

    type lskqbResidueRangeMatch = {
        refChainId: string;
        movChainId: string;
        refResidueRange: [number, number];
        movResidueRange: [number, number];
    };

    type History = import("./src/utils/MoorhenHistory").History;

    type createCovLinkAtomInput = {
        selectedMolNo: number;
        selectedAtom: string;
        deleteAtom: boolean;
        deleteSelectedAtom: string;
        changeAtomCharge: boolean;
        changeSelectedAtomCharge: string;
        newAtomCharge: string;
        changeBondOrder: boolean;
        changeSelectedBondOrder: string;
        newBondOrder: string;
    };

    interface AceDRGInstance {
        createCovalentLink: (arg0: createCovLinkAtomInput, arg1: createCovLinkAtomInput) => void;
    }

    type selectedMtzColumns = {
        F?: string;
        PHI?: string;
        Fobs?: string;
        SigFobs?: string;
        FreeR?: string;
        isDifference?: boolean;
        useWeight?: boolean;
        calcStructFact?: any;
    };

    type ScreenRecorder = import("./src/utils/MoorhenScreenRecorder").ScreenRecorder;


    type AtomRightClickEventInfo = {
        atom: AtomInfo;
        buffer: { id: string };
        coords: string;
        pageX: number;
        pageY: number;
    };

    type AtomRightClickEvent = CustomEvent<AtomRightClickEventInfo>;

    type AtomDraggedEvent = CustomEvent<{
        atom: AtomInfo;
        buffer: any;
    }>;

    type OriginUpdateEvent = CustomEvent<{ origin: [number, number, number] }>;

    type WheelContourLevelEvent = CustomEvent<{ factor: number }>;

    type MapRadiusChangeEvent = CustomEvent<{ factor: number }>;

    type AtomClickedEvent = CustomEvent<{
        buffer: { id: string };
        atom: AtomInfo;
        isResidueSelection: boolean;
        label: string;
    }>;

    type NewMapContourEvent = CustomEvent<{
        molNo: number;
        mapRadius: number;
        isVisible: boolean;
        contourLevel: number;
        mapColour: [number, number, number, number];
        litLines: boolean;
    }>;

    interface ContextSetters {
        setDefaultMapSamplingRate: React.Dispatch<React.SetStateAction<number>>;
        setDoShadowDepthDebug: React.Dispatch<React.SetStateAction<boolean>>;
        setDefaultBackgroundColor: React.Dispatch<React.SetStateAction<[number, number, number, number]>>;
        setDoShadow: React.Dispatch<React.SetStateAction<boolean>>;
        setDoSSAO: React.Dispatch<React.SetStateAction<boolean>>;
        setDoEdgeDetect: React.Dispatch<React.SetStateAction<boolean>>;
        setEdgeDetectDepthThreshold: React.Dispatch<React.SetStateAction<number>>;
        setEdgeDetectNormalThreshold: React.Dispatch<React.SetStateAction<number>>;
        setEdgeDetectDepthScale: React.Dispatch<React.SetStateAction<number>>;
        setEdgeDetectNormalScale: React.Dispatch<React.SetStateAction<number>>;
        setDoOutline: React.Dispatch<React.SetStateAction<boolean>>;
        setClipCap: React.Dispatch<React.SetStateAction<boolean>>;
        setResetClippingFogging: React.Dispatch<React.SetStateAction<boolean>>;
        setUseOffScreenBuffers: React.Dispatch<React.SetStateAction<boolean>>;
        setDepthBlurRadius: React.Dispatch<React.SetStateAction<number>>;
        setDepthBlurDepth: React.Dispatch<React.SetStateAction<number>>;
        setSsaoRadius: React.Dispatch<React.SetStateAction<number>>;
        setSsaoBias: React.Dispatch<React.SetStateAction<number>>;
        setDoPerspectiveProjection: React.Dispatch<React.SetStateAction<boolean>>;
        setDrawInteractions: React.Dispatch<React.SetStateAction<boolean>>;
        setDrawMissingLoops: React.Dispatch<React.SetStateAction<boolean>>;
        setDrawAxes: React.Dispatch<React.SetStateAction<boolean>>;
        setDrawCrosshairs: React.Dispatch<React.SetStateAction<boolean>>;
        setDrawFPS: React.Dispatch<React.SetStateAction<boolean>>;
        setDefaultExpandDisplayCards: React.Dispatch<React.SetStateAction<boolean>>;
        setUrlPrefix: React.Dispatch<React.SetStateAction<string>>;
        setEnableRefineAfterMod: React.Dispatch<React.SetStateAction<boolean>>;
        setDefaultMapLitLines: React.Dispatch<React.SetStateAction<boolean>>;
        setMapLineWidth: React.Dispatch<React.SetStateAction<number>>;
        setAtomLabelDepthMode: React.Dispatch<React.SetStateAction<boolean>>;
        setMouseSensitivity: React.Dispatch<React.SetStateAction<number>>;
        setShowShortcutToast: React.Dispatch<React.SetStateAction<boolean>>;
        setShowHoverInfo: React.Dispatch<React.SetStateAction<boolean>>;
        setMakeBackups: React.Dispatch<React.SetStateAction<boolean>>;
        setContourWheelSensitivityFactor: React.Dispatch<React.SetStateAction<number>>;
        setDevMode: React.Dispatch<React.SetStateAction<boolean>>;
        setUseGemmi: React.Dispatch<React.SetStateAction<boolean>>;
        setEnableTimeCapsule: React.Dispatch<React.SetStateAction<boolean>>;
        setShowScoresToast: React.Dispatch<React.SetStateAction<boolean>>;
        setDefaultMapSurface: React.Dispatch<React.SetStateAction<boolean>>;
        setDefaultBondSmoothness: React.Dispatch<React.SetStateAction<number>>;
        setGLLabelsFontFamily: React.Dispatch<React.SetStateAction<string>>;
        setGLLabelsFontSize: React.Dispatch<React.SetStateAction<number>>;
        setMaxBackupCount: React.Dispatch<React.SetStateAction<number>>;
        setModificationCountBackupThreshold: React.Dispatch<React.SetStateAction<number>>;
        setShortcutOnHoveredAtom: React.Dispatch<React.SetStateAction<boolean>>;
        setZoomWheelSensitivityFactor: React.Dispatch<React.SetStateAction<number>>;
        setShortCuts: React.Dispatch<React.SetStateAction<string>>;
        setDefaultUpdatingScores: React.Dispatch<{
            action: "Add" | "Remove" | "Overwrite";
            item?: string;
            items?: string[];
        }>;
        setTransparentModalsOnMouseOut: React.Dispatch<React.SetStateAction<boolean>>;
    }

    interface Context extends ContextSetters, PreferencesValues {}
}
