/**
 * Pause/resume the global click-away listeners.
 *
 * Pauses are reference-counted, so nesting multiple pauses is safe and an early
 * resume can never leave the listeners disabled for the remaining pauses (the
 * original "click-away listener never re-activated" bug). The resume is deferred
 * so the click that finished the interaction isn't mistaken for an away click.
 */
export declare const usePauseClickAwayListener: () => (() => void)[];
//# sourceMappingURL=pauseClickAwayListener.d.ts.map