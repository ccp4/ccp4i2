import { WorkerResponse, cootCommandKwargs } from "./MoorhenCommandCentre";
export type CootValidationData = {
    chainId: string;
    seqNum: number;
    restype: string;
    value: number;
}[];
export type ResidueValidationData = {
    seqNum: number;
    insCode?: string;
    resName?: string;
} & Record<string, number | null>;
export type ValidationData = Record<string, ResidueValidationData[]>;
/**
 * CootCommand wrapper allowing the execution of web worker commands.
 *
 * It is not destined to be used directly, but attached to the
 * `moorhenInstance` as `moorhenInstance.cootCommand` and used as
 * `moorhenInstance.cootCommandWrapper.command(params)`.
 *
 * Its goal is to provide fully typed methods for each command, with proper argument and return types.
 * It *will* also manage the queue of commands and their execution, as well as the journal of commands executed.
 * It is very incomplete, and slowly growing, you can open a github issue or PR for any commands you need to be wrapped.
 * @remarks
 * Each method corresponds to a Coot web worker command and forwards its
 * arguments to the internal `cootCommand` handler, returning the
 * resulting {@link WorkerResponse}.
 */
export declare class CootCommandWrapper {
    private cootCommand;
    constructor(cootCommand: (kwargs: cootCommandKwargs, doJournal: boolean) => Promise<WorkerResponse>);
    /**
     * Sets the maximum number of vertices allowed for simple mesh rendering in Coot.
     * This parameter controls the complexity of meshes that can be displayed, affecting
     * both rendering performance and visual quality.
     *
     * @param maxVertices - The maximum number of vertices allowed for simple meshes.
     *                     Default is 1,000,000,000. Higher values allow more detailed
     *                     meshes but may impact performance.
     */
    set_max_number_of_simple_mesh_vertices(maxVertices?: number): Promise<WorkerResponse>;
    /**
     * Adds water molecules to the specified molecule using the provided map.
     *
     * @param moleculeMolNo - The molecule number to which water molecules will be added.
     * @param mapMolNo - The map molecule number used for water placement.
     * @returns A promise that resolves to a {@link WorkerResponse} indicating the status of the operation.
     */
    add_water(moleculeMolNo: any, mapMolNo: any): Promise<WorkerResponse>;
    /**
     * Sets the sigma cutoff value for adding water molecules.
     *
     * @param sigma - The sigma cutoff threshold used to determine water placement criteria.
     * @returns A promise that resolves to a {@link WorkerResponse} indicating the status of the operation.
     */
    set_add_waters_sigma_cutoff(sigma: number): Promise<WorkerResponse>;
    /**
     * Removes dust artifacts from the specified map.
     *
     * This method sends a 'dedust_map' command to the Coot backend, which processes the map
     * identified by the given `imol` parameter to eliminate dust or noise artifacts.
     *
     * @param imol - The identifier of the map to be dedusted.
     */
    dedust_map(imol: any): Promise<WorkerResponse>;
    /**
     * Retrieves density fit analysis data for a molecule against a selected map.
     * Density fit values represent the average map value at atomic centres and can be
     * converted to Z-scores by dividing by the map RMS.
     *
     * @param imol - The molecule identifier for which to analyze density fit.
     * @param selectedMap - The map to use for density fit analysis.
     * @param mapRMS - Optional map RMS value to convert density fit values to Z-scores.
     * @returns A promise that resolves to {@link CootValidationData} containing the density fit analysis results.
     */
    getDensityFitAnalysis(imol: any, selectedMap: any, mapRMS?: number): Promise<CootValidationData>;
    /**
     * Retrieves density correlation analysis data for a molecule against a selected map.
     *
     * @param imol - The molecule identifier for which to analyze density correlation.
     * @param selectedMap - The map to use for density correlation analysis.
     * @returns A promise that resolves to {@link CootValidationData} containing the density correlation analysis results.
     */
    getDensityCorrelationAnalysis(imol: any, selectedMap: any): Promise<CootValidationData>;
    /**
     * Retrieves geometric validation data for a molecule.
     *
     * @param imol - The molecule identifier for which to retrieve validation data.
     * @returns A promise that resolves to {@link ValidationData} containing the geometric validation results organized by chain.
     */
    getGeoValidationData(imol: any): Promise<ValidationData>;
    /**
     * Retrieves per-residue B-factor validation data for a molecule.
     *
     * For each residue it provides the average B-factor of the main chain
     * atoms and the average B-factor of the side chain atoms.
     *
     * @param imol - The molecule identifier for which to retrieve B-factor data.
     * @returns A promise that resolves to {@link ValidationData} containing the
     * per-residue B-factor averages organized by chain.
     */
    getBValidationData(imol: any): Promise<ValidationData>;
    /**
     * Retrieves Q-score validation data for a model against a selected map.
     *
     * @param selectedModel - The model molecule identifier to score.
     * @param selectedMap - The map to use for Q-score calculation.
     * @returns A promise that resolves to {@link CootValidationData} containing the Q-score results.
     */
    getQScore(selectedModel: any, selectedMap: any): Promise<CootValidationData>;
    getPeptideOmegaAnalysis(selectedModel: any): Promise<CootValidationData>;
    get_map_bounding_sphere(imol: number, thresold: number): Promise<{
        center: [number, number, number];
        radius: number;
    }>;
    get_pdb_from_smiles(smiles: string, name: string, conformers: number, iterations: number): Promise<string>;
}
//# sourceMappingURL=CootCommandWrapper.d.ts.map