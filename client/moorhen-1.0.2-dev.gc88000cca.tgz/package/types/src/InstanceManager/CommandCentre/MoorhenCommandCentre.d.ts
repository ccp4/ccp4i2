import { moorhen } from "../../types/moorhen";
import { History } from "../../utils/MoorhenHistory";
export type WorkerResponse<T = any> = {
    data: WorkerResult<T>;
};
export type WorkerResult<T = any> = {
    result: {
        status: string;
        result: T;
        [key: string]: any;
    };
    command: string;
    messageId: string;
    myTimeStamp: string;
    message: string;
    consoleMessage: string;
};
export interface cootCommandKwargs {
    message?: string;
    data?: unknown;
    returnType?: string;
    command?: string;
    commandArgs?: any[];
    changesMolecules?: number[];
    [key: string]: any;
}
export type WorkerMessage = {
    consoleMessage?: string;
    messageId: string;
    handler: (reply: WorkerResponse) => void;
    /** Rejects the command's promise with a CootCommandError when no reply can arrive. */
    reject?: (reason?: unknown) => void;
    kwargs: cootCommandKwargs;
};
/**
 * A command centre used to communicate between Moorhen and a web worker running an instance of the
 * headless libcoot API
 * @property {Worker} cootWorker - A web worker holding a headless libcoot instance
 * @constructor
 * @param {string} urlPrefix - The root url used to find the /CootWorker.js worker file
 * @param {function} onConsoleChanged - Callback executed whenever the worker prints a message to the console
 * @param {function} onCommandStart - Callback executed whenever a new command is issued to the web worker
 * @param {function} onCommandExit - Callback executed whenever a new command is completed by the web worker
 * @param {function} onActiveMessagesChanged  - Callback executed whenever a new message is received from the worker
 * @param {function} onCootInitialized - Callback executed once after coot is initialised in the web worker
 * @property {function} cootCommand - Runs a coot command
 * @property {moorhen.History} history - An object that contains the command history
 * @example
 * import { MoorhenCommandCentre } from "moorhen";
 *
 * commandCentre = new MoorhenCommandCentre({
 *  onActiveMessagesChanged: (newActiveMessages) => {
 *      setBusy(newActiveMessages.length !== 0)
 *  },
 *  onCootInitialized: () => {
 *      setCootInitialized(true)
 *  },
 *      urlPrefix: urlPrefix
 * })
 *
 * await props.commandCentre.current.cootCommand({
 *  returnType: 'status',
 *  command: 'flipPeptide_cid',
 *  commandArgs: [0, "//A/150"],
 * })
 *
 */
export declare class CommandCentre {
    urlPrefix: string;
    cootWorker: Worker;
    activeMessages: WorkerMessage[];
    history: History;
    isClosed: boolean;
    onCootInitialized: null | (() => void);
    onConsoleChanged: null | ((msg: string) => void);
    onCommandStart: null | ((kwargs: any) => void);
    onCommandExit: null | ((kwargs: any) => void);
    onActiveMessagesChanged: null | ((activeMessages: WorkerMessage[]) => void);
    onMoleculeChanged: null | ((molNo: number) => void);
    loadedRotamerTables: boolean;
    loadedRotaRamaTables: boolean;
    constructor(urlPrefix: string, timeCapsule: React.RefObject<moorhen.TimeCapsule>, props: {
        [x: string]: any;
    });
    init(): Promise<void>;
    close(): Promise<void>;
    handleMessage(reply: WorkerResponse): void;
    makeHandler(resolve: any): (reply: any) => void;
    /**
     * Reject the given in-flight commands and drop them from activeMessages, for when
     * their reply can never arrive. Without this they stay pending for ever, which keeps
     * the global busy state (and its spinner) switched on permanently.
     */
    failActiveMessages(messages: WorkerMessage[], reason: string): void;
    cootCommand(kwargs: cootCommandKwargs, doJournal?: boolean): Promise<WorkerResponse>;
    cootCommandList(commandList: cootCommandKwargs[], doJournal?: boolean): Promise<WorkerResponse>;
    postMessage(kwargs: cootCommandKwargs): Promise<WorkerResponse>;
}
//# sourceMappingURL=MoorhenCommandCentre.d.ts.map