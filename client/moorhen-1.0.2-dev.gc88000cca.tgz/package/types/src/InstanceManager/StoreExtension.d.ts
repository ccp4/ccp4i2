import { RootState } from "../store";
import { Dispatch, Store, UnknownAction } from "@reduxjs/toolkit";
import type { SidePanelIDs } from '../components/panels';
import type { ModalCall } from '../store/modalsSlice';
import type { MoorhenMap } from "../utils";
import type { MoorhenVector } from "../store/vectorsSlice";
import type { Tags } from "../utils/tags";
import { ModalKey } from "../components/interface-base/ModalBase/ModalsContainer";
import { SnackbarPayload } from "../store/snackbarSlice";
export declare class StoreExtension {
    private _dispatch;
    private _store;
    get dispatch(): Dispatch<UnknownAction>;
    get store(): Store<RootState>;
    subscribeToStore: <T>(selector: (state: RootState) => T, callback: (value: T) => void) => import("redux").Unsubscribe;
    set dispatch(value: Dispatch<UnknownAction>);
    set store(value: Store<RootState>);
    get backupSettings(): {
        resetBackupSettings(): void;
        setEnableTimeCapsule(value: boolean): void;
        setMakeBackups(value: boolean): void;
        setMaxBackupCount(value: number): void;
        setModificationCountBackupThreshold(value: number): void;
    };
    get generalOptions(): {
        /** disable file upload through the interface, API call still works normally */
        setDisableFileUpload(value: boolean): void;
        setShowResidueSelection(value: boolean): void;
        setUseGemmi(value: boolean): void;
        /** Set the view-only mode of the application. In view-only mode, users can interact with the visualisation but cannot make any modifications to the loaded structures or maps. */
        setViewOnly(value: boolean): void;
    };
    get globalUI(): {
        /** Show dev menu and extra tools */
        setDevMode(value: boolean): void;
        /** Block or unblock shortcuts globally. This is used to prevent shortcut actions from being triggered when the user is typing in an input field, for example. */
        setShortCutsBlocked(value: boolean): void;
        setShowHoverInfo(value: boolean): void;
        /** Display the side panel corresponding to the provided ID, or hide the side panel if the payload is null.
        @param value SidePanelIDs | null */
        setShownSidePanel(value: SidePanelIDs | null): void;
        setSidePanelWidth(value: number): void;
    };
    get hoveringStates(): {
        setEnableAtomHovering(value: boolean): void;
    };
    get labelSettings(): {
        setAtomLabelDepthMode(value: boolean): void;
        setGLLabelsFontFamily(value: string): void;
        setGLLabelsFontSize(value: number): void;
    };
    get mapContourSettings(): {
        hideMap(value: MoorhenMap): void;
        setContourLevel(value: {
            molNo: number;
            contourLevel: number;
        }): void;
        setDefaultMapLitLines(value: boolean): void;
        setDefaultMapSamplingRate(value: number): void;
        setDefaultMapSurface(value: boolean): void;
        setMapAlpha(value: {
            molNo: number;
            alpha: number;
        }): void;
        setMapColours(value: {
            molNo: number;
            rgb: {
                r: number;
                g: number;
                b: number;
            };
        }): void;
        setMapLineWidth(value: number): void;
        setMapRadius(value: {
            molNo: number;
            radius: number;
        }): void;
        setMapStyle(value: {
            molNo: number;
            style: "solid" | "lit-lines" | "lines";
        }): void;
        setNegativeMapColours(value: {
            molNo: number;
            rgb: {
                r: number;
                g: number;
                b: number;
            };
        }): void;
        setPositiveMapColours(value: {
            molNo: number;
            rgb: {
                r: number;
                g: number;
                b: number;
            };
        }): void;
        /** If true the map will not be re-contoured when moving around, only on mouse up.
        helps performance on slower machines */
        setReContourMapOnlyOnMouseUp(value: boolean): void;
        showMap(value: MoorhenMap): void;
    };
    get maps(): {
        setActiveMap(value: MoorhenMap): void;
    };
    get modals(): {
        focusOnModal(value: ModalKey): void;
        hideModal(value: ModalKey): void;
        showModal(value: ModalCall): void;
        unFocusModal(value: string): void;
    };
    get moleculeMapUpdate(): {
        disableUpdatingMaps(): void;
        enableUpdatingMaps(): void;
        resetMoleculeMapUpdates(): void;
        setConnectedMoleculeMolNo(value: number): void;
        setCurrentScores(value: {
            rFactor: number;
            rFree: number;
            moorhenPoints: number;
        }): void;
        setShowScoresToast(value: boolean): void;
        triggerUpdate(value: number): void;
    };
    get mouseSettings(): {
        resetDefaultMouseSettings(): void;
        setContourWheelSensitivityFactor(value: number): void;
        setMouseSensitivity(value: number): void;
        setZoomWheelSensitivityFactor(value: number): void;
    };
    get refinementSettings(): {
        resetRefinementSettings(): void;
        setAnimateRefine(value: boolean): void;
        setEnableRefineAfterMod(value: boolean): void;
        setRefinementSelection(value: "SINGLE" | "TRIPLE" | "SPHERE"): void;
        setUseRamaRefinementRestraints(value: boolean): void;
        setuseTorsionRefinementRestraints(value: boolean): void;
    };
    get sceneSettings(): {
        resetSceneSettings(): void;
        setAmbient(value: [number, number, number, number]): void;
        setBackgroundColor(value: [number, number, number, number]): void;
        setClipCap(value: boolean): void;
        setClipEnd(value: number): void;
        setClipStart(value: number): void;
        setDefaultBackgroundColor(value: [number, number, number, number]): void;
        setDefaultBondSmoothness(value: number): void;
        setDepthBlurDepth(value: number): void;
        setDepthBlurRadius(value: number): void;
        setDepthPeelLayers(value: number): void;
        setDiffuse(value: [number, number, number, number]): void;
        setDoAnaglyphStereo(value: boolean): void;
        setDoCrossEyedStereo(value: boolean): void;
        setDoEdgeDetect(value: boolean): void;
        setDoMultiView(value: boolean): void;
        setDoOutline(value: boolean): void;
        setDoPerspectiveProjection(value: boolean): void;
        setDoSSAO(value: boolean): void;
        setDoShadow(value: boolean): void;
        setDoShadowDepthDebug(value: boolean): void;
        setDoSideBySideStereo(value: boolean): void;
        setDoSpin(value: boolean): void;
        setDoThreeWayView(value: boolean): void;
        setDrawAxes(value: boolean): void;
        setDrawCrosshairs(value: boolean): void;
        setDrawEnvBOcc(value: boolean): void;
        setDrawFPS(value: boolean): void;
        setDrawMissingLoops(value: boolean): void;
        setDrawScaleBar(value: boolean): void;
        setEdgeDetectDepthScale(value: number): void;
        setEdgeDetectDepthThreshold(value: number): void;
        setEdgeDetectNormalScale(value: number): void;
        setEdgeDetectNormalThreshold(value: number): void;
        setFogClipOffset(value: number): void;
        setFogEnd(value: number): void;
        setFogStart(value: number): void;
        setGlViewportHeight(value: number): void;
        setGlViewportWidth(value: number): void;
        setHeight(value: number): void;
        setHoverSize(value: number): void;
        setIsDark(value: boolean): void;
        setLightPosition(value: [number, number, number, number]): void;
        setMultiViewColumns(value: number): void;
        setMultiViewRows(value: number): void;
        /** Set the origin of the scene to the provided coordinates.
        @param value [number, number, number] X, Y, Z coordinates */
        setOrigin(value: [number, number, number]): void;
        setPeelOpaqueSeparately(value: boolean): void;
        /** Move the eye towards or away from the view centre, in angstroms. This is what sets how
        strongly a perspective view converges: close in, the far side of a molecule shrinks
        markedly; far off, the view approaches orthographic. The framing stays put, because the
        projection's scale is derived from the same distance, so this is a dolly zoom rather
        than a zoom. Fog moves with the eye so that it stays where it was on the molecule.
        Clip needs no adjustment, being measured from the centre already. No effect under
        orthographic projection. */
        setPerspectiveEyeDistance(value: number): void;
        setResetClippingFogging(value: boolean): void;
        setSpecifyMultiViewRowsColumns(value: boolean): void;
        setSpecular(value: [number, number, number, number]): void;
        setSpecularPower(value: number): void;
        setSsaoBias(value: number): void;
        setSsaoRadius(value: number): void;
        setThreeWayViewOrder(value: string): void;
        setUseOffScreenBuffers(value: boolean): void;
        setWidth(value: number): void;
        /** @param zoom level 1 = 22A
        or A/22 */
        setZoom(value: number): void;
    };
    get snackbar(): {
        /** Clear all messages from the display. */
        clearSnackbar(): void;
        /** Remove the message with the specified unique identifier from the display. */
        closeSnackbar(value: {
            uid: string;
        }): void;
        /** Display a message on the interface with the provided content and styling options.
        @param message The content of the message to be displayed.
        @param variant The styling variant for the message, which can be "success", "error", "warning", or "info". Defaults to "info" if not provided.
        @param autoHideDuration The duration in milliseconds for which the message should be displayed before automatically hiding. If null, the message will not auto-hide. Defaults to 6000 milliseconds if not provided.
        @param uid An optional unique identifier for the message. If not provided, a unique ID will be generated using the current timestamp and a random number. */
        enqueueSnackbar(value: SnackbarPayload): void;
    };
    get vectors(): {
        addVector(value: MoorhenVector): void;
        addVectors(value: MoorhenVector[]): void;
        emptyVectors(): void;
        removeVector(value: MoorhenVector): void;
        /** * Remove one vector by its uniqueId, without needing the vector itself. */
        removeVectorById(value: string): void;
        removeVectors(value: MoorhenVector[]): void;
        /** * Remove several vectors by their uniqueIds, without needing the vectors themselves. */
        removeVectorsByIds(value: string[]): void;
        /** *
        * Remove every vector carrying all of the given tags. One pair removes a whole group,
        * several narrow it: { source: "xpid" } takes every XPID vector, and adding
        * { molecule: uid } restricts it to one molecule's. An empty query removes nothing, so
        * that a tag object which came out empty by accident cannot clear the scene; use
        * emptyVectors to mean all of them. */
        removeVectorsByTag(value: Tags): void;
        /** *
        * @deprecated Matches a substring of uniqueId, from when a tag was written into the
        * identifier. Use removeVectorsByTag. Kept because it is public and takes an arbitrary
        * string, so identifiers in the wild carry tags that cannot be migrated. */
        removeVectorsMatchingIDString(value: string): void;
    };
}
//# sourceMappingURL=StoreExtension.d.ts.map