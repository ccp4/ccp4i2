export declare const useTimeCapsule: () => import("react").RefObject<import("../moorhen").MoorhenTimeCapsule>;
export declare const useCommandCentre: () => import("react").RefObject<import("./CommandCentre").CommandCentre>;
export declare const useCommandAndCapsule: () => {
    commandCentre: import("react").RefObject<import("./CommandCentre").CommandCentre>;
    timeCapsuleRef: import("react").RefObject<import("../moorhen").MoorhenTimeCapsule>;
};
export declare const usePaths: () => {
    urlPrefix: string;
    monomerLibraryPath: string;
};
//# sourceMappingURL=hooks.d.ts.map