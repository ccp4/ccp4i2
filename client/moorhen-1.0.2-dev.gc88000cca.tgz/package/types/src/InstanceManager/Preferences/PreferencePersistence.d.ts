import type { AppDispatch, MoorhenReduxStoreType } from "../../store/MoorhenReduxStore";
import { Preferences } from "./MoorhenPreferences";
export type InitPreferencePersistenceArgs = {
    store: MoorhenReduxStoreType;
    dispatch: AppDispatch;
    localStorageInstance: Preferences;
    onUserPreferencesChange?: (key: string, value: unknown) => void;
};
/**
 * Initialises preference persistence for a given Redux store and localForage instance.
 *
 * Preferences are persisted ONLY when their value differs from the current code default
 * ("persist only deviations"). Defaults are never stored, so developers can change default
 * values freely and users who never touched a preference automatically pick up the new default.
 *
 * Stored values are wrapped as `{ version, value }`, where `version` is the preference's version
 * at the time the value was saved. On restore:
 *   - nothing stored -> the code default is used
 *   - stored `version` is stale (older than the preference's current version) -> reset to default
 *   - stored plain value (legacy format, no version) -> untrusted -> reset to default
 *   - stored `{ version, value }` with a current version -> restored (an explicit user choice)
 *
 * Once all preferences have been restored, `userPreferencesMounted` is dispatched so the rest of
 * the application can proceed (see MainContainer's startup effect).
 *
 * `onUserPreferencesChange` is called once a change has been written to storage, including when a
 * preference is set back to its default (its stored entry is removed).
 *
 * @returns an unsubscribe function that stops the store subscription (call on cleanup). Its `restore`
 * method re-applies whatever is in storage to the store (used to import preferences after start-up);
 * changes made by a restore are not persisted again and do not call `onUserPreferencesChange`.
 */
export declare const initPreferencePersistence: (args: InitPreferencePersistenceArgs) => (() => void) & {
    restore: () => Promise<void>;
};
//# sourceMappingURL=PreferencePersistence.d.ts.map