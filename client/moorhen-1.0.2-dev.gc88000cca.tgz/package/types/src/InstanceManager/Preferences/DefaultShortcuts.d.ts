export type Shortcut = {
    modifiers: string[];
    keyPress: string;
    label: string;
    viewOnly: boolean;
};
export declare const DEFAULT_SHORTCUTS: {
    [key: string]: Shortcut;
};
//# sourceMappingURL=DefaultShortcuts.d.ts.map