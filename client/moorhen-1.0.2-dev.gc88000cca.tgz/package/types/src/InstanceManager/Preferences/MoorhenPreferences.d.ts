import { PreferencesValues } from "./PreferencesList";
export type LocalStorageInstance = LocalForage;
/**
 * Interface for the Moorhen preferences kept in the browser local storage
 * @property {string} name - The name of the local storage instance
 * @property {LocalForage} localStorageInstance - The local storage instance
 * @constructor
 * @param {string} name - The name of the local storage instance
 */
export declare class Preferences {
    name: string;
    defaultPreferencesValues: PreferencesValues;
    localStorageInstance: LocalForage;
    constructor(name?: string);
    createLocalForageInstance(empty?: boolean): LocalForage;
    static get defaultPreferencesValues(): PreferencesValues;
}
//# sourceMappingURL=MoorhenPreferences.d.ts.map