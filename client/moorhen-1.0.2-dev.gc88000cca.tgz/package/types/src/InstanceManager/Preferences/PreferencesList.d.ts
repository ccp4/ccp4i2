/**
 * A mapping of user preferences for the application, where each entry defines a configurable setting.
 * Each preference is represented by a {@link PreferenceEntry} object, which includes:
 * - `label`: The unique string identifier for the preference.
 * - `valueSetter`: The Redux action creator used to update the preference value.
 * - `selector`: A function to select the current value from the Redux state.
 * - `defaultValue`: The default value for the preference.
 *
 * ## How to add a new preference
 * 1. Create a new Redux action and selector for your setting if they do not already exist.
 * 2. Add a new entry to the `PREFERENCES_MAP` object with a unique numeric key.
 * 3. Set the `label` to a unique string identifier for your preference.
 * 4. Set the `valueSetter` to your Redux action creator.
 * 5. Set the `selector` to a function that retrieves the value from the Redux state.
 * 6. Set the `defaultValue` to the desired default.
 *
 * @example
 * ```typescript
 * 52: {
 *   label: "myNewPreference",
 *   valueSetter: setMyNewPreference,
 *   selector: (state: RootState) => state.mySettings.myNewPreference,
 *   defaultValue: false,
 * }
 * ```
 *
 * @see PreferenceEntry
 * @see RootState
 */
import { UnknownAction } from "@reduxjs/toolkit";
import { RootState } from "../../store";
export type PreferenceEntry<T = unknown> = {
    label: string;
    valueSetter: (value: T) => UnknownAction;
    selector: (state: RootState) => T;
    defaultValue: T;
    /**
     * The version of this preference's current default. Bump it (increment) whenever you
     * change `defaultValue`: stored values saved under an older version are considered stale
     * and are reset to the new default. If omitted, defaults to 1.
     */
    version?: number;
};
export declare const PREFERENCES_MAP: {
    [key: number]: PreferenceEntry;
};
export type PreferenceLabel = (typeof PREFERENCES_MAP)[keyof typeof PREFERENCES_MAP]["label"];
export type PreferenceDefaultValue<L extends PreferenceLabel> = Extract<(typeof PREFERENCES_MAP)[keyof typeof PREFERENCES_MAP], {
    label: L;
}>["defaultValue"];
export type PreferencesValues = {
    version: string;
} & {
    [K in PreferenceLabel]: PreferenceDefaultValue<K>;
};
//# sourceMappingURL=PreferencesList.d.ts.map