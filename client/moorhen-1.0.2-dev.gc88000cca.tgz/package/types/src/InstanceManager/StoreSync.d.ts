import type { MoorhenInstance } from "./MoorhenInstance";
/**
 * Start keeping every STORE_SYNCS entry in sync. Values present at start-up are not applied (start-up does that);
 * only later changes are.
 * @returns A function that stops the syncing
 */
export declare const startStoreSyncs: (instance: MoorhenInstance) => (() => void);
//# sourceMappingURL=StoreSync.d.ts.map