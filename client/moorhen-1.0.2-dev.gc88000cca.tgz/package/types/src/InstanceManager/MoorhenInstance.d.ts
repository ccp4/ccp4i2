import { Dispatch, Store, UnknownAction } from "redux";
import React from "react";
import { MoorhenWebComponent } from "../WebComponent/MoorhenWebComponent";
import { Preferences } from "./Preferences/MoorhenPreferences";
import type { MoorhenMenuSystem } from "../components/menu-system/MenuSystem";
import { ThreeDObject } from "../store/threeDObjectsSlice";
import { MoorhenVector } from "../store/vectorsSlice";
import { Tags } from "../utils/tags";
import { AllowedObjectKeys, ThreeDObjectCreateParams } from "../utils/threeDObjectFactories";
import { MoorhenMap, MoorhenMolecule } from "../utils";
import type { MtzMapRequest } from "../utils/MtzLoading";
import { MoleculeRepresentation } from "../utils/Representation/MoorhenMoleculeRepresentation";
import type { PictureWizardType } from "../utils/Representation/PictureWizard";
import { ScreenRecorder } from "../utils/MoorhenScreenRecorder";
import { MoorhenTimeCapsule, backupSession } from "../utils/MoorhenTimeCapsule";
import type { CreateRepresentationParams, PublicRepresentationStyles } from "../utils/Representation/RepresentationBuilder";
import { moorhen } from "../types/moorhen";
import { CommandCentre } from "./CommandCentre";
import { CootCommandWrapper } from "./CommandCentre/CootCommandWrapper";
import { StoreExtension } from "./StoreExtension";
import type { AppDispatch, MoorhenReduxStoreType } from "../store/MoorhenReduxStore";
/**
 * Result of a file-loading operation: one entry per successfully loaded file,
 * describing the kind of object created and how to refer to it afterwards.
 * @property {string} type - "molecule" when a model was loaded, "map" when a map was loaded
 * @property {string} uniqueID - Unique ID of the created {@link MoorhenMolecule} or {@link MoorhenMap}
 * @property {number} molNo - Molecule/map number used by the Coot worker
 * @property {string} fileName - Name of the source file that was loaded
 */
export type LoadFilesResult = {
    type: "molecule" | "map";
    uniqueID: string;
    molNo: number;
    fileName: string;
}[];
/**
 * User preferences as exchanged with a host application: what Moorhen keeps in its preference storage,
 * i.e. only the preferences that differ from their default, each as `{ version, value }`.
 */
export type StoredPreferences = {
    format: "moorhen-1.0";
    entries: {
        [label: string]: {
            version: number;
            value: unknown;
        };
    };
};
export type moleculeChangeAction = "new" | "add" | "delete" | "modify" | "refine";
/**
 * MoorhenInstance is the key public API entry point for the whole application.
 * It ties together the Redux store, the {@link CommandCentre} (which wraps the Coot
 * worker), the session {@link MoorhenTimeCapsule}, the user {@link Preferences},
 * the container ref that hosts the WebGL component and all high-level actions such
 * as loading files, restoring sessions and managing representations.
 *
 * High-level operations are grouped behind getters that each return an object of
 * related methods:
 * - `files` - loading molecules and maps (from files, URLs, strings or SMILES)
 * - `session` - restoring data from a saved session
 * - `representation` - creating, editing, deleting and styling representations
 *
 * The instance is constructed and initialised (via the `@private` constructor and
 * `startInstance`) by the application shell. Code that holds a reference to the
 * instance - for example through the `useMoorhenInstance` hook - should use
 * `execWhenReady` to run anything that depends on Coot being initialised.
 *
 * @extends StoreExtension
 */
export declare class MoorhenInstance extends StoreExtension {
    private _defaultStyle;
    private _filesLoadedCallbacks;
    private _commandCentre;
    private commandCentreRef;
    private timeCapsule;
    private timeCapsuleRef;
    private videoRecorder;
    private videoRecorderRef;
    private aceDRGInstance;
    private containerRef;
    private _preferences;
    private _preferencesRestore;
    private _preferencesChangeCallbacks;
    private moleculesRef;
    private mapsRef;
    private _cootCommand;
    private _menuSystem;
    private ready;
    private _webComponent;
    private readyCallbacks;
    private preferencesUnsubscribe;
    private storeSyncsUnsubscribe;
    /**
     * Create a new Moorhen instance.
     *
     * **Internal use only.** The application shell constructs and wires up the
     * instance; consumers should obtain an already-initialised instance from the
     * application rather than constructing one (and calling `startInstance`) themselves.
     *
     * @private
     * @param containerRef - Ref to the HTML container that hosts the WebGL component.
     * @param menuSystem - Optional menu system that drives the application UI.
     * @param externalCommandCentre - Optional {@link CommandCentre} to use instead of
     * creating one internally during `startInstance`.
     * @param externalTimeCapsuleRef - Optional ref that is populated with the
     * {@link MoorhenTimeCapsule} once it is created, so the caller can access it externally.
     */
    constructor(containerRef: React.RefObject<HTMLDivElement>, menuSystem?: MoorhenMenuSystem, externalCommandCentre?: CommandCentre, externalTimeCapsuleRef?: React.RefObject<MoorhenTimeCapsule | null>);
    /**
     * Paths used to locate the Coot worker assets and the monomer library.
     * `urlPrefix` prefixes asset URLs; `monomerLibraryPath` points at the directory
     * holding the monomer (ligand) restraints. Populated via `setPaths`.
     */
    paths: {
        urlPrefix: string;
        monomerLibraryPath: string;
    };
    /**
     * Execute a callback once the instance is fully initialised (i.e. after
     * `startInstance` has completed), or immediately if it is already ready.
     *
     * This avoids having to check `isReady()` in every method that needs to
     * interact with the Coot command or other attributes that might not be
     * available as soon as the instance is created.
     *
     * @param callback - Function to run once the instance is ready. It may be
     * synchronous or return a promise; its resolved value is forwarded to the caller.
     * @returns A promise that resolves with the return value of `callback`.
     * @example
     * instance.execWhenReady(() => {
     *     // Coot is initialised and safe to call here.
     *     console.log("Moorhen instance ready");
     * });
     */
    execWhenReady<T>(callback: () => T | Promise<T>): Promise<T>;
    /**
     * Attach a {@link CommandCentre} to this instance and (re)build the wrapper
     * used to send commands to the Coot worker.
     *
     * **Internal use only.** Called by the application wiring during startup.
     * @private
     * @param commandCentre - The command centre to attach.
     */
    setCommandCentre(commandCentre: CommandCentre): void;
    /**
     * The low-level wrapper used to send commands to the Coot worker.
     */
    get cootCommand(): CootCommandWrapper;
    /**
     * The {@link CommandCentre} attached to this instance.
     */
    get commandCentre(): CommandCentre;
    /**
     * Get the React ref holding the {@link CommandCentre}, for callers that need
     * the raw ref object rather than the centre itself.
     *
     * @returns The command centre React ref.
     */
    getCommandCentreRef(): React.RefObject<CommandCentre>;
    /**
     * Attach a {@link MoorhenTimeCapsule} to this instance.
     *
     * **Internal use only.** Called by the application wiring during startup.
     * @private
     * @param timeCapsule - The time capsule to attach.
     */
    setTimeCapsule(timeCapsule: MoorhenTimeCapsule): void;
    /**
     * The session {@link MoorhenTimeCapsule} attached to this instance.
     *
     */
    getTimeCapsule(): MoorhenTimeCapsule;
    /**
     * Get the React ref holding the session {@link MoorhenTimeCapsule}.
     *
     * @returns The time capsule React ref.
     */
    getTimeCapsuleRef(): React.RefObject<MoorhenTimeCapsule>;
    /**
     * Attach a screen recorder to this instance (used to capture the GL canvas).
     *
     * **Internal use only.** Called by the application wiring during startup.
     * @private
     * @param videoRecorder - The screen recorder to attach.
     */
    setVideoRecorder(videoRecorder: ScreenRecorder): void;
    /**
     * The screen recorder attached to this instance.
     *
     */
    getVideoRecorder(): ScreenRecorder;
    /**
     * Get the React ref holding the screen recorder.
     *
     * @returns The screen recorder React ref.
     */
    getVideoRecorderRef(): React.RefObject<ScreenRecorder>;
    /**
     * The user {@link Preferences} object for this instance.
     */
    getPreferences(): Preferences;
    /**
     * Initialise preference persistence (restore from local storage + subscribe
     * to the store).
     *
     * **Internal use only.** Called by the application wiring during startup.
     *
     * @private
     * @param store - The Redux store that drives this instance.
     * @param dispatch - Redux dispatch function used to apply preference changes.
     * @param onUserPreferencesChange - Optional callback invoked whenever a user
     * preference changes; receives the preference key and its new value.
     * @returns An unsubscribe function; call it to stop subscribing to the store
     * (e.g. during cleanup).
     */
    initPreferences(store: MoorhenReduxStoreType, dispatch: AppDispatch, onUserPreferencesChange?: (key: string, value: unknown) => void): (() => void);
    /**
     * Set the paths used to locate the Coot worker assets and the monomer library.
     *
     * **Internal use only.** Called by the application wiring during startup.
     * @private
     * @param urlPrefix - Prefix prepended to asset URLs.
     * @param monomerLibrary - Path to the directory of monomer (ligand) restraints.
     */
    setPaths(urlPrefix: string, monomerLibrary: string): void;
    /**
     * Attach the AceDRG instance used to generate ligand restraints.
     *
     * **Internal use only.** Called by the application wiring during startup.
     * @private
     * @param aceDRGInstance - The AceDRG instance to attach.
     */
    setAceDRGInstance(aceDRGInstance: moorhen.AceDRGInstance): void;
    /**
     * The AceDRG instance used to generate ligand restraints.
     *
     * **Internal use only.**
     * @private
     * @returns The AceDRG instance, or null if none has been attached.
     */
    getAceDRGInstance(): moorhen.AceDRGInstance | null;
    /**
     * Get the React ref of the HTML container that hosts the WebGL component.
     *
     * **Internal use only.**
     * @private
     * @returns The container ref.
     */
    getContainerRef(): React.RefObject<HTMLDivElement>;
    /**
     * The menu system driving the application UI.
     *
     * Use it to add your own main-menu entries and submenus. See
     * {@link MoorhenMenuSystem} for the methods and the menu configuration types.
     */
    get menuSystem(): MoorhenMenuSystem | null;
    /**
     * Whether the instance has completed `startInstance` initialisation.
     * @returns True once the instance is ready to interact with Coot.
     */
    isReady(): boolean;
    /**
     * File-loading API for this instance.
     *
     * All methods return a {@link LoadFilesResult}: one entry per successfully
     * loaded file. Loaded objects are automatically added to the store and drawn.
     */
    get files(): {
        /**
         * Load one or more structure/map files into Moorhen.
         *
         * Files can be supplied in several forms:
         * - a `File`, `File[]` or `FileList` (e.g. from an `<input type="file">`)
         * - a `string`/`string[]` or `URL`/`URL[]` pointing at a file to fetch
         *   (`http(s)://`, `blob:`, `file://` or, in a Node context, a local path)
         * - an object `{ url, filename }` (or an array of them) to fetch a URL and
         *   give the downloaded file a specific name
         *
         * The kind of object created is detected from the file name extension:
         * - `.pdb`, `.ent`, `.cif`, `.mmcif` are read as structures (a `.cif` that
         *   is not a structure is attempted as a ligand dictionary)
         * - `.mtz` reflection data are read into one or more maps
         * - `.mrc`, `.map`, `.ccp4` (optionally `.gz`) are read as maps; names
         *   containing `_fofc.mrc`/`_diff.ccp4` are treated as difference maps and
         *   `_locres.mrc` as local-resolution maps
         *
         * @param files - The file(s), URL(s) or file-like object(s) to load. A
         * single value and an array of the same value type are both accepted.
         * @param origin - Optional label describing where the load came from; it is
         * forwarded to subscribers registered via `newFilesLoadedCallback`.
         * @returns A promise resolving to a {@link LoadFilesResult}.
         * @example
         * await instance.files.loadFiles([
         *   "https://example.com/model.pdb",
         *   { url: "https://example.com/emd.map", filename: "my-map.map" }
         * ]);
         */
        loadFiles(files: File[] | File | FileList | string | string[] | URL | URL[] | {
            url: string | URL;
            filename: string;
        }[] | {
            url: string | URL;
            filename: string;
        }, origin?: string): Promise<LoadFilesResult>;
        /**
         * Load one or more maps from a single MTZ file, with explicitly chosen columns and display options.
         *
         * The file is fetched once for all maps, and every requested column is checked against its
         * header before anything is sent to Coot. A missing `F` or `PHI` column rejects the call with a
         * message listing the available columns; a missing `Fobs`/`SigFobs`/`FreeR` column only gives a
         * warning, and the map is loaded without reflection data.
         *
         * Active map: the first map requested with `active: true` becomes active; otherwise the first
         * map does, unless a map is already active.
         *
         * @param source - A URL or a `File`.
         * @param maps - The maps to read. If omitted, the maps are detected automatically, exactly as when
         * the file is passed to `loadFiles`.
         * @param origin - Optional label forwarded to subscribers registered via `newFilesLoadedCallback`.
         * @returns A promise resolving to a {@link LoadFilesResult}, one entry per map in request order.
         * @example
         * await instance.files.loadMtz("job/output.mtz", [
         *   { name: "map", columns: { F: "FWT", PHI: "PHWT", Fobs: "FP", SigFobs: "SIGFP", FreeR: "FreeR_flag" }, active: true },
         *   { name: "diff-map", columns: { F: "DELFWT", PHI: "PHDELWT" }, isDifference: true },
         * ]);
         */
        loadMtz(source: string | URL | File, maps?: MtzMapRequest[], origin?: string): Promise<LoadFilesResult>;
        /**
         * Generate a ligand from a SMILES string (via Coot/AceDRG) and load the
         * resulting restraints dictionary as a new molecule.
         * @param smiles - The SMILES string describing the ligand.
         * @param ligname - Name to give the generated ligand/molecule (defaults to "LIG").
         * @returns A promise resolving to a {@link LoadFilesResult}.
         */
        ligandFromSmiles(smiles: string, ligname: string): Promise<LoadFilesResult>;
        /**
         * Load a model from a raw PDB-format string.
         * @param pdbString - The PDB file contents.
         * @param name - Base name used for the resulting file/molecule.
         * @returns A promise resolving to a {@link LoadFilesResult}.
         */
        loadPDBString(pdbString: string, name: string): Promise<LoadFilesResult>;
        /**
         * Load a model (or ligand dictionary) from a raw mmCIF-format string.
         * @param cifString - The mmCIF file contents.
         * @param name - Base name used for the resulting file/molecule.
         * @returns A promise resolving to a {@link LoadFilesResult}.
         */
        loadCifString(cifString: string, name: string): Promise<LoadFilesResult>;
        /**
         * Register a callback that is invoked whenever files are loaded through
         * `loadFiles` (or helpers built on top of it).
         * @param callback - Function called with the {@link LoadFilesResult} of the
         * load and the `origin` label that was passed to `loadFiles`.
         * @returns A function that unregisters the callback.
         */
        newFilesLoadedCallback(callback: (filesLoaded: LoadFilesResult, origin: string) => void): () => void;
    };
    /**
     * Preferences API for host applications that store the user preferences themselves.
     */
    get preferences(): {
        /**
         * Replace the stored preferences with `stored` and apply them, at any time. Anything that is not
         * a {@link StoredPreferences} object is ignored. Does not fire `onChange`.
         */
        import(stored: unknown): Promise<void>;
        /** The stored preferences, in the format accepted by `import` */
        export(): Promise<StoredPreferences>;
        /**
         * Call `callback` with the exported preferences after every stored change, including a preference
         * set back to its default.
         * @returns A function that unregisters the callback.
         */
        onChange(callback: (stored: StoredPreferences) => void): () => void;
    };
    /**
     * Session-restore API for this instance.
     */
    get session(): {
        /**
         * Restore a previously saved Moorhen session into this instance.
         *
         * The `backupSession` object is produced by the time capsule and can contain
         * molecule data (coordinates, representations, colour rules, ligand
         * dictionaries), map data (optionally including additional/reflection data),
         * the view state (origin, lighting, zoom...), the active map index and any
         * vector/2D-overlay annotations.
         *
         * @param sessionData - The session data to restore.
         * @param fetchExternalUrl - Optional callback that returns the URL of a file
         * by its unique ID; used to fetch external data that was not embedded in the
         * session blob.
         * @returns A promise resolving to the number of molecules that were restored.
         */
        loadSessionData(sessionData: backupSession, fetchExternalUrl?: (uniqueId: string) => Promise<string>): Promise<number>;
    };
    /**
     * Get the {@link MoorhenMolecule} whose unique ID matches `uid`.
     * @param uid - The unique ID of the molecule to look up.
     * @returns The matching molecule, or undefined if no loaded molecule has that ID.
     */
    getMolecule(uid: string): MoorhenMolecule;
    /**
     * Get all currently loaded molecules.
     * @returns The list of loaded {@link MoorhenMolecule}s.
     */
    getMoleculeList(): MoorhenMolecule[];
    /**
     * Get all currently loaded maps.
     * @returns The list of loaded {@link MoorhenMap}s.
     */
    getMapList(): MoorhenMap[];
    /**
     * 3D object API for this instance.
     *
     * Lets you get, create, edit and delete the geometric shapes - spheres, cylinders,
     * arcs, paths, polyhedra and the rest - drawn in the 3D view alongside the molecules.
     * Each object's `uniqueId` is its handle, as a representation's is.
     *
     * Unlike a representation, an object is plain data rather than an instance of a class:
     * it goes into the store, and the viewer draws whatever it finds there. So there is no
     * separate step to draw or redraw one, and no async work - these methods return as soon
     * as the store has been updated.
     *
     * @example
     * const uid = instance.object.create({ type: "sphere", origin: [10, 0, 0], radius: 5 });
     * instance.object.edit(uid, { colour: "#00ff00ff", wireframe: true });
     * instance.object.delete(uid);
     */
    get object(): {
        /**
         * The shape names that {@link create} accepts.
         * @example
         * console.log(instance.object.types); // ["sphere", "cylinder", "cone", ...]
         */
        readonly types: ThreeDObject["type"][];
        /**
         * Get a 3D object by its unique ID.
         * @param uniqueId - The unique identifier of the object.
         * @returns The matching object, or null if there is no such object.
         * @example
         * const sphere = instance.object.get(uid);
         */
        get(uniqueId: string): ThreeDObject | null;
        /**
         * Get the 3D objects currently in the scene, in the order they were added.
         *
         * @param tags - Optional filter. An object must carry all the pairs given to be
         * included, so `{ source: "myApp" }` returns everything that application drew and
         * adding another pair narrows it further. Omit it for everything.
         * @returns The matching objects. Treat the list as read-only: change an object
         * through {@link edit} rather than by mutating what comes back, or the viewer will
         * not hear about it.
         * @example
         * instance.object.list().forEach(obj => console.log(obj.type, obj.uniqueId));
         * instance.object.list({ source: "myApp" }).length;
         */
        list(tags?: Tags): ThreeDObject[];
        /**
         * Create a 3D object and draw it.
         *
         * `type` is the only required field. Everything else falls back to that shape's
         * default, so `{ type: "sphere" }` is a complete request and gives a unit sphere
         * at the origin. Because the object types form a discriminated union, naming the
         * type narrows the rest of the fields: a "sphere" takes `radius`, a "cylinder"
         * takes `end` and `radius`, a "torus" takes `major_radius` and `minor_radius`.
         *
         * Any `uniqueId` in `params` is ignored - the new object always gets a fresh one,
         * so two calls with the same parameters give two objects rather than one.
         *
         * @param params - The shape to make, plus any fields to override its defaults.
         * @param params.type - One of {@link types}.
         * @returns The unique ID of the new object, which is its handle for
         * {@link get}, {@link edit} and {@link delete}. Null if `type` is not a
         * known shape.
         * @example
         * const uid = instance.object.create({
         *     type: "cylinder",
         *     origin: [0, 0, 0],
         *     end: [0, 20, 0],
         *     radius: 2,
         *     colour: "#3366ffff"
         * });
         */
        create<P extends ThreeDObjectCreateParams>(params: P & { [Key in Exclude<keyof P, AllowedObjectKeys<P>>]: never; }): string | null;
        /**
         * Edit an existing 3D object in place.
         *
         * A partial update: fields left out keep their current value. The object's
         * `type` and `uniqueId` cannot be changed - to turn a sphere into a cube,
         * delete it and create the cube, which also makes it clear in a session that
         * two different objects were involved.
         *
         * @param uniqueId - Unique ID of the object to edit.
         * @param params - The fields to change.
         * @returns True if the object was found and updated, otherwise false.
         * @example
         * instance.object.edit(uid, { radius: 8, colour: "#ff0000ff" });
         */
        edit(uniqueId: string, params: Partial<Omit<ThreeDObject, "type" | "uniqueId">>): boolean;
        /**
         * Delete a 3D object, removing it from the scene.
         * @param uniqueId - Unique ID of the object to delete.
         * @returns True if the object was found and deleted, otherwise false.
         * @example
         * const deleted = instance.object.delete(uid);
         */
        delete(uniqueId: string): boolean;
        /**
         * Delete 3D objects in bulk. Molecules and maps are untouched.
         *
         * This is how whatever created a group of objects disposes of them: tag them on the
         * way in, and clear by that tag rather than having to remember their ids. A custom
         * representation that redraws itself wants exactly this.
         *
         * @param tags - Optional filter, with the same meaning as in {@link list}. Omit it
         * to clear everything. An empty object - `{}` - clears nothing rather than
         * everything, so a tag object that came out empty by accident cannot wipe the
         * scene; pass no argument to mean all of them.
         * @returns The number of objects removed.
         * @example
         * instance.object.clear({ source: "myApp" });   // just that application's
         * instance.object.clear();                      // all of them
         */
        clear(tags?: Tags): number;
    };
    /**
     * Vector API for this instance.
     *
     * Vectors are the arrows, dashed lines and distance labels drawn between atoms or points -
     * XH-pi interactions, NOE restraints, and anything an application wants to point at
     * something with.
     *
     * This extends rather than replaces what the generated store API already offered. Everything
     * from there is still here, so `addVector(wholeVector)` and the rest keep working; the
     * additions are the shape the 3D object API uses - `type`-free defaults, a returned handle,
     * tag filtering - so that the two read alike.
     *
     * Overriding the getter rather than adding a second namespace is deliberate. The generated
     * methods are grouped by slice name, which gives `instance.vectors`; a curated
     * `instance.vector` beside it would be one keystroke apart and do something different.
     *
     * @example
     * const uid = instance.vectors.create({ xTo: 10, yTo: 5, tags: { source: "myApp" } });
     * instance.vectors.edit(uid, { labelText: "3.4 A", labelMode: "middle" });
     * instance.vectors.clear({ source: "myApp" });
     */
    get vectors(): {
        /**
         * Get a vector by its unique ID.
         * @param uniqueId - The unique identifier of the vector.
         * @returns The matching vector, or null if there is no such vector.
         */
        get(uniqueId: string): MoorhenVector | null;
        /**
         * Get the vectors currently in the scene, in the order they were added.
         * @param tags - Optional filter; a vector must carry all the pairs given.
         * @returns The matching vectors, to be treated as read-only.
         */
        list(tags?: Tags): MoorhenVector[];
        /**
         * Create a vector and draw it.
         *
         * Every field is optional: what is left out takes its default, so
         * `create({ xTo: 10 })` is a complete request. Any `uniqueId` passed is ignored and
         * a fresh one minted, so two identical calls give two vectors rather than one.
         *
         * A field that does not exist on a vector is a compile error, whether it is written
         * at the call site or arrives in a variable.
         *
         * @param params - Fields to set, in place of their defaults.
         * @returns The unique ID of the new vector, which is its handle for {@link get},
         * {@link edit} and {@link delete}.
         */
        create<P extends Partial<Omit<MoorhenVector, "uniqueId">>>(params?: P & { [K in Exclude<keyof P, keyof MoorhenVector>]: never; }): string;
        /**
         * Edit an existing vector in place.
         *
         * A partial update: fields left out keep their current value. `uniqueId` cannot be
         * changed.
         *
         * @param uniqueId - Unique ID of the vector to edit.
         * @param params - The fields to change.
         * @returns True if the vector was found and updated, otherwise false.
         */
        edit(uniqueId: string, params: Partial<Omit<MoorhenVector, "uniqueId">>): boolean;
        /**
         * Delete a vector.
         * @param uniqueId - Unique ID of the vector to delete.
         * @returns True if the vector was found and deleted, otherwise false.
         */
        delete(uniqueId: string): boolean;
        /**
         * Delete vectors in bulk.
         * @param tags - Optional filter, as in {@link list}. Omit it to clear everything;
         * `{}` clears nothing rather than everything.
         * @returns The number of vectors removed.
         */
        clear(tags?: Tags): number;
        addVector(value: MoorhenVector): void;
        addVectors(value: MoorhenVector[]): void;
        emptyVectors(): void;
        removeVector(value: MoorhenVector): void;
        removeVectorById(value: string): void;
        removeVectors(value: MoorhenVector[]): void;
        removeVectorsByIds(value: string[]): void;
        removeVectorsByTag(value: Tags): void;
        removeVectorsMatchingIDString(value: string): void;
    };
    /**
     * Representation API for this instance.
     *
     * Lets you get, create, edit, delete and style the molecular representations
     * (cartoons, spheres, surfaces...) shown in the 3D view, plus configure the
     * default style applied to newly loaded molecules.
     */
    get representation(): {
        /**
         * Set the default representation style applied to molecules when they are
         * loaded. Accepts plain styles ("CAs", "CBs", "CRs") or picture-wizard style
         * names ("ribbons-and-ligands", "ribbons-and-side-chains", "site-and-ribbons").
         * @param style - The default style to apply.
         */
        defaultStyle: "CAs" | "CBs" | "CRs" | "ribbons-and-ligands" | "ribbons-and-side-chains" | "site-and-ribbons";
        /**
         * Get a representation by its unique ID, searching across all molecules.
         * @param uniqueID - The unique identifier of the representation.
         * @returns The matching representation, or undefined if not found.
         * @example
         * const rep = instance.representation.get("representation-abc");
         */
        get(uniqueID: string): MoleculeRepresentation | null;
        /**
         * Create a new representation on the given molecule via the public API and
         * (optionally) add it to the interface.
         *
         * `params.representationStyle` must be a public style; internal-only styles
         * (hover highlights, validation/analysis tools, etc.) are rejected with a
         * warning and a `null` return.
         *
         * @param moleculeUid - Unique ID of the molecule the representation is added to.
         * @param params - Creation options. `representationStyle` is the only required
         * field and must be a public style. All other fields are optional and are
         * described below.
         * @param params.representationStyle - The visual style of the representation.
         * Public styles are: VdwSpheres, ligands, CAs, CBs, CDs, gaussian, allHBonds,
         * CRs, MolecularSurface, DishyBases, VdWSurface, Calpha, unitCell,
         * ligand_environment, contact_dots, restraints, MetaBalls, StickBases,
         * residue_environment, NEFRestraints and RMSD. Internal-only styles (hover,
         * environment, residueSelection, transformation, rama, rotamer,
         * chemical_features, ligand_validation, glycoBlocks, adaptativeBonds) are
         * rejected.
         * @param params.ruleType - How the represented selection is built: "ligands",
         * "cid", "molecule", "chain", "residue-range" or "neighbourhood". When omitted
         * it is inferred from `cid`/`sequenceResidueRange`/`chainName` (default "molecule").
         * @param params.chainName - Chain identifier (e.g. "A") used by the "chain" and
         * "residue-range" selection types.
         * @param params.sequenceResidueRange - A `[start, end]` residue-number range used
         * by the "residue-range" selection type (e.g. `[12, 45]`).
         * @param params.cid - A full selection CID (e.g. "//A/12-20/*:*") used directly by
         * the "cid" selection type.
         * @param params.notHOH - Exclude water molecules from the selection (default false).
         * @param params.notH - Exclude hydrogen atoms from the selection (default false).
         * @param params.sideChainOnly - Only represent side-chain atoms (default false).
         * @param params.restrictToNeighbours - Only represent atoms lying within
         * `neighboursDistance` of the (optional) `neighboursCid` selection (default false).
         * @param params.excludeNeighbours - Invert `restrictToNeighbours` so the
         * neighbourhood is excluded instead of restricted to (default false).
         * @param params.neighboursCid - Additional CID defining the centre of the
         * neighbourhood selection.
         * @param params.neighboursDistance - Radius (in Angstrom) around the neighbourhood
         * selection (default 6.0).
         * @param params.useDefaultColours - Use the molecule's default colour scheme
         * (default true when no explicit `colour` is given).
         * @param params.colourMode - Colour mode: "custom" for a single colour, or a
         * multi-colour mode such as "b-factor", "secondary-structure" or "mol-symm".
         * @param params.colour - Hex colour (e.g. "#FF8800") used when `colourMode` is
         * "custom". Providing a colour disables `useDefaultColours`.
         * @param params.applyColourToNonCarbonAtoms - Whether the colour also applies to
         * non-carbon atoms (default false).
         * @param params.ncsColourRule - Colour rule used by the "mol-symm" colour mode.
         * @param params.isCustom - Mark the representation as custom (user-created);
         * internal representations set this to false.
         * @param params.bondOptions - Overrides for bond rendering (thickness, colour...).
         * @param params.m2tParams - Overrides for mesh-to-triangle rendering.
         * @param params.residueEnvironmentOptions - Options for residue-environment
         * (neighbourhood) rendering.
         * @param params.nonCustomOpacity - Opacity applied when a non-custom (multi-colour)
         * mode is in use.
         * @param params.hbondedTo - Only represent atoms hydrogen-bonded to the
         * `neighboursCid` selection (default false).
         * @param hideFromInterface - If true the representation is created and drawn but
         * not added to the interface (molecule card) list.
         * @returns The unique ID of the new representation, or null if creation failed.
         * @example
         * const repUid = await instance.representation.create(molecule.uniqueId, {
         *     representationStyle: "CAs",
         *     colourMode: "b-factor"
         * });
         */
        create(moleculeUid: string, params: Omit<CreateRepresentationParams, "molecule" | "representationStyle" | "existingRepresentation"> & {
            representationStyle: PublicRepresentationStyles;
        }, hideFromInterface?: boolean): Promise<string | null>;
        /**
         * Delete an existing representation via the public API.
         *
         * The representation is removed from its parent molecule and from the
         * interface (molecule card) list, and redrawn away.
         *
         * @param representationUid - Unique ID of the representation to delete.
         * @returns True if the representation was found and deleted, otherwise false.
         * @example
         * const deleted = await instance.representation.delete(repUid);
         */
        delete(representationUid: string): Promise<boolean>;
        /**
         * Edit an existing representation in place via the public API.
         *
         * The representation is looked up by its unique ID and updated in place
         * (no new representation is created). `representationStyle` is the only
         * required field; any other field that is omitted keeps the representation's
         * current value, so partial updates are supported. Internal-only styles
         * (hover, validation/analysis tools, etc.) are rejected with a warning.
         *
         * @param representationUid - Unique ID of the representation to edit.
         * @param params - The fields to change. `representationStyle` is required; all
         * other fields are optional and keep the representation's existing value when omitted.
         * @param params.representationStyle - The new visual style. Must be one of the
         * public styles (VdwSpheres, ligands, CAs, CBs, CDs, gaussian, allHBonds, CRs,
         * MolecularSurface, DishyBases, VdWSurface, Calpha, unitCell, ligand_environment,
         * contact_dots, restraints, MetaBalls, StickBases, residue_environment,
         * NEFRestraints, RMSD). Internal-only styles (hover, environment,
         * residueSelection, transformation, rama, rotamer, chemical_features,
         * ligand_validation, glycoBlocks, adaptativeBonds) are rejected.
         * @param params.ruleType - How the represented selection is built: "ligands",
         * "cid", "molecule", "chain", "residue-range" or "neighbourhood".
         * @param params.chainName - Chain identifier used by the "chain"/"residue-range"
         * selection types.
         * @param params.sequenceResidueRange - A `[start, end]` residue-number range used
         * by the "residue-range" selection type.
         * @param params.cid - A full selection CID used directly by the "cid" selection type.
         * @param params.notHOH - Exclude water molecules from the selection.
         * @param params.notH - Exclude hydrogen atoms from the selection.
         * @param params.sideChainOnly - Only represent side-chain atoms.
         * @param params.restrictToNeighbours - Only represent atoms within
         * `neighboursDistance` of the `neighboursCid` selection.
         * @param params.excludeNeighbours - Invert `restrictToNeighbours` to exclude the
         * neighbourhood instead of restricting to it.
         * @param params.neighboursCid - Additional CID defining the neighbourhood centre.
         * @param params.neighboursDistance - Radius (in Angstrom) of the neighbourhood.
         * @param params.useDefaultColours - Use the molecule's default colour scheme.
         * @param params.colourMode - Colour mode: "custom" or a multi-colour mode
         * (e.g. "b-factor", "secondary-structure", "mol-symm").
         * @param params.colour - Hex colour (e.g. "#FF8800") used when `colourMode` is "custom".
         * @param params.applyColourToNonCarbonAtoms - Whether the colour also applies to
         * non-carbon atoms.
         * @param params.ncsColourRule - Colour rule used by the "mol-symm" colour mode.
         * @param params.isCustom - Whether the representation is marked as custom.
         * @param params.bondOptions - Overrides for bond rendering (thickness, colour...).
         * @param params.m2tParams - Overrides for mesh-to-triangle rendering.
         * @param params.residueEnvironmentOptions - Options for residue-environment
         * (neighbourhood) rendering.
         * @param params.nonCustomOpacity - Opacity used with non-custom colour modes.
         * @param params.hbondedTo - Only represent atoms hydrogen-bonded to the
         * `neighboursCid` selection.
         * @returns The unique ID of the updated representation, or null if the style was
         * rejected or the representation was not found.
         * @example
         * await instance.representation.edit(repUid, { colourMode: "secondary-structure" });
         */
        edit(representationUid: string, params: Omit<CreateRepresentationParams, "molecule" | "representationStyle" | "existingRepresentation"> & {
            representationStyle: PublicRepresentationStyles;
        }): Promise<any>;
        /**
         * Run the picture wizard on the given molecule via the public API.
         *
         * Optionally deletes the molecule's existing representations first, then
         * creates the set of representations implied by the wizard type. The created
         * representations are added to the interface.
         *
         * @param molecule - The target molecule unique ID, or a {@link MoorhenMolecule}
         * object. Passing the object avoids a store lookup, which is needed when the
         * molecule has not yet been added to the store.
         * @param wizardType - The wizard type to run: "site-and-ribbons" (binding site
         * and ribbons), "ribbons-and-ligands" (ribbons and ligands),
         * "ribbons-and-side-chains" (ribbons and side chains), "catrace" (CA trace and
         * ligands), or "bonds" (bonds).
         * @param deleteExisting - If true, delete existing representations before creating
         * new ones (defaults to true).
         * @returns The unique IDs of the created representations.
         * @example
         * const createdUids = await instance.representation.wizard("mol-1", "ribbons-and-ligands");
         */
        wizard(molecule: string | MoorhenMolecule, wizardType: PictureWizardType, deleteExisting?: boolean): Promise<string[]>;
    };
    /**
     * Get the {@link MoorhenMap} whose unique ID matches `uid`.
     * @param uid - The unique ID of the map to look up.
     * @returns The matching map, or undefined if no loaded map has that ID.
     */
    getMap(uid: string): MoorhenMap;
    /**
     * Center the view on the given world-space coordinate.
     *
     * The scene's `origin` holds the negative of the point being looked at - translating the
     * world by it is what brings that point to the middle of the screen - so a coordinate to
     * centre on has to be negated on the way in. Without that this centred on minus the point
     * it was given, which is to say on the wrong side of the origin by twice the distance.
     *
     * @param x - X coordinate to centre on.
     * @param y - Y coordinate to centre on.
     * @param z - Z coordinate to centre on.
     */
    centerOnCoordinate(x: number, y: number, z: number): void;
    /**
     * Center the view on a given residue.
     *
     * If no `moleculeUID` is given the first loaded molecule is used (only
     * meaningful when a single molecule is loaded).
     *
     * @param chain - Chain identifier of the residue (e.g. "A").
     * @param residueNumber - Number of the residue to centre on.
     * @param moleculeUID - Optional unique ID of the molecule containing the residue.
     */
    centerOnResidue(chain: string, residueNumber: number, moleculeUID?: string): void;
    /**
     * Center the view on a given atom.
     *
     * If no `moleculeUID` is given the first loaded molecule is used (only
     * meaningful when a single molecule is loaded).
     *
     * @param chain - Chain identifier of the atom (e.g. "A").
     * @param residueNumber - Number of the residue containing the atom.
     * @param atomName - Name of the atom (e.g. "CA").
     * @param moleculeUID - Optional unique ID of the molecule containing the atom.
     */
    centerOnAtom(chain: string, residueNumber: number, atomName: string, moleculeUID?: string): void;
    /**
     * Register a callback that fires whenever a new atom is hovered in the 3D view.
     *
     * The callback only fires once the hovered-atom store state carries a real atom
     * (i.e. a molecule and atom info are available).
     *
     * @param callback - Function invoked with the unique ID of the hovered atom's
     * molecule, the residue number and the atom name.
     * @returns A function that unsubscribes the callback.
     * @example
     * const unsubscribe = instance.newAtomHoveredCallback((moleculeID, residueNumber, atomName) => {
     *     console.log(`Hovered atom: ${atomName} in residue ${residueNumber} of molecule ${moleculeID}`);
     * });
     */
    newAtomHoveredCallback(callback: (moleculeID: string, residueNumber: string, atomName: string) => void): () => void;
    private _moleculeChangedCallbacks;
    /**
     * Register a callback that fires whenever a molecule changes (new, added,
     * deleted, modified or refined).
     *
     * If `moleculeUID` is provided the callback only runs for that molecule;
     * otherwise it runs for any molecule change.
     *
     * @param callback - Function invoked with the unique ID of the changed molecule,
     * the change `action` ("new", "add", "delete", "modify" or "refine") and, when
     * relevant, the CID of the modified region.
     * @param moleculeUID - Optional unique ID restricting the callback to a single molecule.
     * @returns A function that unsubscribes the callback.
     * @example
     * const unsubscribe = instance.newMoleculeChangedCallback((uid, action, cid) => {
     *     console.log(`Molecule ${uid} changed (${action})`);
     * });
     */
    newMoleculeChangedCallback(callback: (moleculeUID: string, action?: moleculeChangeAction, cid?: string) => void, moleculeUID?: string): () => void;
    /**
     * Notify all registered molecule-change callbacks that a molecule changed.
     *
     * `UIDorMolNo` can be either a molecule unique ID or a molecule number. When a
     * number is provided it is resolved to the current molecule unique ID before
     * invoking the matching callbacks.
     *
     * @param UIDorMolNo - The unique ID (string) or molecule number (number) of the
     * molecule that changed.
     * @param action - Optional change action ("new", "add", "delete", "modify", "refine").
     * @param cid - Optional CID of the region that changed.
     */
    triggerMoleculeChanged(UIDorMolNo: string | number, action?: moleculeChangeAction, cid?: string): void;
    /**
     * Set the width of the web component hosting the application. Accepts a CSS
     * size string, a number of pixels or null. Forwarded to the attached web
     * component, triggering a re-render of the React tree.
     *
     * @param value - The new width.
     */
    set width(value: number | string | null);
    /**
     * Set the height of the web component hosting the application. Accepts a CSS
     * size string, a number of pixels or null. Forwarded to the attached web
     * component, triggering a re-render of the React tree.
     *
     * @param value - The new height.
     */
    set height(value: number | string | null);
    /**
     * Set the URL prefix used to locate Moorhen assets. Forwarded to the attached
     * web component.
     *
     * @param value - The new URL prefix.
     */
    set urlPrefix(value: string);
    /**
     * Enable/disable the file-upload controls of the web component. Forwarded to
     * the attached web component.
     * @param value - True to disable file uploads.
     */
    set disableFileUploads(value: boolean);
    /**
     * Put the web component into read-only (view-only) mode. Forwarded to the
     * attached web component.
     *
     * @param value - True to enable view-only mode.
     */
    set viewOnly(value: boolean);
    /**
     * Attach the web component that hosts the application UI.
     *
     * **Internal use only.** Set by the application wiring when the component mounts.
     * @private
     * @param webComponent - The web component to attach.
     */
    set webComponent(webComponent: MoorhenWebComponent);
    /**
     * Create (or reuse) a local storage instance used to persist data such as
     * time-capsule backups and preferences.
     *
     * **Internal use only.** Low-level helper used to back the time capsule.
     * @private
     * @param name - Name of the storage instance; also used as the store name.
     * @param empty - If true, clear any existing data in the instance first.
     * @returns A localforage instance ready for read/write access.
     */
    static createLocalStorageInstance: (name: string, empty?: boolean) => LocalForage;
    /**
     * Initialise the instance and mark it ready.
     *
     * **Internal use only.** The application shell calls this once after constructing
     * the instance; consumers of a running instance should not call it.
     *
     * Wires up the Redux store/dispatch and the molecule/map refs, then initialises
     * the session {@link MoorhenTimeCapsule} (backed by a local-storage instance that
     * can be overridden via `timeCapsuleConfig`) and the {@link CommandCentre} if one
     * was not already provided. Finally it flags the instance as ready and flushes
     * all callbacks that were registered with `execWhenReady`.
     *
     * @private
     * @param dispatch - Redux dispatch function used to update the store.
     * @param moleculesRef - React ref that will hold the list of loaded molecules.
     * @param mapsRef - React ref that will hold the list of loaded maps.
     * @param store - The Redux store driving the instance.
     * @param externalCommandCentreRef - Optional ref that is populated with the created
     * {@link CommandCentre}, so the caller can access it externally.
     * @param externalTimeCapsuleRef - Optional ref that is populated with the created
     * {@link MoorhenTimeCapsule}.
     * @param timeCapsuleConfig - Optional configuration for the session time capsule.
     * @param timeCapsuleConfig.providedBackupStorageInstance - A localforage instance to
     * use for backups; if omitted a default "Moorhen-TimeCapsule" instance is created.
     * @param timeCapsuleConfig.maxBackupCount - Maximum number of backups to keep.
     * @param timeCapsuleConfig.modificationCountBackupThreshold - Number of molecule
     * modifications that trigger a new backup.
     */
    startInstance(dispatch: Dispatch<UnknownAction>, moleculesRef: React.RefObject<moorhen.Molecule[]>, mapsRef: React.RefObject<moorhen.Map[]>, store: Store, externalCommandCentreRef?: React.RefObject<CommandCentre | null>, externalTimeCapsuleRef?: React.RefObject<MoorhenTimeCapsule | null>, timeCapsuleConfig?: {
        providedBackupStorageInstance?: LocalForage | null;
        maxBackupCount: number;
        modificationCountBackupThreshold: number;
    }): Promise<void>;
    /**
     * Tear the instance down: unsubscribe from preferences and close the command
     * centre, clearing the attached time capsule and video recorder.
     *
     * **Internal use only.** Called by the application shell when the instance is no
     * longer needed (e.g. on unmount).
     * @private
     */
    cleanup(): void;
}
//# sourceMappingURL=MoorhenInstance.d.ts.map