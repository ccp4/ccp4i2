import React, { ReactNode } from "react";
import type { MoorhenMenuSystem } from "../components/menu-system/MenuSystem";
import { MoorhenInstance } from ".";
interface MoorhenInstanceContextType {
    instance: MoorhenInstance;
}
declare const MoorhenInstanceContext: React.Context<MoorhenInstanceContextType>;
export interface MoorhenInstanceProviderProps {
    children: ReactNode;
    menuSystem: MoorhenMenuSystem;
}
export declare const MoorhenInstanceProvider: (props: MoorhenInstanceProviderProps) => import("react/jsx-runtime").JSX.Element;
export { MoorhenInstanceContext };
//# sourceMappingURL=MoorhenInstanceContext.d.ts.map