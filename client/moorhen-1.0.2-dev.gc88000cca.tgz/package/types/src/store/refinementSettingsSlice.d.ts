export declare const setAnimateRefine: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "refinementSettings/setAnimateRefine">, setEnableRefineAfterMod: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "refinementSettings/setEnableRefineAfterMod">, setUseRamaRefinementRestraints: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "refinementSettings/setUseRamaRefinementRestraints">, setuseTorsionRefinementRestraints: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "refinementSettings/setuseTorsionRefinementRestraints">, setRefinementSelection: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<"SINGLE" | "TRIPLE" | "SPHERE", "refinementSettings/setRefinementSelection">, resetRefinementSettings: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"refinementSettings/resetRefinementSettings">;
declare const _default: import("redux").Reducer<{
    useRamaRefinementRestraints: boolean;
    useTorsionRefinementRestraints: boolean;
    enableRefineAfterMod: boolean;
    animateRefine: boolean;
    refinementSelection: "SINGLE" | "TRIPLE" | "SPHERE";
}>;
export default _default;
//# sourceMappingURL=refinementSettingsSlice.d.ts.map