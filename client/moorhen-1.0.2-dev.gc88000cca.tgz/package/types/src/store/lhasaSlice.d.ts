export declare const resetLhasaSettings: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"lhasa/resetLhasaSettings">, addRdkitMoleculePickle: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    cid: string;
    moleculeMolNo: number;
    ligandName: string;
    pickle: string;
    id: string;
}, "lhasa/addRdkitMoleculePickle">, removeRdkitMoleculePickle: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "lhasa/removeRdkitMoleculePickle">, emptyRdkitMoleculePickleList: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"lhasa/emptyRdkitMoleculePickleList">;
declare const _default: import("redux").Reducer<{
    rdkitMoleculePickleList: {
        cid: string;
        moleculeMolNo: number;
        ligandName: string;
        pickle: string;
        id: string;
    }[];
}>;
export default _default;
//# sourceMappingURL=lhasaSlice.d.ts.map