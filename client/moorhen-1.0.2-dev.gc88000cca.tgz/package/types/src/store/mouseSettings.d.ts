export declare const setContourWheelSensitivityFactor: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "mouseSettings/setContourWheelSensitivityFactor">, setZoomWheelSensitivityFactor: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "mouseSettings/setZoomWheelSensitivityFactor">, setMouseSensitivity: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "mouseSettings/setMouseSensitivity">, resetDefaultMouseSettings: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"mouseSettings/resetDefaultMouseSettings">;
declare const _default: import("redux").Reducer<{
    contourWheelSensitivityFactor: number;
    zoomWheelSensitivityFactor: number;
    mouseSensitivity: number;
}>;
export default _default;
//# sourceMappingURL=mouseSettings.d.ts.map