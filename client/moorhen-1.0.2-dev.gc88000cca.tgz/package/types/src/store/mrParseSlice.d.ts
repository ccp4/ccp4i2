import { MoorhenMolecule } from "../utils/MoorhenMolecule";
export declare const setMrParseModels: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMolecule[], "mrParse/setMrParseModels">, setTargetSequence: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "mrParse/setTargetSequence">, setAfJson: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<any[], "mrParse/setAfJson">, setEsmJson: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<any[], "mrParse/setEsmJson">, setHomologsJson: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<any[], "mrParse/setHomologsJson">, setAfSortField: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "mrParse/setAfSortField">, setHomologsSortField: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "mrParse/setHomologsSortField">, setAfSortReversed: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "mrParse/setAfSortReversed">, setHomologsSortReversed: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "mrParse/setHomologsSortReversed">, setAFDisplaySettings: import("@reduxjs/toolkit").ActionCreatorWithPayload<any, "mrParse/setAFDisplaySettings">, setHomologsDisplaySettings: import("@reduxjs/toolkit").ActionCreatorWithPayload<any, "mrParse/setHomologsDisplaySettings">;
declare const _default: import("redux").Reducer<{
    mrParseModels: MoorhenMolecule[];
    targetSequence: string;
    afJson: any[];
    esmJson: any[];
    homologsJson: any[];
    afSortField: string;
    homologsSortField: string;
    afSortReversed: boolean;
    homologsSortReversed: boolean;
    AFDisplaySettings: any;
    HomologsDisplaySettings: any;
}>;
export default _default;
//# sourceMappingURL=mrParseSlice.d.ts.map