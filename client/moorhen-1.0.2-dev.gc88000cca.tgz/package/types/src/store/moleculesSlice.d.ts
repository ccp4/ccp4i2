import { moorhen } from "../types/moorhen";
import { MoorhenMolecule } from "../utils";
export declare const addMolecule: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMolecule, "molecules/addMolecule">, removeMolecule: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMolecule, "molecules/removeMolecule">, emptyMolecules: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"molecules/emptyMolecules">, addMoleculeList: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMolecule[], "molecules/addMoleculeList">, addGeneralRepresentation: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<import("../utils").MoleculeRepresentation, "molecules/addGeneralRepresentation">, showMolecule: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMolecule, "molecules/showMolecule">, hideMolecule: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMolecule, "molecules/hideMolecule">, addCustomRepresentation: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<import("../utils").MoleculeRepresentation, "molecules/addCustomRepresentation">, removeCustomRepresentation: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<import("../utils").MoleculeRepresentation, "molecules/removeCustomRepresentation">, removeGeneralRepresentation: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<import("../utils").MoleculeRepresentation, "molecules/removeGeneralRepresentation">;
declare const _default: import("redux").Reducer<{
    visibleMolecules: number[];
    moleculeList: MoorhenMolecule[];
    customRepresentations: moorhen.MoleculeRepresentation[];
    generalRepresentations: moorhen.MoleculeRepresentation[];
}>;
export default _default;
//# sourceMappingURL=moleculesSlice.d.ts.map