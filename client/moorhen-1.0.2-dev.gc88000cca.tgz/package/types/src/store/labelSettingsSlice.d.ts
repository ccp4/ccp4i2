export declare const emptyAvailableFonts: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"labelSettings/emptyAvailableFonts">, addAvailableFontList: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string[], "labelSettings/addAvailableFontList">, setAtomLabelDepthMode: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "labelSettings/setAtomLabelDepthMode">, setGLLabelsFontFamily: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "labelSettings/setGLLabelsFontFamily">, setGLLabelsFontSize: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "labelSettings/setGLLabelsFontSize">, resetLabelSettings: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"labelSettings/resetLabelSettings">;
declare const _default: import("redux").Reducer<{
    atomLabelDepthMode: boolean;
    GLLabelsFontFamily: string;
    GLLabelsFontSize: number;
    availableFonts: string[];
}>;
export default _default;
//# sourceMappingURL=labelSettingsSlice.d.ts.map