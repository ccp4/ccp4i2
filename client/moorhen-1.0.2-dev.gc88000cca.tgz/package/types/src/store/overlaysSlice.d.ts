export interface Overlay2DFracPath {
    type: "FracPath";
    path: number[];
    fillStyle?: string;
    strokeStyle?: string;
    drawStyle?: string;
    gradientBoundary?: [number, number, number, number];
    gradientStops?: {
        stop: number;
        colour: string;
    }[];
    lineWidth?: number;
    uniqueId: string;
    zIndex?: number;
}
export interface Overlay2DSvgPath {
    type: "SvgPath";
    path: string;
    fillStyle?: string;
    strokeStyle?: string;
    drawStyle?: string;
    gradientBoundary?: [number, number, number, number];
    gradientStops?: {
        stop: number;
        colour: string;
    }[];
    lineWidth?: number;
    uniqueId: string;
    zIndex?: number;
}
export interface Overlay2DTextFrac {
    type: "Text";
    x: number;
    y: number;
    text: string;
    fontFamily: string;
    fontPixelSize: number;
    fillStyle?: string;
    strokeStyle?: string;
    drawStyle?: string;
    lineWidth?: number;
    uniqueId: string;
    zIndex?: number;
}
export interface Overlay2DImageSrcFrac {
    type: "Image";
    x: number;
    y: number;
    width: number;
    height: number;
    src: string;
    uniqueId: string;
    zIndex?: number;
}
export interface Overlay2DLatexSrcFrac {
    type: "Latex";
    x: number;
    y: number;
    height: number;
    text: string;
    uniqueId: string;
    zIndex?: number;
}
export declare const addImageOverlay: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<Omit<Overlay2DImageSrcFrac, "type">, "overlays/addImageOverlay">, addTextOverlay: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<Omit<Overlay2DTextFrac, "type">, "overlays/addTextOverlay">, addSvgPathOverlay: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<Omit<Overlay2DSvgPath, "type">, "overlays/addSvgPathOverlay">, addFracPathOverlay: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<Omit<Overlay2DFracPath, "type">, "overlays/addFracPathOverlay">, emptyOverlays: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"overlays/emptyOverlays">, addCallback: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<Function, "overlays/addCallback">, addLatexOverlay: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<Omit<Overlay2DLatexSrcFrac, "type">, "overlays/addLatexOverlay">, removeImageOverlay: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<Overlay2DImageSrcFrac, "overlays/removeImageOverlay">, removeLatexOverlay: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<Overlay2DLatexSrcFrac, "overlays/removeLatexOverlay">, removeTextOverlay: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<Overlay2DTextFrac, "overlays/removeTextOverlay">, removeSvgPathOverlay: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<Overlay2DSvgPath, "overlays/removeSvgPathOverlay">, removeFracPathOverlay: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<Overlay2DFracPath, "overlays/removeFracPathOverlay">;
declare const _default: import("redux").Reducer<{
    imageOverlayList: Overlay2DImageSrcFrac[];
    latexOverlayList: Overlay2DLatexSrcFrac[];
    textOverlayList: Overlay2DTextFrac[];
    svgPathOverlayList: Overlay2DSvgPath[];
    fracPathOverlayList: Overlay2DFracPath[];
    callBacks: Function[];
}>;
export default _default;
//# sourceMappingURL=overlaysSlice.d.ts.map