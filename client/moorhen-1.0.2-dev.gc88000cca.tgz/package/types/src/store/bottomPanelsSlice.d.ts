import { SequenceViewerOption } from "../components/panels/BottomPanels/SequenceViewerPanel/SequenceViewerPanel";
import { ValidationOption } from "../components/panels/BottomPanels/SequenceViewerPanel/ValidationPanel";
import { BottomPanelIDs } from "../components/panels";
export declare const setSeqViewerOption: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<SequenceViewerOption, "bottomPanels/setSeqViewerOption">, setValidationOption: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<ValidationOption, "bottomPanels/setValidationOption">, setShownBottomPanel: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<BottomPanelIDs, "bottomPanels/setShownBottomPanel">;
declare const _default: import("redux").Reducer<{
    shownBottomPanel: BottomPanelIDs;
    seqviewerOption: SequenceViewerOption;
    validationOption: ValidationOption;
}>;
export default _default;
//# sourceMappingURL=bottomPanelsSlice.d.ts.map