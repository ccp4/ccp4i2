import type { AppDispatch } from "./MoorhenReduxStore";
/**
 * Custom hook to retrieve a menu setting from the Redux store.
 * @param menu - The name of the menu.
 * @param key - The key for the specific setting.
 * @param defaultValue - The default value if the setting is not found in the Redux store.
 * @returns The value of the setting from the Redux store or the default value.
 */
export declare const usePersistent: <T>(menu: string, key: string, defaultValue: T) => T;
/**
 * Custom hook to manage menu state and store it to Redux.
 * @param menu - The name of the menu.
 * @param key - The key for the specific setting.
 * @param defaultValue - The default value if the setting is not found in the Redux store.
 * @param autoUpdate - If true, the Redux store will be updated automatically when the value changes.
 * @returns A tuple containing the current value and a function to update it.
 */
export declare const usePersistentState: <T>(menu: string, key: string, defaultValue: T, autoUpdate?: boolean) => readonly [T, (newValue: T) => void];
/**
 * Utility function to batch dispatch multiple menu settings.
 * Groups multiple `setMenuSetting` actions into a single render update.
 * @param dispatch - The Redux dispatch function.
 * @param menu - The name of the menu.
 * @param data - An array of key-value pairs to be stored.
 */
export declare const dispatchPersistentStates: (dispatch: AppDispatch, menu: string, data: {
    key: string;
    value: unknown;
}[]) => void;
export declare const setMenuSetting: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    menu: string;
    key: string;
    value: unknown;
}, "menus/setMenuSetting">, resetMenuSetting: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    menu: string;
    key: string;
}, "menus/resetMenuSetting">, resetMenu: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    menu: string;
}, "menus/resetMenu">;
declare const _default: import("redux").Reducer<{
    settings: Record<string, Record<string, unknown>>;
}>;
export default _default;
//# sourceMappingURL=menusSlice.d.ts.map