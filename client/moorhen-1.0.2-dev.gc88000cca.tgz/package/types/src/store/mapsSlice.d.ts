import type { MoorhenMap } from "../utils/MoorhenMap";
export declare const addMap: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMap, "maps/addMap">, removeMap: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMap, "maps/removeMap">, emptyMaps: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"maps/emptyMaps">, addMapList: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMap[], "maps/addMapList">;
declare const _default: import("redux").Reducer<MoorhenMap[]>;
export default _default;
//# sourceMappingURL=mapsSlice.d.ts.map