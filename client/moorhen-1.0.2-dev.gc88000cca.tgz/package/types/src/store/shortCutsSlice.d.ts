export declare const setShowShortcutToast: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "shortcutSettings/setShowShortcutToast">, setShortcutOnHoveredAtom: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "shortcutSettings/setShortcutOnHoveredAtom">, setShortCuts: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "shortcutSettings/setShortCuts">, resetShortcutSettings: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"shortcutSettings/resetShortcutSettings">;
declare const _default: import("redux").Reducer<{
    shortcutOnHoveredAtom: boolean;
    showShortcutToast: boolean;
    shortCuts: string;
}>;
export default _default;
//# sourceMappingURL=shortCutsSlice.d.ts.map