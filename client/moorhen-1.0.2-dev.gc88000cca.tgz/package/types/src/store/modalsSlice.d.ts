import { ModalComponentProps, ModalKey } from "../components/interface-base/ModalBase/ModalsContainer";
export type ModalCall = {
    key: ModalKey;
} & ModalComponentProps;
export declare const showModal: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<ModalCall, "modals/showModal">, hideModal: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<ModalKey, "modals/hideModal">, focusOnModal: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<ModalKey, "modals/focusOnModal">, unFocusModal: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "modals/unFocusModal">, resetActiveModals: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"modals/resetActiveModals">;
declare const _default: import("redux").Reducer<{
    activeModals: ModalCall[];
    focusHierarchy: ModalKey[];
}>;
export default _default;
//# sourceMappingURL=modalsSlice.d.ts.map