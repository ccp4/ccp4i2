import { MoorhenMolecule } from "../utils";
import { DisplayBuffer } from "../WebGLgComponents/displayBuffer";
export declare const setRequestDrawScene: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "glRef/setRequestDrawScene">, setIsWebGL2: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "glRef/setIsWebGL2">, setActiveMolecule: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMolecule, "glRef/setActiveMolecule">, setQuat: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<any[], "glRef/setQuat">, setCursorPosition: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<[number, number], "glRef/setCursorPosition">, setShortCutHelp: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string[], "glRef/setShortCutHelp">, setDraggableMolecule: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMolecule, "glRef/setDraggableMolecule">, triggerRedrawEnv: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "glRef/triggerRedrawEnv">, triggerClearLabels: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "glRef/triggerClearLabels">, setGLCtx: import("@reduxjs/toolkit").ActionCreatorWithPayload<any, "glRef/setGLCtx">, setDisplayBuffers: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<DisplayBuffer[], "glRef/setDisplayBuffers">, setHoverSize: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "glRef/setHoverSize">, setLabelBuffers: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<any[], "glRef/setLabelBuffers">, setTexturedShapes: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<any[], "glRef/setTexturedShapes">, setRttFramebufferSize: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<[number, number], "glRef/setRttFramebufferSize">, setCanvasSize: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<[number, number], "glRef/setCanvasSize">, setElementsIndicesRestrict: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "glRef/setElementsIndicesRestrict">;
declare const _default: import("redux").Reducer<{
    isWebGL2: boolean;
    glCtx: any;
    displayBuffers: DisplayBuffer[];
    activeMolecule: MoorhenMolecule;
    draggableMolecule: MoorhenMolecule;
    quat: any[];
    cursorPosition: [number, number];
    shortCutHelp: string[];
    requestDrawScene: {
        switch: boolean;
    };
    envUpdate: {
        switch: boolean;
    };
    clearLabels: {
        switch: boolean;
    };
    hoverSize: number;
    labelBuffers: any[];
    texturedShapes: any[];
    canvasSize: [number, number];
    rttFramebufferSize: [number, number];
    elementsIndicesRestrict: boolean;
}>;
export default _default;
//# sourceMappingURL=glRefSlice.d.ts.map