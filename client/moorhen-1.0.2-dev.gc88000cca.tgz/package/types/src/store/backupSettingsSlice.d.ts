export declare const setEnableTimeCapsule: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "backupSettings/setEnableTimeCapsule">, setMakeBackups: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "backupSettings/setMakeBackups">, setMaxBackupCount: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "backupSettings/setMaxBackupCount">, setModificationCountBackupThreshold: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "backupSettings/setModificationCountBackupThreshold">, resetBackupSettings: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"backupSettings/resetBackupSettings">;
declare const _default: import("redux").Reducer<{
    enableTimeCapsule: boolean;
    makeBackups: boolean;
    maxBackupCount: number;
    modificationCountBackupThreshold: number;
}>;
export default _default;
//# sourceMappingURL=backupSettingsSlice.d.ts.map