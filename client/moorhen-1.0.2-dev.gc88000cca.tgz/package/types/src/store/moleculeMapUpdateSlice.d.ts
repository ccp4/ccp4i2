export declare const setConnectedMolecule: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<import("../utils").MoorhenMolecule, "moleculeMapUpdateSlice/setConnectedMolecule">, enableUpdatingMaps: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"moleculeMapUpdateSlice/enableUpdatingMaps">, disableUpdatingMaps: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"moleculeMapUpdateSlice/disableUpdatingMaps">, setReflectionMap: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<import("../utils").MoorhenMap, "moleculeMapUpdateSlice/setReflectionMap">, setFoFcMap: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<import("../utils").MoorhenMap, "moleculeMapUpdateSlice/setFoFcMap">, setTwoFoFcMap: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<import("../utils").MoorhenMap, "moleculeMapUpdateSlice/setTwoFoFcMap">, setReflectionMapMolNo: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "moleculeMapUpdateSlice/setReflectionMapMolNo">, overwriteMapUpdatingScores: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string[], "moleculeMapUpdateSlice/overwriteMapUpdatingScores">, setCurrentScores: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    rFactor: number;
    rFree: number;
    moorhenPoints: number;
}, "moleculeMapUpdateSlice/setCurrentScores">, setConnectedMoleculeMolNo: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "moleculeMapUpdateSlice/setConnectedMoleculeMolNo">, setFoFcMapMolNo: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "moleculeMapUpdateSlice/setFoFcMapMolNo">, setTwoFoFcMapMolNo: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "moleculeMapUpdateSlice/setTwoFoFcMapMolNo">, removeMapUpdatingScore: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "moleculeMapUpdateSlice/removeMapUpdatingScore">, setShowScoresToast: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "moleculeMapUpdateSlice/setShowScoresToast">, addMapUpdatingScore: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "moleculeMapUpdateSlice/addMapUpdatingScore">, triggerUpdate: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "moleculeMapUpdateSlice/triggerUpdate">, resetMoleculeMapUpdates: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"moleculeMapUpdateSlice/resetMoleculeMapUpdates">;
declare const _default: import("redux").Reducer<{
    updatingMapsIsEnabled: boolean;
    connectedMolecule: number;
    reflectionMap: number;
    twoFoFcMap: number;
    foFcMap: number;
    uniqueMaps: number[];
    defaultUpdatingScores: string[];
    showScoresToast: boolean;
    moleculeUpdate: {
        switch: boolean;
        molNo: number;
    };
    currentScores: {
        rFactor: number;
        rFree: number;
        moorhenPoints: number;
    };
    currentScoreDiffs: {
        rFactor: number;
        rFree: number;
        moorhenPoints: number;
    };
}>;
export default _default;
//# sourceMappingURL=moleculeMapUpdateSlice.d.ts.map