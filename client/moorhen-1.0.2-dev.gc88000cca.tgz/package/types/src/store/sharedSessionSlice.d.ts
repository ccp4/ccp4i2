export declare const setIsInSharedSession: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sharedSession/setIsInSharedSession">, setSharedSessionToken: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "sharedSession/setSharedSessionToken">, setShowSharedSessionManager: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sharedSession/setShowSharedSessionManager">, resetSharedSession: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"sharedSession/resetSharedSession">;
declare const _default: import("redux").Reducer<{
    isInSharedSession: boolean;
    sharedSessionToken: string;
    showSharedSessionManager: boolean;
}>;
export default _default;
//# sourceMappingURL=sharedSessionSlice.d.ts.map