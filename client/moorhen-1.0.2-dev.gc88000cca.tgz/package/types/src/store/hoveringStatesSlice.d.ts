import { moorhen } from "@/types/moorhen";
import { MoorhenMolecule } from "../utils/MoorhenMolecule";
export type HoveredAtom = {
    molecule: MoorhenMolecule | null;
    cid: string | null;
    atomInfo: moorhen.AtomInfo | null;
};
/**
 * A piece of a mesh to light up, named by the buffer it belongs to and its index within that
 * buffer's sections.
 *
 * Already resolved to indices rather than left as a label to match: the match is done once when
 * the hover changes, not per buffer per frame in the draw loop.
 */
export type HoveredSection = {
    bufferId: string;
    section: number;
};
export declare const setCursorStyle: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "hoveringStates/setCursorStyle">, setEnableAtomHovering: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "hoveringStates/setEnableAtomHovering">, setHoveredAtom: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<HoveredAtom, "hoveringStates/setHoveredAtom">, setHoveredSection: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<HoveredSection, "hoveringStates/setHoveredSection">, resetHoveringStates: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"hoveringStates/resetHoveringStates">;
declare const _default: import("redux").Reducer<{
    enableAtomHovering: boolean;
    hoveredAtom: HoveredAtom;
    hoveredSection: HoveredSection | null;
    cursorStyle: string;
}>;
export default _default;
//# sourceMappingURL=hoveringStatesSlice.d.ts.map