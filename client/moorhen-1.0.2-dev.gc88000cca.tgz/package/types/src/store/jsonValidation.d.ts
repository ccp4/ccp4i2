export declare const setValidationJson: import("@reduxjs/toolkit").ActionCreatorWithPayload<any, "jsonValidation/setValidationJson">;
declare const _default: import("redux").Reducer<{
    validationJson: {
        sections: any;
        title: string;
    };
}>;
export default _default;
//# sourceMappingURL=jsonValidation.d.ts.map