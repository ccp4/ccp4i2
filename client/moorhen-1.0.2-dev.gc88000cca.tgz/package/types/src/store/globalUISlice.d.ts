import { SidePanelIDs } from "../components/panels";
import { ShownControl } from "../components/snack-bars/PopupControls/PopupControlList";
export declare const setBusy: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "globalUI/setBusy">, setTimeCapsuleBusy: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "globalUI/setTimeCapsuleBusy">, setGlobalInstanceReady: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "globalUI/setGlobalInstanceReady">, setSearchBarActive: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "globalUI/setSearchBarActive">, setMainMenuOpen: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "globalUI/setMainMenuOpen">, setShortCutsBlocked: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "globalUI/setShortCutsBlocked">, setShownSidePanel: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<SidePanelIDs, "globalUI/setShownSidePanel">, setSidePanelWidth: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "globalUI/setSidePanelWidth">, setBottomPanelHeight: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "globalUI/setBottomPanelHeight">, setShownControl: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<ShownControl, "globalUI/setShownControl">, lockControls: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "globalUI/lockControls">, unlockControls: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "globalUI/unlockControls">, closeResidueSelectionTools: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"globalUI/closeResidueSelectionTools">, pauseClickAwayListener: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"globalUI/pauseClickAwayListener">, resumeClickAwayListener: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"globalUI/resumeClickAwayListener">;
declare const _default: import("redux").Reducer<{
    busy: boolean;
    isTimeCapsuleBusy: boolean;
    isGlobalInstanceReady: boolean;
    isMainMenuOpen: boolean;
    isSearchBarActive: boolean;
    areShortcutsBlocked: boolean;
    shownSidePanel: SidePanelIDs | null;
    sidePanelWidth: number;
    bottomPanelHeight: number | null;
    shownControl: ShownControl | null;
    controlLocked: number | null;
    selectionToolsActive: boolean;
    clickAwayListenerPauseCount: number;
}>;
export default _default;
//# sourceMappingURL=globalUISlice.d.ts.map