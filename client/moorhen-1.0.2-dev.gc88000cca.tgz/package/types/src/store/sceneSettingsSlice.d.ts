import type { ShadowMapQuality } from "../WebGLgComponents/mgWebGLParts/framebuffers";
export declare const initialState: {
    defaultBackgroundColor: [number, number, number, number];
    origin: [number, number, number];
    zoom: number;
    drawScaleBar: boolean;
    drawCrosshairs: boolean;
    drawAxes: boolean;
    drawEnvBOcc: boolean;
    drawFPS: boolean;
    drawMissingLoops: boolean;
    fogClipOffset: number;
    fogStart: number;
    fogEnd: number;
    clipStart: number;
    clipEnd: number;
    doPerspectiveProjection: boolean;
    useOffScreenBuffers: boolean;
    depthBlurRadius: number;
    /**
     * How many depth-peel layers to resolve transparency with.
     *
     * One per depth of transparent surface that needs separating. A single closed surface wants
     * two - its front and its back - while several contour levels of the same field drawn at
     * once want one per level. Each layer is a further pass over the transparent geometry, so
     * this is a direct trade of cost against how deep the transparency stays correct.
     */
    depthPeelLayers: number;
    /**
     * Whether the opaque scene is drawn once while depth peeling, rather than into every layer.
     *
     * Deliberately not in the persisted preferences: it exists so the two paths can be compared
     * on screen, and it should come back on after a reload rather than leaving someone stuck on
     * the slow path because they once turned it off.
     */
    peelOpaqueSeparately: boolean;
    depthBlurDepth: number;
    lightPosition: [number, number, number, number];
    ambient: [number, number, number, number];
    specular: [number, number, number, number];
    diffuse: [number, number, number, number];
    specularPower: number;
    ssaoBias: number;
    ssaoRadius: number;
    doShadowDepthDebug: boolean;
    doShadow: boolean;
    /**
     * How finely shadows are resolved: "coarse", "nice" or "smooth".
     *
     * Named to match the mesh quality settings rather than quoting a texture size, which is a
     * number nobody outside the renderer should have to reason about. See SHADOW_MAP_TEXELS for
     * what each one costs.
     */
    shadowMapQuality: ShadowMapQuality;
    doSSAO: boolean;
    doEdgeDetect: boolean;
    edgeDetectDepthThreshold: number;
    edgeDetectNormalThreshold: number;
    edgeDetectDepthScale: number;
    edgeDetectNormalScale: number;
    doOutline: boolean;
    doSpin: boolean;
    doThreeWayView: boolean;
    multiViewRows: number;
    multiViewColumns: number;
    threeWayViewOrder: string;
    specifyMultiViewRowsColumns: boolean;
    doSideBySideStereo: boolean;
    doMultiView: boolean;
    doCrossEyedStereo: boolean;
    doAnaglyphStereo: boolean;
    defaultBondSmoothness: number;
    resetClippingFogging: boolean;
    clipCap: boolean;
    backgroundColor: [number, number, number, number];
    height: number;
    width: number;
    GlViewportHeight: number;
    GlViewportWidth: number;
    isDark: boolean;
};
export declare const setOrigin: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<[number, number, number], "sceneSettings/setOrigin">, setDefaultBackgroundColor: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<[number, number, number, number], "sceneSettings/setDefaultBackgroundColor">, setDrawCrosshairs: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setDrawCrosshairs">, setDrawScaleBar: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setDrawScaleBar">, setDrawFPS: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setDrawFPS">, setDrawMissingLoops: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setDrawMissingLoops">, setDefaultBondSmoothness: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setDefaultBondSmoothness">, setDoSSAO: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setDoSSAO">, setSsaoRadius: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setSsaoRadius">, setSsaoBias: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setSsaoBias">, setResetClippingFogging: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setResetClippingFogging">, setClipCap: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setClipCap">, resetSceneSettings: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"sceneSettings/resetSceneSettings">, setEdgeDetectNormalScale: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setEdgeDetectNormalScale">, setUseOffScreenBuffers: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setUseOffScreenBuffers">, setDoShadowDepthDebug: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setDoShadowDepthDebug">, setDoShadow: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setDoShadow">, setShadowMapQuality: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<ShadowMapQuality, "sceneSettings/setShadowMapQuality">, setDoSpin: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setDoSpin">, setDoOutline: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setDoOutline">, setDepthBlurRadius: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setDepthBlurRadius">, setDepthPeelLayers: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setDepthPeelLayers">, setPeelOpaqueSeparately: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setPeelOpaqueSeparately">, setBackgroundColor: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<[number, number, number, number], "sceneSettings/setBackgroundColor">, setDepthBlurDepth: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setDepthBlurDepth">, setDrawAxes: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setDrawAxes">, setDoPerspectiveProjection: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setDoPerspectiveProjection">, setPerspectiveEyeDistance: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setPerspectiveEyeDistance">, setHeight: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setHeight">, setWidth: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setWidth">, setGlViewportHeight: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setGlViewportHeight">, setGlViewportWidth: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setGlViewportWidth">, setIsDark: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setIsDark">, setEdgeDetectDepthScale: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setEdgeDetectDepthScale">, setDoEdgeDetect: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setDoEdgeDetect">, setEdgeDetectDepthThreshold: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setEdgeDetectDepthThreshold">, setEdgeDetectNormalThreshold: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setEdgeDetectNormalThreshold">, setDrawEnvBOcc: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setDrawEnvBOcc">, setDoAnaglyphStereo: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setDoAnaglyphStereo">, setDoCrossEyedStereo: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setDoCrossEyedStereo">, setDoSideBySideStereo: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setDoSideBySideStereo">, setDoThreeWayView: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setDoThreeWayView">, setDoMultiView: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setDoMultiView">, setMultiViewRows: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setMultiViewRows">, setMultiViewColumns: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setMultiViewColumns">, setSpecifyMultiViewRowsColumns: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sceneSettings/setSpecifyMultiViewRowsColumns">, setThreeWayViewOrder: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "sceneSettings/setThreeWayViewOrder">, setLightPosition: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<[number, number, number, number], "sceneSettings/setLightPosition">, setAmbient: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<[number, number, number, number], "sceneSettings/setAmbient">, setSpecular: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<[number, number, number, number], "sceneSettings/setSpecular">, setDiffuse: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<[number, number, number, number], "sceneSettings/setDiffuse">, setSpecularPower: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setSpecularPower">, setFogClipOffset: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setFogClipOffset">, setFogStart: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setFogStart">, setFogEnd: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setFogEnd">, setClipStart: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setClipStart">, setClipEnd: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setClipEnd">, setZoom: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sceneSettings/setZoom">, autoClipFogByZoom: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"sceneSettings/autoClipFogByZoom">;
declare const _default: import("redux").Reducer<{
    defaultBackgroundColor: [number, number, number, number];
    origin: [number, number, number];
    zoom: number;
    drawScaleBar: boolean;
    drawCrosshairs: boolean;
    drawAxes: boolean;
    drawEnvBOcc: boolean;
    drawFPS: boolean;
    drawMissingLoops: boolean;
    fogClipOffset: number;
    fogStart: number;
    fogEnd: number;
    clipStart: number;
    clipEnd: number;
    doPerspectiveProjection: boolean;
    useOffScreenBuffers: boolean;
    depthBlurRadius: number;
    /**
     * How many depth-peel layers to resolve transparency with.
     *
     * One per depth of transparent surface that needs separating. A single closed surface wants
     * two - its front and its back - while several contour levels of the same field drawn at
     * once want one per level. Each layer is a further pass over the transparent geometry, so
     * this is a direct trade of cost against how deep the transparency stays correct.
     */
    depthPeelLayers: number;
    /**
     * Whether the opaque scene is drawn once while depth peeling, rather than into every layer.
     *
     * Deliberately not in the persisted preferences: it exists so the two paths can be compared
     * on screen, and it should come back on after a reload rather than leaving someone stuck on
     * the slow path because they once turned it off.
     */
    peelOpaqueSeparately: boolean;
    depthBlurDepth: number;
    lightPosition: [number, number, number, number];
    ambient: [number, number, number, number];
    specular: [number, number, number, number];
    diffuse: [number, number, number, number];
    specularPower: number;
    ssaoBias: number;
    ssaoRadius: number;
    doShadowDepthDebug: boolean;
    doShadow: boolean;
    /**
     * How finely shadows are resolved: "coarse", "nice" or "smooth".
     *
     * Named to match the mesh quality settings rather than quoting a texture size, which is a
     * number nobody outside the renderer should have to reason about. See SHADOW_MAP_TEXELS for
     * what each one costs.
     */
    shadowMapQuality: ShadowMapQuality;
    doSSAO: boolean;
    doEdgeDetect: boolean;
    edgeDetectDepthThreshold: number;
    edgeDetectNormalThreshold: number;
    edgeDetectDepthScale: number;
    edgeDetectNormalScale: number;
    doOutline: boolean;
    doSpin: boolean;
    doThreeWayView: boolean;
    multiViewRows: number;
    multiViewColumns: number;
    threeWayViewOrder: string;
    specifyMultiViewRowsColumns: boolean;
    doSideBySideStereo: boolean;
    doMultiView: boolean;
    doCrossEyedStereo: boolean;
    doAnaglyphStereo: boolean;
    defaultBondSmoothness: number;
    resetClippingFogging: boolean;
    clipCap: boolean;
    backgroundColor: [number, number, number, number];
    height: number;
    width: number;
    GlViewportHeight: number;
    GlViewportWidth: number;
    isDark: boolean;
}>;
export default _default;
//# sourceMappingURL=sceneSettingsSlice.d.ts.map