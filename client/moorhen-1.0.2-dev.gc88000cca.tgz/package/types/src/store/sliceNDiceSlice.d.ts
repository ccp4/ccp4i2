import { MoorhenMolecule } from "../utils";
export declare const resetSliceNDiceSlice: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"sliceNDice/resetSliceNDiceSlice">, setPaeFileIsUploaded: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<boolean, "sliceNDice/setPaeFileIsUploaded">, setThresholdType: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<"b-factor-norm" | "af2-plddt", "sliceNDice/setThresholdType">, setMoleculeBfactors: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    cid: string;
    bFactor: number;
    normalised_bFactor: number;
}[], "sliceNDice/setMoleculeBfactors">, setSlicingResults: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MoorhenMolecule[], "sliceNDice/setSlicingResults">, setMoleculeMaxBfactor: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sliceNDice/setMoleculeMaxBfactor">, setMoleculeMinBfactor: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sliceNDice/setMoleculeMinBfactor">, setBFactorThreshold: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sliceNDice/setBFactorThreshold">, setNClusters: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "sliceNDice/setNClusters">, setClusteringType: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "sliceNDice/setClusteringType">, setPAEFileContents: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    fileContents: string;
    fileName: string;
}[], "sliceNDice/setPAEFileContents">;
declare const _default: import("redux").Reducer<{
    paeFileIsUploaded: boolean;
    thresholdType: "b-factor-norm" | "af2-plddt";
    moleculeBfactors: {
        cid: string;
        bFactor: number;
        normalised_bFactor: number;
    }[];
    moleculeMinBfactor: number;
    moleculeMaxBfactor: number;
    bFactorThreshold: number;
    nClusters: number;
    clusteringType: string;
    slicingResults: MoorhenMolecule[];
    paeFileContents: {
        fileContents: string;
        fileName: string;
    }[];
}>;
export default _default;
//# sourceMappingURL=sliceNDiceSlice.d.ts.map