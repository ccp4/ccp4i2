export type Snackbar = {
    message: string;
    variant: "success" | "error" | "warning" | "info";
    autoHideDuration: number | null;
    createdAt: number;
    uid: string;
    tag?: string;
};
export type SnackbarPayload = {
    message: string;
    variant?: "success" | "error" | "warning" | "info";
    autoHideDuration?: number | null;
    tag?: string;
};
export declare const enqueueSnackbar: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<SnackbarPayload, "snackbar/enqueueSnackbar">, closeSnackbar: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    uid: string;
}, "snackbar/closeSnackbar">, clearSnackbar: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"snackbar/clearSnackbar">;
declare const _default: import("redux").Reducer<Snackbar[]>;
export default _default;
//# sourceMappingURL=snackbarSlice.d.ts.map