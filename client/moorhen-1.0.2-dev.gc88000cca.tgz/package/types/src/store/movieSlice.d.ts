/**
 * The movie being authored.
 *
 * In the store rather than in the panel, for one reason: a movie outlives the panel. Side panels
 * are unmounted when they are closed, so a document held in component state would be thrown away
 * by closing the panel to look at something - which, since authoring a movie consists largely of
 * looking at things, would happen constantly.
 *
 * All the editing lives in utils/movieEditing as plain functions. The reducers here only say which
 * one to call, so the rules that matter - a deleted keyframe merging its segments, an object
 * introduced to every keyframe rather than one - are tested without a store.
 *
 * ON FROZEN STATE
 *
 * Redux Toolkit freezes state in development. Two consequences worth stating, because both have
 * bitten this codebase already:
 *
 *  - every editing function returns a new document and mutates nothing, which is what makes them
 *    safe here;
 *  - a keyframe taken *out* of here and handed to the camera must be copied first. captureKeyframe
 *    stores plain arrays and cameraTargetFrom copies them element by element, so the live path is
 *    safe; anything new that reaches into a keyframe's quat should do the same rather than hand
 *    the array to a renderer that mutates in place.
 */
import { type PayloadAction } from "@reduxjs/toolkit";
import type { Keyframe, Motion, Segment } from "../utils/cameraPath";
import { type MovieDocument, type MovieOutputSettings, type MovieSceneSettings } from "../utils/movieDocument";
export interface MovieState {
    document: MovieDocument;
    /**
     * Which keyframe the panel is working on, or null for none.
     *
     * Kept beside the document rather than in the panel because deleting a keyframe has to move
     * it, and a selection that outlived the thing it pointed at would read as an empty editor
     * over a movie that plainly has keyframes in it.
     */
    selected: number | null;
    /** Where the document came from, for the title bar and for deciding what Save means. */
    fileName: string | null;
}
export declare const movieSlice: import("@reduxjs/toolkit").Slice<MovieState, {
    setMovieDocument: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }, action: PayloadAction<MovieDocument>) => void;
    setMovieName: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }, action: PayloadAction<string>) => void;
    setMovieFileName: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }, action: PayloadAction<string | null>) => void;
    newMovie: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }) => void;
    selectKeyframe: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }, action: PayloadAction<number | null>) => void;
    appendKeyframe: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }, action: PayloadAction<Keyframe>) => void;
    insertKeyframe: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }, action: PayloadAction<{
        keyframe: Keyframe;
        at: number;
    }>) => void;
    updateKeyframe: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }, action: PayloadAction<{
        index: number;
        keyframe: Keyframe;
    }>) => void;
    removeKeyframe: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }, action: PayloadAction<number>) => void;
    duplicateKeyframe: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }, action: PayloadAction<number>) => void;
    reorderKeyframe: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }, action: PayloadAction<{
        from: number;
        to: number;
    }>) => void;
    updateSegment: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }, action: PayloadAction<{
        index: number;
        change: Partial<Segment>;
    }>) => void;
    updateMotion: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }, action: PayloadAction<{
        index: number;
        motion: Motion;
    }>) => void;
    /** End on the last keyframe rather than on a motion. See removeTrailingSegment. */
    clearTrailingMotion: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }) => void;
    spreadSceneFromKeyframe: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }, action: PayloadAction<number>) => void;
    updateMovieScene: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }, action: PayloadAction<Partial<MovieSceneSettings>>) => void;
    updateMovieOutput: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }, action: PayloadAction<Partial<MovieOutputSettings>>) => void;
    updateObjectOpacity: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }, action: PayloadAction<{
        index: number;
        id: string;
        value: number;
    }>) => void;
    addObjectToMovie: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }, action: PayloadAction<{
        id: string;
        value?: number;
    }>) => void;
    removeObjectFromMovie: (state: {
        document: {
            name: string;
            path: {
                keyframes: {
                    quat: quat4.quat;
                    origin: [number, number, number];
                    zoom: number;
                    clipFront: number;
                    clipBack: number;
                    fogFront: number;
                    fogBack: number;
                    opacity?: {
                        [x: string]: number;
                    };
                    scene?: {
                        backgroundColor?: [number, number, number, number];
                        lightPosition?: [number, number, number, number];
                        ambient?: [number, number, number, number];
                        diffuse?: [number, number, number, number];
                        specular?: [number, number, number, number];
                        specularPower?: number;
                        blurDepth?: number;
                    };
                    thumbnail?: string;
                }[];
                segments: {
                    seconds: number;
                    motion: {
                        kind: "move";
                    } | {
                        kind: "hold";
                    } | {
                        kind: "spin";
                        turns?: number;
                        axis?: "x" | "y" | "z";
                    } | {
                        kind: "rock";
                        degrees?: number;
                        periodSeconds?: number;
                        axis?: "x" | "y" | "z";
                    };
                }[];
            };
            scene: {
                doShadow: boolean;
                doSSAO: boolean;
                ssaoRadius: number;
                ssaoBias: number;
                doEdgeDetect: boolean;
                edgeDetectDepthScale: number;
                edgeDetectNormalScale: number;
                edgeDetectDepthThreshold: number;
                edgeDetectNormalThreshold: number;
                doOutline: boolean;
                useOffScreenBuffers: boolean;
                blurRadius: number;
                doPerspectiveProjection: boolean;
                eyeDistance: number;
            };
            output: {
                fps: number;
                width: number;
                height: number;
                quality?: import("../utils/videoBitrate").VideoQuality;
            };
        };
        selected: number | null;
        fileName: string | null;
    }, action: PayloadAction<string>) => void;
}, "movie", "movie", import("@reduxjs/toolkit").SliceSelectors<MovieState>>;
export declare const setMovieDocument: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<MovieDocument, "movie/setMovieDocument">, setMovieName: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "movie/setMovieName">, setMovieFileName: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "movie/setMovieFileName">, newMovie: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"movie/newMovie">, selectKeyframe: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "movie/selectKeyframe">, appendKeyframe: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<Keyframe, "movie/appendKeyframe">, insertKeyframe: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    keyframe: Keyframe;
    at: number;
}, "movie/insertKeyframe">, updateKeyframe: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    index: number;
    keyframe: Keyframe;
}, "movie/updateKeyframe">, removeKeyframe: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "movie/removeKeyframe">, reorderKeyframe: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    from: number;
    to: number;
}, "movie/reorderKeyframe">, duplicateKeyframe: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "movie/duplicateKeyframe">, updateSegment: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    index: number;
    change: Partial<Segment>;
}, "movie/updateSegment">, updateMotion: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    index: number;
    motion: Motion;
}, "movie/updateMotion">, clearTrailingMotion: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"movie/clearTrailingMotion">, spreadSceneFromKeyframe: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<number, "movie/spreadSceneFromKeyframe">, updateMovieScene: import("@reduxjs/toolkit").ActionCreatorWithNonInferrablePayload<"movie/updateMovieScene">, updateMovieOutput: import("@reduxjs/toolkit").ActionCreatorWithNonInferrablePayload<"movie/updateMovieOutput">, updateObjectOpacity: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    index: number;
    id: string;
    value: number;
}, "movie/updateObjectOpacity">, addObjectToMovie: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    id: string;
    value?: number;
}, "movie/addObjectToMovie">, removeObjectFromMovie: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<string, "movie/removeObjectFromMovie">;
declare const _default: import("redux").Reducer<MovieState>;
export default _default;
//# sourceMappingURL=movieSlice.d.ts.map