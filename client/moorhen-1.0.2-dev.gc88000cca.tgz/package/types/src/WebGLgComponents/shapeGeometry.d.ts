/**
 * Geometry generators for the 3D annotation objects.
 *
 * Every generator returns local-space geometry that is then placed by the instanced draw path:
 * the vertex shader computes `instancePosition + instanceOrientation * (instanceSize * vertex)`.
 * So each mesh is built at a canonical size and the per-instance size/orientation do the rest.
 *
 * Normals are a per-vertex attribute, so `normals` always has exactly the same length as
 * `vertices`. Faces that should read as flat are given per-face duplicated vertices rather than
 * shared corners - a shared corner can only carry one normal.
 */
/**
 * WIREFRAMES
 *
 * Every shape except the disc and the plane can be drawn as a cage of tubes instead of a surface.
 * There are two routes to the wires, and which one a shape takes is not a style choice:
 *
 *  - A flat-sided solid has real edges, and they can be recovered from its triangles as the
 *    creases - see getWireframe. Adding another polyhedron costs nothing; its wires come for free.
 *  - A curved surface has no creases left to find. At any useful tolerance every edge of a
 *    sphere's triangulation is one, so crease detection returns a tube along all of them, quad
 *    diagonals included - a mess, not a wireframe. Curved shapes therefore state their wires
 *    parametrically and sweep them with tubesAlongPaths. Adding a curved shape means writing its
 *    wire set by hand, which is the price of the useful half of this: wire density stops being
 *    tied to tessellation, so a sphere meshed at 32x16 can be drawn as eight smooth hoops.
 *
 * Three invariants hold across both routes. Breaking any of them is a visual bug that is easy to
 * introduce and hard to attribute, so they are worth stating once here:
 *
 *  1. A wireframe is ALWAYS placed with a uniform instance size, whatever the solid does. An
 *     uneven size flattens round tubes into ellipses and makes the requested thickness wrong by a
 *     different factor along each axis. Uneven proportions are baked into the geometry instead -
 *     by stretchedMesh on the crease route, or as ratio arguments on the parametric one - and the
 *     instance then scales by the largest component.
 *  2. Thickness is absolute, in scene units, not a fraction of the shape. So a caller converts to
 *     mesh units by dividing by the uniform scale it is about to apply, and the result has to
 *     appear in the mesh key: two objects of different sizes need different meshes to end up with
 *     the same wires on screen, and so no longer share one. Same size and thickness still do.
 *  3. A closed path must be planar. The cross-section frame is parallel-transported, which returns
 *     to itself around a planar loop but generally not otherwise, leaving a twist at the join. A
 *     non-planar loop should be passed as an open path whose ends coincide; tubesAlongPaths drops
 *     the repeated point and the caps hide inside the tube.
 *
 * Tubes are expected to interpenetrate where they meet - at a polyhedron's corners, at a sphere's
 * poles - and their caps are buried inside those joints on purpose. So an edge shared by four
 * triangles is normal at a junction, whereas an edge used only once is a hole and a real fault.
 *
 * tubesAlongPaths knows nothing about any of these shapes: it takes polylines and returns tubes.
 * A user-defined path primitive - a tube through a CA trace, say - would be a thin wrapper over
 * it, needing only a data model. Note that such a path is already in scene coordinates, so it
 * wants a uniform scale of 1 and is its own mesh, with nothing to share and no instancing.
 */
export type ShapeMesh = {
    vertices: number[];
    normals: number[];
    idx: number[];
    /**
     * Flat u,v per vertex, for the generators that have a sensible mapping.
     *
     * Absent for most of them, and deliberately so: there is no one right way to unwrap a torus
     * or an icosahedron, and an arbitrary choice would be worse than none. A shape without these
     * draws untextured however its object is set up.
     */
    texCoords?: number[];
};
/** A regular tetrahedron: four alternate corners of a cube. */
export declare const getTetrahedron: () => ShapeMesh;
/** A regular octahedron: the six signed unit axes. */
export declare const getOctahedron: () => ShapeMesh;
/** A regular icosahedron: 12 vertices, 20 triangular faces. */
export declare const getIcosahedron: () => ShapeMesh;
/** A regular dodecahedron: 20 vertices, 12 pentagonal faces. */
export declare const getDodecahedron: () => ShapeMesh;
/**
 * A truncated octahedron: 24 vertices, 8 hexagons and 6 squares.
 *
 * Also the Wigner-Seitz cell of a body-centred cubic lattice, and one of the standard periodic
 * boundary cells in molecular dynamics, which is the main reason it is worth having.
 */
export declare const getTruncatedOctahedron: () => ShapeMesh;
/**
 * A cuboctahedron: 12 vertices, 8 triangles and 6 squares - a cube with its corners cut back to
 * the edge midpoints. Also the shape of Elite's Coriolis station.
 */
export declare const getCuboctahedron: () => ShapeMesh;
/**
 * A rhombic dodecahedron: 14 vertices and 12 rhombic faces. The other standard periodic boundary
 * cell shape, and the Wigner-Seitz cell of a face-centred cubic lattice.
 *
 * Unlike the others here it is a Catalan solid, so it is face-transitive rather than
 * vertex-transitive: its vertices sit at two different radii - eight at the cube corners and six
 * further out along the axes. facesFromAdjacency still copes, because what it actually relies on
 * is that all the edges are the same length (they are, at sqrt(3)) rather than all the vertices
 * being equidistant. Normalising to a circumradius therefore refers to the outer six.
 */
export declare const getRhombicDodecahedron: () => ShapeMesh;
/**
 * A truncated icosahedron - the football / Bucky ball: 60 vertices, 12 pentagons and 20 hexagons.
 *
 * Built by actually truncating an icosahedron rather than from a vertex table. Cutting every edge
 * at both of its third-points replaces each vertex with a pentagon and each triangular face with a
 * hexagon; cutting at exactly one third is what makes every edge of the result the same length,
 * and so every face regular. The faces themselves fall out of facesFromAdjacency.
 */
export declare const getFootball: () => ShapeMesh;
/**
 * A unit square in the xy plane, centred on the origin and spanning -0.5 to 0.5 on each axis, so
 * the instance size gives its two side lengths directly. Double-sided.
 */
export declare const getPlane: () => ShapeMesh;
/**
 * A filled circle of radius 1 in the xy plane, centred on the origin, so the instance size gives
 * its radius. Double-sided. `nSides` is the number of segments around the rim.
 */
export declare const getDisc: (nSides: number) => ShapeMesh;
/**
 * A flat ring in the xy plane, centred on the origin: outer radius 1, inner radius `innerRatio`,
 * so the instance size gives the outer radius and the ratio is inner_radius / radius.
 *
 * Double-sided like the plane and disc, and for the same reason. It cannot go through
 * doubleSidedPolygon, because an annulus is not convex - a fan from one corner would cover the
 * hole. Instead each segment of the ring is a quad spanning inner to outer radius.
 *
 * `nSides` is the number of segments around the ring.
 */
export declare const getAnnulus: (innerRatio: number, nSides: number) => ShapeMesh;
/**
 * An ellipsoid centred on the origin with semi-axes rx, ry, rz.
 *
 * The axis lengths are baked into the mesh rather than left to a non-uniform instance size,
 * because the vertex shader rotates normals but does not scale them: under a non-uniform scale a
 * normal needs the inverse transpose, so a sphere squashed by the instance size would keep its
 * spherical normals and light as though it were still a sphere. A uniform instance scale leaves
 * normal directions alone, so the caller passes the shape here as a ratio and scales uniformly.
 *
 * The outward normal of an ellipsoid is the gradient of x^2/rx^2 + y^2/ry^2 + z^2/rz^2, i.e.
 * (x/rx^2, y/ry^2, z/rz^2) normalised - not the position, which is only true for a sphere.
 */
export declare const getEllipsoid: (rx: number, ry: number, rz: number, slices: number, stacks: number) => ShapeMesh;
/**
 * A torus lying in the xy plane, major radius 1, so the instance size scales it to the wanted
 * major radius and `minorRatio` is minor_radius / major_radius.
 */
export declare const getTorus: (minorRatio: number, majorAccu: number, minorAccu: number) => ShapeMesh;
/**
 * An arc - a segment of a torus - sweeping from angle 0 in the xy plane, major radius 1, so the
 * instance size gives the major radius and `minorRatio` is minor_radius / major_radius.
 *
 * There is no start angle: the orientation already decides where the arc begins, so a start angle
 * would just be a second way of saying the same thing.
 *
 * The open ends are capped, otherwise you see through the hollow tube. A sweep of a full turn
 * closes on itself, and the caps are dropped so they do not sit on top of each other.
 *
 * @param {number} minorRatio - tube radius as a fraction of the major radius
 * @param {number} sweep - the angle swept, in radians
 */
export declare const getArc: (minorRatio: number, sweep: number, majorAccu: number, minorAccu: number) => ShapeMesh;
/**
 * A capsule - a cylinder with hemispherical ends - along z, centred on the origin, radius 1.
 *
 * `lengthRatio` is the total end-to-end length as a multiple of the radius, so the caller scales
 * uniformly by the radius. The shape is baked rather than scaled non-uniformly for the usual two
 * reasons: a [r, r, h] instance size would squash the hemispheres into ellipsoid caps, and the
 * shader does not scale normals.
 *
 * A length of less than twice the radius has no room for a cylindrical section and gives a sphere.
 */
export declare const getCapsule: (lengthRatio: number, slices: number, capStacks: number) => ShapeMesh;
/**
 * A helix: a tube following a helical path, major radius 1, rising along z and centred on the
 * origin, so the caller scales uniformly by the major radius.
 *
 * Effectively an arc that climbs, which is why it needs no parameters of its own beyond the ones
 * an arc already has - `heightRatio` is the total rise and `sweep` may exceed a full turn.
 *
 * The tube is swept along a moving frame. The radial direction (cos t, sin t, 0) happens to stay
 * perpendicular to the helix tangent at every point, so it can be used directly as one axis of
 * that frame and the tube never twists relative to the axis.
 *
 * @param {number} minorRatio - tube radius as a fraction of the major radius
 * @param {number} heightRatio - total rise as a fraction of the major radius
 * @param {number} sweep - total angle swept, in radians; 4*pi is two turns
 */
export declare const getHelix: (minorRatio: number, heightRatio: number, sweep: number, majorAccu: number, minorAccu: number) => ShapeMesh;
/**
 * A copy of a mesh with its positions stretched along the axes.
 *
 * For baking a shape's proportions into its wire mesh instead of leaving them to the instance
 * size. A wireframe has to be scaled uniformly - an uneven instance size would flatten its round
 * tubes into ellipses and the requested thickness would not be what you got - so a cuboid, or
 * anything in the frustum family with its [radius, radius, height] size, has to arrive here
 * already the right shape.
 *
 * Normals are carried over untouched, which would be wrong in general but is fine for the one use
 * this has: getWireframe reads only positions, computing each face's normal itself. An affine
 * stretch keeps flat faces flat, so the creases it finds are still the shape's real edges.
 */
export declare const stretchedMesh: (mesh: ShapeMesh, ratios: number[]) => ShapeMesh;
/**
 * Turn a flat-sided solid into a wireframe: a thin tube along each of its edges.
 *
 * The edges have to be recovered from the triangles, because the meshes carry no notion of a
 * polygon. The test is whether an edge is a crease: the triangles either side of a real edge
 * belong to different faces and so have different normals, whereas the diagonals introduced by
 * triangulating a polygon lie *within* one face and are shared by two triangles with the same
 * normal. Drawing every triangle edge instead would criss-cross each face with its fan diagonals.
 *
 * Vertices are welded by position first, because the flat-shaded meshes deliberately duplicate
 * every corner once per face so that each copy can carry its own normal.
 *
 * `tubeRadius` is in the mesh's own units, so a caller wanting a given thickness in the scene has
 * to divide by the instance scale it is going to apply.
 *
 * Only meaningful for flat-sided solids. A curved surface is all creases at this tolerance, so a
 * sphere or a torus would come out as a tube along every triangle edge.
 */
export declare const getWireframe: (mesh: ShapeMesh, tubeRadius: number, sides?: number) => ShapeMesh;
/**
 * An ellipsoid drawn as a cage of hoops - `meridians` half circles from pole to pole plus
 * `latitudes` rings of latitude - instead of as a surface.
 *
 * Axes and parameterisation match getEllipsoid, so the cage and the solid describe the same
 * surface and `rx, ry, rz` mean the same thing in both: semi-axes as ratios, scaled uniformly by
 * the caller.
 *
 * `segments` samples a full turn, so a meridian - half a turn - takes half as many. Two opposite
 * meridians together make one great circle, so an even count gives meridians/2 great circles.
 */
export declare const getEllipsoidWireframe: (rx: number, ry: number, rz: number, meridians: number, latitudes: number, segments: number, tubeRadius: number) => ShapeMesh;
/**
 * The frustum family drawn as a cage: the two rims plus a set of lines up the slant. Covers a
 * cylinder (both radii equal), a cone (top radius zero) and anything between.
 *
 * Every dimension is a ratio, so the caller can scale uniformly and keep the wire tubes circular.
 * A [radius, radius, height] instance size - which is how the *solid* frustum is drawn - would
 * squash them into ellipses. Ratios are taken against the larger rim rather than the base, so a
 * frustum standing on a point (base radius zero) is not a division by zero.
 *
 * A rim of zero radius is skipped: a cone has one rim, not two, and its slant lines converge on
 * the apex, where their caps bury themselves in the joint.
 */
export declare const getFrustumWireframe: (bottomRatio: number, topRatio: number, heightRatio: number, rimSegments: number, verticals: number, tubeRadius: number) => ShapeMesh;
/**
 * A torus or arc drawn as a cage: rings around the tube plus circles running the long way round.
 * Matches getTorus and getArc - major radius 1, tube thickness as `minorRatio` - so the cage and
 * the solid describe the same surface.
 *
 * Both families of wire are planar circles, so they can be closed paths without a seam. On a
 * partial sweep the long-way-round wires become open arcs, and the ring count is scaled down with
 * the sweep so that a quarter turn is not given a full turn's worth of hoops.
 */
export declare const getTorusWireframe: (minorRatio: number, sweep: number, crossSections: number, longitudes: number, segments: number, tubeRadius: number) => ShapeMesh;
/**
 * A helix drawn as a cage: helical lines following the tube plus rings around it.
 *
 * The frame repeats getHelix's, so the wires sit on the same surface as the solid. The helical
 * lines are the one set of wires here that is not planar, which is why they are open paths - a
 * closed non-planar loop would come back with a twist at the join.
 */
export declare const getHelixWireframe: (minorRatio: number, heightRatio: number, sweep: number, crossSections: number, longitudes: number, segments: number, tubeRadius: number) => ShapeMesh;
/**
 * A capsule drawn as a cage: lines running the full length over both domes plus rings across it.
 *
 * The profile repeats getCapsule's, hemisphere centres included, so the wires follow the same
 * surface: the rings at the two joins are where the domes meet the barrel, which is what makes a
 * wireframe capsule read as a capsule rather than as a stretched sphere.
 */
export declare const getCapsuleWireframe: (lengthRatio: number, meridians: number, segments: number, tubeRadius: number) => ShapeMesh;
/**
 * An annulus drawn as a cage: the two rims plus spokes between them, like a wheel. Matches
 * getAnnulus - outer radius 1, the hole as `innerRatio` - and flat in the xy plane.
 *
 * The one flat shape that is worth wireframing. A disc or a plane has a single outline and nothing
 * within it, so a wireframe of either would discard the shape rather than reveal it; an annulus
 * has two rims, and the gap between them is the shape.
 */
export declare const getAnnulusWireframe: (innerRatio: number, spokes: number, segments: number, tubeRadius: number) => ShapeMesh;
/**
 * A tube following an explicit list of points - the path primitive, and the only generator here
 * whose geometry is data rather than parameters.
 *
 * `points` is flat x, y, z triples. `runStarts` gives the point indices (not float indices) at
 * which each separate run begins, so one path can hold several disconnected strands - which is
 * exactly what tubesAlongPaths takes, and what a CA trace broken at chain ends and at unmodelled
 * residues needs. An empty runStarts means one run.
 *
 * There is no canonical size to scale from, so the caller places this with a uniform scale of 1
 * and `tubeRadius` is already in scene units.
 *
 * `sectionStride` above zero splits the tube into separately highlightable sections, one per
 * that many segments of the path, each owning its own vertices; the returned `sectionRanges` give
 * each one's half-open range of vertex ids and `sectionPoints` a point in the middle of each for
 * the hover test to aim at. Zero, the default, gives one continuous strip.
 *
 * One limit is worth knowing, and it is inherent to sweeping a tube rather than a fault here: the
 * radius has to stay below the path's local radius of curvature. A tube cannot follow a bend
 * tighter than itself - the inside of the turn folds through the centre line and those triangles
 * come out inside-out. A CA trace is safe by a wide margin, at about 2.7 Angstrom at its tightest
 * raw and 1 Angstrom once splined, but a hand-built path with a hairpin in it may not be, and the
 * cure is a thinner tube or a gentler corner.
 */
export declare const getPathTubes: (points: number[], runStarts: number[], tubeRadius: number, sides?: number, innerRadius?: number, sectionStride?: number) => ShapeMesh & {
    sectionRanges?: number[][];
    sectionPoints?: number[][];
    sectionSpans?: number[][];
    sectionRadius?: number;
    sectionLevelRanges?: number[][][];
    sectionLevelPoints?: number[][][];
};
/**
 * A copy of a mesh scaled, turned and moved into place.
 *
 * Unlike the instanced path, which leaves placement to the per-instance attributes, this bakes it
 * into the geometry - for when several differently placed parts have to become one mesh, as the
 * manipulation handles do so that each can be a separately hoverable section of it.
 *
 * Normals take the inverse transpose, which for a diagonal scale means dividing rather than
 * multiplying: a cylinder squashed along its length keeps normals that point along the surface
 * they belong to, instead of leaning the way the vertices moved.
 *
 * `orientation` is a column-major 4x4, as everything else here takes it.
 */
export declare const placedMesh: (mesh: ShapeMesh, scale: number[], orientation: number[], translate: number[]) => ShapeMesh;
/** Several meshes concatenated into one, with indices offset to follow. */
export declare const mergeMeshes: (...meshes: ShapeMesh[]) => ShapeMesh;
/**
 * Several meshes joined into one, each becoming a separately hoverable section of it.
 *
 * The sections are what the highlight and the pick test already understand: a range of vertex
 * ids, a point to aim at and a centre line to measure against. So a handful of parts assembled
 * here arrive at the renderer indistinguishable from a path's sections, and light up one at a
 * time for free.
 *
 * Each part gives the two ends of its own axis as `span`, which is what the pick measures
 * against - far better for a long thin handle than a single point at its middle.
 */
export declare const combineIntoSections: (parts: {
    mesh: ShapeMesh;
    span: number[];
}[], pickRadius: number) => ShapeMesh & {
    sectionRanges: number[][];
    sectionPoints: number[][];
    sectionSpans: number[][];
    sectionRadius: number;
};
/**
 * Subdivide a polyline into a Catmull-Rom spline through its own points.
 *
 * For drawing a CA trace as a curve rather than as a 3.8 Angstrom zig-zag. Catmull-Rom is the
 * right family here because it interpolates: the curve passes exactly through every atom, so the
 * smoothed path still says where the backbone is. A B-spline would approximate them instead and
 * pull the curve off the atoms, flattening helices.
 *
 * Points are flat x, y, z triples in and out. `subdivisions` is the number of segments each
 * original interval becomes, so 1 returns the input unchanged. The ends are handled by reflecting
 * the neighbouring point, which keeps the curve from swinging wide of the first and last atoms.
 */
export declare const smoothPath: (points: number[], subdivisions: number) => number[];
/**
 * A frustum - a cone or pyramid with its tip cut off - running along z from a base of radius 1 at
 * z = -0.5 to a top of radius `topRadiusRatio` at z = +0.5, with both ends capped.
 *
 * Centred on the origin, like the closed solids, so that the instance orientation turns it on the
 * spot rather than swinging it about its base, and the instance size's z component is its height.
 *
 * `nSides` controls the cross section: a large value gives a circular (conical) frustum, a small
 * one a truncated pyramid. `flat` selects the shading to match - a truncated pyramid wants one
 * normal per face, a cone wants normals that vary around the barrel.
 *
 * The side normal is not purely radial: for a surface of revolution r(z) the outward normal is
 * (cos, sin, -dr/dz) normalised. The radius goes from 1 to topRadiusRatio over a unit height, so
 * dr/dz is the constant (topRadiusRatio - 1) regardless of where the ends sit.
 */
export declare const getFrustum: (nSides: number, topRadiusRatio: number, flat: boolean) => ShapeMesh;
//# sourceMappingURL=shapeGeometry.d.ts.map