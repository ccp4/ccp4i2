/**
 * The camera: one owner, transitions as data, drivers that say who is moving it.
 *
 * Pure. No GL, no store, no React - it is told the time and says where the camera is, and the
 * renderer draws that.
 *
 * WHY IT EXISTS
 *
 * The camera had three homes - origin and zoom in sceneSettings, quat in the glRef slice, the live
 * values in MGWebGL - and no owner. There was no "set the camera" operation at all: only "the store
 * and the renderer disagree, so close the gap", and the gap-closer animated. Specifying a camera
 * therefore required animating to it, a movie driving the camera directly provoked an animation
 * that fought it, and the fight sustained itself because each animation announced its arrival into
 * the store and re-triggered the reconciliation.
 *
 * Here the live value has exactly one writer, so there is nothing to reconcile. Stored state asks
 * to be agreed with by going through a driver - moveCameraTo, which declines outright while
 * somebody else holds the camera. A move in progress means the store is out of date, not that the
 * camera is wrong, and `driver` is what says so.
 *
 * THE CLOCK IS AN ARGUMENT
 *
 * `tick(seconds)` takes the time rather than reading it. The live app passes wall-clock and drops
 * frames when rendering is slow; a movie export passes i/fps and keeps every frame. Same
 * controller, same interpolation, different clock. That distinction cost a day to find empirically
 * and is the single most useful thing in this interface.
 */
import { Movie } from "../utils/cameraPath";
export type Vec3 = [number, number, number];
export type Quat = [number, number, number, number];
/**
 * Everything that decides what the camera sees.
 *
 * THE BOUNDARIES ARE OFFSETS FROM THE VIEW CENTRE, ALL OF THEM
 *
 * This is the one real change from what the store holds today, and it removes a long-standing
 * inconsistency: clip was already relative to the centre while fog was absolute from the eye.
 *
 *     clipStart = zoom * 8                 fogStart = fogClipOffset - zoom * 8
 *     clipEnd   = zoom * 21                fogEnd   = fogClipOffset + zoom * 21
 *
 * Same two distances, two conventions. That is why both slider modals keep computing
 * `fogClipOffset - gl_fog_start` to show the user a number, and why set_clip_range has a negation
 * at its call site that cost an afternoon to understand.
 *
 * With everything relative, three things stop being needed. The sliders already want offsets, so
 * they stop converting. Moving the eye no longer drags the slab out of place, so
 * clipPlanesAfterEyeMove - added precisely to compensate - has nothing to compensate for. And a
 * movie interpolating the slab interpolates the numbers a user actually set.
 */
export interface CameraState {
    quat: Quat;
    /** Negated view centre, matching the existing setOrigin convention. */
    origin: Vec3;
    zoom: number;
    /**
     * Distance from the eye to the view centre, previously `fogClipOffset`.
     *
     * It is camera, not scene: it sets how strongly a perspective view converges, and the
     * perspective eye-distance control changes it. The Camera collaborator in camera.ts already
     * held it next to quat, zoom and origin, which was the right instinct.
     */
    eyeDistance: number;
    /** How far in front of the view centre the front clip plane sits. */
    clipFront: number;
    /** How far behind it the back clip plane sits. */
    clipBack: number;
    /** Where fog begins, in front of the centre. */
    fogFront: number;
    /** Where it reaches full density, behind the centre. */
    fogBack: number;
}
/** A target names only the fields it cares about; the rest are left strictly alone. */
export type CameraTarget = Partial<CameraState>;
export type Transition = {
    kind: "instant";
} | {
    kind: "ease";
    seconds: number;
} | {
    kind: "path";
    movie: Movie;
};
export type DriverName = "user" | "centring" | "movie" | "session" | "api";
/**
 * How the clip and fog slab follows the camera.
 *
 * `auto` is applied inside the tick, as part of producing each state, rather than by a listener
 * reacting after the fact. That is what keeps one writer: the slab is coupled to zoom, and two
 * writers for coupled values is how the original loop happened.
 */
export type SlabPolicy = {
    kind: "manual";
} | {
    kind: "auto";
    fieldDepthFront: number;
    fieldDepthBack: number;
};
export interface MoveResult {
    /** False when another driver took over before this move finished. */
    completed: boolean;
}
export interface CameraDriver {
    readonly name: DriverName;
    readonly active: boolean;
    set(target: CameraTarget): void;
    moveTo(target: CameraTarget, transition: Transition): Promise<MoveResult>;
    /** A relative turn. During a move it accumulates and is applied on arrival. */
    turnBy(delta: Quat): void;
    /** Supply a camera per tick, for a caller computing its own path. */
    drive(sample: (seconds: number) => CameraTarget): void;
    release(): void;
}
export declare class CameraController {
    private current;
    private activeDriver;
    private move;
    private sampler;
    /** Turns that arrived while a move was in flight, applied when it lands. */
    private pendingTurn;
    private listeners;
    slabPolicy: SlabPolicy;
    constructor(initial: CameraState, slabPolicy?: SlabPolicy);
    /** Where the camera is now. Authoritative; read this rather than the store. */
    get state(): Readonly<CameraState>;
    /**
     * The live state, writable, with none of the rules applied and nobody told.
     *
     * This began as migration scaffolding - the renderer wrote the camera in dozens of places and
     * they could not all become drivers in one commit - and a survey of what is left found that
     * most of those are gone, but that the remainder are not a backlog. They are the per-frame
     * scratch writes in drawCore: multi-view and the stereo modes save the quaternion and origin,
     * set a value for one view, draw it, and put the originals back, all within a single frame.
     *
     * Those must stay silent, and that is a design decision rather than an unpaid debt. A per-eye
     * camera is not where the view is; echoing one to the store would be wrong as well as costing
     * a dispatch per view per frame on the hot path.
     *
     * So: writes that nothing should hear about come through here. Writes that move the view go
     * through `writeLive` or a driver. The distinction is the point, and the test is
     * simple - would it be a lie to tell the rest of the application that the camera is here?
     *
     * Nothing outside the Camera facade in mgWebGLParts/camera.ts should touch it.
     */
    get liveState(): CameraState;
    /**
     * Set part of the live state, with the slab policy applied and listeners told.
     *
     * The renderer's own direct writes: a zoom, a slab, an orientation handed in through setQuat.
     * Distinct from `liveState` above in that somebody hears about it - which is how the store's
     * copy of the view stays current, and therefore how MoorhenWebMG's reconciling effect is kept
     * from easing the camera back to a value it only believes because nobody told it otherwise.
     *
     * The difference from assigning through `liveState` is the policy. Zoom and the slab are
     * coupled, so a zoom that did not re-derive the slab would leave the two disagreeing until
     * something else happened to put them right - which is what the zoomChanged -> autoClipFogByZoom
     * round trip was for, and what made the slab a second writer. Writing through here is what lets
     * that round trip go.
     *
     * To apply the policy after switching it on, call `reapplySlab`: an empty write now changes
     * nothing, because the policy only acts when the zoom moves.
     *
     * It does not defer to an active driver: its callers have always landed unconditionally.
     * Whether they should - whether a slab drag during a movie ought to win or wait - is a real
     * question, and not one this answers.
     */
    writeLive(part: CameraTarget): void;
    /**
     * Apply the auto policy now, whatever the zoom is doing.
     *
     * The one thing `writeLive({})` used to be for. Now that the policy only acts when the zoom
     * moves - so that a hand-set clip survives, as it always did - an empty write means what it
     * says and changes nothing, and turning the switch on needs to ask explicitly.
     */
    reapplySlab(): void;
    get driver(): DriverName | null;
    /** True while a move or a driven sequence is running. */
    get moving(): boolean;
    /**
     * Claim the camera, superseding whoever had it.
     *
     * Not a queue: two things wanting the camera at once is a conflict to resolve, not work to get
     * through in order. Not a refusal either - refusing is how the old `animating` guard silently
     * dropped requests.
     */
    acquire(name: DriverName): CameraDriver;
    /**
     * Turn the camera by a relative rotation. What the mouse does.
     *
     * Not a driver operation, deliberately. Acquiring would supersede whatever was running, and
     * the rule is the opposite: a move that has been asked for should finish, and a nudge of the
     * mouse on the way must not stop the camera arriving where it was sent. So a turn that lands
     * during a move accumulates and is applied when the move does.
     *
     * That is strictly better than what happened before, which was that a drag during a centring
     * animation wrote the quaternion and the animation's next frame wrote over it - the input was
     * not deferred, it was lost. The cost is a possible visible step on arrival, bounded by how
     * far the mouse moved in a quarter of a second.
     */
    turnBy(delta: Quat): void;
    /** Advance to a moment in time. Called by the renderer before it draws. */
    tick(seconds: number): void;
    private ticking;
    private tickOnce;
    /**
     * Notified when the camera comes to rest - not per frame.
     *
     * A move settles on arrival, a `set` settles at once, a driven sequence settles when released.
     * So there is no React cost during motion and nothing is stale once anything stops. A live
     * echo can be added later if measurement says it is affordable; starting there and retreating
     * would be the wrong way round.
     */
    subscribe(listener: (state: Readonly<CameraState>) => void): () => void;
    /** @internal */
    driverSet(target: CameraTarget): void;
    /** @internal */
    driverMoveTo(target: CameraTarget, transition: Transition): Promise<MoveResult>;
    /**
     * @internal
     *
     * A turn arriving during a move is remembered rather than applied or discarded. Today a drag
     * during a centring animation is lost - both write the quaternion and the animation writes
     * last - so accumulating is better than the present behaviour as well as honouring the rule
     * that accidental mouse motion must not stop the camera arriving.
     */
    driverTurnBy(delta: Quat): void;
    /** @internal */
    driverDrive(sample: (seconds: number) => CameraTarget): void;
    /** @internal */
    driverRelease(driver: Driver): void;
    private supersede;
    private abandonMove;
    private applyPendingTurn;
    /** The slab, derived from zoom when the policy says so. One writer, no event round trip. */
    /**
     * The auto policy, applied only where it was ever meant to apply.
     *
     * The setting is called "reset clip and fog on zoom", and that is exactly what it used to do:
     * the old autoClipFogByZoom ran when the zoom changed and at no other time, so a clip set by
     * hand - from the keyboard shortcuts, the scene-slider handles, or the scripting API - stood
     * until the next zoom.
     *
     * Applying it on every write instead made all three of those useless, and silently: the value
     * was accepted, overwritten in the same breath, and the keyboard shortcut still announced
     * itself with a toast. A rotation re-derived the slab too, since turnBy writes like anything
     * else.
     *
     * @param wroteSlab  the write named clip or fog itself. Then it wins outright, even if the
     *                   zoom moved in the same write - someone setting the slab explicitly is not
     *                   asking for it to be derived.
     */
    private applySlab;
    private notify;
}
/** A claim on the camera, valid until released or superseded. */
declare class Driver implements CameraDriver {
    readonly name: DriverName;
    private readonly controller;
    private valid;
    constructor(name: DriverName, controller: CameraController);
    get active(): boolean;
    /** @internal */
    invalidate(): void;
    set(target: CameraTarget): void;
    moveTo(target: CameraTarget, transition: Transition): Promise<MoveResult>;
    turnBy(delta: Quat): void;
    drive(sample: (seconds: number) => CameraTarget): void;
    release(): void;
}
export {};
//# sourceMappingURL=cameraController.d.ts.map