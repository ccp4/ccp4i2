/**
 * Turning meshes into instanced draw buffers, with the pick information that makes them
 * hoverable.
 *
 * Extracted from the 3D object producer so that anything else wanting to draw with these meshes -
 * the manipulation handles, for one - can do so without going through the object store. Nothing
 * here knows what a 3D object is, what a molecule is, or where the meshes came from: it deals in
 * meshes, placements and colours.
 */
import type { ShapeMesh } from './shapeGeometry';
import type { BufferMaterial } from './textureRegistry';
/**
 * The identity orientation, used by primitives that are not rotated.
 */
export declare const IDENTITY_ORIENTATION: number[];
/**
 * How many points on each instance are offered to the hover test, beyond its centre.
 *
 * One point per object only makes a shape hoverable near that point, which is fine for a compact
 * solid and poor for anything long or hollow - a helix, a long cylinder, a torus whose centre is
 * empty space. Several points spread over the shape make all of it hoverable.
 */
export declare const PICK_POINTS_PER_INSTANCE = 16;
/**
 * One instanced draw: a single mesh plus the per-instance attributes of everything sharing it.
 */
export type InstanceGroup = {
    mesh: ShapeMesh & {
        sectionRanges?: number[][];
        sectionPoints?: number[][];
        sectionSpans?: number[][];
        sectionRadius?: number;
        sectionLevelRanges?: number[][][];
        sectionLevelPoints?: number[][][];
    };
    /**
     * What this group is drawn with beyond its per-instance colours.
     *
     * One per group, not per instance, because every instance in a group shares the mesh and is
     * drawn in a single call - there is nowhere for a second texture to go. That is why the
     * texture forms part of the group key at the call site: two shapes with different textures
     * are different groups, however identical their geometry.
     */
    material?: BufferMaterial;
    tags?: string[];
    tagKind?: string;
    instanceTags?: string[];
    pickPriority?: number;
    origins: number[];
    sizes: number[];
    orientations: number[];
    colours: number[];
};
/**
 * Collects meshes and their placements, and emits them as instanced draw buffers.
 *
 * Shapes drawn from a mesh are grouped by that mesh, so that everything sharing one can be drawn
 * in a single instanced call.
 */
export declare const createMeshInstances: (instanceTagKind?: string) => {
    addInstance: (key: string, buildMesh: () => ShapeMesh, origin: number[], size: number[], orientation: number[], colour: number[], material?: BufferMaterial) => void;
    group: (key: string) => InstanceGroup | undefined;
    emit: (objects: any[]) => void;
    setInstanceTag: (tag: string | null) => void;
};
//# sourceMappingURL=meshInstancing.d.ts.map