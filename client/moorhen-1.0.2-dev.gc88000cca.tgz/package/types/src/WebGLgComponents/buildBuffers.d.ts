import { DisplayBuffer } from './displayBuffer';
import { RootState } from '../store/MoorhenReduxStore';
import { Store } from '@reduxjs/toolkit';
export declare const appendOtherData: (jsondata: any, store: Store<RootState>, skipRebuild?: boolean, name?: string) => any;
export declare const linesToThickLines: (axesVertices: any, axesColours: any, size: any) => {};
export declare const cloneBuffers: (displayBuffers: DisplayBuffer[], gl: WebGLRenderingContext) => DisplayBuffer[];
export declare const buildBuffers: (displayBuffers: DisplayBuffer[], store: Store<RootState>, gl_in?: WebGLRenderingContext) => void;
//# sourceMappingURL=buildBuffers.d.ts.map