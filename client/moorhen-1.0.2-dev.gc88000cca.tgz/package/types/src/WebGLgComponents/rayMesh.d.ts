/**
 * Asking whether the pointer is actually over a mesh, rather than near a sample of one.
 *
 * Everything else the pick test handles has something better than isolated points to measure
 * against: a path offers the centre line of each section, a smooth mesh carries a per-vertex
 * influence weight, an instanced shape is compact enough that a handful of samples covers it.
 * A cavity has none of those - it is a branching hollow pocket described only by its triangles -
 * and sampling its surface is the weakest approximation of the lot. Tuning the tolerance on
 * that approximation trades one wrong answer for another; there is no value that is right.
 *
 * So this asks the exact question instead. The triangles are already here: the display buffer
 * keeps `triangleVertices` and `triangleIndexs` in JavaScript to build its GL buffers from, so
 * an exact test costs no extra memory and needs nothing from libcoot.
 *
 * Möller-Trumbore, with a bounding box tried first. Double-sided deliberately: a cavity is a
 * closed surface and the viewer may be inside one, in which case the first thing the ray meets
 * is a back face and refusing it would make the pocket unhoverable from within.
 *
 * A LINE, not a segment. The caller unprojects two points to say which way the ray goes, but
 * how far apart those two points happen to be says nothing about how much of the scene is
 * visible: in Moorhen they straddle only about half the depth of the slab between the clip
 * planes, so bounding the test by them made most of what was on screen unpickable. How far
 * along the line the mesh may be is a question about the clip planes, and it is answered in
 * eye space by the caller, which is where the clip planes are defined.
 */
export type Bounds = {
    low: [number, number, number];
    high: [number, number, number];
};
/**
 * The chord the line cuts through the mesh: where it first crosses the surface and where it
 * last does, in increasing t.
 *
 * Both are reported because which of the two faces the viewer depends on which way round the
 * caller's two points run, and that is the caller's business, not this file's.
 */
export type MeshHit = {
    entry: {
        point: [number, number, number];
        t: number;
    };
    exit: {
        point: [number, number, number];
        t: number;
    };
};
/**
 * Does the line meet this box?
 *
 * The slab test. Cheap, and it rejects almost every mesh on almost every hover - twenty pockets
 * scattered through a protein, and the pointer is over at most one or two of them.
 */
export declare const rayHitsBounds: (bounds: Bounds, from: readonly number[], to: readonly number[]) => boolean;
/**
 * Where the line crosses the mesh, or null if it misses it entirely.
 *
 * `t` is the distance along in units of from→to, and may be anything: the two points are a
 * direction, not a range.
 */
export declare const rayMeshHit: (vertices: ArrayLike<number>, indices: ArrayLike<number>, from: readonly number[], to: readonly number[], bounds?: Bounds) => MeshHit | null;
//# sourceMappingURL=rayMesh.d.ts.map