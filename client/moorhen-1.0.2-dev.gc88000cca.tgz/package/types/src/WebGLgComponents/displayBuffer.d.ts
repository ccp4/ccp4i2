import { vec3 } from 'gl-matrix';
import { moorhen } from '../types/moorhen';
import type { BufferMaterial } from './textureRegistry';
interface MGWebGLBuffer {
    itemSize: number;
    numItems: number;
}
export declare class DisplayBuffer {
    pick_info: {
        influence_weights_width?: number;
        influence_index_offsets_width?: number;
        influence_point_indexes_width?: number;
        influence_weights_texture?: number;
        influence_index_offsets_texture?: number;
        influence_point_indexes_texture?: number;
        pick_points?: [];
        point_triangles?: number[][];
        pick_point_instances?: number[];
        pick_point_sections?: number[];
        section_ranges?: number[][];
        section_level_ranges?: number[][][];
        section_level_points?: number[][][];
        pick_spans?: number[][];
        pick_radius?: number;
        pick_point_tags?: string[];
        pick_tag_kind?: string;
        instance_tags?: string[];
        instance_tag_kind?: string;
        claims_pointer?: boolean;
        pick_priority?: number;
        highlight_whole?: boolean;
        pick_exact?: boolean;
        pick_bounds?: {
            low: [number, number, number];
            high: [number, number, number];
        };
    };
    origin: number[];
    visible: boolean;
    name_label: string;
    display_class: string;
    transparent: boolean;
    /**
     * A fade applied to the whole buffer, from 0 to 1, multiplied into the fragment alpha.
     *
     * Distinct from the vertex colours' own alpha, which says what the object is made of. This
     * says how much of it is there at this moment, which is a movie's business and changes per
     * frame - so it is a uniform rather than a rewrite of every vertex. See objectFade.
     *
     * Ignored on a WebGL1 context, where the uniform is not registered and objects stay solid.
     */
    alphaMultiplier: number;
    alphaChanged: boolean;
    atoms: moorhen.AtomInfo[];
    symmetryAtoms: {
        chain_id: string;
        has_altloc: boolean;
        mol_name: string;
        serial: number;
        res_no: string;
        res_name: string;
        name: string;
        charge: number;
        tempFactor: number;
        pos: vec3;
        element: string;
    }[][];
    symmetryMatrices: number[];
    changeColourWithSymmetry: boolean;
    triangleVertexRealNormalBuffer: MGWebGLBuffer[];
    triangleVertexNormalBuffer: MGWebGLBuffer[];
    triangleVertexPositionBuffer: MGWebGLBuffer[];
    triangleVertexIndexBuffer: MGWebGLBuffer[];
    triangleVertexTextureBuffer: MGWebGLBuffer[];
    triangleInstanceOriginBuffer: MGWebGLBuffer[];
    triangleInstanceOrientationBuffer: MGWebGLBuffer[];
    triangleInstanceSizeBuffer: MGWebGLBuffer[];
    triangleColourBuffer: MGWebGLBuffer[];
    triangleIndexs: number[][];
    triangleVertices: number[][];
    triangleInstanceOrigins: number[][];
    triangleInstanceSizes: number[][];
    triangleInstanceOrientations: number[][];
    triangleColours: number[][];
    triangleNormals: number[][];
    /**
     * Flat u,v per vertex, one array per sub-buffer.
     *
     * The GL buffer for these (triangleVertexTextureBuffer) and the attribute they feed
     * (aVertexTexture, bound to location 3) both long predate anything filling them.
     */
    triangleTextureCoords: number[][];
    /**
     * What each sub-buffer is drawn with, beyond its vertex colours.
     *
     * Per sub-buffer rather than per buffer because that is the grain a material has: a glTF
     * primitive carries exactly one, and a file with several becomes several sub-buffers of one
     * object. Sparse - most sub-buffers have no entry, and that means "vertex colours alone".
     */
    materials: (BufferMaterial | undefined)[];
    primitiveSizes: number[][];
    bufferTypes: string[];
    customColour: [number, number, number, number] | null;
    transformMatrix: number[];
    transformMatrixInteractive: number[];
    transformOriginInteractive: number[];
    symopnums: number[];
    supplementary: any;
    isDirty: boolean;
    textNormalBuffer: MGWebGLBuffer[] | null;
    textPositionBuffer: MGWebGLBuffer[] | null;
    textColourBuffer: MGWebGLBuffer[] | null;
    textTexCoordBuffer: MGWebGLBuffer[] | null;
    textIndexesBuffer: MGWebGLBuffer[] | null;
    clickLinePositionBuffer: MGWebGLBuffer[] | null;
    clickLineColourBuffer: MGWebGLBuffer[] | null;
    clickLineIndexesBuffer: MGWebGLBuffer[] | null;
    textNormals: number[];
    textColours: number[];
    isHoverBuffer: boolean;
    id: string;
    /**
     * What made this buffer, for attributing a frame's cost back to a representation.
     *
     * Descriptive only: nothing in the renderer branches on it, and a buffer without one is
     * still drawn exactly the same. It exists because the draw loop sees a flat list of
     * buffers and cannot say which of them is the ribbons, so "1.1M triangles" is a number
     * with nowhere to go. Set where buffers are produced rather than derived at draw time,
     * since that is the only place that still knows.
     */
    statsLabel?: string;
    multiViewGroup: number;
    clickTol: number;
    doStencil: boolean;
    alwaysOnTop: boolean;
    constructor();
    setCustomColour(col: any): void;
    /**
     * Fade the whole buffer.
     *
     * A faded buffer has to be drawn as a transparent one, or it writes depth as though solid and
     * everything behind it disappears instead of showing through. That is why this touches
     * `transparent` rather than only storing a number.
     */
    setAlphaMultiplier(alphaMultiplier: number): void;
    updateSymmetryAtoms(): void;
    clearBuffers(): void;
    setTransformMatrix(transformMatrix: any): void;
}
export {};
//# sourceMappingURL=displayBuffer.d.ts.map