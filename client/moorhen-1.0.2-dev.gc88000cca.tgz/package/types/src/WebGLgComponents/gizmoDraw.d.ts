import { RootState } from '../store';
import { Store } from '@reduxjs/toolkit';
/**
 * The handles for one object.
 *
 * One buffer per axis rather than one for the whole gizmo, because colour is a per-instance
 * attribute: three buffers is what lets x, y and z be told apart. Within each, the arrow and the
 * ring are sections, so hovering lights the one under the pointer and its label says which it is.
 */
export declare const getGizmoBuffers: (store: Store<RootState>) => Promise<any>;
//# sourceMappingURL=gizmoDraw.d.ts.map