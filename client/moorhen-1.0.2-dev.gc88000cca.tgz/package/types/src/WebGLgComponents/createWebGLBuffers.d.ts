import { DisplayBuffer } from './displayBuffer';
export declare const createWebGLBuffers: (jsondata: any, idat: number, gl: any) => DisplayBuffer;
//# sourceMappingURL=createWebGLBuffers.d.ts.map