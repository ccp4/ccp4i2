/**
 * Where to point the shadow camera, and how much to cover with it.
 *
 * A shadow map is a fixed number of texels - 1024 to 4096 square here - spread over whatever area
 * the light's projection covers. Every ångström of that area the viewer cannot see is texels
 * thrown away, and the visible part gets coarser in proportion. So the only question that matters
 * is: what is the smallest box that still produces the right picture?
 *
 * WHAT WENT WRONG BEFORE
 *
 * The old extent was built from the whole structure rather than from the view:
 *
 *     const shadowExtent = Math.max(170.0, atom_span);
 *     let d = Math.min(48*self.zoom, atom_span)
 *     let excess = Math.abs(shadowExtent*tanA);
 *     d += excess;  d /= 2.0;  d = Math.max(d, 60.0)
 *
 * `d` starts out right - `48*zoom` is exactly the visible height - and is then swamped by
 * `excess`, the whole structure's span leaned over by the light angle. With the default light at
 * [25,25,50] that is 0.707 of it. A ribosome contributed about 177 Å of excess to a view perhaps
 * 25 Å across, so most of the map covered geometry nobody was looking at and the shadows in the
 * visible part came out in steps. A small structure escaped it only because the 170 floor was
 * smaller than a large structure's span - which is why the same code looked acceptable on a
 * ligand and poor on a ribosome.
 *
 * WHY THE EXCESS WAS THERE AT ALL
 *
 * It answers a real question: geometry outside the view can still cast into it, so the light must
 * see more than the camera does. The error is in which direction it reached. A caster outside the
 * view matters only if it lies between the light and something visible, so the frustum needs
 * extending **along the light axis** - the near plane pulled back. Widening it sideways, which is
 * what `excess` did, catches no caster the near plane would not, and only spends texels.
 *
 * WHY A BOX FIT IS STABLE HERE
 *
 * Fitting tightly to the visible box would normally make the frustum resize as the camera turns,
 * and a texel grid that keeps resizing under static geometry crawls. It does not happen here,
 * because Moorhen's light is defined in *eye* space - `rotX` is composed onto the view quaternion
 * rather than applied in world space - so the visible box and the light keep a fixed relative
 * orientation however the camera is turned. The fit is therefore both tight and steady.
 */
/** Half-extents of the visible region along the eye-space axes, in ångström. */
export interface VisibleRegion {
    /** Half the width of the screen in world units at the view centre. */
    halfWidth: number;
    /** Half the height. */
    halfHeight: number;
    /** Half the front-to-back thickness of the slab. */
    halfDepth: number;
}
/** The orthographic box to render the shadow map with. All distances in ångström. */
export interface ShadowFrustum {
    /** Half-extent across the shadow map's x axis. */
    halfWidth: number;
    /** Half-extent across its y axis. Kept separate from the width: padding one to match the
     *  other would only make that axis' texels coarser for nothing. */
    halfHeight: number;
    /** How far back from the view centre to put the light's eye. */
    eyeDistance: number;
    /** Near plane, far enough in front of the eye to be positive. */
    near: number;
    /** Far plane, just past the visible region. */
    far: number;
}
/**
 * The near plane's distance in front of the light's eye.
 *
 * Only has to be positive and clear of zero. Nothing is gained by making it small: the depth
 * range that matters runs from the nearest caster to the far side of the visible region, and that
 * is set by the radii, not by this.
 */
export declare const SHADOW_NEAR = 1;
/** Below this the frustum stops shrinking, so a very close view does not sharpen to nothing. */
export declare const MIN_HALF_EXTENT = 2;
/**
 * The light-space axes, taken from the rotation that carries eye space into light space.
 *
 * Column-major, as gl-matrix stores a mat4 and as `quatToMat4` returns one. A point is mapped by
 * `p_light = R · p_eye`, so the *rows* of R are the light-space axes written in eye coordinates -
 * row i being (m[i], m[i+4], m[i+8]). Getting this transposed would give a frustum fitted to the
 * wrong axes, which is why it lives in one place with a test on it rather than inline at the call
 * site.
 */
export declare function lightAxes(rotationColumnMajor: ArrayLike<number>): [[number, number, number], [number, number, number], [number, number, number]];
/**
 * Fit the light's orthographic frustum to what is actually visible.
 *
 * @param visible - the region the camera can see, in eye-space half-extents about the view centre.
 * @param casterRadius - radius of a sphere about the **view centre** containing everything that
 *     could cast a shadow. Used only to pull the near plane back far enough to catch casters
 *     outside the view; it deliberately does not widen the box.
 * @param axes - the light-space axes in eye coordinates, from {@link lightAxes}.
 */
export declare function fitShadowFrustum(visible: VisibleRegion, casterRadius: number, axes: readonly [readonly number[], readonly number[], readonly number[]]): ShadowFrustum;
/**
 * Radius of a sphere about `centre` containing the whole box.
 *
 * The box is the scene's bounding box and the centre is the view centre, which is usually not the
 * box's middle - you zoom in on one end of a long structure - so this is the distance to the
 * furthest corner, not half a diagonal.
 */
export declare function radiusAbout(centre: readonly [number, number, number], min: readonly [number, number, number], max: readonly [number, number, number]): number;
//# sourceMappingURL=shadowFrustum.d.ts.map