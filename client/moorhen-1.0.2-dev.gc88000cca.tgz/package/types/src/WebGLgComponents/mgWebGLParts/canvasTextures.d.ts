import type { MGWebGL } from '../mgWebGL';
/**
 * 2D-canvas text/circle rasterisation helpers. These draw a string (or a
 * ringed letter) into an offscreen 2D canvas so its pixels can be uploaded as
 * a WebGL texture. They are self-contained: they only touch the reusable
 * drawing contexts (`textCtx`, `circleCtx`, `extraFontCtxs`) and the
 * `*Initialized` flags on the MGWebGL instance, which stay there because the
 * texture-upload code reads their canvases. Only the drawing logic moves here.
 * `self` is the live MGWebGL instance (type-only import avoids a runtime cycle).
 */
export declare function makeCircleCanvas(self: MGWebGL, text: any, width: any, height: any, circleColour: any): void;
export declare function makeTextCanvas(self: MGWebGL, text: string, width: number, height: number, textColour: string, font?: string): [number, CanvasRenderingContext2D];
//# sourceMappingURL=canvasTextures.d.ts.map