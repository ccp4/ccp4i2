import type { MGWebGL } from '../mgWebGL';
/**
 * Uniform-buffer-object (UBO) setup for the WebGL2 post-processing shaders:
 * the separable Gaussian blur passes and SSAO. These build/upload the coeff
 * and kernel UBOs from the shader-program reflection data. Self-contained: they
 * read the shader programs, `gl`, `WEBGL2` and the SSAO kernel/buffer fields off
 * the MGWebGL instance and (for SSAO) call back through `self.lerp`; those
 * fields and the buffers stay on the instance because the draw pipeline reads
 * them. Only the setup logic moves here. `self` is the live MGWebGL instance
 * (type-only import avoids a runtime cycle).
 */
export declare function makeBlurBuffers(self: MGWebGL, blurSize: any): void;
/**
 * How long the i'th occlusion sample is, as a fraction of the radius the user set.
 *
 * Stratified over the kernel, so the 32 samples cover the radius range evenly instead of clustering
 * wherever the random numbers happen to fall. The half-step keeps the first sample off zero.
 *
 * One length scaling, not two. This used to scale by Math.random() as well as by the stratified
 * term, which compounded: the median sample ended up at 0.12 of the radius and 43% of the kernel
 * sat within 0.1 of it. The slider then could not mean what it said - at the 2.0 angstrom default
 * the typical probe reached 0.24 angstroms, so on anything larger than a small ligand the
 * hemisphere never left the surface it started on, and the whole pass did almost nothing.
 *
 * Pure and exported so the distribution can be asserted on directly; it is the part that was wrong,
 * and it is invisible in any screenshot.
 */
export declare function ssaoSampleLength(i: number, kernelSize?: number): number;
export declare function initializeSSAOBuffers(self: MGWebGL): void;
export declare function bindSSAOBuffers(self: MGWebGL): void;
//# sourceMappingURL=postProcessUniformBuffers.d.ts.map