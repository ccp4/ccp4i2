import { webGL } from '../../types/mgWebGL';
import type { MGWebGL } from '../mgWebGL';
/**
 * The low-level buffer-draw helpers - bind instance/vertex attribute arrays
 * and issue draw calls for a single buffer, plus the interactive/PMV
 * transform-matrix draw wrappers - moved out of MGWebGL (following the
 * viewTransforms/framebuffers/overlays pattern). Rendering state,
 * applySymmetryMatrix and setLightUniforms stay on the instance, reached
 * through the explicit `self` parameter.
 */
export declare function drawBuffer(self: MGWebGL, theBuffer: any, theShaderIn: webGL.MGWebGLShader | webGL.ShaderTrianglesInstanced, j: number, vertexType: number, specialDrawBuffer?: any): void;
export declare function drawMaxElementsUInt(self: MGWebGL, vertexType: any, numItems: any): void;
export declare function setupModelViewTransformMatrixInteractive(self: MGWebGL, transformMatrix: any, transformOrigin: any, buffer: any, shader: any, vertexType: any, bufferIdx: any, specialDrawBuffer: any): void;
export declare function drawTransformMatrixInteractive(self: MGWebGL, transformMatrix: number[], transformOrigin: number[], buffer: any, shader: webGL.MGWebGLShader, vertexType: number, bufferIdx: number, specialDrawBuffer?: number): void;
export declare function drawTransformMatrix(self: MGWebGL, transformMatrix: number[], buffer: any, shader: any, vertexType: number, bufferIdx: number, specialDrawBuffer?: any): void;
export declare function drawTransformMatrixInteractivePMV(self: MGWebGL, transformMatrix: number[], transformOrigin: number[], buffer: any, shader: any, vertexType: number, bufferIdx: number): void;
export declare function drawTransformMatrixPMV(self: MGWebGL, transformMatrix: number[], buffer: any, shader: any, vertexType: number, bufferIdx: number): void;
//# sourceMappingURL=bufferDraw.d.ts.map