import * as quat4 from 'gl-matrix/quat';
import type { MGWebGL } from '../mgWebGL';
import type { CameraTarget, MoveResult, Transition } from '../cameraController';
/**
 * Where the renderer meets the camera: the clock, the pump, and the entry points that ask for a
 * move.
 *
 * This file used to be seven tweening loops. Each held its own interpolation state and recursed
 * through requestAnimationFrame, and they differed only in which of the four fields they touched -
 * which is the whole argument for a partial target: most of the sprawl was one optional field
 * written out seven times. What remains is `advanceCamera`, which tells the camera what time it
 * is; `pumpCamera`, which keeps asking for frames while there is something to advance; and
 * `moveCameraTo`, which takes the transition as an argument rather than assuming one.
 *
 * The spin test is still its own loop, because it is a different thing: an endless rotation with
 * no destination, which the camera has no concept of yet.
 *
 * `self` is the live MGWebGL instance (type-only import avoids a runtime cycle).
 */
/**
 * How long a centring move takes.
 *
 * The old loop counted 15 frames, which is a quarter of a second at 60 Hz and longer than that on
 * a scene that draws slowly. This is a quarter of a second of wall-clock time whatever the frame
 * rate, dropping frames instead of stretching. Same length when the scene is fast, consistent when
 * it is not.
 */
export declare const CENTRING_SECONDS = 0.25;
/**
 * Advance the camera to the moment this frame represents. Called by drawScene, before it draws.
 *
 * `moving` is two field tests, so an idle scene pays nothing and the wall clock is not even read.
 *
 * THE CLOCK IS AN ARGUMENT, AND THAT IS THE POINT
 *
 * It is the whole reason a live preview and a movie export can share this path. The live app passes
 * wall-clock time, so a slow frame means the camera has moved further by the time it is drawn - the
 * move keeps its duration and loses frames, which is what a person watching wants. An export sets
 * `cameraTime` to i/fps before asking for each frame, so nothing is dropped however long rendering
 * took, and the file runs at the speed it was authored at. Same camera, same arithmetic, different
 * clock. Discovering that distinction empirically cost a day; it is one line here.
 */
export declare function advanceCamera(self: MGWebGL): void;
/**
 * Keep asking for frames while the camera is moving.
 *
 * The camera itself has no loop: drawScene advances it, so something has to keep calling drawScene
 * for as long as there is anything to advance. That is all this is. It is reentrancy-guarded by
 * `cameraPumpHandle` so that two overlapping requests do not pump the scene at twice the rate.
 *
 * A movie export does not use it — the export owns its clock and asks for each frame itself, which
 * is the answer to "who ticks during an export": the renderer always does, and the export decides
 * when a frame happens and what time it happens at.
 */
export declare function pumpCamera(self: MGWebGL): void;
/** Stop the pump. Called on unmount; harmless if nothing is pumping. */
export declare function stopPumpingCamera(self: MGWebGL): void;
/**
 * Put the camera somewhere, over whatever time the caller asks for.
 *
 * This is the operation that did not exist before: `{ kind: "instant" }` sets the camera without
 * animating to it, which is what a movie, a session restore and an API caller all actually want.
 * Animation is now an argument rather than a precondition.
 *
 * IT DEFERS TO OTHERS, AND SUPERSEDES ITSELF
 *
 * Its only caller today is MoorhenWebMG's reconciling effect, which cannot tell "the user asked to
 * centre here" from "the store and the renderer have drifted apart". So it declines while somebody
 * *else* is driving: a movie running means the *store* is out of date, not that the camera is
 * wrong. That is the same judgement the old `if (self.animating) return` made, and the same one
 * `settle` makes in the controller.
 *
 * A centring move already in flight is the one case that is not deference but self-conflict, and it
 * supersedes instead. Declining there was a quiet way to lose a view: nothing retries a declined
 * move, and the effect that asked only re-fires when the stored camera changes again, so the scene
 * stayed where the previous move left it until the user happened to touch the mouse. A molecule
 * centred twice inside the quarter-second a move takes - which is what loading one does - therefore
 * drew nothing at all until the camera was wiggled, and the second centring was the one that
 * mattered. Between two requests from the same source the later one is simply the better one.
 *
 * `animating` is not consulted. It used to be, because a movie had no way to say it owned the
 * camera and set that flag by hand instead; a movie acquires a driver now, so asking who is
 * driving is the whole question. The flag is still written below - the superseding rule needs to
 * know whether a move is the one that still holds the camera - but nothing decides anything from
 * it any more, which is why it can mean one thing rather than two.
 */
export declare function moveCameraTo(self: MGWebGL, target: CameraTarget, transition: Transition): Promise<MoveResult>;
export declare function doSpinTestFrame(self: MGWebGL): void;
export declare function startSpinTest(self: MGWebGL): void;
export declare function stopSpinTest(self: MGWebGL): void;
export declare function setOrientationAndZoomAnimated(self: MGWebGL, q: any, z: any): void;
export declare function setOrientationAnimated(self: MGWebGL, q: any): void;
export declare function setViewAnimated(self: MGWebGL, o: any, q: any, z: any): void;
/**
 * Centre, orient and zoom, smoothly. The move the user sees whenever anything re-centres the view.
 *
 * Its observable contract is unchanged: it declines while something else is driving, it ends at the
 * target, and on arrival it calls handleOriginUpdated and dispatches `zoomChanged`, which is what
 * autoClipFogByZoom and the map recontouring hang off. What changed is underneath — fifteen
 * recursive requestAnimationFrame calls holding their own interpolation state have become one move
 * held by the camera, advanced by drawScene.
 *
 * TWO DIFFERENCES WORTH NAMING, BOTH DELIBERATE
 *
 * The motion now eases in and out instead of running at constant speed, because it is sampled by
 * the same code that samples a movie, and that code eases. On a quarter-second move it reads as a
 * slightly softer landing.
 *
 * And the duration is now wall-clock rather than a frame count, so a heavy scene gets a move of the
 * same length with fewer frames in it, rather than a longer move.
 */
export declare function setOriginOrientationAndZoomAnimated(self: MGWebGL, o: number[], q: quat4, z: number): void;
export declare function setOriginAndZoomAnimated(self: MGWebGL, newOrigin: [number, number, number], newZoom: number): void;
/**
 * Move the view centre.
 *
 * The parameter is the destination, despite its name: the old implementation computed its delta as
 * `calculateOriginDelta(oldOrigin, self.origin, 1)`, which is destination minus current, and then
 * walked from the current origin along it. Named for what it is here, since nothing depends on the
 * old name and the old one was simply wrong.
 *
 * Its duration scaled with distance - between five and fifteen frames - and that is kept, now in
 * seconds. Short hops stay quick.
 */
export declare function setOriginAnimated(self: MGWebGL, target: number[]): void;
export declare function setZoomAnimated(self: MGWebGL, newZoom: number): void;
//# sourceMappingURL=cameraAnimations.d.ts.map