/**
 * Turning the view slab into projection near and far planes.
 *
 * Moorhen's front and back clipping is a depth slab, expressed as two view-aligned planes
 * (0,0,-1,d0) and (0,0,1,d1) in eye space. A fragment is kept when
 *
 *     dot(eyePos, clipPlane0) >= 0   i.e.   z <= d0
 *     dot(eyePos, clipPlane1) >= 0   i.e.   z >= -d1
 *
 * which is simply the range -d1 <= z <= d0. gl-matrix's ortho and perspective both make eye z
 * visible over [-far, -near], so that range is near = -d0, far = d1 - the slab IS the near and
 * far planes, and nothing in a fragment shader needs to re-derive it.
 *
 * The orthographic path has always done this. The perspective path did not: it used a fixed
 * near 100 / far 1270 and left the slab entirely to per-fragment discards, which cost the whole
 * program its early depth rejection and gave the depth buffer a range ten times wider than the
 * geometry needed.
 *
 * The one real difference between the two is that a perspective near plane must be strictly
 * positive - the projection divides by it - while an orthographic one may sit anywhere,
 * including behind the eye. So perspective can be forced to clamp, and when it does the
 * projection no longer describes the slab and the shader discards become load-bearing again.
 * That is what `exact` reports: callers use it to decide whether the discard-free shaders are
 * safe, rather than assuming they always are.
 */
/**
 * Smallest perspective near plane we will ask for.
 *
 * Only reached when the user pulls the front clip to or behind the eye point, which is a
 * degenerate view rather than a normal one. Depth precision in a perspective projection is
 * governed by the near plane, so a very small value here would spend most of the depth buffer
 * on the first few units; it is a floor to keep the matrix valid, not a value to aim for, and
 * reaching it sets `exact` to false.
 */
export declare const MIN_PERSPECTIVE_NEAR = 1;
export interface SlabRange {
    near: number;
    far: number;
    /**
     * Whether near and far describe the slab exactly.
     *
     * False when the values had to be adjusted to keep the projection valid. The picture is
     * still correct in that case - the shader discards enforce the slab - but it is no longer
     * true that the hardware alone clips it, so the discard-free shader variants must not be
     * used.
     */
    exact: boolean;
}
/**
 * Near and far for the current slab.
 *
 * @param clipPlane0W  the w component of the front plane, (0,0,-1,w)
 * @param clipPlane1W  the w component of the back plane, (0,0,1,w)
 * @param fogEnd       fog cuts geometry off no later than the back plane does, and the
 *                     orthographic path has always taken the nearer of the two
 * @param perspective  whether the projection divides by the near plane
 */
export declare const slabNearFar: (clipPlane0W: number, clipPlane1W: number, fogEnd: number, perspective: boolean) => SlabRange;
/** Half the orthographic view height at zoom 1, in world units. Matches the mat4.ortho extents. */
export declare const ORTHO_HALF_HEIGHT = 24;
/** The perspective field of view Moorhen uses, in radians. */
export declare const PERSPECTIVE_FOV = 1;
/** How close and how far the eye may be placed from the view centre, in angstroms. */
export declare const MIN_EYE_DISTANCE = 50;
export declare const MAX_EYE_DISTANCE = 1000;
/**
 * The divisor applied to the perspective projection's x and y scale.
 *
 * Long carried as an unexplained 5.7. It is the number that makes a perspective view frame the
 * same thing an orthographic one does at the view centre:
 *
 *     eyeDistance * tan(PERSPECTIVE_FOV / 2) / ORTHO_HALF_HEIGHT
 *
 * which at the historical eye distance of 250 gives 5.690.
 *
 * It takes the eye distance rather than a constant because that distance is what sets how strongly
 * a perspective view converges, and it is adjustable. Deriving the divisor from it holds the
 * framing still at the view centre while the convergence changes - a dolly zoom. With the divisor
 * fixed instead, moving the eye would simply rescale the picture.
 *
 * Note what this is *not*: a field-of-view control. At a fixed eye distance with the framing held,
 * the field of view cancels out of the projection entirely - the tan in mat4.perspective against
 * the tan here - and changing it does nothing whatsoever. Only the eye distance moves the
 * geometry, which is why PERSPECTIVE_FOV stays a constant.
 */
export declare const perspectiveScale: (eyeDistance: number) => number;
/** What perspectiveScale was fixed at before the field of view could be changed. */
export declare const PERSPECTIVE_SCALE = 5.7;
/**
 * Half the view extents at a given depth, for turning a cursor position into a world ray.
 *
 * Orthographic extents do not depend on depth, which is why the picking code could get away with
 * a single pair of numbers for years. Perspective extents grow with distance from the eye, so a
 * ray built from one pair is wrong everywhere except the depth that pair happened to describe -
 * and picking, hover, measurement and gizmo dragging all build their ray this way.
 *
 * @param depth  distance in front of the eye, i.e. fogClipOffset plus the slab offset
 * @param eyeDistance  the distance the two projections are made to agree at
 */
export declare const pickHalfExtents: (depth: number, zoom: number, aspect: number, perspective: boolean, eyeDistance?: number) => {
    halfWidth: number;
    halfHeight: number;
};
/**
 * The aspect ratio a projection should use, from the viewport it will actually draw into.
 *
 * Not the canvas. In side-by-side stereo each eye draws into half the width, and in three-way
 * or multiview into a tile, so a projection built from the canvas is stretched by exactly the
 * factor the viewport was divided by. The orthographic path got this right by folding
 * `ratioMult` into its extents; the perspective path used `gl.viewportWidth / gl.viewportHeight`
 * and so was wrong in every mode except plain single-view.
 *
 * @param viewport  as GL takes it: [x, y, width, height]
 */
export declare const viewportAspect: (viewport: ArrayLike<number> | null | undefined) => number;
/**
 * The clip plane w values after the eye has moved by `delta` towards or away from the scene.
 *
 * set_clip_range stores the planes as absolute distances from the eye, so moving the eye without
 * moving them leaves the slab behind and slices the molecule open. Shifting both by the same amount
 * keeps the slab where it was relative to the view centre, which is where the user put it.
 */
export declare const clipPlanesAfterEyeMove: (clipPlane0W: number, clipPlane1W: number, delta: number) => {
    clipPlane0W: number;
    clipPlane1W: number;
};
/**
 * The clip slab expressed as offsets from the view centre, negative towards the viewer.
 *
 * slabNearFar returns distances from the eye, which is what a projection matrix wants. Anything
 * positioned relative to what the user is looking at - the focal plane, the side-on widget's
 * handles - wants them relative to the centre of the view instead. Both ends are the same
 * subtraction; neither is negated.
 *
 * The negation is worth warning about, because the obvious reading of the code says otherwise.
 * set_clip_range stores `gl_clipPlane0[3] = -fogClipOffset - clipStart`, which looks as though a
 * larger clipStart pushes the near plane further away. It does not: MoorhenWebMG calls it as
 * `set_clip_range(-clipStart, clipEnd)`, negating the near distance on the way in. So the stored w
 * is `-fogClipOffset + clipStart`, slabNearFar's near is `fogClipOffset - clipStart`, and the near
 * plane sits clipStart *in front of* the centre - which is what the side-on widget has always
 * drawn and what execAutoClipFogByZoom means by setting clip and fog from one fieldDepthFront.
 */
export declare const slabOffsets: (near: number, far: number, fogClipOffset: number) => {
    nearOffset: number;
    farOffset: number;
};
/**
 * Where a focal plane given in angstroms falls as a fraction of the slab, 0 at the near plane and
 * 1 at the far one.
 *
 * This is the one conversion the depth blur needs, and it runs in a single direction: the stored
 * setting is a distance, and the shaders want a depth-buffer value, so the renderer converts.
 *
 * The setting is a distance rather than a fraction because a fraction needs something to be a
 * fraction of, and nothing on offer is stable. It was once a fraction of the side-on widget's
 * plot, which moved whenever that widget's scale did. Making it a fraction of the slab instead
 * only moved the problem: switching Clip off sets the slab to 1.5 * the scene span in each
 * direction, so the whole useful range of the control collapsed into a few percent near the
 * middle, and a value saved with Clip on meant something else entirely with Clip off.
 *
 * An angstrom is an angstrom under every one of those.
 */
export declare const focalPlaneFraction: (offset: number, nearOffset: number, farOffset: number) => number;
/**
 * The depth-buffer value a focal plane given in angstroms corresponds to.
 *
 * The blur shaders sample the depth buffer and compare against this, so it has to be in the
 * buffer's own terms - and those differ between the two projections.
 *
 * Orthographic writes depth linearly across the slab, so the fraction of the distance is the
 * answer. Perspective divides by distance, so equal steps in angstroms are not equal steps in the
 * buffer: it spends most of its range close to the near plane. The exact relation for the matrix
 * gl-matrix builds is
 *
 *     z = far * (d - near) / (d * (far - near))
 *
 * which is 0 at the near plane and 1 at the far one, as the linear form is, but bows between them.
 * Sending the linear fraction under perspective put the plane a few angstroms nearer the viewer
 * than asked - about 3 angstroms out of a 60 angstrom slab, worst around the middle where people
 * actually put it.
 *
 * `offset` is measured from the view centre, which sits at fogClipOffset from the eye because the
 * modelview matrix is translated by -fogClipOffset before anything is drawn.
 */
export declare const focalPlaneDepth: (offset: number, near: number, far: number, fogClipOffset: number, perspective: boolean) => number;
//# sourceMappingURL=projection.d.ts.map