import type { MGWebGL } from '../mgWebGL';
/**
 * HUD / overlay draws for the MGWebGL canvas: crosshairs, mouse-track, FPS
 * meter, and the text / line / label / circle / textured-shape overlays that
 * sit on top of the 3D scene. These were methods on MGWebGL and have been
 * moved here (following the viewTransforms/framebuffers/eventHandlers pattern).
 * All rendering state and the shared setMatrixUniforms helper stay on the
 * instance, reached through the explicit `self` parameter.
 */
export declare function drawTransparent(self: MGWebGL, theMatrix: any): void;
export declare function drawImagesAndText(self: MGWebGL, invMat: any): void;
export declare function drawTexturedShapes(self: MGWebGL, invMat: any): void;
export declare function drawTextLabels(self: MGWebGL, up: any, right: any): void;
export declare function drawDistancesAndLabels(self: MGWebGL): void;
export declare function drawCircles(self: MGWebGL, up: any, right: any): void;
export declare function drawLineMeasures(self: MGWebGL, invMat: any): void;
export declare function drawCrosshairs(self: MGWebGL, invMat: any, ratioMult?: number): void;
export declare function drawMouseTrack(self: MGWebGL): void;
export declare function drawFPSMeter(self: MGWebGL): void;
export declare function drawTextOverlays(self: MGWebGL, invMat: any, ratioMult?: number, font_scale?: number): void;
//# sourceMappingURL=overlays.d.ts.map