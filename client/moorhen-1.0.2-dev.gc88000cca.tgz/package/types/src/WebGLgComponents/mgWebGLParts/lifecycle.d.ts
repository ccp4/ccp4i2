import { MGWebGL } from '../mgWebGL';
/**
 * componentDidMount, decomposed into ordered phases. The mount used to be one
 * ~450-line method; splitting it into named steps makes the startup sequence
 * legible — which is the point, since the React lifecycle here (a class
 * component driving a WebGL canvas, with no teardown yet) is what we want to
 * scrutinise next.
 *
 * The phases run in this exact order (see MGWebGL.componentDidMount):
 *   1. initInstanceState   — default every instance field (state, matrices, clip planes)
 *   2. initGraphicsContext — create the GL context + the view-transform layouts
 *   3. attachCanvasListeners — wire up all mouse / touch / wheel / key listeners (once)
 *   4. initGraphics        — extensions, shaders, framebuffers, buffers, textures, first draw
 *
 * Order matters and is preserved verbatim from the original. `self` is the live
 * MGWebGL instance (type-only-ish import; initGL is a real runtime import).
 */
/** Phase 1 — default every instance field. Runs before the GL context exists. */
export declare function initInstanceState(self: MGWebGL): void;
/** Phase 2 — create the WebGL context and the stereo / three-way view layouts. */
export declare function initGraphicsContext(self: MGWebGL): void;
/** Phase 3 — attach all canvas mouse / touch / wheel / key listeners, once. */
export declare function attachCanvasListeners(self: MGWebGL): void;
/** Phase 4 — extensions, shaders, framebuffers, buffers, textures, first draw. */
export declare function initGraphics(self: MGWebGL): void;
//# sourceMappingURL=lifecycle.d.ts.map