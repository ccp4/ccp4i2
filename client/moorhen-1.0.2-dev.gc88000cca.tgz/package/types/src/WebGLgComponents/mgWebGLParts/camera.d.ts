import * as quat4 from 'gl-matrix/quat';
import { CameraController } from '../cameraController';
export declare class Camera {
    /**
     * The camera controller. The handle later slices reach for: `glRef.current.cameraController`.
     */
    readonly controller: CameraController;
    constructor();
    /** Rotation quaternion. The live object: MGWebGL mutates it in place. */
    get quat(): quat4;
    set quat(q: quat4);
    /**
     * Zoom factor.
     *
     * Written through the controller rather than straight into the state, because the slab follows
     * zoom under the auto policy and the two must not be allowed to disagree even briefly. Every
     * `self.zoom = x` in the renderer therefore re-derives clip and fog, which is what makes the
     * old zoomChanged -> autoClipFogByZoom -> store -> set_clip_range round trip unnecessary.
     */
    get zoom(): number;
    set zoom(z: number);
    /** Rotation / translation centre in world coordinates. Negated, per setOrigin's convention. */
    get origin(): [number, number, number];
    set origin(o: [number, number, number]);
    /**
     * Distance from the eye to the view centre; fog and the clip planes are offset by it.
     *
     * The controller calls this `eyeDistance`, which is what it is. The old name stays on this
     * side of the seam until the call sites move.
     */
    get fogClipOffset(): number;
    set fogClipOffset(v: number);
}
//# sourceMappingURL=camera.d.ts.map