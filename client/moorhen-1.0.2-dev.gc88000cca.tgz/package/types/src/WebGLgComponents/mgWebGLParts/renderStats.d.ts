/**
 * Counting what a frame actually costs, so that optimisation is aimed at a number.
 *
 * This exists because three plausible explanations for a slow frame - fill rate, per-draw call
 * overhead, and vertex processing - look identical from outside the renderer, and a fourth
 * possibility is that the time is not in the renderer at all. Measuring separates them in a way
 * that resizing the window and toggling features does not.
 *
 * Off by default and installed on demand. When it is off nothing here runs at all: the GL methods
 * are untouched, so there is no per-call cost and no chance of the measurement changing what it
 * measures.
 *
 * Turning it off restores what was there before, rather than deleting the wrapper and trusting
 * the prototype to show through. That distinction matters twice: a context someone else has
 * already wrapped - a debugger such as Spector.js - would otherwise lose their wrapper instead of
 * getting mine removed, and a context whose methods are own-properties rather than inherited
 * would be left with nothing at all.
 *
 * The three numbers to read together:
 *
 *   drawScene ms against the frame interval. If drawScene is a small part of the frame then the
 *   renderer is not the problem and the time is in React, event handling or scheduling - a
 *   different investigation entirely.
 *
 *   state calls per draw. Moorhen sets around a hundred pieces of GL state per sub-buffer and uses
 *   no vertex array objects, so a high draw count means the CPU is mostly talking to the driver.
 *   That is what vertex array objects and uniform buffers would fix.
 *
 *   triangles per frame. If draws are few but triangles are many, the cost is vertex processing
 *   and the answer is level of detail rather than anything about call overhead.
 *
 * What this cannot tell you is GPU time: a WebGL call returns once the command is queued, not once
 * it is done. If the four numbers look small and do not add up to the frame interval, that is the
 * answer - the GPU is the bottleneck - and EXT_disjoint_timer_query_webgl2 is the next instrument.
 */
export declare const renderStats: {
    enabled: boolean;
    /** Accumulated since the last report, then zeroed. */
    frames: number;
    drawCalls: number;
    triangles: number;
    stateCalls: number;
    drawSceneMs: number;
    /** Nanoseconds the GPU spent, and how many frames that covers. */
    gpuNs: number;
    gpuFrames: number;
    /** Whether to block until the GPU finishes each frame, and what that cost. */
    syncGpu: boolean;
    gpuWaitMs: number;
    gpuWaitFrames: number;
    /**
     * Results the driver marked disjoint and which were therefore thrown away.
     *
     * Counted rather than silently dropped. Without this, "the extension is missing" and "the
     * extension works but every result is unusable" both show up as no GPU figure at all, which
     * is how an afternoon gets spent on the wrong question.
     */
    gpuDisjointFrames: number;
};
type Gl2 = WebGL2RenderingContext;
export declare const beginGpuTimer: (gl: Gl2) => void;
export declare const endGpuTimer: (gl: Gl2) => void;
/**
 * Wait for the GPU to finish, and report how long that took.
 *
 * For Firefox, which does not expose EXT_disjoint_timer_query_webgl2 - it was withdrawn over
 * timing-attack concerns - leaving no way to ask the GPU how long it took. This asks a different
 * question that gets at the same thing: having submitted the frame, how long before it is done?
 *
 * Read it against drawScene and the frame interval. A long wait means the GPU is the bottleneck
 * and the main thread was idle waiting for it. A short wait means the GPU finished promptly and
 * the rest of the frame went somewhere else entirely.
 *
 * Deliberately a separate switch, because it is not free: it serialises the CPU against the GPU
 * and destroys any overlap between them, so the frame rate while it is on is worse than the real
 * one. It is a diagnostic for one question, not a mode to leave running.
 *
 * finish() rather than a fence, which was the first attempt and was worse than useless. A fence
 * on the main thread can only be waited on with a zero timeout, so the only way to wait is to ask
 * again and again - and hammering clientWaitSync costs real time per call and can keep the driver
 * from making progress. The first reading that way was 125 ms of "GPU wait" on a frame that takes
 * 28 ms without the sync, which is impossible: it was measuring the polling loop. finish() blocks
 * in the driver instead, which is one call and no spinning.
 */
export declare const waitForGpu: (gl: Gl2) => void;
/**
 * Wrap the counted methods on one context.
 *
 * Idempotent: a second call does nothing, so this cannot end up counting each call twice through
 * a stack of wrappers.
 */
export declare const instrumentGl: (gl: WebGLRenderingContext) => void;
/** Put the context back exactly as it was. */
export declare const uninstrumentGl: (gl: WebGLRenderingContext) => void;
export declare const resetRenderStats: () => void;
/**
 * Which representation the triangles belong to.
 *
 * "1.1M triangles" is a true number with nowhere to go: the draw loop sees a flat list of
 * buffers and cannot say which of them is the ribbons and which the surface. This attributes
 * the geometry back to whatever made it, so that "too many triangles" becomes a specific
 * representation with a specific setting behind it.
 *
 * Counted from the buffers rather than hooked into the draw loop. That keeps the hot path
 * untouched and costs nothing when nobody asks, and it answers the question actually being
 * asked - how much geometry is there, and whose - rather than how many times it was drawn.
 *
 * The price is that this is a model of the draw loop, not an observation of it, and a model
 * can be wrong. Two known gaps, both reported rather than hidden:
 *
 *   Spheres (POINTS_SPHERES, SPHEROIDS) draw a shared sphere mesh once per sphere, so their
 *   triangle count lives on a buffer this function never sees. They are counted as unknown.
 *
 *   A buffer drawn more than once per frame - a shadow pass, an outline - is counted once.
 *
 * Which is why the caller is given the instrumented per-frame figure alongside it. If the two
 * agree, the model holds and the attribution can be trusted; if they do not, the difference is
 * itself the finding, and it is visible rather than silently folded into one of the rows.
 */
export interface TriangleRow {
    label: string;
    triangles: number;
    buffers: number;
    /** Sub-buffers whose triangle count cannot be determined from the buffer alone. */
    unknown: number;
}
/** Shape this needs from a display buffer. Deliberately minimal, so it is testable without one. */
export interface CountableBuffer {
    visible?: boolean;
    statsLabel?: string;
    bufferTypes?: string[];
    triangleVertexIndexBuffer?: {
        numItems?: number;
    }[];
    triangleInstanceOriginBuffer?: {
        numItems?: number;
    }[];
}
export declare const triangleBreakdown: (buffers: CountableBuffer[]) => TriangleRow[];
/**
 * The breakdown as lines of text, with the measured per-frame total to check it against.
 *
 * measuredPerFrame is the instrumented figure - renderStats.triangles over renderStats.frames -
 * or undefined when the instrument is off, in which case there is nothing to check against and
 * the report says so rather than implying agreement.
 */
export declare const triangleBreakdownText: (buffers: CountableBuffer[], measuredPerFrame?: number) => string;
/**
 * Triangles per frame as measured, without zeroing the counters.
 *
 * Separate from renderStatsText, which reads and resets together. This is read out of band by
 * the breakdown, and stealing the overlay's accumulated frames to do so would make the next
 * overlay line an average over a fraction of its interval.
 */
export declare const measuredTrianglesPerFrame: () => number | undefined;
/** One frame's worth, added by drawScene. */
export declare const recordFrame: (drawSceneMs: number) => void;
/**
 * A line for the overlay, or "" when not instrumented.
 *
 * Per frame rather than per second, because the question is what one frame costs. Reading and
 * zeroing together, so the numbers are an average over the reporting interval rather than over
 * the whole session.
 */
export declare const renderStatsText: () => string;
export {};
//# sourceMappingURL=renderStats.d.ts.map