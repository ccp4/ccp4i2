import type { MGWebGL } from '../mgWebGL';
import type { webGL } from "../../types/mgWebGL";
/**
 * Framebuffer / offscreen-buffer setup. These methods create and resize the
 * WebGL framebuffer objects used by the render pipeline (silhouette, edge
 * detect, gbuffers, SSAO, simple blur, depth peel, generic offscreen, texture).
 * They are self-contained: no cross-calls, no shader-init dependencies. The
 * buffer/framebuffer fields stay on the MGWebGL instance (the draw pipeline
 * reads them); only the setup logic moves here. `self` is the live instance.
 */
export declare function recreateSilhouetteBuffers(self: MGWebGL): void;
export declare function createEdgeDetectFramebufferBuffer(self: MGWebGL, width: number, height: number): void;
export declare function createGBuffers(self: MGWebGL, width: number, height: number): void;
export declare function createSSAOFramebufferBuffer(self: MGWebGL): void;
export declare function createSimpleBlurOffScreeenBuffers(self: MGWebGL): void;
/**
 * Release every depth-peel layer.
 *
 * Gathered here because the layers are now rebuilt whenever the size or the count changes, and
 * freeing five arrays by hand at each call site is how one of them gets forgotten. GL objects
 * are not reclaimed with their JavaScript handles, so a missed delete is a leak that only shows
 * up as memory pressure much later.
 */
export declare function deleteDepthPeelBuffers(self: MGWebGL): void;
/**
 * Multisampling for the opaque peel layer.
 *
 * As soon as anything in the scene is transparent, the whole scene is drawn through the depth-peel
 * layers instead of straight to the canvas, and those layers are ordinary single-sample textures.
 * So making one object transparent switched antialiasing off for everything else - most visibly
 * on map mesh, which is a mass of one-pixel lines. The FXAA in the compositing shader could not
 * make up for it: it only runs where the layer drew something, so it can never add coverage to
 * the pixels beside a line, which is the whole of what antialiasing a thin line means.
 *
 * Only the opaque layer is multisampled. It holds nearly everything on screen, and is drawn exactly
 * once, so it costs about what the canvas's own multisampling costs when nothing is transparent.
 * The transparent layers stay single-sample: they are composited at partial opacity, where aliasing
 * shows far less, and multisampling them too would multiply the cost by the layer count.
 */
/** Memory allowed for the multisampled opaque layer, colour and depth over all samples. */
export declare const PEEL_MSAA_BUDGET_BYTES: number;
/** What browsers give the canvas by default. More costs fill rate without being visible. */
export declare const PEEL_MSAA_MAX_SAMPLES = 4;
/**
 * How many samples to give the opaque peel layer at this size, or 0 for none.
 *
 * Bounded by memory as well as by the hardware, because the layers follow the render target: on
 * screen that is the canvas, around 90 MB at 4 samples on a large Retina window, but a 4096x4096
 * capture would want over 500 MB at 4 samples on top of the capture buffers themselves, so it gets
 * 2. Past the budget the count drops, and below 2 there is no point multisampling at all.
 *
 * @param supported sample counts the implementation supports for both formats, in any order.
 */
export declare function peelResolveSamples(width: number, height: number, supported: readonly number[]): number;
export declare function deleteDepthPeelResolveBuffer(self: MGWebGL): void;
/**
 * Make sure the multisampled opaque-layer buffer exists at this size, and say whether it can be
 * used. False means draw layer 0 single-sample as before: WebGL1, too large for the budget, or an
 * implementation that will not build it. A failed build is remembered for that size so it is not
 * retried every frame.
 */
export declare function ensureDepthPeelResolveBuffer(self: MGWebGL, width: number, height: number): boolean;
/**
 * Resolve the multisampled opaque layer into a peel layer's colour and depth textures.
 *
 * The depth resolve keeps one sample per pixel, chosen by the implementation. That only matters at
 * silhouette edges, where it decides by a pixel whether transparent geometry counts as behind the
 * opaque surface - the same choice a single-sample layer would have made anyway.
 */
export declare function resolveDepthPeelResolveBuffer(self: MGWebGL, target: webGL.MGWebGLFrameBuffer): void;
/**
 * Allocate the depth-peeling layers, or reuse them if they already match.
 *
 * Rebuilt whenever the size or the number of layers changes, which the old version could not
 * do: it returned early whenever any buffers existed at all, so a window resize left the layers
 * at whatever size the window happened to be when transparency was first switched on.
 *
 * @param layers how many peels. One per depth of transparent surface the scene needs resolved;
 *               several contour levels of the same field want more than a single surface does.
 */
export declare function recreateDepthPeelBuffers(self: MGWebGL, width: any, height: any, layers?: number): void;
/**
 * Whether the off-screen buffers need rebuilding before they can be drawn into at this size.
 *
 * Pure, and separate from the GL work, because the condition is the part that was wrong. The draw
 * path asked only "are they ready", and resize() rebuilt them only when depth blur was already
 * switched on. So resizing the canvas with blur off - which includes opening a side panel, since
 * that narrows the canvas - left buffers at the old size, still flagged ready. Switching blur on
 * then rendered the scene into a framebuffer of the wrong shape and the picture came out squashed.
 *
 * Comparing the dimensions catches that however the size changed, including routes that never
 * reach resize() at all.
 */
export declare function offScreenBuffersStale(ready: boolean, framebuffer: {
    width?: number;
    height?: number;
} | null | undefined, width: number, height: number): boolean;
/** Rebuild the off-screen buffers if they are missing, not ready, or the wrong size. */
export declare function ensureOffScreeenBuffers(self: MGWebGL, width: number, height: number): void;
export declare function recreateOffScreeenBuffers(self: MGWebGL, width: any, height: any): void;
/**
 * Free everything initTextureFramebuffer made.
 *
 * Nothing used to, and initTextureFramebuffer runs more than once: resize() clears
 * screenshotBuffersReady, and the next render that wants the texture rebuilds the lot. So every
 * window resize stranded two framebuffers, three textures and the renderbuffers - at 4096x4096
 * that is around 100 MB of GPU memory per resize, held until the context died.
 *
 * The renderbuffers used to be local consts, so they could not have been freed even by a caller
 * that wanted to. They are kept on the instance now for that reason alone.
 */
/**
 * How finely shadows are resolved, named the way the mesh settings are.
 *
 * Measured on 1ibm drawn as ribbons, with GPU timer queries in Chrome: 9.1 ms a frame at 2048,
 * 10.5 at 4096, 17.6 at 8192. The step to 4096 is nearly free because the shadow pass is still
 * dominated by vertex work; by 8192 fill has taken over and the cost is close to linear in
 * texels. 16384 measured 75.8 ms - eight times coarse, for no visible gain over 8192 - so it is
 * deliberately not offered.
 */
export type ShadowMapQuality = "coarse" | "nice" | "smooth";
/** Edge length of the shadow map for each quality. Still bounded by what the hardware allows. */
export declare const SHADOW_MAP_TEXELS: Record<ShadowMapQuality, number>;
export declare function deleteTextureFramebuffer(self: MGWebGL): void;
/**
 * Build the render-to-texture buffers: a square as large as the hardware allows, up to 4096.
 *
 * Screenshots render into this and then crop an aspect-correct band out of it, which is why the
 * projection built for this path uses square extents. The two halves only make sense together.
 */
export declare function initTextureFramebuffer(self: MGWebGL): void;
//# sourceMappingURL=framebuffers.d.ts.map