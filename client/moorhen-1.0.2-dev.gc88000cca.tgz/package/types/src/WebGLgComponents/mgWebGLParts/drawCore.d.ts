import type { MGWebGL } from '../mgWebGL';
export declare function drawPeel(self: MGWebGL, theShaders: any, doClear?: boolean, ratioMult?: number): any;
export declare function drawTriangles(self: MGWebGL, calculatingShadowMap: any, invMat: any): void;
export declare function drawScene(self: MGWebGL): void;
export declare function applySymmetryMatrix(self: MGWebGL, theShader: any, symmetryMatrix: any, tempMVMatrix: any, tempMVInvMatrix: any, doTransform?: boolean): void;
export declare function bindFramebufferDrawBuffers(self: MGWebGL): void;
export declare function getMultiViewInfo(self: MGWebGL): {
    multiViewOrigins: any;
    multiViewGroupsKeys: any;
    quats: any;
    viewports: any;
    ratioMult: any;
    multi_rows_cols: any;
};
export declare function textureBlur(self: MGWebGL, width: any, height: any, inputTexture: any): void;
export declare function depthBlur(self: MGWebGL, invMat: any): void;
export declare function GLrender(self: MGWebGL, calculatingShadowMap: any, doClear?: boolean, ratioMult?: number): any;
//# sourceMappingURL=drawCore.d.ts.map