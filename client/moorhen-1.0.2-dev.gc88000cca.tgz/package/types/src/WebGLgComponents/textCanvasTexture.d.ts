import { AtlasPacker } from "./atlasPacker";
import { RootState } from '../store/MoorhenReduxStore';
import { webGL } from '../types/mgWebGL';
import { Store } from '@reduxjs/toolkit';
interface Dictionary<T> {
    [Key: string]: T;
}
export declare class TextCanvasTexture {
    gl: WebGL2RenderingContext;
    ext: any;
    instanced_ext: any;
    nBigTextures: number;
    nBigTexturesInt: number;
    refI: Dictionary<number>;
    bigTextureTexOrigins: number[][];
    bigTextureTexOffsets: number[][];
    bigTextureScalings: number[][];
    bigTextureScreenOffsets: number[][];
    canvasBig: OffscreenCanvas;
    contextBig: OffscreenCanvasRenderingContext2D;
    /** Where each rasterised string sits. Replaces the three cursor fields it used to carry. */
    packer: AtlasPacker;
    /**
     * Set when a string could not be placed, so the next frame starts from an empty atlas.
     *
     * Deferred rather than compacted on the spot: strings already added this frame have had their
     * texture coordinates pushed into the instance arrays, and rebuilding underneath them would
     * leave every one of those labels pointing at a slot that had moved. One frame missing one
     * label, on the rare occasion the atlas fills, is the cheaper mistake.
     */
    atlasFull: boolean;
    bigTextTex: WebGLTexture;
    bigTextureTexOffsetsBuffer: WebGLBuffer;
    bigTextureTextInstanceOriginBuffer: WebGLBuffer;
    bigTextureTextInstanceSizeBuffer: WebGLBuffer;
    bigTextureTextScreenOffsetBuffer: WebGLBuffer;
    bigTextureTextTexCoordBuffer: WebGLBuffer;
    bigTextureTextPositionBuffer: WebGLBuffer;
    bigTextureTextIndexesBuffer: WebGLBuffer;
    textureCache: Dictionary<Dictionary<Dictionary<number[]>>>;
    shader: webGL.ShaderTextInstanced;
    store: Store<RootState>;
    /**
     * What the atlas currently holds, or null when that is unknown.
     *
     * Null rather than an empty string so that "nothing has been drawn yet" and "the atlas holds
     * no text" are distinguishable: the first must rebuild, the second need not.
     */
    contentKey: string | null;
    constructor(gl: any, ext: any, instanced_ext: any, shader: any, width: number, height: number, store: Store<RootState>);
    draw(): void;
    /**
     * Push the per-instance data to GL, and the glyph atlas with it unless told otherwise.
     *
     * uploadAtlas defaults to true so that every existing caller behaves exactly as before. Only
     * the per-frame overlay path passes false, and only when beginFrame has just confirmed the
     * atlas is unchanged. The buffers below are a few hundred bytes and are rewritten every
     * frame regardless; the texture is 6 MB and is the whole reason this parameter exists.
     */
    /**
     * Rebuild the per-instance buffers, and send whatever glyphs are new.
     *
     * @param forceFullUpload re-send the entire atlas rather than the dirty region. Only wanted
     *                        when something outside has invalidated the texture; the default
     *                        incremental path is correct for every ordinary frame.
     */
    recreateBigTextureBuffers(forceFullUpload?: boolean): void;
    /**
     * Send only the part of the atlas that has been drawn into since the last upload.
     *
     * This is the point of the whole exercise. The atlas used to go up in full whenever its
     * content changed - 8 MB for a 1024x2048 one, twice over, because clearBigTexture uploaded the
     * blank canvas first - and it changed whenever any single label did. A new label is a few
     * hundred pixels square.
     *
     * getImageData rather than handing texSubImage2D the canvas directly: the form that takes a
     * canvas uploads the whole of it at an offset, with no way to crop the source, so the region
     * has to be read out first. For a small rectangle that read is cheap, and it is the only way
     * to upload less than everything.
     */
    private uploadDirtyRegion;
    addImageToBigTexture(t: string, textColour: string, font: string, imgData: ImageData): number[] | null;
    addTextToBigTexture(t: string, textColour: string, font: string): number[] | null;
    clearBigTexture(): void;
    /**
     * Drop the per-instance arrays, keeping the rasterised glyphs.
     *
     * This is the half of clearBigTexture that has to happen every frame. Where each label sits
     * changes as the view moves, so the origins, offsets, scalings and screen offsets are rebuilt
     * from scratch each time; the pixels of the glyphs themselves do not change and are the
     * expensive part to recreate.
     */
    resetInstances(): void;
    /** The text colour the atlas would currently rasterise with, from the background. */
    currentTextColour(): string;
    /**
     * A key over everything that decides what the atlas looks like.
     *
     * Font, text and colour, in order. Order is part of it because it decides the layout: the
     * same strings packed in a different sequence get different texture coordinates, so treating
     * two orderings as equal would leave every label showing its neighbour's glyphs.
     *
     * The separators are control characters rather than anything that can appear in a label,
     * so that ["a", "b"] cannot collide with ["a b"].
     */
    contentKeyFor(items: {
        text: string;
        font: string;
    }[], textColour?: string): string;
    /**
     * Begin a frame's worth of text.
     *
     * The rasterised glyphs are kept. Only the per-instance arrays are dropped, because where each
     * label sits changes as the view moves while its pixels do not - and a string already in the
     * atlas costs a dictionary lookup rather than a re-rasterise and a multi-megabyte upload.
     *
     * This used to wipe the atlas whenever the content differed at all, so one label changing out
     * of fifty threw away the other forty-nine. The content key is still recorded, but it no
     * longer decides anything: what to upload is now answered by which pixels were drawn into.
     *
     * The one case that still wipes is an atlas that filled up. Returns whether that happened, so
     * the caller can ask for a full upload rather than an incremental one.
     */
    beginFrame(contentKey: string): boolean;
    removeBigTextureTextImages(textObjects: any, uuid?: any): void;
    removeBigTextureTextImage(textObject: any, uuid?: any): void;
    getScreenOffsetKey(textObject: any): string;
    addBigTextureTextImage(textObject: any, uuid?: any): void;
}
export {};
//# sourceMappingURL=textCanvasTexture.d.ts.map