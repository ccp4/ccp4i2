export declare function getEncodedData(rssentries: any[]): any[];
//# sourceMappingURL=encodedData.d.ts.map