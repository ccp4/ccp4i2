/**
 * Where each rasterised string sits in the glyph atlas.
 *
 * Pulled out of TextCanvasTexture so the arithmetic can be tested without a GL context or a canvas.
 * The packing is a simple column filler: items stack downwards until one will not fit, then a new
 * column starts to the right of the widest item in the previous one.
 *
 * It replaces an inline version that had no notion of being full. When a column ran off the right
 * edge the cursor simply kept going, the normalised coordinates passed 1.0, and CLAMP_TO_EDGE
 * turned the overflow into a smear of the atlas's last column. That was unreachable in practice
 * only because the atlas was cleared whenever anything changed - which is the very thing worth
 * stopping, since a clear throws away every glyph and re-uploads several megabytes.
 */
/** A rectangle in atlas pixels. */
export type AtlasRect = {
    x: number;
    y: number;
    w: number;
    h: number;
};
export interface PlacedItem {
    /** Left edge in atlas pixels: where the caller draws. */
    x: number;
    /**
     * The baseline *after* this item was placed.
     *
     * Both callers draw relative to it rather than to the top - text subtracts the font's descent,
     * an image subtracts its height - so this is the number they need.
     */
    baseline: number;
    /** [x1, y1, x2, y2], normalised, for the texture coordinates. */
    texCoords: [number, number, number, number];
}
export declare class AtlasPacker {
    readonly width: number;
    readonly height: number;
    private baseline;
    private columnX;
    private columnWidth;
    private dirty;
    constructor(width: number, height: number);
    /**
     * Find room for an item, or report that the atlas is full.
     *
     * @param advanceWidth     the text metric's width, which is how far the pen moves
     * @param boxHeight        ascent + descent, plus whatever padding the caller wants
     * @param boundingBoxRight how far the ink actually reaches right, which for an overhanging
     *                         glyph can be more than advanceWidth - so both are considered when
     *                         deciding what the item occupies, otherwise an italic tail would be
     *                         allowed to run past the right edge and wrap as a smear
     * @param topInset         pixels to leave above the ink when computing y1; the text path uses
     *                         1 and the image path 0, a difference preserved from the original
     *
     * @returns null when the item cannot be placed, which means the caller should compact and
     *          retry rather than draw something wrong
     */
    place(advanceWidth: number, boxHeight: number, boundingBoxRight: number, topInset?: number): PlacedItem | null;
    /** Start again from an empty atlas. */
    reset(): void;
    /**
     * The region written to since the last clearDirty, or null if nothing was.
     *
     * This is what makes an incremental upload possible: only this rectangle has changed, so only
     * it needs to reach the texture, rather than the whole atlas going up again because one label
     * out of fifty was different.
     */
    get dirtyRegion(): AtlasRect | null;
    /** Forget the dirty region, after the caller has uploaded it. */
    clearDirty(): void;
    /** Whether anything has been placed since the last reset. */
    get isEmpty(): boolean;
    private markDirty;
}
//# sourceMappingURL=atlasPacker.d.ts.map