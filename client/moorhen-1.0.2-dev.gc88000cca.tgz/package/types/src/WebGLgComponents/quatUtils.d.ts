export declare function createQuatFromDXAngle(angle_in: any, axis: any): any;
export declare function createQuatFromAngle(angle_in: any, axis: any): any;
export declare function createXQuatFromDX(angle_in: any): any;
export declare function createYQuatFromDY(angle_in: any): any;
export declare function createZQuatFromDX(angle_in: any): any;
export declare function quatDotProduct(q1: any, q2: any): number;
export declare function quatSlerp(q1: any, q2: any, h: any): any;
//# sourceMappingURL=quatUtils.d.ts.map