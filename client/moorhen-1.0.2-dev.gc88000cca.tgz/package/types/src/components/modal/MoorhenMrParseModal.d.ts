export declare const MoorhenMrParseModal: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenMrParseModal.d.ts.map