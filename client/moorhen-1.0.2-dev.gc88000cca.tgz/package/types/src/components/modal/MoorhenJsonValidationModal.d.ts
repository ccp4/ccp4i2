import { ModalComponentProps } from "../interface-base/ModalBase/ModalsContainer";
export declare const MoorhenJsonValidationModal: (props: ModalComponentProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenJsonValidationModal.d.ts.map