export declare const addAtomVector: (dispatch: any, molUniqueID: string, cidFrom: string, cidTo: string) => void;
//# sourceMappingURL=MoorhenNOEVectors.d.ts.map