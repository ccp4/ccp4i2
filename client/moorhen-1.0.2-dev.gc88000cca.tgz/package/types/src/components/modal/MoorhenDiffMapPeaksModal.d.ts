import { ModalComponentProps } from "../interface-base/ModalBase/ModalsContainer";
export declare const MoorhenDiffMapPeaksModal: (props: ModalComponentProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenDiffMapPeaksModal.d.ts.map