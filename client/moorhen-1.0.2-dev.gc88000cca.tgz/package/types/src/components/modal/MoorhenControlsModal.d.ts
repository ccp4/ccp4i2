import { ModalComponentProps } from "../interface-base/ModalBase/ModalsContainer";
export declare const MoorhenControlsModal: (props: ModalComponentProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenControlsModal.d.ts.map