export declare const MoorhenSlidersSettings: (props: {
    stackDirection: "horizontal" | "vertical";
    width?: number;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenSceneSlidersModal.d.ts.map