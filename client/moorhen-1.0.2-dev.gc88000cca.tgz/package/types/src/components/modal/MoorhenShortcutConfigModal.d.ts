import { ModalComponentProps } from "../interface-base/ModalBase/ModalsContainer";
export declare const MoorhenShortcutConfigModal: (props: ModalComponentProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenShortcutConfigModal.d.ts.map