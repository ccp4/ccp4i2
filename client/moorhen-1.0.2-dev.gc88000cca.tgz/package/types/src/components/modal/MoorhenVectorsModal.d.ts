export declare const MoorhenVectors: () => import("react/jsx-runtime").JSX.Element;
export declare const MoorhenVectorsModal: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenVectorsModal.d.ts.map