import { ModalComponentProps } from "../interface-base/ModalBase/ModalsContainer";
export declare const MoorhenSuperposeStructuresModal: (props: ModalComponentProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenSuperposeStructuresModal.d.ts.map