export declare const Moorhen3DObjects: () => import("react/jsx-runtime").JSX.Element;
export declare const Moorhen2DCanvasObjectsModal: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Moorhen3DObjectsModal.d.ts.map