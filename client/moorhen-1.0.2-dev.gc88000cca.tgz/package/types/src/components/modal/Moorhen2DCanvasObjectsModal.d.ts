import { ModalComponentProps } from "../interface-base/ModalBase/ModalsContainer";
export declare const Moorhen2DCanvasObjects: (props: ModalComponentProps) => import("react/jsx-runtime").JSX.Element;
export declare const Moorhen2DCanvasObjectsModal: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Moorhen2DCanvasObjectsModal.d.ts.map