import { ModalComponentProps } from "../interface-base/ModalBase/ModalsContainer";
export declare const MoorhenColourMapByOtherMapModal: (props: ModalComponentProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenColourMapByOtherMapModal.d.ts.map