import { ModalComponentProps } from "../interface-base/ModalBase/ModalsContainer";
export declare const MoorhenPAEModal: (props: ModalComponentProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenPAEModal.d.ts.map