export declare const MoorhenConKitModal: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenConKitModal.d.ts.map