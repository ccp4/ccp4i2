import "../../LhasaReact/src/index.scss";
export declare const MoorhenLhasaModal: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenLhasaModal.d.ts.map