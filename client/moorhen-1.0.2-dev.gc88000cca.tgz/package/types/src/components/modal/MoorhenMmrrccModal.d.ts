import { ModalComponentProps } from "../interface-base/ModalBase/ModalsContainer";
export declare const MoorhenMmrrccModal: (props: ModalComponentProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenMmrrccModal.d.ts.map