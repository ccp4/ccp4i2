export declare const MoorhenWaterValidationModal: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenWaterValidationModal.d.ts.map