export declare const MoorhenUnmodelledBlobsModal: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenUnmodelledBlobsModal.d.ts.map