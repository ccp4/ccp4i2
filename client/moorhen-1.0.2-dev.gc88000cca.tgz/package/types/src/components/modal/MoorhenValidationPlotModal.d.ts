export declare const MoorhenValidationPlotModal: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenValidationPlotModal.d.ts.map