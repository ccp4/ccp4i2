export declare const MoorhenMrBumpModal: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenMrBumpModal.d.ts.map