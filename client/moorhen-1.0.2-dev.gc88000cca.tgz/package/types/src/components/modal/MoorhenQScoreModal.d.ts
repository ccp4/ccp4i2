export declare const MoorhenQScoreModal: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenQScoreModal.d.ts.map