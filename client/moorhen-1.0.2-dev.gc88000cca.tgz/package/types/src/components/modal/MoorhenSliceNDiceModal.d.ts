export declare const MoorhenSliceNDiceModal: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenSliceNDiceModal.d.ts.map