import { ModalComponentProps } from "../interface-base/ModalBase/ModalsContainer";
export declare const MoorhenFillPartialResiduesModal: (props: ModalComponentProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenFillPartialResiduesModal.d.ts.map