import { ModalComponentProps } from "../interface-base/ModalBase/ModalsContainer";
export declare const MoorhenFindLigandModal: (props: ModalComponentProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenFindLigandModal.d.ts.map