export declare const MoorhenQuerySequenceModal: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenQuerySequenceModal.d.ts.map