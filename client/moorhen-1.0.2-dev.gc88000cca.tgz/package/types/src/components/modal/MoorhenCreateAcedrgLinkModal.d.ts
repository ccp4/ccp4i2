import { ModalComponentProps } from "../interface-base/ModalBase/ModalsContainer";
export declare const MoorhenCreateAcedrgLinkModal: (props: ModalComponentProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenCreateAcedrgLinkModal.d.ts.map