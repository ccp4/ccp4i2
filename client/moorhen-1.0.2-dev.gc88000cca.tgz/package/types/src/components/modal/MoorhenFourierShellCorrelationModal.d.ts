import { ModalComponentProps } from "../interface-base/ModalBase/ModalsContainer";
export declare const MoorhenFourierShellCorrelationModal: (props: ModalComponentProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenFourierShellCorrelationModal.d.ts.map