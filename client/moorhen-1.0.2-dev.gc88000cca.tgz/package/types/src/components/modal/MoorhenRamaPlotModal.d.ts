import { ModalComponentProps } from "../interface-base/ModalBase/ModalsContainer";
export declare const MoorhenRamaPlotModal: (props: ModalComponentProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenRamaPlotModal.d.ts.map