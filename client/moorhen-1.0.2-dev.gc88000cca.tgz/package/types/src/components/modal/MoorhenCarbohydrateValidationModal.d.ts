import { ModalComponentProps } from "../interface-base/ModalBase/ModalsContainer";
export declare const MoorhenCarbohydrateValidationModal: (props: ModalComponentProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenCarbohydrateValidationModal.d.ts.map