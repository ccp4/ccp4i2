import "prismjs/components/prism-clike";
import "prismjs/components/prism-javascript";
import "prismjs/themes/prism.css";
export declare const MoorhenScriptModal: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenScriptModal.d.ts.map