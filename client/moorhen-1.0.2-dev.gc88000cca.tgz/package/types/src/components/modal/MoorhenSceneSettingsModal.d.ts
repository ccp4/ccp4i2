export declare const MoorhenSceneSettings: (props: {
    stackDirection: "horizontal" | "vertical";
}) => import("react/jsx-runtime").JSX.Element;
export declare const MoorhenSceneSettingsModal: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenSceneSettingsModal.d.ts.map