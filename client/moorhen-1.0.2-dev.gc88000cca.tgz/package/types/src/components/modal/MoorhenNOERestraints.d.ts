export declare const MoorhenNOERestraints: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenNOERestraints.d.ts.map