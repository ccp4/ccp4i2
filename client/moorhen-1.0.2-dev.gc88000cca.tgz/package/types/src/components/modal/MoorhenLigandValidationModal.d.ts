import { ModalComponentProps } from "../interface-base/ModalBase/ModalsContainer";
export declare const MoorhenLigandValidationModal: (props: ModalComponentProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenLigandValidationModal.d.ts.map