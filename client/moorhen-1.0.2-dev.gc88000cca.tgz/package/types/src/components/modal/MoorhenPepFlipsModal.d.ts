import { ModalComponentProps } from "../interface-base/ModalBase/ModalsContainer";
export declare const MoorhenPepFlipsModal: (props: ModalComponentProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenPepFlipsModal.d.ts.map