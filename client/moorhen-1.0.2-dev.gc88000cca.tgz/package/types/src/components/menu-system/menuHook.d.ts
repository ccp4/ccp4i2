export declare const useMenuHook: () => number;
//# sourceMappingURL=menuHook.d.ts.map