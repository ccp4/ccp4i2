import "./search-bar.css";
export declare const MoorhenSearchBar: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SearchBar.d.ts.map