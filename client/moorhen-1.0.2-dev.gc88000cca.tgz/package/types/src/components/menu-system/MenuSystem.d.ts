import { MainMenuMap, MainMenuType } from "./mainMenuConfig";
import { MenuItem, MenuItemType, SubMenuMap } from "./subMenuConfig";
export declare class MoorhenMenuSystem {
    subMenuMap: SubMenuMap;
    mainMenuMap: MainMenuMap;
    private listeners;
    constructor();
    private createSubMenu;
    subscribe: (listener: () => void) => (() => void);
    private notifyListeners;
    cleanup(): void;
    getItems(selectedMenu: string): MenuItemType[];
    getAllItems: () => MenuItem[];
    /**
     * Adds a main menu item to the menu system at the specified position.
     *
     * If no position is provided, the item is added to the end of the menu.
     * If a position is specified, existing menu items at or after that position
     * are shifted to make space for the new item.
     *
     * @param mainMenuItem - The main menu item to add.
     * @param position - The position at which to insert the menu item (optional).
     */
    addMainMenu: (mainMenuItem: MainMenuType, position?: number) => void;
    /**
     * Adds one or more submenus to the current submenu map.
     *
     * Merges the provided `subMenuMap` into the existing `subMenuMap` property.
     * After merging, it checks for unique submenu IDs to ensure there are no duplicates.
     *
     * @param subMenuMap - An object mapping submenu IDs to submenu definitions to be added.
     */
    addSubmenu: (subMenuMap: SubMenuMap) => void;
    /**
     * Adds the provided menu items to an existing submenu.
     *
     * @param MenuItems - An array of menu items to add to the submenu.
     * @param subMenu - The key or name of the submenu to which the items will be added.
     * @param top - If true, the new items are added to the top of the submenu; otherwise, they are added to the bottom. Defaults to false.
     *
     * @remarks
     * If the submenu exists in `subMenuMap`, the items are added according to the `top` parameter.
     * After modification, the method checks for unique IDs among all menu items.
     */
    addToExistingSubmenu: (MenuItems: MenuItemType[], subMenu: string, top?: boolean) => void;
    /**
     * Deletes a menu item with the specified ID from all submenus.
     *
     * Iterates through each submenu in `subMenuMap` and removes any item whose `id` matches the provided `id`.
     *
     * @param id - The unique identifier of the menu item to be deleted.
     */
    deleteItemById: (id: string) => void;
    private checkUniqueIds;
}
//# sourceMappingURL=MenuSystem.d.ts.map