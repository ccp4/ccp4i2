import "./main-menu.css";
export declare const MoorhenMainMenu: import("react").MemoExoticComponent<() => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=MainMenu.d.ts.map