import { ActionCreatorWithOptionalPayload, PayloadAction } from "@reduxjs/toolkit";
import React from "react";
import type { ModalKey } from "../../components/interface-base/ModalBase/ModalsContainer";
import { RootState } from "../../store/MoorhenReduxStore";
import { ModalComponentProps } from "../interface-base/ModalBase/ModalsContainer";
import { SidePanelIDs } from "../panels";
export type BaseMenuItem = {
    id: string;
    label: string;
    ariaLabel?: string;
    keywords?: string[];
    description?: string;
    devOnly?: boolean;
    specialType?: "script" | "upload";
};
export type MenuItemPopover = BaseMenuItem & {
    type: "popover";
    content: () => React.ReactElement;
};
export type MenuItem = BaseMenuItem & {
    type: "item";
    onClick: () => void;
};
export type MenuItemShowModal = BaseMenuItem & {
    type: "showModal";
    modal: ModalKey;
    args?: ModalComponentProps;
};
export type MenuItemShowSidePanel = BaseMenuItem & {
    type: "showPanel";
    panel: SidePanelIDs;
};
export type MenuItemDispatch = BaseMenuItem & {
    type: "dispatch";
    action: PayloadAction<any>;
};
export type MenuItemCustomJSX = BaseMenuItem & {
    type: "customJSX";
    jsx: (aeg0: any) => React.JSX.Element;
};
export type MenuItemHTMLSlot = BaseMenuItem & {
    type: "HTMLslot";
    slotName: string;
};
export type MenuItemSlider = BaseMenuItem & {
    type: "customJSX";
    jsx: (aeg0: any) => React.JSX.Element;
};
export type MenuItemSubMenu = BaseMenuItem & {
    type: "subMenu";
    menu: string;
};
export type PreferenceSwitch = BaseMenuItem & {
    type: "preferenceSwitch";
    selector: (state: RootState) => boolean;
    action: ActionCreatorWithOptionalPayload<boolean>;
};
export type Separator = {
    type: "separator";
    label?: string;
};
export type MenuItemType = MenuItem | MenuItemPopover | MenuItemShowModal | MenuItemCustomJSX | PreferenceSwitch | MenuItemSubMenu | MenuItemShowSidePanel | MenuItemDispatch | MenuItemHTMLSlot | Separator;
export type SubMenu = {
    label: string;
    items: MenuItemType[];
};
export type SubMenuMap = {
    [submenu: string]: SubMenu;
};
export declare const subMenuMap: SubMenuMap;
//# sourceMappingURL=subMenuConfig.d.ts.map