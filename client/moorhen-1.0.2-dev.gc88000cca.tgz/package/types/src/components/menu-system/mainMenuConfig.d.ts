import React from "react";
import { MoorhenSVG } from "../icons";
import { ModalComponentProps, ModalKey } from "../interface-base/ModalBase/ModalsContainer";
import { SidePanelIDs } from "../panels";
import "./main-menu.css";
export type Icon = {
    icon: MoorhenSVG;
    iconSrc?: never;
} | {
    icon?: never;
    iconSrc: string;
};
export type MainMenuEntrySubMenu = {
    type: "sub-menu";
    label: string;
    ariaLabel?: string;
    menu: string;
    align?: number;
} & Icon;
export type MainMenuEntryModal = {
    type: "modal";
    label: string;
    ariaLabel?: string;
    modal: ModalKey;
    args?: ModalComponentProps;
} & Icon;
export type MainMenuEntryPanel = {
    type: "panel";
    label: string;
    ariaLabel?: string;
    panel: SidePanelIDs;
} & Icon;
export type MainMenuEntryJSX = {
    type: "jsx";
    label: string;
    ariaLabel?: string;
    component: React.JSX.Element;
    props?: {};
    align?: number;
} & Icon;
/** Runs `action` once per click and closes the menu, so non-React hosts can add buttons */
export type MainMenuEntryAction = {
    type: "action";
    label: string;
    ariaLabel?: string;
    action: () => void;
} & Icon;
export type MainMenuType = MainMenuEntrySubMenu | MainMenuEntryModal | MainMenuEntryJSX | MainMenuEntryPanel | MainMenuEntryAction;
export type MainMenuMap = {
    [key: number]: MainMenuType;
};
export declare const MainMenu: MainMenuMap;
//# sourceMappingURL=mainMenuConfig.d.ts.map