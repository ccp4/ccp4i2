export declare const MoorhenDevMenu: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenDevMenu.d.ts.map