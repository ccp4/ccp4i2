import React from "react";
import type { MenuItemType } from "./subMenuConfig";
export declare const MenuFromItems: (props: {
    menuItemList: MenuItemType[];
    title?: string;
}) => React.JSX.Element;
//# sourceMappingURL=MenuFromItems.d.ts.map