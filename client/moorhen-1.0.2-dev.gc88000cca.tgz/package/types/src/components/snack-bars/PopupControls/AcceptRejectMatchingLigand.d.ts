export declare const AcceptRejectMatchingLigand: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AcceptRejectMatchingLigand.d.ts.map