import "./popup-controls.css";
export declare const Screenshot: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ScreenshotControls.d.ts.map