export declare const AtomInfo: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AtomInfo.d.ts.map