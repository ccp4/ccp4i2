import "./popup-controls.css";
export declare const PopupControls: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=PopupControls.d.ts.map