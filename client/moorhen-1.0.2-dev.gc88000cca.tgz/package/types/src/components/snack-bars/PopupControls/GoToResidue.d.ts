export declare const GoToResidue: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=GoToResidue.d.ts.map