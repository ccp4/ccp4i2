export declare const MapContourLevel: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MapContourLevel.d.ts.map