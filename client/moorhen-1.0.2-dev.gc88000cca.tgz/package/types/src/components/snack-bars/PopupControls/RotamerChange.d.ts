export declare const RotamerChange: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=RotamerChange.d.ts.map