export declare const AcceptRejectDragAtoms: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AcceptRejectDragAtoms.d.ts.map