export declare const AcceptRejectRotateTranslate: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AcceptRejectRotateTranslate.d.ts.map