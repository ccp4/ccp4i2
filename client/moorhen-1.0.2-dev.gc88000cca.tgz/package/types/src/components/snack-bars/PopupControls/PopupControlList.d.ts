import React from "react";
import { moorhen } from "@/types/moorhen";
import { RepresentationStyles } from "../../../utils";
type PayloadType = Record<string, string | string[] | number | number[] | boolean | boolean[] | moorhen.ResidueSpec | moorhen.ResidueSpec[] | undefined>;
type ValidatePayloadMap<T extends Record<string, PayloadType | undefined>> = T;
type PayloadMap = ValidatePayloadMap<{
    screenshot: undefined;
    acceptRejectDraggingAtoms: {
        molNo: number;
        fragmentCid: string | string[];
        drawSelectionOnClose?: boolean;
    };
    acceptRejectRotateTranslate: {
        molNo: number;
        fragmentCid: string;
        drawSelectionOnClose?: boolean;
    };
    selectionTools: undefined;
    atomInfo: {
        molNo: number;
        fragmentCid: string;
    };
    changeRotamer: {
        molNo: number;
        chosenAtom: moorhen.ResidueSpec;
    };
    videoRecorder: undefined;
    mapContourLvl: {
        molNo: number;
        mapPrecision: number;
    };
    trajectory: {
        molNo: number;
        style: RepresentationStyles;
    };
    acceptRejectMatchingLigand: {
        movingMolNo: number;
        refMolNo: number;
        movingLigandCid: string;
        refLigandCid: string;
    };
    goToResidue: undefined;
    flipAllPeptides: {
        residueList: string[];
        selectedMolecule: number;
    };
    steppedRefine: {
        residueList: string[];
        selectedMolecule: number;
    };
    fillAllAtoms: {
        residueList: string[];
        selectedMolecule: number;
    };
}>;
type PopupControl = {
    name: string;
    component: React.JSX.Element;
};
export type ShownControl = {
    [K in keyof PayloadMap]: {
        name: K;
        payload?: PayloadMap[K];
    };
}[keyof PayloadMap];
export declare const PopupControlList: PopupControl[];
export {};
//# sourceMappingURL=PopupControlList.d.ts.map