export declare const ResidueSelectionControls: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ResidueSelection.d.ts.map