export declare const ModelTrajectory: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ModelTrajectory.d.ts.map