export declare const ResidueSteps: (props: {
    variant: "pepFlip" | "stepRefine" | "fillAllAtoms";
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ResidueSteps.d.ts.map