import "./activity-indicator.css";
export declare const ActivityIndicator: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ActivityIndicator.d.ts.map