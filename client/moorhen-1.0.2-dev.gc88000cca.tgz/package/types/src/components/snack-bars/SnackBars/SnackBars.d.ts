import { Snackbar } from "../../../store/snackbarSlice";
import "./snack-bars.css";
export declare const SnackBars: () => import("react/jsx-runtime").JSX.Element;
export declare const SnackBar: (props: Snackbar) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SnackBars.d.ts.map