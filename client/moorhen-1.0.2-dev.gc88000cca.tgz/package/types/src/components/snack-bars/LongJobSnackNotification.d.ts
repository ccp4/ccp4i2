import "./long-job.css";
export declare const LongJobSnackNotification: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=LongJobSnackNotification.d.ts.map