import React, { ReactNode } from "react";
import "./menu-item.css";
interface MoorhenMenuItemProps {
    children: ReactNode;
    selected?: boolean;
    onClick?: (e: any) => void | ((e: any) => Promise<void>) | ((event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void);
    ref?: React.Ref<HTMLButtonElement>;
    id?: string;
    disabled?: boolean;
    style?: React.CSSProperties;
    ariaLabel?: string;
}
/**
 * A thin wrapper around a standard HTML `<button>` element, applying Moorhen-specific styling.
 *
 * @remarks
 * This component is primarily used to provide consistent styling for menu items within the application.
 *
 * @param props - The props for the MoorhenMenuItem component.
 * @param props.children - The content to be displayed inside the button.
 * @param props.onClick - Optional click handler for the button.
 */
export declare const MoorhenMenuItem: React.FC<MoorhenMenuItemProps>;
export {};
//# sourceMappingURL=MenuItem.d.ts.map