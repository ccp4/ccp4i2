import { MoorhenSVG } from "../../icons";
type MoorhenPopoverButtonType = {
    popoverContent?: React.JSX.Element;
    disabled?: boolean;
    size?: "small" | "medium" | "large" | "accordion";
    icon?: MoorhenSVG;
    popoverPlacement?: "left" | "right" | "top" | "bottom";
    children?: React.ReactNode;
    tooltip?: string;
    type?: "icon-only" | "default";
    style?: React.CSSProperties;
    popoverStyle?: React.CSSProperties;
    closeButton?: boolean;
    label?: string;
};
export declare const MoorhenPopoverButton: (props: MoorhenPopoverButtonType) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=PopoverButton.d.ts.map