type MoorhenMenuItemPopoverProps = {
    popoverContent?: React.JSX.Element;
    children?: React.JSX.Element;
    popoverPlacement?: "left" | "right";
    setPopoverIsShown?: React.Dispatch<React.SetStateAction<boolean>>;
    menuItemTitle?: string;
    buttonVariant?: string;
    buttonText?: string;
    textClassName?: string;
    id?: string;
    menuItemText: string;
    disabled?: boolean;
    style?: React.CSSProperties;
    popoverStyle?: React.CSSProperties;
    ariaLabel?: string;
};
export declare const MoorhenMenuItemPopover: (props: MoorhenMenuItemPopoverProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MenuItemPopover.d.ts.map