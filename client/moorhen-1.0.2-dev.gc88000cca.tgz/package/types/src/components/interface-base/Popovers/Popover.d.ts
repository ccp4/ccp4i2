import "./popover.css";
type PlacementType = "left" | "right" | "top" | "bottom" | "center";
type MoorhenPopoverType = {
    popoverContent?: React.JSX.Element | React.ReactNode;
    children?: React.JSX.Element | React.ReactNode;
    disabled?: boolean;
    popoverPlacement?: PlacementType;
    link: React.JSX.Element;
    linkRef: React.RefObject<HTMLDivElement | HTMLButtonElement>;
    isShown: boolean;
    type?: "default" | "tooltip" | "autocomplete";
    setIsShown: (arg0: boolean) => void;
    overridePopoverSize?: {
        width: number;
        height: number;
    };
    allowAutoFlip?: boolean;
    closeButton?: boolean;
    style?: React.CSSProperties;
    dynamicPosition?: boolean;
    hideOverflow?: boolean;
};
export declare const MoorhenPopover: (props: MoorhenPopoverType) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Popover.d.ts.map