import { JSX } from "react";
type InfoCardProps = {
    infoText: string | JSX.Element;
    popoverPlacement?: "left" | "right" | "top" | "bottom";
    width?: string;
    large?: boolean;
};
export declare const MoorhenInfoCard: (props: InfoCardProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=InfoCard.d.ts.map