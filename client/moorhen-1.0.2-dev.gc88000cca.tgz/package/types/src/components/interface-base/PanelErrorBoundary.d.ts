import React, { ErrorInfo } from "react";
type PanelErrorBoundaryProps = {
    children: React.ReactNode;
    panelName?: string;
};
type PanelErrorBoundaryState = {
    hasError: boolean;
    error: Error | null;
};
export declare class PanelErrorBoundary extends React.Component<PanelErrorBoundaryProps, PanelErrorBoundaryState> {
    constructor(props: PanelErrorBoundaryProps);
    static getDerivedStateFromError(error: Error): PanelErrorBoundaryState;
    componentDidCatch(error: Error, errorInfo: ErrorInfo): void;
    handleRetry: () => void;
    render(): string | number | bigint | boolean | Iterable<React.ReactNode> | Promise<string | number | bigint | boolean | React.ReactPortal | React.ReactElement<unknown, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode>> | import("react/jsx-runtime").JSX.Element;
}
export {};
//# sourceMappingURL=PanelErrorBoundary.d.ts.map