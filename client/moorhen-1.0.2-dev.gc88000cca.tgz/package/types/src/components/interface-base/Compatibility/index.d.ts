export { ActivityCompat } from "./Activity";
//# sourceMappingURL=index.d.ts.map