import "./moorhen-stack.css";
type MoorhenStackType = {
    direction?: "row" | "line" | "horizontal" | "column" | "vertical";
    gap?: number | string;
    justify?: "center" | "flex-start" | "flex-end" | "space-between" | "space-around" | "space-evenly";
    align?: "center" | "flex-start" | "flex-end" | "stretch" | "baseline" | "normal";
    children: React.ReactNode;
    style?: React.CSSProperties;
    card?: boolean;
    className?: string;
    inputGrid?: boolean;
    grid?: boolean;
    gridWidth?: 1 | 2 | 3 | 4;
    addMargin?: boolean;
    ref?: React.RefObject<HTMLDivElement>;
    flex?: 1 | 0;
    overflow?: "auto" | "hidden" | "visible" | "scroll" | "clip";
};
export declare const MoorhenStack: (props: MoorhenStackType) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Stack.d.ts.map