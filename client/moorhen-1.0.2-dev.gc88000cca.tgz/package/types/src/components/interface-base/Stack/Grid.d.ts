import "./grid.css";
export declare const MoorhenGrid: (props: {
    children: React.ReactNode;
    gap?: string;
    rowGap?: string;
    columnGap?: string;
    columns: number;
    table?: boolean;
    style?: React.CSSProperties;
    titleRow?: boolean;
    titleColumn?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Grid.d.ts.map