import React, { ErrorInfo } from "react";
import type { ModalKey } from "./ModalsContainer";
type ModalErrorBoundaryProps = {
    children: React.ReactNode;
    modalId?: ModalKey;
    headerTitle?: string;
};
type ModalErrorBoundaryState = {
    hasError: boolean;
    error: Error | null;
};
export declare class ModalErrorBoundary extends React.Component<ModalErrorBoundaryProps, ModalErrorBoundaryState> {
    constructor(props: ModalErrorBoundaryProps);
    static getDerivedStateFromError(error: Error): ModalErrorBoundaryState;
    componentDidCatch(error: Error, errorInfo: ErrorInfo): void;
    handleRetry: () => void;
    render(): string | number | bigint | boolean | Iterable<React.ReactNode> | Promise<string | number | bigint | boolean | React.ReactPortal | React.ReactElement<unknown, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode>> | import("react/jsx-runtime").JSX.Element;
}
export {};
//# sourceMappingURL=ModalErrorBoundary.d.ts.map