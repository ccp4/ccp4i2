import React from "react";
export type ModalKey = "acedrg" | "query-seq" | "scripting" | "show-controls" | "fit-ligand" | "rama-plot" | "diff-map-peaks" | "validation-plot" | "mmrrcc" | "water-validation" | "lig-validation" | "fill-partial-residues" | "pepflips" | "unmodelled-blobs" | "carb-validation" | "slice-n-dice" | "superpose" | "scene-settings" | "lhasa" | "qscore" | "json-validation" | "mrbump" | "mrparse" | "colour-map-by-map" | "vectors" | "overlays-2d" | "conkit" | "pae-plot" | "NOE" | "config-shortcuts" | "fourier-shell-correlation";
export type ModalComponentProps = {
    openDocked?: "left" | "right" | null | undefined;
    modalProps?: {
        [key: string]: string | number | boolean;
    };
};
export type ExtraDraggableModals = React.JSX.Element[];
export declare const MoorhenModalsContainer: React.MemoExoticComponent<(props: {
    extraDraggableModals?: ExtraDraggableModals;
}) => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=ModalsContainer.d.ts.map