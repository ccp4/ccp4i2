import type { ModalKey } from "./ModalsContainer";
import "./draggable-modal-base.css";
export type MoorhenDraggableModalBaseProps = {
    headerTitle: string | React.JSX.Element;
    body: React.JSX.Element | React.JSX.Element[];
    modalId: ModalKey;
    allowDocking?: boolean;
    initialWidth?: number;
    initialHeight?: number;
    maxWidth?: number;
    maxHeight?: number;
    minWidth?: number;
    minHeight?: number;
    top?: number;
    left?: number;
    rememberSize?: boolean;
    additionalHeaderButtons?: React.JSX.Element[];
    footer?: React.JSX.Element;
    additionalChildren?: React.JSX.Element;
    showCloseButton?: boolean;
    onClose?: () => void | Promise<void>;
    onResize?: (evt: MouseEvent | TouchEvent | null, direction: "top" | "right" | "bottom" | "left" | "topRight" | "bottomRight" | "bottomLeft" | "topLeft", ref: HTMLDivElement | null, delta: {
        width: number;
        height: number;
    }, size: {
        width: number;
        height: number;
    }) => void;
    onResizeStop?: (evt: MouseEvent | TouchEvent | null, direction: "top" | "right" | "bottom" | "left" | "topRight" | "bottomRight" | "bottomLeft" | "topLeft", ref: HTMLDivElement | null, delta: {
        width: number;
        height: number;
    }) => void;
    onDock?: (side: "left" | "right" | null) => void;
    openDocked?: "left" | "right" | null;
    enforceMaxBodyDimensions?: boolean;
    resizeNodeRef?: null | React.RefObject<HTMLDivElement>;
    overflowY?: "visible" | "hidden" | "clip" | "scroll" | "auto";
    overflowX?: "visible" | "hidden" | "clip" | "scroll" | "auto";
    handleClassName?: string;
    lockAspectRatio?: boolean;
    enableResize?: false | {
        [key: string]: boolean;
    };
};
/**
 * A draggable, resizable modal component.
 *
 * ## Auto-sizing behavior
 * If `initialWidth` and `initialHeight` are not provided, the modal renders its
 * body off-screen first to measure its natural size, then displays at that size
 * (clamped to min/max bounds). This means the body must be renderable before
 * the modal appears. If the body content is async/slow, provide explicit
 * initial dimensions to avoid a blank flash.
 *
 * ## Drag & resize implementation
 * Both dragging (via the header) and resizing (via the bottom-right handle)
 * work by attaching `pointermove`/`pointerup` listeners to `window` on
 * mousedown, and removing them via AbortController on mouseup. This avoids
 * the jank of CSS-only resize and works even when the pointer leaves the modal.
 *
 * **Stale closure caveat:** Because `dragWindow`, `resizeModal`, etc. are
 * captured by the event listener at mousedown time, they close over the
 * render-cycle's state values. For values that change during the drag gesture
 * (size, callbacks), we use refs (`sizeRef`, `onResizeRef`, `onResizeStopRef`)
 * so the listener always reads current values. See inline comments below.
 *
 * ## Z-index / focus
 * Clicking anywhere on the modal calls `focusOnModal`, which pushes it to
 * the top of the global focus hierarchy. The z-index is derived from position
 * in that hierarchy (999 minus index).
 */
export declare const MoorhenDraggableModalBase: (props: MoorhenDraggableModalBaseProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=DraggableModalBase.d.ts.map