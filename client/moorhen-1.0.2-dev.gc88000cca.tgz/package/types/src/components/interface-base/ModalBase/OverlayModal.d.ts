export declare const OverlayModal: (props: {
    children?: React.ReactNode;
    isShown: boolean;
    overlay: React.ReactNode | React.JSX.Element | string;
    style?: React.CSSProperties;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=OverlayModal.d.ts.map