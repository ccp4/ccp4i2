import React, { ReactNode } from "react";
import "./tabs.css";
type TabContainerProps = {
    children: React.ReactElement<TabProps> | React.ReactElement<TabProps>[];
    defaultActiveId?: string;
    onChange?: (activeId: string) => void;
    className?: string;
};
export declare const MoorhenTabContainer: (props: TabContainerProps) => import("react/jsx-runtime").JSX.Element;
interface TabProps {
    id: string;
    label: string;
    children: ReactNode;
}
export declare const MoorhenTab: React.FC<TabProps>;
export {};
//# sourceMappingURL=Tabs.d.ts.map