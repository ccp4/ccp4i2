import React from "react";
import "./accordion.css";
export type MoorhenAccordionType = {
    title: string | React.JSX.Element;
    children: React.ReactNode;
    disabled?: boolean;
    defaultOpen?: boolean;
    extraControls?: React.JSX.Element[];
    hideExtraControlsWhenClosed?: boolean;
    type?: "default" | "card";
    twoLinesHeader?: boolean;
    onChange?: (isExpanded: boolean) => void;
    onOpen?: () => void;
    onClose?: () => void;
    open?: boolean;
};
export declare const MoorhenAccordion: (props: MoorhenAccordionType) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Accordion.d.ts.map