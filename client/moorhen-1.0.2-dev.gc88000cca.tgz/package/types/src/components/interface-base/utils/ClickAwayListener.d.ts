import React from "react";
export declare const MoorhenClickAwayListener: (props: {
    onClickAway: (() => void) | ((event: MouseEvent) => void);
    children: React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ClickAwayListener.d.ts.map