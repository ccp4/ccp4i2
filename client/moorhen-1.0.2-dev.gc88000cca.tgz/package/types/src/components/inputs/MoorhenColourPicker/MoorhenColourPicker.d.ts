import "./colour-picker.css";
import "./react-colorful.css";
export type RGBAColour = [number, number, number] | [number, number, number, number];
type MoorhenColourPickerBase = {
    colour: RGBAColour;
    setColour?: (colour: RGBAColour) => void;
    useAlpha?: boolean;
    label?: string;
    position?: "top" | "bottom" | "left" | "right";
    onClose?: () => void;
    onOpen?: () => void;
    tooltip?: string;
    onApply?: (colour: RGBAColour) => void;
    style?: React.CSSProperties;
    ariaLabel?: string;
    asPopoverButton?: boolean;
    hexFormat?: boolean;
    showColourSwatches?: boolean;
};
type MoorhenColourPickerSingle = MoorhenColourPickerBase & {
    colour2?: null;
    setColour2?: null;
    label2?: null;
};
type MoorhenColourPickerDual = MoorhenColourPickerBase & {
    colour2: RGBAColour;
    setColour2: (colour: RGBAColour) => void;
    label2?: string;
};
type MoorhenColourPickerType = MoorhenColourPickerSingle | MoorhenColourPickerDual;
export declare const MoorhenColourPicker: {
    (props: MoorhenColourPickerType): import("react/jsx-runtime").JSX.Element;
    displayName: string;
};
export {};
//# sourceMappingURL=MoorhenColourPicker.d.ts.map