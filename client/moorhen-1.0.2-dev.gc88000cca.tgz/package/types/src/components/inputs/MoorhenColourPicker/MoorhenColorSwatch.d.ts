type MoorhenColorSwatchProps = {
    cols?: string[];
    size?: number;
    columns?: number;
    onClick: (colour: string) => void;
};
export declare const MoorhenColorSwatch: (props: MoorhenColorSwatchProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoorhenColorSwatch.d.ts.map