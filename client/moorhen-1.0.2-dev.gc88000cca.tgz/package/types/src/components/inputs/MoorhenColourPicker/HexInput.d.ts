import { RGBAColour } from "./MoorhenColourPicker";
type HexInputProps = {
    colour: RGBAColour;
    setColour: (colour: RGBAColour) => void;
    useAlpha?: boolean;
    label?: string;
    onApply?: (colour: RGBAColour) => void;
    style?: React.CSSProperties;
    ariaLabel?: string;
};
export declare const MoorhenHexInput: (props: HexInputProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=HexInput.d.ts.map