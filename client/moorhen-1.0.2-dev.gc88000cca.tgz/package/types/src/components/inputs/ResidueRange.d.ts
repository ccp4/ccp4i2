import { MoorhenMolecule } from "../../utils";
export type ResidueRangeSelectorProps = {
    molecule: MoorhenMolecule;
    selectedChain: string;
    sequenceResidueRange: [number, number] | null;
    setSequenceResidueRange: React.Dispatch<React.SetStateAction<[number, number] | null>>;
    style?: React.CSSProperties;
};
export declare const ResidueRangeSelector: (props: ResidueRangeSelectorProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ResidueRange.d.ts.map