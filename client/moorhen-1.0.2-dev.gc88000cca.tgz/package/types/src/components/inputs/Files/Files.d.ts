import "./files-input.css";
export type FilesInputProps = {
    label?: string;
    extraTooltip?: string;
    ref?: React.RefObject<HTMLInputElement>;
    onChange?: ((e: React.ChangeEvent<HTMLInputElement>) => void) | (() => void);
    accept?: string;
    multiple?: boolean;
    isLoading?: boolean;
    className?: string;
    style?: React.CSSProperties;
    disabled?: boolean;
    dowebkitdirectory?: boolean;
};
export declare const MoorhenFileInput: (props: FilesInputProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Files.d.ts.map