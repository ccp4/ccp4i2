export declare const gradientPresets: {
    "Red White Blue": (number | number[])[][];
    "Red White Green": (number | number[])[][];
    "Red Blue Green": (number | number[])[][];
    "Green White Blue": (number | number[])[][];
    "Pool Party": (number | number[])[][];
    Heatmap: (number | number[])[][];
    Rainbow: (number | number[])[][];
    "mpl Viridis": (number | number[])[][];
    "mpl Plasma": (number | number[])[][];
    "test gradient": (number | number[])[][];
};
export type GradientPreset = keyof typeof gradientPresets;
export declare const getColorFromGradient: (gradient: GradientPreset | [number, [number, number, number]][], value: number, reverse?: boolean, cssString?: boolean) => string | number[];
//# sourceMappingURL=gradientPresets.d.ts.map