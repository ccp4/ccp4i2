type MoorhenGradientPickerType = {
    colourTable: [number, [number, number, number]][];
    setColourTable: (colourTable: [number, [number, number, number]][]) => void;
    menu: string;
    showValues?: boolean;
    modifyValues?: boolean;
    minValue?: number;
    setMinValue?: (val: number) => void;
    maxValue?: number;
    setMaxValue?: (val: number) => void;
};
export declare const MoorhenGradientPicker: import("react").MemoExoticComponent<(props: MoorhenGradientPickerType) => import("react/jsx-runtime").JSX.Element>;
export {};
//# sourceMappingURL=MoorhenGradientPicker.d.ts.map