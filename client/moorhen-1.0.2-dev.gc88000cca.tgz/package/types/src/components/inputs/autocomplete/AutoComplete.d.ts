import Fuse, { IFuseOptions } from "fuse.js";
import "./autocomplete.css";
type MoorhenAutoCompleteProps<T> = {
    extraFuseOptions?: IFuseOptions<T>;
    searchItems: T[];
    keys?: {
        name: Extract<keyof T, string>;
        weight: number;
    }[];
    resultsRenderer: (results: T) => React.ReactNode;
    autocompleteOpen?: boolean;
    setAutocompleteOpen?: (open: boolean) => void;
    maxResults?: number;
    debounceMs?: number;
    minQueryLength?: number;
    value?: string;
    setValue?: (text: string) => void;
    searchFn?: (query: string, context: {
        fuse: Fuse<T>;
        maxResults?: number;
    }) => Promise<T[]> | T[];
};
export declare const MoorhenAutoComplete: <T>(props: MoorhenAutoCompleteProps<T>) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=AutoComplete.d.ts.map