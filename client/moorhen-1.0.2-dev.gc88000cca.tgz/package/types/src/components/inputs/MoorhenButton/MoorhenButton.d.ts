import { JSX } from "react";
import { MoorhenSVG } from "../../icons";
import "./moorhen-button.css";
type MoorhenButtonPropsTypeBase = {
    label?: string;
    onClick?: (() => void) | ((event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void);
    onMouseDown?: (() => void) | ((event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void);
    onMouseUp?: () => void;
    onMouseLeave?: () => void;
    onMouseEnter?: () => void;
    disabled?: boolean;
    ref?: React.Ref<HTMLButtonElement>;
    style?: React.CSSProperties;
    className?: string;
    children?: React.ReactNode;
    value?: string | number;
    id?: string;
    tooltip?: string | JSX.Element | false;
    disabledTooltip?: string | JSX.Element | false;
    tooltipPlacement?: "top" | "bottom" | "left" | "right";
    iconStyle?: React.CSSProperties;
    ariaLabel?: string;
};
type MoorhenButtonIconProps = MoorhenButtonPropsTypeBase & {
    type: "icon-only";
    size?: "small" | "medium" | "large" | "accordion";
    icon?: MoorhenSVG;
    variant?: "default" | "danger";
};
type MoorhenButtonDefaultProps = MoorhenButtonPropsTypeBase & {
    type?: "default";
    size?: "small" | "medium" | "large" | "sm" | "lg" | "md" | "accordion";
    variant?: "primary" | "secondary" | "danger" | "white" | "outlined" | "light";
    icon?: MoorhenSVG;
};
type MoorhenButtonToggleProps = MoorhenButtonPropsTypeBase & {
    type: "toggle";
    checked: boolean;
    size?: "small" | "medium" | "large";
    icon?: MoorhenSVG;
};
/**
 * Renders a Moorhen button with optional label, icon, tooltip, and toggle state.
 *
 * @remarks
 * Use `type="default"` for the standard button, `type="icon-only"` for compact icon buttons,
 * and `type="toggle"` for buttons that reflect a checked state.
 *
 * @param props - Button props.
 * @param props.type - Button variant.
 * @param props.label - Text label displayed inside the button.
 * @param props.children - Additional content rendered inside the button.
 * @param props.onClick - Click handler invoked unless the button is disabled.
 * @param props.onMouseDown - Mouse down handler.
 * @param props.onMouseUp - Mouse up handler.
 * @param props.onMouseLeave - Mouse leave handler.
 * @param props.onMouseEnter - Mouse enter handler.
 * @param props.disabled - Whether the button is disabled.
 * @param props.ref - Forwarded ref to the underlying button element.
 * @param props.style - Inline styles applied to the button.
 * @param props.className - Additional CSS class names.
 * @param props.value - Value attribute for the underlying button.
 * @param props.id - ID attribute for the underlying button.
 * @param props.tooltip - Tooltip content shown on hover or focus.
 * @param props.disabledTooltip - Extra tooltip content shown when the button is disabled.
 * @param props.tooltipPlacement - Tooltip placement when a tooltip is rendered.
 * @param props.icon - SVG icon rendered inside the button.
 * @param props.iconStyle - Inline styles applied to the icon.
 * @param props.ariaLabel - Accessible label for the button.
 * @param props.size - Button or icon size.
 * @param props.variant - Visual style variant.
 * @param props.checked - Checked state for toggle buttons.
 */
export declare const MoorhenButton: (props: MoorhenButtonIconProps | MoorhenButtonDefaultProps | MoorhenButtonToggleProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoorhenButton.d.ts.map