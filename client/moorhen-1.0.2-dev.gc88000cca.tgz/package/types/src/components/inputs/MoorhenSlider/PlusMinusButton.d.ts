type PlusMinusButtonProps = {
    step: number;
    setButtonIsDown?: (isDown: boolean) => void;
    value: number | null | undefined;
    setValue?: (value: number) => void;
    minVal?: number;
    maxVal?: number;
    isDisabled?: boolean;
    logScale?: boolean;
    allowedValues?: number[];
    type?: "arrow" | "round";
    style?: React.CSSProperties;
    colour?: string;
    minMax?: [number, number];
};
export declare function PlusMinusButton(props: PlusMinusButtonProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=PlusMinusButton.d.ts.map