import React from "react";
import "./MoorhenSlider.css";
type MoorhenSliderPropsBase = {
    value: number;
    setValue: ((value: number) => void) | React.Dispatch<React.SetStateAction<number>>;
    scale?: "linear" | "log" | "asinh";
    sliderTitle?: string;
    sliderPrecision?: number;
    decimalPlaces?: number;
    showLabels?: boolean;
    showButtons?: boolean;
    stepButtons?: number;
    isDisabled?: boolean;
    usePreciseInput?: boolean;
    piWidth?: string | number;
    piWaitReturn?: boolean;
    piMinMax?: [number, number];
    labels?: {
        value: number;
        label: string;
        tick?: boolean;
        colour?: string;
    }[];
    showTicks?: boolean;
    tickSpacing?: number;
    majorTickSpacing?: number;
    logMinorTickStep?: number;
    logMajorTickBase?: number;
    autoLabelMajorTicks?: boolean;
    tickInside?: boolean;
    step?: number;
    showTitleValue?: boolean;
    allowedValues?: number[];
    sliderTitleUnit?: string;
    style?: React.CSSProperties;
    colour?: string;
    ariaLabel?: string;
    getAriaValueText?: (value: number) => string;
};
type MoorhenSliderRange = {
    type: "range";
    value2: number;
    setValue2: ((value: number) => void) | React.Dispatch<React.SetStateAction<number>>;
    minVal?: number;
    maxVal?: number;
} & MoorhenSliderPropsBase;
type MoorhenSliderDefault = {
    type?: "default";
    minVal?: number;
    maxVal?: number;
    steps?: never;
    value2?: never;
} & MoorhenSliderPropsBase;
export type MoorhenSliderProps = MoorhenSliderDefault | MoorhenSliderRange;
/**
 * MoorhenSlider component.
 *
 * A configurable slider supporting linear, logarithmic and asinh scaling,
 * optional range selection, tick marks, labels, precise numeric input,
 * and increment/decrement buttons.
 *
 * @prop {number} value
 *   Current value of the primary slider.
 *
 * @prop {(value: number) => void} setValue
 *   Callback used to update the primary value.
 *
 * @prop {"linear"|"log"|"asinh"} [scale="linear"]
 *   Scaling mode used by the slider.
 *
 *   - "linear": uniform spacing
 *   - "log": logarithmic spacing (base 10)
 *   - "asinh": inverse hyperbolic sine spacing
 *
 * @prop {number} [minVal=0]
 *   Minimum permitted slider value.
 *
 * @prop {number} [maxVal=100]
 *   Maximum permitted slider value.
 *
 * @prop {string} [sliderTitle]
 *   Optional title displayed above the slider.
 *
 * @prop {number} [sliderPrecision]
 *   Precision used internally by the native range input.
 *   Defaults to 10^-decimalPlaces.
 *
 * @prop {number} [decimalPlaces=0]
 *   Number of decimal places displayed when showing values.
 *
 * @prop {boolean} [showTitleValue=true]
 *   Whether the current value should be displayed in the title.
 *
 * @prop {string} [sliderTitleUnit]
 *   Optional unit string appended to displayed values.
 *
 * @prop {boolean} [showLabels=true]
 *   Whether labels are shown beneath the slider.
 *
 * @prop {Array<{value:number,label:string,tick?:boolean,colour?:string}>} [labels]
 *   Custom labels positioned along the slider.
 *
 * @prop {boolean} [showTicks=false]
 *   Whether tick marks are displayed along the slider.
 *
 * @prop {number} [tickSpacing=5]
 *   Minor tick spacing.
 *
 *   For linear scales this is expressed in value units.
 *   For logarithmic scales this corresponds to the mantissa increment.
 *
 * @prop {number} [majorTickSpacing]
 *   Major tick spacing for linear scales.
 *
 * @prop {number} [logMinorTickStep]
 *   Mantissa increment used for logarithmic minor ticks.
 *
 * @prop {number} [logMajorTickBase]
 *   Base mantissa used for logarithmic major ticks.
 *
 * @prop {boolean} [autoLabelMajorTicks=false]
 *   Whether major ticks should automatically generate labels.
 *
 * @prop {boolean} [tickInside=false]
 *   Draw tick marks inside the track rather than outside.
 *
 * @prop {boolean} [showButtons=true]
 *   Whether increment/decrement buttons are displayed.
 *
 * @prop {number} [stepButtons]
 *   Increment applied by the side buttons.
 *
 * @prop {number} [step]
 *   Value quantisation step applied to slider movement.
 *
 * @prop {number[]} [allowedValues]
 *   Restricts slider values to the closest member of this list.
 *
 * @prop {boolean} [isDisabled=false]
 *   Disables all slider interaction.
 *
 * @prop {boolean} [usePreciseInput=false]
 *   Replaces the displayed value with editable numeric input fields.
 *
 * @prop {string|number} [piWidth]
 *   Width of the precise input field.
 *
 * @prop {boolean} [piWaitReturn=true]
 *   If true, updates from the precise input occur only after Enter is pressed.
 *
 * @prop {number[]} [piMinMax]
 *   Minimum and maximum values for the precise input.
 *   Two-element array: [min, max].
 *
 * @prop {string} [colour]
 *   Accent colour used for buttons.
 *
 * @prop {React.CSSProperties} [style]
 *   Additional styles applied to the root container.
 *
 * @prop {string} [ariaLabel]
 *   Accessible label for the slider.
 *
 * @prop {(value:number) => string} [getAriaValueText]
 *   Returns a human-readable string for assistive technologies.
 *
 * @prop {number} [value2]
 *   Secondary value when `type="range"`.
 *
 * @prop {(value:number) => void} [setValue2]
 *   Callback used to update the secondary value when `type="range"`.
 *
 * @prop {"range"} [type]
 *   Enables dual range selection.
 */
export declare const MoorhenSlider: (props: MoorhenSliderProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoorhenSlider.d.ts.map