import "../MoorhenInput.css";
import React from "react";
import type { MoorhenMolecule } from "../../../utils/MoorhenMolecule";
type MoorhenCidInputFormPropsType = {
    height?: string;
    width?: string;
    margin?: string;
    label?: string;
    placeholder?: string;
    defaultValue?: string;
    onChange?: (arg0: React.ChangeEvent<HTMLInputElement>) => void;
    invalidCid?: boolean;
    allowUseCurrentSelection?: boolean;
    ref?: React.Ref<HTMLInputElement>;
    inline?: boolean;
    setValue?: React.Dispatch<React.SetStateAction<string>> | ((newCid: string) => void);
    setMolecule?: React.Dispatch<React.SetStateAction<MoorhenMolecule>> | ((newMolecules: MoorhenMolecule) => void);
    setMoleculeUniqueId?: React.Dispatch<React.SetStateAction<string>> | ((newMoleculeUniqueId: string) => void);
    allowPickAtom?: boolean;
    selectedUniqueId?: number;
    value?: string;
};
export declare const MoorhenCidInputForm: (props: MoorhenCidInputFormPropsType) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoorhenCidInputForm.d.ts.map