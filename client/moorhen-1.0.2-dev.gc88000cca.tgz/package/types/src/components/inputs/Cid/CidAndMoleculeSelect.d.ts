import { MoorhenMolecule } from "../../../utils/MoorhenMolecule";
export declare const MoorhenCidAndMoleculeSelect: (props: {
    moleculeList?: MoorhenMolecule[];
    setSelectedMoleculeUniqueId: React.Dispatch<React.SetStateAction<string>> | ((newMoleculeUniqueId: string) => void);
    setSelectedCid: React.Dispatch<React.SetStateAction<string>> | ((newCid: string) => void);
    selectedMoleculeUniqueId?: string;
    selectedCid?: string;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=CidAndMoleculeSelect.d.ts.map