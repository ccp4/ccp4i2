import { Dispatch, SetStateAction } from "react";
import "./NumberInput.css";
type MoorhenNumberInputProps = {
    value: number | null;
    setValue?: (newVal: number) => void | Dispatch<SetStateAction<number>>;
    onChange?: (arg0: React.ChangeEvent<HTMLInputElement>) => void;
    onBlur?: (arg0: React.FocusEvent<HTMLInputElement>) => void;
    onReturn?: () => void;
    waitReturn?: boolean;
    allowNegativeValues?: boolean;
    decimalDigits?: number;
    label?: string;
    disabled?: boolean;
    width?: string | number;
    minMax?: [number, number];
    type?: "default" | "number" | "numberForm" | "withButtons";
    labelPosition?: "top" | "left";
    style?: React.CSSProperties;
    ref?: React.Ref<HTMLInputElement>;
    integer?: boolean;
    showButtons?: boolean;
    buttonSteps?: number;
    tooltip?: string;
    className?: string;
    isInvalid?: boolean;
    specialValuesTexts?: {
        [key: number]: string;
    };
};
/**
 * MoorhenNumberInput component props
 *
 * @prop {number | null | undefined} value
 *   The current value of the input. Can be a number, null, or undefined.
 *
 * @prop {function} setValue
 *   Callback to update the value in the parent component. Receives the new value as a string. Returns void.
 *
 * @prop {boolean} [waitReturn=false]
 *   If true, only updates value when the user presses Enter. Otherwise, updates on every valid change.
 *
 * @prop {boolean} [allowNegativeValues=true]
 *   If false, negative values are not allowed.
 *
 * @prop {number} [decimalDigits=2]
 *   Number of decimal digits to display and allow for input.
 *
 * @prop {string} [label]
 *   Optional label to display next to the input.
 *
 * @prop {boolean} [disabled=false]
 *   If true, disables the input.
 *
 * @prop {string | number} [width]
 *   Width of the input field (e.g., "4rem" or 100).
 *
 * @prop {number[]} [minMax]
 *   Minimum and maximum [number,number] allowed values for the input.
 *
 * @prop {string} [type="standard" | "number" | "numberForm"]
 *   This is something of a misnomer, as it is always a number input, but it can be set to number to get the clicky arrows next to the input.
 *   this might be changed for a future version, with the same button as sliders and same step behaviour.
 *
 * @returns {JSX.Element}
 *   A React component that renders a precise input field with validation and optional label.
 */
export declare const MoorhenNumberInput: (props: MoorhenNumberInputProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=NumberInput.d.ts.map