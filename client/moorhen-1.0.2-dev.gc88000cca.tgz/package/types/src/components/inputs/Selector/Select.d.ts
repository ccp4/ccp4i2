import React from "react";
export type MoorhenSelectProps = {
    children: React.ReactNode;
    ref?: React.Ref<HTMLSelectElement>;
    label?: string | React.JSX.Element;
    inline?: boolean;
    defaultValue?: string | number | readonly string[];
    value?: string | number | readonly string[];
    onChange?: (arg0: React.ChangeEvent<HTMLSelectElement>) => void;
    disabled?: boolean;
    setValue?: ((val: string | number | readonly string[]) => void) | React.Dispatch<React.SetStateAction<string | number | readonly string[]>>;
    style?: React.CSSProperties;
    onFocus?: () => void;
    onBlur?: () => void;
};
export declare const MoorhenSelect: (props: MoorhenSelectProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Select.d.ts.map