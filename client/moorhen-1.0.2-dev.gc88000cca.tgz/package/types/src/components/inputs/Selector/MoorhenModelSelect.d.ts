import { moorhen } from "../../../types/moorhen";
type MoorhenModelSelectProps = {
    height?: string;
    width?: string;
    margin?: string;
    label?: string;
    disabled?: boolean;
    selectedCoordMolNo: number;
    molecules: moorhen.Molecule[];
    onChange?: (arg0: React.ChangeEvent<HTMLSelectElement>) => void;
    ref?: React.Ref<HTMLSelectElement>;
    allowAll?: boolean;
    setValue?: (cid: string) => void;
};
export declare const MoorhenModelSelect: (props: MoorhenModelSelectProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoorhenModelSelect.d.ts.map