import { moorhen } from "../../../types/moorhen";
type MoorhenLigandSelectProps = {
    height?: string;
    width?: string;
    margin?: string;
    label?: string;
    disabled?: boolean;
    selectedCoordMolNo: number;
    molecules: moorhen.Molecule[];
    onChange?: (arg0: React.ChangeEvent<HTMLSelectElement>) => void;
    ref?: React.Ref<HTMLSelectElement>;
    allowAll?: boolean;
    setValue?: (cid: string) => void;
};
export declare const MoorhenLigandSelect: (props: MoorhenLigandSelectProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoorhenLigandSelect.d.ts.map