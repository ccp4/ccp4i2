import React from "react";
import type { MoorhenMolecule } from "../../../utils/MoorhenMolecule";
import "./selectors.css";
type MoorhenMoleculeSelectType = {
    onChange?: (evt: React.ChangeEvent<HTMLSelectElement>) => void;
    molecules?: MoorhenMolecule[];
    disabled?: boolean;
    allowAny?: boolean;
    ref?: React.Ref<HTMLSelectElement>;
    label?: string | null;
    style?: React.CSSProperties;
    filterFunction?: (arg0: MoorhenMolecule) => boolean;
    useUniqueId?: boolean;
};
export type MoorhenMoleculeSelectMolNoType = MoorhenMoleculeSelectType & {
    useUniqueId?: false;
    selectedMolecule?: number;
    setSelectedMolecule?: React.Dispatch<React.SetStateAction<number | undefined>>;
    onSelect?: (arg0: number) => void;
};
export type MoorhenMoleculeSelectUIDType = MoorhenMoleculeSelectType & {
    useUniqueId: true;
    selectedMolecule?: string;
    setSelectedMolecule?: React.Dispatch<React.SetStateAction<string | undefined>>;
    onSelect?: (arg0: string) => void;
};
export declare const MoorhenMoleculeSelect: (props: MoorhenMoleculeSelectMolNoType | MoorhenMoleculeSelectUIDType) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoleculeSelector.d.ts.map