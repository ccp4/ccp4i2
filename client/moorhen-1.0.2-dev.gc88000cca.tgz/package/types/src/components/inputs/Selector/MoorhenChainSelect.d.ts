import { moorhen } from "../../../types/moorhen";
type MoorhenChainSelectPropsType = {
    allowedTypes?: number[];
    height?: string;
    width?: string;
    margin?: string;
    label?: string;
    molecules: moorhen.Molecule[];
    selectedCoordMolNo: number;
    onChange?: (arg0: React.ChangeEvent<HTMLSelectElement>) => void;
    defaultValue?: string;
    disabled?: boolean;
    ref?: React.Ref<HTMLSelectElement>;
    allowAll?: boolean;
    value?: string;
    setValue?: React.Dispatch<React.SetStateAction<string>> | ((newValue: string) => void);
};
export declare const MoorhenChainSelect: (props: MoorhenChainSelectPropsType) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoorhenChainSelect.d.ts.map