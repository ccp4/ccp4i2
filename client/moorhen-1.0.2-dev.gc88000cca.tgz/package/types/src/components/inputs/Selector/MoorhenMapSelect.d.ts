import React from "react";
import type { MoorhenMap } from "../../../utils/MoorhenMap";
type MoorhenMapSelectBaseProps = {
    label?: string;
    maps?: MoorhenMap[];
    filterFunction?: (arg0: MoorhenMap) => boolean;
    ref?: React.Ref<HTMLSelectElement>;
    disabled?: boolean;
    onChange?: (evt: React.ChangeEvent<HTMLSelectElement>) => void;
    onSelect?: (value: number | string) => void;
    useUniqueId?: boolean;
};
export type MoorhenMapSelectPropsType = MoorhenMapSelectBaseProps & {
    defaultValue?: number | null;
    selectedMap?: number | null;
    setSelectedMap?: React.Dispatch<React.SetStateAction<number | null>>;
};
export type MoorhenMapSelectPropsUIDType = MoorhenMapSelectBaseProps & {
    defaultValue?: string | null;
    selectedMap?: string | null;
    setSelectedMap?: React.Dispatch<React.SetStateAction<string | null>>;
};
/**
 * A map selector react component
 * @property {string} [height="4rem"] The height of the selector
 * @property {string} [width="20rem"] The width of the selector
 * @property {string} [label="Map"] A text label shown on top of the selector
 * @property {MoorhenMap[]} maps List of maps displayed in the selector options
 * @property {function} filterFunction A function that takes a MoorhenMap as input and returns a boolean: true if the map is to be included in the options.
 * @property {function} onChange A function that is called when the user changes the selector option
 * @property {number | string} [defaultValue=-999999] The default value of the selector
 * @example
 * import { MoorhenMapSelect } from "moorhen";
 * import { useRef } from "react";
 *
 * const mapSelectRef = useRef(null);
 *
 * const handleMapChange = (evt) => {
 *  const selectedMap = parseInt(evt.target.value)
 *  console.log(`New selected map is ${selectedMap}`)
 * }
 *
 * return (
 *  <MoorhenMapSelect ref={mapSelectRef} filterFunction={(map) => !map.hasReflectionData}
     width='100%' label='Select a map' onChange={handleMapChange} />
 * )
 */
export declare const MoorhenMapSelect: (props: MoorhenMapSelectPropsType | MoorhenMapSelectPropsUIDType) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoorhenMapSelect.d.ts.map