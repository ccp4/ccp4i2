import { ReactNode } from "react";
export declare const MoorhenProvider: (props: {
    children: ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenProvider.d.ts.map