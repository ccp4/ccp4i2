import React from "react";
import "../side-panels.css";
export declare const SidePanelContainer: (props: {
    title: string;
    extraControls?: React.JSX.Element;
    children: React.JSX.Element | React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SidePanelContainer.d.ts.map