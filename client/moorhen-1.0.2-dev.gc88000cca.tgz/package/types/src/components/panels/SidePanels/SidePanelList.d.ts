import React from "react";
import { MoorhenSVG } from "../../icons";
export type SidePanelIDs = "models" | "maps" | "sceneSettings" | "vectors" | "overlay2DObjects" | "3DObjects" | "movie" | (string & {});
export type MoorhenPanel = {
    icon: MoorhenSVG;
    label: string;
    panelContent: React.JSX.Element;
};
export declare const PanelsList: Partial<Record<SidePanelIDs, MoorhenPanel>>;
//# sourceMappingURL=SidePanelList.d.ts.map