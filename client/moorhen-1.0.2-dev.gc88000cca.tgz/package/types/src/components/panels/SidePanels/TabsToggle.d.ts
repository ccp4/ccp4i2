import { MoorhenSVG } from "../../icons";
import { SidePanelIDs } from "./SidePanelList";
type TabsToggleProps = {
    label: string;
    icon: MoorhenSVG;
    showHintLabel?: boolean;
    id: SidePanelIDs;
    onDelete: (id: SidePanelIDs) => void;
};
export declare const TabsToggle: (props: TabsToggleProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=TabsToggle.d.ts.map