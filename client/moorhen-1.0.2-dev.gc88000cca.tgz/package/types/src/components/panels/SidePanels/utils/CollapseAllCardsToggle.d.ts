export declare const CollapseAllCardsToggle: (props: {
    keyList: number[];
    allOpen: any;
    setAllOpen: (val: any) => void;
    activeToggle: {
        key: any;
        isOpen: any;
    };
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=CollapseAllCardsToggle.d.ts.map