export declare const MapsPanel: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MapsPanel.d.ts.map