export declare const ModelsPanel: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ModelsPanel.d.ts.map