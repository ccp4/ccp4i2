import { MoorhenPanel } from "./SidePanelList";
import "./side-panels.css";
interface MoorhenSidePanelProps {
    extraSidePanels?: Record<string, MoorhenPanel>;
}
export declare const MoorhenSidePanel: ({ extraSidePanels }: MoorhenSidePanelProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=SidePanel.d.ts.map