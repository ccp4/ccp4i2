export declare const SequenceViewerTab: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SequenceViewerTab.d.ts.map