import { ReactNode } from "react";
export interface BaseSequenceViewerTabProps {
    isActiveTab: boolean;
    onTitleClick: () => void;
    titleText: string;
    configPanel?: ReactNode;
    showExpandButton?: boolean;
    expandedState?: boolean;
    onExpandClick?: () => void;
    infoCard?: ReactNode;
}
/**
 * Generic base tab component for sequence viewer panels
 * Eliminates duplication between SequenceViewerTab and ValidationTab
 */
export declare const BaseSequenceViewerTab: ({ isActiveTab, onTitleClick, titleText, configPanel, showExpandButton, expandedState, onExpandClick, infoCard, }: BaseSequenceViewerTabProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=BaseSequenceViewerTab.d.ts.map