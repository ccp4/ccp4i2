export type BottomPanelIDs = "sequences-viewer" | "validation" | null;
export declare const BottomPanelsList: Partial<Record<BottomPanelIDs, React.JSX.Element>>;
//# sourceMappingURL=BottomPanelsList.d.ts.map