import "./bottom-panel.css";
export declare const BottomPanelContainer: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=BottomPanel.d.ts.map