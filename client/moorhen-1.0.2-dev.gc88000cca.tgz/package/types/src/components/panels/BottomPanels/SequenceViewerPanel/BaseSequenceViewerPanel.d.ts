import { MoorhenSequenceViewerSequence } from "../../../../components/sequence-viewer";
export interface BaseSequenceViewerPanelProps {
    selectedMolecule: string;
    sequences: MoorhenSequenceViewerSequence[];
    displayHeight?: number;
    showValidationData?: boolean;
    nameColumnWidth?: number;
    validationTracks?: string[];
    showTitleBar?: boolean;
    columnWidth?: number;
}
/**
 * Generic base component for rendering a sequence viewer
 * Eliminates duplication between SequenceViewerPanel and ValidationPanel
 */
export declare const BaseSequenceViewerPanel: ({ selectedMolecule, sequences, displayHeight, showValidationData, nameColumnWidth, validationTracks, showTitleBar, columnWidth, }: BaseSequenceViewerPanelProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=BaseSequenceViewerPanel.d.ts.map