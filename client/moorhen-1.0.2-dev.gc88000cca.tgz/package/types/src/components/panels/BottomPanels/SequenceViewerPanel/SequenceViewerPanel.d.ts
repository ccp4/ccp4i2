export type SequenceViewerOption = {
    showExpandButton: boolean;
    nOfLines: number;
    expanded: boolean;
    selectedMolecule: string;
    columnWidth: number;
};
export declare const SequenceViewerPanel: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SequenceViewerPanel.d.ts.map