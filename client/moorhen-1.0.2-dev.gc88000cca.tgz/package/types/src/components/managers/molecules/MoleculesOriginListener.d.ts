export declare const MoleculesOriginListener: () => any;
//# sourceMappingURL=MoleculesOriginListener.d.ts.map