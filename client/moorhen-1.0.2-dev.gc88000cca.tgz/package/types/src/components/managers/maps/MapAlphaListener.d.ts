import { moorhen } from "../../../types/moorhen";
export declare const MapAlphaListener: (props: {
    map: moorhen.Map;
}) => any;
//# sourceMappingURL=MapAlphaListener.d.ts.map