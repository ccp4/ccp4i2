/**
 * React functional component that manages and renders a list of `MoorhenMapManager` components,
 * one for each map present in the application's Redux state.
 *
 * @returns {JSX.Element[] | null} An array of `MoorhenMapManager` components, or `null` if no maps are present.
 *
 * @remarks
 * - Uses the `useSelector` hook to access the `maps` array from the Redux state.
 * - Each `MoorhenMapManager` is keyed by its associated `molNo`.
 */
export declare const MoorhenMapsHeadManager: () => import("react/jsx-runtime").JSX.Element[];
//# sourceMappingURL=MoorhenMapsHeadManager.d.ts.map