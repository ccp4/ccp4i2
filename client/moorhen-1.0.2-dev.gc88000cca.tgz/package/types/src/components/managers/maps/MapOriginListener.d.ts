export declare const MapOriginListener: (props: {
    drawMap(): void;
    mapUID: string;
}) => any;
export declare const MapOriginListenerMouseUp: (props: {
    drawMap(): void;
}) => any;
//# sourceMappingURL=MapOriginListener.d.ts.map