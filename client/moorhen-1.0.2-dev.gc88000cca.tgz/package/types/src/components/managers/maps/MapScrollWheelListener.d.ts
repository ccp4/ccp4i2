import { moorhen } from "../../../types/moorhen";
export declare const MapScrollWheelListener: (props: {
    mapContourLevel: number;
    mapIsVisible: boolean;
    map: moorhen.Map;
}) => any;
//# sourceMappingURL=MapScrollWheelListener.d.ts.map