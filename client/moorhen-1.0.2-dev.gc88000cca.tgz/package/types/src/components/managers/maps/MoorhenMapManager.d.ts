export declare const MoorhenMapManager: import("react").MemoExoticComponent<(props: {
    mapMolNo: number;
}) => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=MoorhenMapManager.d.ts.map