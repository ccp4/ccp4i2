export declare const AtomClickManager: () => any;
//# sourceMappingURL=AtomClickManager.d.ts.map