export declare const MoorhenExitMenu: (props: {
    exitCallback: () => void;
}) => import("react/jsx-runtime").JSX.Element;
export declare const MoorhenApp: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenApp.d.ts.map