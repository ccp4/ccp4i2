import { moorhen } from "../../types/moorhen";
import { webGL } from "../../types/mgWebGL";
interface MoorhenWebMGPropsInterface {
    monomerLibraryPath: string;
    timeCapsuleRef: React.RefObject<moorhen.TimeCapsule>;
    viewOnly: boolean;
    urlPrefix: string;
    onAtomHovered: (identifier: {
        buffer: {
            id: string;
        };
        atom: moorhen.AtomInfo;
    }) => void;
    onSectionHovered?: (identifier: {
        buffer: {
            id: string;
        };
        kind: string;
        tag: string;
    }) => void;
}
export declare const MoorhenWebMG: import("react").ForwardRefExoticComponent<MoorhenWebMGPropsInterface & import("react").RefAttributes<webGL.MGWebGL>>;
export {};
//# sourceMappingURL=MoorhenWebMG.d.ts.map