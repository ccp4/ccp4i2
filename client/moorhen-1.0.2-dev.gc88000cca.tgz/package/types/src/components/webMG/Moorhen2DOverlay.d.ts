import * as quat4 from 'gl-matrix/quat';
import { RootState } from '../../store/MoorhenReduxStore';
import { Store } from '@reduxjs/toolkit';
import "./UoY-legal.css";
interface ImageFrac2D {
    x: number;
    y: number;
    width: number;
    height: number;
    img: HTMLImageElement;
    zIndex: number;
}
export declare const drawOn2DContext: (canvas2D_ctx: CanvasRenderingContext2D, width: number, height: number, scale: number, helpText: string[], images: ImageFrac2D[], drawQuat: quat4, zIndex: number, store: Store<RootState>) => void;
export declare const Moorhen2DOverlay: (props: any) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Moorhen2DOverlay.d.ts.map