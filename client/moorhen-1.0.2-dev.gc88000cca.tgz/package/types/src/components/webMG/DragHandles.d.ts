/**
 * Moving and turning an object by its handles.
 *
 * The renderer reports three things - a grab began, the pointer moved, the grab ended - each
 * carrying a label it does not interpret and the pointer as a ray through the scene. Here that
 * label is read as an axis and an action, and the ray is turned into a distance or an angle.
 *
 * Everything is measured against where the drag started rather than accumulated step by step,
 * so a slow drag and a fast one over the same distance end in the same place, and a dropped
 * frame costs nothing.
 */
export declare const DragHandles: () => any;
//# sourceMappingURL=DragHandles.d.ts.map