export declare const DrawHoverAtom: () => any;
//# sourceMappingURL=HoverAtom.d.ts.map