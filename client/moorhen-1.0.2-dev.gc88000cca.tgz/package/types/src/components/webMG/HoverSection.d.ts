/**
 * The reciprocal of the bridge in MainContainer: an atom is hovered, so light the piece of mesh
 * that stands for it.
 *
 * The same opaque labels carry the meaning in both directions. There a section's label became an
 * atom hover; here an atom hover is turned back into a label and looked for among the meshes.
 * Neither the mesh code nor the molecular code learns anything about the other - this component
 * and the label scheme are the whole of the coupling.
 *
 * The hover may have come from the sequence viewer, a validation plot, or the pointer landing on
 * an atom in the 3D view. None of that matters here: whatever set hoveredAtom gets the same
 * reciprocal highlight, which is why hovering an atom also lights the trace that passes through
 * it. Whether a golden ball appears alongside is a separate question, settled by DrawHoverAtom
 * according to whether the molecule is showing its atoms.
 */
export declare const HighlightHoveredSection: () => any;
//# sourceMappingURL=HoverSection.d.ts.map