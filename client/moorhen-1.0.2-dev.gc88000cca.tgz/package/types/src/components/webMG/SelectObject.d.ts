/**
 * Choosing which 3D object the manipulation handles belong to, by clicking it.
 *
 * The renderer reports that something was clicked and hands over the label it was carrying,
 * without knowing what the label means or whether anyone is listening. Here that label is read
 * as an object id - but only if it is in this scheme, so a click on anything else labelled in
 * some other way passes by untouched.
 *
 * Clicking nothing clears the selection, which is the only way to put the handles away without
 * going back to the dialog.
 */
export declare const SelectClickedObject: () => any;
//# sourceMappingURL=SelectObject.d.ts.map