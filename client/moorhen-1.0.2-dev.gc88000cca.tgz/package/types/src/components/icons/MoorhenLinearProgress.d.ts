export declare const MoorhenLinearProgress: (props: {
    colour?: string;
    thickness?: number;
    style?: React.CSSProperties;
    value?: number;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenLinearProgress.d.ts.map