type SpinnerProps = {
    size?: number | string;
    colour?: string;
    backgroundColour?: string;
};
export declare const MoorhenSpinner: (props: SpinnerProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoorhenSpinner.d.ts.map