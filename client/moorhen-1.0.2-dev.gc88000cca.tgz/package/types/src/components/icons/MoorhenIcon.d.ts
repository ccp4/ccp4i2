import "./moorhen-icons.css";
import type { MoorhenSVG } from "./moorhen_icons";
type BaseIconProps = {
    alt?: string;
    size?: "small" | "medium" | "large" | "accordion";
    style?: React.CSSProperties;
    isActive?: boolean;
    className?: string;
    ref?: React.Ref<HTMLSpanElement | HTMLImageElement>;
    onMouseEnter?: () => void;
    onMouseLeave?: () => void;
    hover?: boolean;
    variant?: "" | "danger";
    tooltip?: string;
};
type MoorhenIconPropsType = BaseIconProps & ({
    moorhenSVG: MoorhenSVG;
    src?: never;
} | {
    src: string;
    moorhenSVG?: never;
});
export declare const MoorhenIcon: ({ moorhenSVG, src, alt, size, isActive, className, style, ref, hover, onMouseEnter, onMouseLeave, variant, tooltip, }: MoorhenIconPropsType) => any;
export {};
//# sourceMappingURL=MoorhenIcon.d.ts.map