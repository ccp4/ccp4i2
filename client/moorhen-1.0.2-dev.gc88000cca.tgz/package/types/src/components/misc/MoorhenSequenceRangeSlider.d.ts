export declare const MoorhenSequenceRangeSlider: (props: {
    selectedMolNo: number;
    selectedChainId: string;
    range?: [number, number];
    setRange: (range: [number, number]) => void;
    useSeqNumbers?: boolean;
    style?: React.CSSProperties;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenSequenceRangeSlider.d.ts.map