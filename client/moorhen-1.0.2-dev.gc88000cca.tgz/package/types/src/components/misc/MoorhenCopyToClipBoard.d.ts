export declare const MoorhenCopyToClipBoard: (props: {
    text: string;
    tooltip: string;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenCopyToClipBoard.d.ts.map