export declare function clampValue(value: number, minVal: number, maxVal: number): number;
export declare const getFirstNonZeroDigitIndex: (num: number) => number | null;
export declare function toFixedNoZero(value: number, decimalPlaces: number): string;
//# sourceMappingURL=helpers.d.ts.map