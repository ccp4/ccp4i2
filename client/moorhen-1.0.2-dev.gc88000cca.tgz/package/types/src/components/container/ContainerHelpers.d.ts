import { RefObject } from "react";
import type { moorhen } from "../../types/moorhen";
export declare const cootAPIHelpers: {
    setMakeBackups: (commandCentre: RefObject<moorhen.CommandCentre>, makeBackups: boolean) => Promise<void>;
    setSamplingRate: (commandCentre: RefObject<moorhen.CommandCentre>, rate: number) => Promise<void>;
    setDrawMissingLoops: (commandCentre: RefObject<moorhen.CommandCentre>, drawMissingLoops: boolean) => Promise<void>;
};
//# sourceMappingURL=ContainerHelpers.d.ts.map