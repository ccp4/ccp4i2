import React from "react";
import { MoorhenInstance } from "../../InstanceManager";
import { CommandCentre } from "../../InstanceManager/CommandCentre";
import { webGL } from "../../types/mgWebGL";
import { moorhen } from "../../types/moorhen";
import { MoorhenMenuSystem } from "../menu-system/MenuSystem";
import "./container.css";
import "../../global.css";
interface ContainerRefs {
    glRef?: React.RefObject<null | webGL.MGWebGL>;
    timeCapsuleRef?: React.RefObject<null | moorhen.TimeCapsule>;
    commandCentre?: React.RefObject<null | CommandCentre>;
    videoRecorderRef?: React.RefObject<null | moorhen.ScreenRecorder>;
    moleculesRef?: React.RefObject<null | moorhen.Molecule[]>;
    mapsRef?: React.RefObject<null | moorhen.Map[]>;
    activeMapRef?: React.RefObject<moorhen.Map>;
    lastHoveredAtomRef?: React.RefObject<null | moorhen.HoveredAtom>;
    moorhenInstanceRef?: React.RefObject<null | MoorhenInstance>;
    moorhenMenuSystemRef?: React.RefObject<null | MoorhenMenuSystem>;
    parentElementRef?: React.RefObject<null | HTMLElement>;
}
interface ContainerOptionalProps {
    onUserPreferencesChange?: (key: string, value: unknown) => void;
    onInitialisationCompleted?: () => void;
    disableFileUploads?: boolean;
    urlPrefix?: string;
    viewOnly: boolean;
    extraDraggableModals?: React.JSX.Element[];
    extraSidePanels?: Record<string, import("../panels").MoorhenPanel>;
    monomerLibraryPath?: string;
    allowScripting?: boolean;
    backupStorageInstance?: moorhen.LocalStorageInstance;
    aceDRGInstance?: moorhen.AceDRGInstance | null;
    allowAddNewFittedLigand?: boolean;
    allowMergeFittedLigand?: boolean;
    webComponentMode?: boolean;
    size?: [number, number];
}
export interface ContainerProps extends Partial<ContainerRefs>, Partial<ContainerOptionalProps> {
}
export declare const MoorhenContainer: (props: ContainerProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MainContainer.d.ts.map