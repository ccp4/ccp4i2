import { moorhen } from "../../types/moorhen";
interface MoorhenDroppablePropsInterface {
    monomerLibraryPath: string;
    timeCapsuleRef: React.RefObject<moorhen.TimeCapsule>;
    commandCentre: React.RefObject<moorhen.CommandCentre>;
    children?: React.ReactNode;
}
export declare const MoorhenDroppable: (props: MoorhenDroppablePropsInterface) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoorhenDroppable.d.ts.map