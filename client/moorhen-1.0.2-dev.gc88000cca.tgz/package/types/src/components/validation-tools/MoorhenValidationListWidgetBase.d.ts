import { moorhen } from "../../types/moorhen";
export declare const MoorhenValidationListWidgetBase: (props: {
    filterMapFunction?: (arg0: moorhen.Map) => boolean;
    fetchData: (arg0: number, arg1: number) => Promise<any>;
    getCards: (arg0: number, arg1: number, arg2: any) => React.JSX.Element[];
    extraControlForm?: React.JSX.Element;
    extraControlFormValue?: any;
    enableMapSelect?: boolean;
    menuId?: string;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenValidationListWidgetBase.d.ts.map