export declare const MoorhenJsonValidation: (props: {
    isDocked?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenJsonValidation.d.ts.map