export declare const MoorhenWaterValidation: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenWaterValidation.d.ts.map