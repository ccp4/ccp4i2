export declare const MoorhenCarbohydrateValidation: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenCarbohydrateValidation.d.ts.map