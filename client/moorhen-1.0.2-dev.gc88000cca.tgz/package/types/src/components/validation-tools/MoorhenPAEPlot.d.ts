interface MoorhenPAEProps {
    resizeTrigger?: boolean;
    size?: {
        width: number;
        height: number;
    };
    isDocked?: boolean;
    loadMoleculeOnOpen?: string;
}
export declare const MoorhenPAEPlot: (props: MoorhenPAEProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoorhenPAEPlot.d.ts.map