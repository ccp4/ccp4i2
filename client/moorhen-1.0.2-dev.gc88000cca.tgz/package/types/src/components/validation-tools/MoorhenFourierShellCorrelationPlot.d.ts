export declare const MoorhenFourierShellCorrelationPlot: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenFourierShellCorrelationPlot.d.ts.map