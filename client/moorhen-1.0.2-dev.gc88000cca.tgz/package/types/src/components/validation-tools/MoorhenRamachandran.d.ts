export interface MoorhenRamachandranProps {
    resizeTrigger?: boolean;
    resizeNodeRef?: React.RefObject<HTMLDivElement>;
    size?: {
        width: number;
        height: number;
    };
}
export declare const MoorhenRamachandran: (props: MoorhenRamachandranProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenRamachandran.d.ts.map