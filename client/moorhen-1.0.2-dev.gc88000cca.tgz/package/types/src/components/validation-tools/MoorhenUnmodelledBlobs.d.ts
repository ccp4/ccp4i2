export declare const MoorhenUnmodelledBlobs: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenUnmodelledBlobs.d.ts.map