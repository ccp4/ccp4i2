export declare const MoorhenMMRRCCPlot: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenMMRRCCPlot.d.ts.map