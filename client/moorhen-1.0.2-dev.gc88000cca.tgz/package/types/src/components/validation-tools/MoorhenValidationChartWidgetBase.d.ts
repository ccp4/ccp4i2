import { Chart } from "chart.js";
import { moorhen } from "../../types/moorhen";
type ValidationChartProps = {
    filterMapFunction?: (arg0: moorhen.Map) => boolean;
    fetchData: (arg0: number, arg1: number, arg2: string) => Promise<any>;
    /** The last argument is the chart's container element, for charts that size it to their data */
    getChart: (arg0: number, arg1: number, arg2: string, arg3: any, containerBody: HTMLDivElement | null) => any;
    extraControlForm?: React.JSX.Element;
    extraControlFormValue?: any;
    enableChainSelect?: boolean;
    chartId: string;
};
export declare const MoorhenValidationChartWidgetBase: import("react").ForwardRefExoticComponent<ValidationChartProps & import("react").RefAttributes<Chart<keyof import("chart.js").ChartTypeRegistry, (number | [number, number] | import("chart.js").Point | import("chart.js").BubbleDataPoint)[], unknown>>>;
export {};
//# sourceMappingURL=MoorhenValidationChartWidgetBase.d.ts.map