interface MoorhenConKitProps {
    resizeTrigger?: boolean;
    resizeNodeRef?: React.RefObject<HTMLDivElement>;
    size?: {
        width: number;
        height: number;
    };
}
export declare const MoorhenConKit: (props: MoorhenConKitProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoorhenConKit.d.ts.map