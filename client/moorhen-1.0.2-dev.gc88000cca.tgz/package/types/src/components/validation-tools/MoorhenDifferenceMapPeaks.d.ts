export declare const MoorhenDifferenceMapPeaks: (props: {
    chartId: string;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenDifferenceMapPeaks.d.ts.map