export declare const MoorhenLigandValidation: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenLigandValidation.d.ts.map