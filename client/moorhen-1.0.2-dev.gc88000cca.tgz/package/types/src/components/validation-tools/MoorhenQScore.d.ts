export declare const MoorhenQScore: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenQScore.d.ts.map