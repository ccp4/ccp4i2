export declare const MoorhenValidation: (props: {
    chartId: string;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenValidation.d.ts.map