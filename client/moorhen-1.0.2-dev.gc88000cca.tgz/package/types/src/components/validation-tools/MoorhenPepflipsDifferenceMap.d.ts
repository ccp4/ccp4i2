import { UnknownAction } from "@reduxjs/toolkit";
import { Dispatch } from "react";
import { CommandCentre } from "../../InstanceManager/CommandCentre";
import { moorhen } from "../../types/moorhen";
export declare const flipPeptide: (selectedMolecule: moorhen.Molecule, chainId: string, seqNum: number, insCode: string, commandCentre: React.RefObject<CommandCentre>, enableRefineAfterMod: boolean, dispatch: Dispatch<UnknownAction>, moorhenInstance: any) => Promise<void>;
export declare const MoorhenPepflipsDifferenceMap: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenPepflipsDifferenceMap.d.ts.map