import { UnknownAction } from "@reduxjs/toolkit";
import React, { Dispatch } from "react";
import { CommandCentre } from "../../InstanceManager/CommandCentre/MoorhenCommandCentre";
import { moorhen } from "../../types/moorhen";
export declare const fillPartialResidue: (selectedMolecule: moorhen.Molecule, chainId: string, resNum: number, insCode: string, commandCentre: React.RefObject<CommandCentre>, dispatch: Dispatch<UnknownAction>, enableRefineAfterMod: boolean, moorhenInstance: any) => Promise<void>;
export declare const MoorhenFillMissingAtoms: (props: any) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenFillMissingAtoms.d.ts.map