export declare const ManageSession: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ManageSession.d.ts.map