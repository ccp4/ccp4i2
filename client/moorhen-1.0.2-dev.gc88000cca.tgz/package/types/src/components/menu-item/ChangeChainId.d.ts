export declare const ChangeChainId: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ChangeChainId.d.ts.map