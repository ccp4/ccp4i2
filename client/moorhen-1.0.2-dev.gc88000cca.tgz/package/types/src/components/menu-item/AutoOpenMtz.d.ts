export declare const AutoOpenMtz: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AutoOpenMtz.d.ts.map