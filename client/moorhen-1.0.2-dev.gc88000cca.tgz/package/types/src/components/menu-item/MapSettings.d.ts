import { moorhen } from "../../types/moorhen";
export declare const MapSettings: (props: {
    map: moorhen.Map;
    mapStyle: "solid" | "lit-lines" | "lines";
    mapOpacity: number;
    setPopoverIsShown: React.Dispatch<React.SetStateAction<boolean>>;
    disabled: boolean;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MapSettings.d.ts.map