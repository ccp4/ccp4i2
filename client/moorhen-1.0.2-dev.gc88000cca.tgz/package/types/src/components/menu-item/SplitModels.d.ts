export declare const SplitModels: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SplitModels.d.ts.map