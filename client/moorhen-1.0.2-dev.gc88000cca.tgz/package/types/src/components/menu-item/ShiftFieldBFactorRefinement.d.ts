export declare const ShiftFieldBFactor: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ShiftFieldBFactorRefinement.d.ts.map