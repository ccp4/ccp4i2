export declare const BackupPreferences: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=BackupPreferences.d.ts.map