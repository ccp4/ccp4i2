export declare const CopyFragmentUsingCid: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=CopyFragmentUsingCid.d.ts.map