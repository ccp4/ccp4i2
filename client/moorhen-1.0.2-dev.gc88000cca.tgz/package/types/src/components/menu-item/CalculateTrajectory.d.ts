export declare const CalculateTrajectory: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=CalculateTrajectory.d.ts.map