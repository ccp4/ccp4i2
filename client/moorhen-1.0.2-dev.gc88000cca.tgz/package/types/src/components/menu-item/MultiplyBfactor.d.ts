export declare const MultiplyBfactor: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MultiplyBfactor.d.ts.map