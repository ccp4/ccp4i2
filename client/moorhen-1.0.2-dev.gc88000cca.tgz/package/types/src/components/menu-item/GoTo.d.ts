export declare const GoTo: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=GoTo.d.ts.map