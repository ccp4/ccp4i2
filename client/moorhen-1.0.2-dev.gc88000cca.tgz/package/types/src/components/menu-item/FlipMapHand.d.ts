export declare const FlipMapHand: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=FlipMapHand.d.ts.map