export declare const CentreOnLigand: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=CentreOnLigand.d.ts.map