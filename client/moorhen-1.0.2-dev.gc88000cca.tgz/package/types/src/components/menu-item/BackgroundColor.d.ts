export declare const BackgroundColor: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=BackgroundColor.d.ts.map