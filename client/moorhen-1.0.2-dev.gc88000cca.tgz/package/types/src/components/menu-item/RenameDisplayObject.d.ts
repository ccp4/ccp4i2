import { moorhen } from "../../types/moorhen";
export declare const RenameDisplayObject: (props: {
    item: moorhen.Molecule | moorhen.Map;
    setCurrentName: React.Dispatch<React.SetStateAction<string>>;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=RenameDisplayObject.d.ts.map