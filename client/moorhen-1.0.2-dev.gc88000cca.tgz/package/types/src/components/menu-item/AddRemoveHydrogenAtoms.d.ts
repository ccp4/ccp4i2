export declare const AddRemoveHydrogenAtoms: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AddRemoveHydrogenAtoms.d.ts.map