export declare const ExportGltf: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ExportGltf.d.ts.map