import "../inputs/MoorhenInput.css";
export declare const FetchOnlineSources: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=FetchOnlineSources.d.ts.map