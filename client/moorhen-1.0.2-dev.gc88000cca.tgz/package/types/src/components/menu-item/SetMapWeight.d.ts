import { MoorhenMap } from "../../utils/MoorhenMap";
export declare const SetMapWeight: (props: {
    map: MoorhenMap;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SetMapWeight.d.ts.map