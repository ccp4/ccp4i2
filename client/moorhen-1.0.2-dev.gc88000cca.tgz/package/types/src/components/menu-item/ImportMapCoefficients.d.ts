export declare const ImportMapCoefficients: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ImportMapCoefficients.d.ts.map