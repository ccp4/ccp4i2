export declare const AssociateReflectionsToMap: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AssociateReflectionsToMap.d.ts.map