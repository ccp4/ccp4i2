export declare const References: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=References.d.ts.map