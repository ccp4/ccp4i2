import { moorhen } from "../../types/moorhen";
export declare const ScaleMap: (props: {
    map: moorhen.Map;
    disabled: boolean;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ScaleMap.d.ts.map