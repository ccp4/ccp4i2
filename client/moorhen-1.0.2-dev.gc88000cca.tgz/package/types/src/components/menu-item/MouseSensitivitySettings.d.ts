export declare const MouseSensitivitySettings: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MouseSensitivitySettings.d.ts.map