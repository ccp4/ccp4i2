export declare const RandomJiggleBlur: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=RandomJiggleBlur.d.ts.map