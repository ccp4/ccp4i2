export declare const AddWaters: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AddWaters.d.ts.map