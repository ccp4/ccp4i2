export declare const Backups: (props: {
    disabled: boolean;
    loadSession: (sessionDataString: string) => Promise<void>;
}) => import("react/jsx-runtime").JSX.Element;
type MoorhenBackupSelectPropsType = {
    height?: string;
    width?: string;
    label?: string;
    ref?: React.Ref<HTMLSelectElement>;
};
export declare const MoorhenBackupSelect: (props: MoorhenBackupSelectPropsType) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Backups.d.ts.map