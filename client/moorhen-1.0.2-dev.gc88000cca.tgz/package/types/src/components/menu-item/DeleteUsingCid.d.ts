export declare const DeleteUsingCid: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=DeleteUsingCid.d.ts.map