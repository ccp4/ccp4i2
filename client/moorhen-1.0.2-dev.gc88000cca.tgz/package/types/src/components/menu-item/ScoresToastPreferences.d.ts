export declare const ScoresToastPreferences: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ScoresToastPreferences.d.ts.map