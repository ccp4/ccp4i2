export declare const ExportMenuItem: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Export.d.ts.map