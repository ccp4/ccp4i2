export declare const GLFont: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=GLFont.d.ts.map