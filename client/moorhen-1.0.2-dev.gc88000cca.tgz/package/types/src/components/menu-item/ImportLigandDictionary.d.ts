export declare const SMILESToLigand: () => import("react/jsx-runtime").JSX.Element;
export declare const ImportDictionary: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ImportLigandDictionary.d.ts.map