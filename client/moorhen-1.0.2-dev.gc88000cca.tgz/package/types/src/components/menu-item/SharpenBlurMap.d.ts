export declare const SharpenBlurMap: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SharpenBlurMap.d.ts.map