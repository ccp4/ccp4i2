export declare const AddSimple: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AddSimple.d.ts.map