export declare const SetOccupancy: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SetOccupancy.d.ts.map