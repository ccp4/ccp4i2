export declare const CreateSelection: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=CreateSelection.d.ts.map