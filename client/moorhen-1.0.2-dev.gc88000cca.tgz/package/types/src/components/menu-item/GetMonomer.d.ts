export declare const GetMonomer: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=GetMonomer.d.ts.map