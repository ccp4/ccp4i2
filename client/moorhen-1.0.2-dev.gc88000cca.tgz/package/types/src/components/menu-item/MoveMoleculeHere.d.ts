export declare const MoveMoleculeHere: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoveMoleculeHere.d.ts.map