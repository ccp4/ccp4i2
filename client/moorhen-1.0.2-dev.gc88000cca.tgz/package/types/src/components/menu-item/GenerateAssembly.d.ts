import { moorhen } from "../../types/moorhen";
export declare const GenerateAssembly: (props: {
    item: moorhen.Molecule;
    setCurrentName: React.Dispatch<React.SetStateAction<string>>;
    setPopoverIsShown: React.Dispatch<React.SetStateAction<boolean>>;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=GenerateAssembly.d.ts.map