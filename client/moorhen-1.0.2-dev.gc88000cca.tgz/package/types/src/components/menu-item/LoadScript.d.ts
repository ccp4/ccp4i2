export declare const LoadScript: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=LoadScript.d.ts.map