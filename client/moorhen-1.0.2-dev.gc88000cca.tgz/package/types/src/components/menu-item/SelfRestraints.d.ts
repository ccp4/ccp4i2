export declare const SelfRestraints: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SelfRestraints.d.ts.map