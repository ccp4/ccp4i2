export declare const MinimizeEnergy: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MinimizeEnergy.d.ts.map