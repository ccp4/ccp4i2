export declare const MakeMaskedMapsSplitByChain: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MakeMaskedMapsSplitByChain.d.ts.map