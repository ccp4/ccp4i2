export declare const ConnectMoleculeToMaps: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ConnectMoleculeToMaps.d.ts.map