export declare const DeleteEverything: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=DeleteEverything.d.ts.map