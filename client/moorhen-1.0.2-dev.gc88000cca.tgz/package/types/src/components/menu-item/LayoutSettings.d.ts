export declare const LayoutSettings: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=LayoutSettings.d.ts.map