export declare const LoadFiles: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=LoadFiles.d.ts.map