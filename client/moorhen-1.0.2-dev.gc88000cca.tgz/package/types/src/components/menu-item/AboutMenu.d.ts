export declare const About: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AboutMenu.d.ts.map