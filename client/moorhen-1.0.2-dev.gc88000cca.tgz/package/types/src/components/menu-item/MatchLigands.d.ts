export declare const MatchLigands: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MatchLigands.d.ts.map