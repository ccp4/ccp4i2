export declare const StepRefinement: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=StepRefinement.d.ts.map