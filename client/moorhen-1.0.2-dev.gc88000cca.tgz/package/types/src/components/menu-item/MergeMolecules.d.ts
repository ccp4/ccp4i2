export declare const MergeMolecules: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MergeMolecules.d.ts.map