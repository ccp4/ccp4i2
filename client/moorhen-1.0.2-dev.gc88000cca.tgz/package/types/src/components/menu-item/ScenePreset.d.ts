export declare const ScenePreset: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ScenePreset.d.ts.map