export declare const LoadTutorialData: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=LoadTutorialData.d.ts.map