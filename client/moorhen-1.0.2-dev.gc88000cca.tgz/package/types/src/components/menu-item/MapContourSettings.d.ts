export declare const MapContourSettings: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MapContourSettings.d.ts.map