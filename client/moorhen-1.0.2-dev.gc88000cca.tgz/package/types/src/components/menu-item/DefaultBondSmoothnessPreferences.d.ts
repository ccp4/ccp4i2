export declare const DefaultBondSmoothnessPreferences: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=DefaultBondSmoothnessPreferences.d.ts.map