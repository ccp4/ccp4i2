export declare const ClearSelfRestraints: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ClearSelfRestraints.d.ts.map