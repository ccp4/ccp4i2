import { moorhen } from "../../types/moorhen";
export declare const DeleteDisplayObject: (props: {
    item: moorhen.Map | moorhen.Molecule;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=DeleteDisplayObject.d.ts.map