export declare const MapMasking: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MapMasking.d.ts.map