export declare const OpenLhasa: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=OpenLhasa.d.ts.map