export declare const RefinementSettings: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=RefinementSettings.d.ts.map