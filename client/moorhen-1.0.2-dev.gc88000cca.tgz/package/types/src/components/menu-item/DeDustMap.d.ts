export declare const DedustMap: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=DeDustMap.d.ts.map