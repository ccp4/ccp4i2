export declare const ImportMap: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ImportMap.d.ts.map