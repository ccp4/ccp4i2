import React, { ReactNode } from 'react';
import './CustomHorizontalScrollbar.css';
interface CustomHorizontalScrollbarProps {
    children: ReactNode;
    style?: React.CSSProperties;
    className?: string;
    onDraggingChange?: (isDragging: boolean) => void;
    forceRedrawScrollBarKey?: string | number;
}
export declare const CustomHorizontalScrollbar: React.MemoExoticComponent<(props: CustomHorizontalScrollbarProps) => import("react/jsx-runtime").JSX.Element>;
export {};
//# sourceMappingURL=CustomHorizontalScrollbar.d.ts.map