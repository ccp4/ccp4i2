import React from "react";
import { Residue, SeqElement } from "./MoorhenSeqViewTypes";
interface ResidueBoxProps {
    sequence: SeqElement;
    residue: Residue | null;
    index: number;
    columnWidth?: number;
    fontSize?: number;
    hoveredResidue?: number | null;
    isGliding?: boolean;
    handleResidueMouseOver?: (evt: React.MouseEvent<HTMLDivElement>) => void;
    handleResidueMouseDown?: (evt: React.MouseEvent<HTMLDivElement>) => void;
    handleResidueMouseUp?: (evt: React.MouseEvent<HTMLDivElement>) => void;
    showValidationData?: boolean;
    validationTracks?: string[];
}
export declare const ResidueBox: React.MemoExoticComponent<(props: ResidueBoxProps) => import("react/jsx-runtime").JSX.Element>;
export {};
//# sourceMappingURL=ResidueBox.d.ts.map