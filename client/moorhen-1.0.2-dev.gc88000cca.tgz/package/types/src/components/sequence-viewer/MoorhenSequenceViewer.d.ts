import { clickedResidueType } from "../card/MoleculeCard/MoleculeCard";
import type { ResiduesSelection, SeqElement } from "./MoorhenSeqViewTypes";
import "./MoorhenSequenceViewer.css";
type MoorhenSequenceViewerPropsType = {
    sequences: SeqElement | SeqElement[];
    clickedResidue?: clickedResidueType;
    onResidueClick?: (modelIndex: number, molName: string, chain: string, seqNum: number) => void;
    selectedResidues?: ResiduesSelection;
    setSelectedResidues?: (selection: ResiduesSelection) => void;
    onHoverResidue?: (molName: string, chain: string, resNum: number, resCode: string, resCID: string) => void;
    hoveredResidue?: {
        molNo: number;
        chain: string;
        resNum: number;
    };
    maxDisplayHeight?: number;
    nameColumnWidth?: number;
    columnWidth?: number;
    selectIsActive?: boolean;
    reOrder?: boolean;
    fontSize?: number;
    showTitleBar?: boolean;
    className?: string;
    displayHeight?: number;
    forceRedrawScrollBarKey?: string | number;
    style?: React.CSSProperties;
    showValidationData?: boolean;
    validationTracks?: string[];
};
export declare const MoorhenSequenceViewer: import("react").MemoExoticComponent<(props: MoorhenSequenceViewerPropsType) => import("react/jsx-runtime").JSX.Element>;
export {};
//# sourceMappingURL=MoorhenSequenceViewer.d.ts.map