import React from "react";
import { SeqElement } from "./MoorhenSeqViewTypes";
export declare const SequenceRow: React.MemoExoticComponent<(props: {
    sequence: SeqElement;
    nameColumnWidth?: number;
    columnWidth?: number;
    fontSize?: number;
    hoveredResidue?: number | null;
    isGliding?: boolean;
    handleResidueMouseOver?: (evt: React.MouseEvent<HTMLDivElement>) => void;
    handleResidueMouseDown?: (evt: React.MouseEvent<HTMLDivElement>) => void;
    handleResidueMouseUp?: (evt: React.MouseEvent<HTMLDivElement>) => void;
    showValidationData?: boolean;
    validationTracks?: string[];
}) => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=SequenceRow.d.ts.map