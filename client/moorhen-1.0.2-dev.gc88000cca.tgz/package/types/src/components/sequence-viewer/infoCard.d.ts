export declare const SelectionInfoCard: import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=infoCard.d.ts.map