import { ContextButtonProps } from "./MoorhenContextButtonBase";
export declare const MoorhenAutofitRotamerButton: (props: ContextButtonProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenAutofitRotamerButton.d.ts.map