import { RefObject } from "react";
import { moorhen } from "../../types/moorhen";
import { webGL } from "../../types/mgWebGL";
export type ActionButtonSettings = {
    mutate: "ALA" | "CYS" | "ASP" | "GLU" | "PHE" | "GLY" | "HIS" | "ILE" | "LYS" | "LEU" | "MET" | "ASN" | "PRO" | "GLN" | "ARG" | "SER" | "THR" | "VAL" | "TRP" | "TYR";
    refine: "SINGLE" | "TRIPLE" | "QUINTUPLE" | "HEPTUPLE" | "SPHERE" | "BIG_SPHERE" | "CHAIN" | "ALL";
    delete: "ATOM" | "RESIDUE" | "RESIDUE HYDROGENS" | "RESIDUE SIDE-CHAIN" | "CHAIN" | "CHAIN HYDROGENS" | "MOLECULE HYDROGENS";
    rotateTranslate: "ATOM" | "RESIDUE" | "CHAIN" | "MOLECULE";
    drag: "SINGLE" | "TRIPLE" | "QUINTUPLE" | "HEPTUPLE" | "SPHERE";
    rigidBodyFit: "SINGLE" | "TRIPLE" | "QUINTUPLE" | "HEPTUPLE" | "CHAIN" | "ALL";
};
export declare const MoorhenContextMenu: (props: {
    urlPrefix: string;
    showContextMenu: false | moorhen.AtomRightClickEventInfo;
    timeCapsuleRef: React.RefObject<moorhen.TimeCapsule>;
    setShowContextMenu: React.Dispatch<React.SetStateAction<false | moorhen.AtomRightClickEventInfo>>;
    viewOnly: boolean;
    glRef: React.RefObject<webGL.MGWebGL>;
    commandCentre: RefObject<moorhen.CommandCentre>;
    monomerLibraryPath: string;
    defaultActionButtonSettings: ActionButtonSettings;
    setDefaultActionButtonSettings: (arg0: {
        key: string;
        value: string;
    }) => void;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenContextMenu.d.ts.map