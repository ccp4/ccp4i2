import { ContextButtonProps } from "./MoorhenContextButtonBase";
export declare const MoorhenJedFlipFalseButton: (props: ContextButtonProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenJedFlipFalseButton.d.ts.map