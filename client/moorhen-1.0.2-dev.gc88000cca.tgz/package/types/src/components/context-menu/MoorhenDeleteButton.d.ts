import { ContextButtonProps } from "./MoorhenContextButtonBase";
export declare const MoorhenDeleteButton: (props: ContextButtonProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenDeleteButton.d.ts.map