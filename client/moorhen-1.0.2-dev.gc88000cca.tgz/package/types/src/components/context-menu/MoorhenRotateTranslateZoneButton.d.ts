import { ContextButtonProps } from "./MoorhenContextButtonBase";
export declare const MoorhenRotateTranslateZoneButton: (props: ContextButtonProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenRotateTranslateZoneButton.d.ts.map