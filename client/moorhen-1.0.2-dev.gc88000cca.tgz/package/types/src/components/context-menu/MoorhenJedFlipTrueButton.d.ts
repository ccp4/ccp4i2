import { ContextButtonProps } from "./MoorhenContextButtonBase";
export declare const MoorhenJedFlipTrueButton: (props: ContextButtonProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenJedFlipTrueButton.d.ts.map