import { ContextButtonProps } from "./MoorhenContextButtonBase";
export declare const MoorhenEigenFlipLigandButton: (props: ContextButtonProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenEigenFlipLigandButton.d.ts.map