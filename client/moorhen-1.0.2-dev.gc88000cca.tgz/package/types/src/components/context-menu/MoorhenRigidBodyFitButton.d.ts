import { ContextButtonProps } from "./MoorhenContextButtonBase";
export declare const MoorhenRigidBodyFitButton: (props: ContextButtonProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenRigidBodyFitButton.d.ts.map