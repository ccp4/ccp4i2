import { ContextButtonProps } from "./MoorhenContextButtonBase";
export declare const MoorhenDragAtomsButton: (props: ContextButtonProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenDragAtomsButton.d.ts.map