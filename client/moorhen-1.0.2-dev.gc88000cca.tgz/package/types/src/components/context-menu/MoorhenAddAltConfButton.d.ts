import { ContextButtonProps } from "./MoorhenContextButtonBase";
export declare const MoorhenAddAltConfButton: (props: ContextButtonProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenAddAltConfButton.d.ts.map