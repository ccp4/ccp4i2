import { ContextButtonProps } from "./MoorhenContextButtonBase";
export declare const MoorhenAddTerminalResidueButton: (props: ContextButtonProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenAddTerminalResidueButton.d.ts.map