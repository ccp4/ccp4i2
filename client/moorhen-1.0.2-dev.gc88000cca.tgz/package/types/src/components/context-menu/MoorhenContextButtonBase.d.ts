import { moorhen } from "../../types/moorhen";
import { ActionButtonSettings } from "./MoorhenContextMenu";
import "./context-menu.css";
export type ContextButtonProps = {
    monomerLibraryPath: string;
    urlPrefix: string;
    commandCentre: React.RefObject<moorhen.CommandCentre>;
    selectedMolecule: moorhen.Molecule;
    chosenAtom: moorhen.ResidueSpec;
    setOverlayContents: React.Dispatch<React.SetStateAction<React.JSX.Element>>;
    setShowOverlay: React.Dispatch<React.SetStateAction<boolean>>;
    timeCapsuleRef: React.RefObject<moorhen.TimeCapsule>;
    setToolTip: React.Dispatch<React.SetStateAction<string>>;
    setShowContextMenu: React.Dispatch<React.SetStateAction<false | moorhen.AtomRightClickEventInfo>>;
    setOpacity: React.Dispatch<React.SetStateAction<number>>;
    setOverrideMenuContents: React.Dispatch<React.SetStateAction<React.JSX.Element | boolean>>;
    showContextMenu: false | moorhen.AtomRightClickEventInfo;
    defaultActionButtonSettings: ActionButtonSettings;
    setDefaultActionButtonSettings: (arg0: {
        key: string;
        value: string;
    }) => void;
};
export declare const MoorhenContextButtonBase: (props: {
    selectedMolecule: moorhen.Molecule;
    chosenAtom: moorhen.ResidueSpec;
    refineAfterMod?: boolean;
    needsMapData?: boolean;
    ligandOnly?: boolean;
    needsAtomData?: boolean;
    nonCootCommand?: (arg0: moorhen.Molecule, arg1: moorhen.ResidueSpec, arg2?: string) => Promise<void>;
    cootCommandInput?: moorhen.cootCommandKwargs;
    setOverlayContents: React.Dispatch<React.SetStateAction<React.JSX.Element>>;
    setShowOverlay: React.Dispatch<React.SetStateAction<boolean>>;
    setShowContextMenu: React.Dispatch<React.SetStateAction<false | moorhen.AtomRightClickEventInfo>>;
    onExit?: (arg0: moorhen.Molecule, arg1: moorhen.ResidueSpec, arg2: any) => void;
    onCompleted?: (arg0: moorhen.Molecule, arg1: moorhen.ResidueSpec) => void;
    icon: React.JSX.Element;
    setToolTip: React.Dispatch<React.SetStateAction<string>>;
    toolTipLabel: string;
    showContextMenu: false | moorhen.AtomRightClickEventInfo;
    popoverSettings?: {
        label: string;
        options: string[];
        nonCootCommand?: (arg0: moorhen.Molecule, arg1: moorhen.ResidueSpec, arg2: string) => void;
        getCootCommandInput?: (arg0: moorhen.Molecule, arg2: moorhen.ResidueSpec, arg3: string) => moorhen.cootCommandKwargs;
        extraInput?: (arg0: React.RefObject<any>) => React.JSX.Element;
        defaultValue?: string;
        setDefaultValue?: (arg0: string) => void;
    };
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenContextButtonBase.d.ts.map