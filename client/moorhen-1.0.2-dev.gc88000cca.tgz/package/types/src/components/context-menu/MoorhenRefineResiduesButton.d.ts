import { ContextButtonProps } from "./MoorhenContextButtonBase";
export declare const MoorhenRefineResiduesButton: (props: ContextButtonProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenRefineResiduesButton.d.ts.map