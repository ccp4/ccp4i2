import { ContextButtonProps } from "./MoorhenContextButtonBase";
export declare const MoorhenMutateButton: (props: ContextButtonProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenMutateButton.d.ts.map