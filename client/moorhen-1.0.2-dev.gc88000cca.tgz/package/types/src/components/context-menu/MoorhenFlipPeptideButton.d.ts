import { ContextButtonProps } from "./MoorhenContextButtonBase";
export declare const MoorhenFlipPeptideButton: (props: ContextButtonProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenFlipPeptideButton.d.ts.map