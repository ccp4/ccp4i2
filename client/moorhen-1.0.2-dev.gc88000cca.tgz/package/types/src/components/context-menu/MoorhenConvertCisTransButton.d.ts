import { ContextButtonProps } from "./MoorhenContextButtonBase";
export declare const MoorhenConvertCisTransButton: (props: ContextButtonProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenConvertCisTransButton.d.ts.map