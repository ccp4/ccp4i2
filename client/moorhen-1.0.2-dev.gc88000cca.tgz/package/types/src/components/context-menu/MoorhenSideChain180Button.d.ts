import { ContextButtonProps } from "./MoorhenContextButtonBase";
export declare const MoorhenSideChain180Button: (props: ContextButtonProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenSideChain180Button.d.ts.map