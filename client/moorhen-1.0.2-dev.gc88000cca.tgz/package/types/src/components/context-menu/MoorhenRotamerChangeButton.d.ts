import { ContextButtonProps } from "./MoorhenContextButtonBase";
export declare const MoorhenRotamerChangeButton: (props: ContextButtonProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenRotamerChangeButton.d.ts.map