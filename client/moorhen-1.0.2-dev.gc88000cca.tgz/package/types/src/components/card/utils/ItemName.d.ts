import type { MoorhenMap } from "../../../utils/MoorhenMap";
import type { MoorhenMolecule } from "../../../utils/MoorhenMolecule";
import "./card-utils.css";
export declare const ItemName: (props: {
    item: MoorhenMolecule | MoorhenMap;
    maxLength?: number;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ItemName.d.ts.map