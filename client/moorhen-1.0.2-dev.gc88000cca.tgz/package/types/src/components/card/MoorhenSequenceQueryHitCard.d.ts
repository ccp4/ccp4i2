import { GetPolimerInfoQuery } from "../../utils/__graphql__/graphql";
export declare const MoorhenQueryHitCard: (props: {
    data: GetPolimerInfoQuery;
    idx: number;
    selectedMolNo: number;
    selectedChain: string;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenSequenceQueryHitCard.d.ts.map