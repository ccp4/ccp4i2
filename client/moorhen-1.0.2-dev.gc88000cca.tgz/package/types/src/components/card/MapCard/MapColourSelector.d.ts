import { moorhen } from "../../../types/moorhen";
interface MoorhenMapColorSelector {
    map: moorhen.Map;
    mapIsVisible: boolean;
}
export declare const MapColourSelector: (props: MoorhenMapColorSelector) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MapColourSelector.d.ts.map