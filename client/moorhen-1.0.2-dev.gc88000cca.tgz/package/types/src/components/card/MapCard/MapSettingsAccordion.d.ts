import { moorhen } from "../../../types/moorhen";
interface MoorhenMapCardSettings {
    map: moorhen.Map;
    mapIsVisible: boolean;
    mapStyle: string;
    mapRadius: number;
    mapOpacity: number;
}
export declare const MapSettingsAccordion: (props: MoorhenMapCardSettings) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MapSettingsAccordion.d.ts.map