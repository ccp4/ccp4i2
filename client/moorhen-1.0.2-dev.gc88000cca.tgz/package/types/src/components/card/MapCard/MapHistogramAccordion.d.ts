import { moorhen } from "../../../types/moorhen";
type MapHistogramProps = {
    map: moorhen.Map;
    currentContourLevel: number;
};
export declare const MapHistogramAccordion: (props: MapHistogramProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MapHistogramAccordion.d.ts.map