import { moorhen } from "../../../types/moorhen";
export declare const MoorhenMapInfoCard: (props: {
    map: moorhen.Map;
    disabled: boolean;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenMapInfoCard.d.ts.map