import { moorhen } from "../../../types/moorhen";
type MoorhenMapCardPropsInterface = {
    map: moorhen.Map;
    initialContour?: number;
    initialRadius?: number;
    modalWidth?: number;
    isOpen?: boolean;
    onCollapseToggle?: (key: number, isOpen: boolean) => void;
};
export declare const MoorhenMapCard: (props: MoorhenMapCardPropsInterface) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoorhenMapCard.d.ts.map