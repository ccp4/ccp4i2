import { MoorhenMolecule } from "../../utils";
export declare const MoorhenHeaderInfoCard: (props: {
    molecule: MoorhenMolecule;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenHeaderInfoCard.d.ts.map