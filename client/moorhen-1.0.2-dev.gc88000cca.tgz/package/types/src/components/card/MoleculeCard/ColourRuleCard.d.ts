import { moorhen } from "../../../types/moorhen";
import type { ColourRule } from "../../../utils/MoorhenColourRule";
export declare const NcsColourSwatch: (props: {
    rule: ColourRule;
    applyColourChange: () => void;
    style?: {
        [key: string]: string;
    };
}) => import("react/jsx-runtime").JSX.Element;
export declare const MoorhenColourRuleCard: (props: {
    molecule: moorhen.Molecule;
    index: number;
    rule: ColourRule;
    setRuleList: any;
    reversedOrder: boolean;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ColourRuleCard.d.ts.map