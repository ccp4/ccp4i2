import { moorhen } from "../../../../../types/moorhen";
import { RepresentationStyles } from "../../../../../utils/Representation/MoorhenMoleculeRepresentation";
interface StyleSelectorProps {
    value: moorhen.RepresentationStyles;
    onChange: (style: moorhen.RepresentationStyles) => void;
    mode: "add" | "edit";
    adaptBondOOF: RepresentationStyles;
    setAdaptBondOOF: React.Dispatch<React.SetStateAction<RepresentationStyles>>;
}
export declare const StyleSelector: (props: StyleSelectorProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=StyleSelector.d.ts.map