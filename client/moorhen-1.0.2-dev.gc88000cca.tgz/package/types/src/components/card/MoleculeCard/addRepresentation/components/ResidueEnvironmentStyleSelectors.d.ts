import { MoleculeRepresentation } from "../../../../../utils/Representation/MoorhenMoleculeRepresentation";
interface ResidueEnvironmentStyleSelectorsProps {
    representation: MoleculeRepresentation;
}
/**
 * Focus and background style selectors for residue_environment representations.
 */
export declare const ResidueEnvironmentStyleSelectors: (props: ResidueEnvironmentStyleSelectorsProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=ResidueEnvironmentStyleSelectors.d.ts.map