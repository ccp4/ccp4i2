import { RepresentationStyles } from "../../../../../utils";
import { ResidueSelectionRuleType } from "./ResidueSelectionSection";
interface FilterTogglesProps {
    notHOH: boolean;
    setNotHOH: (val: boolean) => void;
    notH: boolean;
    setNotH: (val: boolean) => void;
    sideChainOnly: boolean;
    setSideChainOnly: (val: boolean) => void;
    representationStyle: RepresentationStyles;
    ruleType: ResidueSelectionRuleType;
}
/**
 * Toggle switches for filtering waters, hydrogens, and side chains.
 * Only shown for MetaBalls, VdwSpheres, and CBs styles
 * when the rule type is chain, molecule, or neighbourhood.
 */
export declare const FilterToggles: (props: FilterTogglesProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=FilterToggles.d.ts.map