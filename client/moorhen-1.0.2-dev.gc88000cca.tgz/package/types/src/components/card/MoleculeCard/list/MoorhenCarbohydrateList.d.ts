import { moorhen } from "../../../../types/moorhen";
export declare const MoorhenCarbohydrateList: (props: {
    setBusy?: React.Dispatch<React.SetStateAction<boolean>>;
    molecule: moorhen.Molecule;
    height?: number | string;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenCarbohydrateList.d.ts.map