import { moorhen } from "../../../../types/moorhen";
export declare const MoorhenLigandList: (props: {
    setBusy?: React.Dispatch<React.SetStateAction<boolean>>;
    commandCentre: React.RefObject<moorhen.CommandCentre>;
    molecule: moorhen.Molecule;
    height?: number | string;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenLigandList.d.ts.map