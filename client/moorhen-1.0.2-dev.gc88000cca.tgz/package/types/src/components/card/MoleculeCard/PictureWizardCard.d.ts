import { moorhen } from "../../../types/moorhen";
export declare const PictureWizardCard: import("react").MemoExoticComponent<(props: {
    molecule: moorhen.Molecule;
    setBusy?: React.Dispatch<React.SetStateAction<boolean>>;
    onApply?: () => void;
}) => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=PictureWizardCard.d.ts.map