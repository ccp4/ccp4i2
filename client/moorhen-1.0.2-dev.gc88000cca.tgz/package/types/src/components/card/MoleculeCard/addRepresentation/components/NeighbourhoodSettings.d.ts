interface NeighbourhoodSettingsProps {
    restrictToNeighbours: boolean;
    neighboursCid: string;
    setNeighboursCid: (val: string) => void;
    excludeNeighbours: boolean;
    setExcludeNeighbours: (val: boolean) => void;
    neighboursDistance: number;
    setNeighboursDistance: (val: number) => void;
    hbondedTo: boolean;
    setHbondedTo: (val: boolean) => void;
    representationStyle: string;
    ruleType: string;
}
export declare const NeighbourhoodSettings: (props: NeighbourhoodSettingsProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=NeighbourhoodSettings.d.ts.map