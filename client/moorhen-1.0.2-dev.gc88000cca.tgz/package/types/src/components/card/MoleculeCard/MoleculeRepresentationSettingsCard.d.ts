import { MoleculeRepresentation, MoorhenMolecule } from "../../../utils";
import { moorhen } from "../../../types/moorhen";
type MoleculeSettingPanelProps = {
    molecule: MoorhenMolecule;
    representation?: never;
} | {
    molecule?: never;
    representation: MoleculeRepresentation;
};
export declare const BondSettingsPanel: (props: MoleculeSettingPanelProps) => import("react/jsx-runtime").JSX.Element;
export declare const SymmetrySettingsPanel: (props: {
    symmetryRadius: number;
    setSymmetryRadius: React.Dispatch<React.SetStateAction<number>>;
    molecule: moorhen.Molecule;
}) => import("react/jsx-runtime").JSX.Element;
export declare const RibbonSettingsPanel: (props: MoleculeSettingPanelProps) => import("react/jsx-runtime").JSX.Element;
export declare const MolSurfSettingsPanel: (props: MoleculeSettingPanelProps) => import("react/jsx-runtime").JSX.Element;
export declare const ResidueEnvironmentSettingsPanel: (props: MoleculeSettingPanelProps) => import("react/jsx-runtime").JSX.Element;
export declare const MoorhenMoleculeRepresentationSettingsCard: (props: {
    molecule: moorhen.Molecule;
}) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoleculeRepresentationSettingsCard.d.ts.map