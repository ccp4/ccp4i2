import { moorhen } from "../../../types/moorhen";
import "./molecule-card.css";
interface MoleculeCardProps {
    dropdownId: number;
    accordionDropdownId: number;
    setAccordionDropdownId: React.Dispatch<React.SetStateAction<number>>;
    sideBarWidth: number;
    showSideBar: boolean;
    busy: boolean;
    key: number;
    index: number;
    molecule: moorhen.Molecule;
    currentDropdownMolNo: number;
    setCurrentDropdownMolNo: React.Dispatch<React.SetStateAction<number>>;
    open?: boolean | null;
    onCollapseToggle?: (key: any, isOpen: any) => void;
}
export type clickedResidueType = {
    modelIndex: number;
    molName: string;
    chain: string;
    seqNum: number;
};
export declare const MoleculeCard: (props: MoleculeCardProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MoleculeCard.d.ts.map