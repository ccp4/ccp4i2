import { MoleculeRepresentation } from "../../../../utils/Representation/MoorhenMoleculeRepresentation";
import { moorhen } from "../../../../types/moorhen";
export declare const AddCustomRepresentationCard: import("react").MemoExoticComponent<(props: {
    molecule: moorhen.Molecule;
    urlPrefix: string;
    mode?: "add" | "edit";
    representation?: MoleculeRepresentation;
    setBusy?: React.Dispatch<React.SetStateAction<boolean>>;
    onApply?: () => void;
}) => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=AddRepresentationCard.d.ts.map