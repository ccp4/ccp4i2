import { moorhen } from "../../../../types/moorhen";
export interface MoorhenXPIDResult {
    H_atom: string;
    X_atom: string;
    X_chain: string;
    X_id: number;
    X_res: string;
    X_xyz_x: number;
    X_xyz_y: number;
    X_xyz_z: number;
    angle_xh_pi: number;
    angle_xpcn: number;
    dist_X_Pi: number;
    method: string;
    model: string;
    pdb: string;
    pi_center_x: number;
    pi_center_y: number;
    pi_center_z: number;
    pi_chain: string;
    pi_id: number;
    pi_res: string;
    proj_dist: number;
    theta: number;
}
export declare const MoorhenXPIDList: (props: {
    setBusy?: React.Dispatch<React.SetStateAction<boolean>>;
    molecule: moorhen.Molecule;
    height?: number | string;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenXPIDList.d.ts.map