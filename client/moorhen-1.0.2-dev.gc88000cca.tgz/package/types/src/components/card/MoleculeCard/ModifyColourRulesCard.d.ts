import { moorhen } from "../../../types/moorhen";
export declare const MoorhenModifyColourRulesCard: import("react").MemoExoticComponent<(props: {
    molecule: moorhen.Molecule;
    residueSelection?: boolean;
}) => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=ModifyColourRulesCard.d.ts.map