import type { MoorhenMolecule } from "../../../utils/MoorhenMolecule";
import type { MoleculeRepresentation } from "../../../utils/Representation/MoorhenMoleculeRepresentation";
import "./representation.css";
export declare const CustomRepresentationChip: (props: {
    addColourRulesAnchorDivRef: React.RefObject<HTMLDivElement>;
    molecule: MoorhenMolecule;
    representation: MoleculeRepresentation;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=RepresentationChip.d.ts.map