import { ColourRule } from "../../../../../utils/MoorhenColourRule";
import { moorhen } from "../../../../../types/moorhen";
import { RepresentationStyles } from "../../../../../utils";
interface ColourSettingsSectionProps {
    useDefaultColours: boolean;
    setUseDefaultColours: React.Dispatch<React.SetStateAction<boolean>>;
    applyColourToNonCarbonAtoms: boolean;
    setApplyColourToNonCarbonAtoms: React.Dispatch<React.SetStateAction<boolean>>;
    colourMode: string;
    setColourMode: React.Dispatch<React.SetStateAction<string>>;
    colour: string;
    setColour: React.Dispatch<React.SetStateAction<string>>;
    nonCustomOpacity: number;
    setNonCustomOpacity: (val: number) => void;
    representationStyle: RepresentationStyles;
    mode: "add" | "edit";
    molecule: moorhen.Molecule;
    urlPrefix: string;
    representation?: moorhen.MoleculeRepresentation;
    ncsColourRuleRef: React.MutableRefObject<ColourRule | null>;
}
export declare const ColourSettingsSection: (props: ColourSettingsSectionProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=ColourSettingsSection.d.ts.map