import React from "react";
import { moorhen } from "../../../../types/moorhen";
export declare const MoorhenSequencesAccordion: (props: {
    setBusy: React.Dispatch<React.SetStateAction<boolean>>;
    molecule: moorhen.Molecule;
    setSelectedResidues: React.Dispatch<React.SetStateAction<[number, number]>>;
    clickedResidue: {
        modelIndex: number;
        molName: string;
        chain: string;
        seqNum: number;
    };
    setClickedResidue: React.Dispatch<React.SetStateAction<{
        modelIndex: number;
        molName: string;
        chain: string;
        seqNum: number;
    }>>;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenSequencesAccordion.d.ts.map