import { MoleculeRepresentation, MoorhenMolecule } from "../../../utils";
type MoleculeSettingPanelProps = {
    molecule: MoorhenMolecule;
    representation?: never;
} | {
    molecule?: never;
    representation: MoleculeRepresentation;
};
export declare const NEFRestraintsSettingsPanel: (props: MoleculeSettingPanelProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=NEFRestraintsSettingsCard.d.ts.map