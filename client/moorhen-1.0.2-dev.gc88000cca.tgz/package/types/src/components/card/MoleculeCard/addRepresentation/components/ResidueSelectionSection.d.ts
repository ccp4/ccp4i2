import { MoorhenMolecule } from "../../../../../utils/MoorhenMolecule";
export type ResidueSelectionRuleType = "ligands" | "cid" | "molecule" | "chain" | "residue-range" | "neighbourhood";
interface ResidueSelectionSectionProps {
    ruleType: ResidueSelectionRuleType;
    setRuleType: (val: ResidueSelectionRuleType) => void;
    representationStyle: string;
    molecules: MoorhenMolecule[];
    molecule: MoorhenMolecule;
    selectedChain: string;
    setSelectedChain: (val: string) => void;
    sequenceResidueRange: [number, number];
    setSequenceResidueRange: React.Dispatch<React.SetStateAction<[number, number] | null>>;
    cid: string;
    setCid: (val: string) => void;
    setRestrictToNeighbours: (val: boolean) => void;
    isThereLigand: boolean;
}
export declare const ResidueSelectionSection: (props: ResidueSelectionSectionProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=ResidueSelectionSection.d.ts.map