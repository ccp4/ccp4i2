import { moorhen } from "../../types/moorhen";
import { LigandInfo } from "../../utils/MoorhenMolecule";
export declare const MoorhenLigandCard: (props: {
    ligand: LigandInfo;
    molecule: moorhen.Molecule;
    validationStyles?: moorhen.RepresentationStyles[];
    calculateQScore?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenLigandCard.d.ts.map