import { moorhen } from "../../types/moorhen";
import { privateer } from "../../types/privateer";
export declare const MoorhenCarbohydrateCard: (props: {
    carbohydrate: privateer.ResultsEntry;
    molecule: moorhen.Molecule;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MoorhenCarbohydrateCard.d.ts.map