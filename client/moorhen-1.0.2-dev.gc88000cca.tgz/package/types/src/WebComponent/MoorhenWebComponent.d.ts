import React from "react";
import type { MoorhenInstance } from "../InstanceManager";
import type { LocalStorageInstance } from "../InstanceManager/Preferences/MoorhenPreferences";
export declare class MoorhenWebComponent extends HTMLElement {
    private _moorhenInstanceRef;
    private _moorhenInstance;
    private _ready;
    private _rootElement;
    private _reactRoot;
    private _parentElementRef;
    onInit: (() => void) | null;
    constructor();
    getMoorhenInstance(): Promise<MoorhenInstance>;
    get ready(): boolean;
    private _width;
    private _height;
    private _size;
    get width(): number | string | null;
    set width(value: number | string | null);
    get height(): number | string | null;
    set height(value: number | string | null);
    private _urlPrefix;
    get urlPrefix(): string;
    set urlPrefix(value: string);
    get size(): [number, number] | null;
    static get observedAttributes(): string[];
    private _disableFileUploads;
    get disableFileUploads(): boolean;
    set disableFileUploads(value: boolean);
    private _viewOnly;
    get viewOnly(): boolean;
    set viewOnly(value: boolean);
    private _monomerLibraryPath;
    private _allowScripting;
    private _backupStorage;
    private _canSetStartupProperty;
    get monomerLibraryPath(): string | undefined;
    set monomerLibraryPath(value: string | undefined);
    get allowScripting(): boolean | undefined;
    set allowScripting(value: boolean | undefined);
    /** Where time capsule backups are kept, e.g. from `createCallbackBackupStorage`. Property only */
    get backupStorage(): LocalStorageInstance | undefined;
    set backupStorage(value: LocalStorageInstance | undefined);
    attributeChangedCallback(name: string, oldValue: string | null, newValue: string | null): void;
    private _triggerUpdate;
    private _renderReactTree;
    private loadStylesheets;
    connectedCallback(): Promise<void>;
}
/**
 * Registers the Moorhen web component for use in the DOM.
 *
 * This function must be called before using the web component, typically in the main entry point of your app (e.g. index.tsx).
 *
 * @example
 * // Call to register the web component
 * registerMoorhenWebComponent();
 *
 * // Then use the web component in your HTML
 * <moorhen-web-component width="800" height="600" />
 *
 * @example
 * // For TypeScript React apps, add this type declaration:
 * declare module "react" {
 *     namespace JSX {
 *         interface IntrinsicElements {
 *             "moorhen-web-component": MoorhenWebComponentAttributes;
 *         }
 *     }
 * }
 */
export declare const registerMoorhenWebComponent: () => void;
export interface MoorhenWebComponentAttributes extends React.HTMLAttributes<HTMLElement> {
    width?: number | string;
    height?: number | string;
    "url-prefix"?: string;
    "disable-file-uploads"?: boolean;
    "view-only"?: boolean;
    "monomer-library"?: string;
    "allow-scripting"?: boolean;
}
//# sourceMappingURL=MoorhenWebComponent.d.ts.map