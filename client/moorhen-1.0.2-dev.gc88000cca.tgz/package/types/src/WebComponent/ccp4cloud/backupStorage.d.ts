import type { LocalStorageInstance } from "../../InstanceManager/Preferences/MoorhenPreferences";
import type { backupKey } from "../../utils/MoorhenTimeCapsule";
/** A backup as stored by CCP4 Cloud: the time capsule key, a serial number identifying it and its serialised data */
export type CloudBackup = backupKey & {
    serNo: number | string;
    data: string;
};
/** The CCP4 Cloud callbacks (MoorhenWrapper's exportBackupCallback, importBackupCallback, removeBackupCallback, loadBackupList) */
export type BackupStorageCallbacks = {
    save: (backup: CloudBackup) => Promise<string | void>;
    load: (serNo: string | number) => Promise<CloudBackup | void>;
    remove: (serNo: string | number) => Promise<void>;
    list: () => Promise<CloudBackup[]>;
};
/**
 * Create the backup storage used by CCP4 Cloud: pass the result as the web component's `backupStorage`
 * property, before the element is appended.
 *
 * Storage format, per time capsule key type:
 * - `version`: serial number 0
 * - `mtzData`: serial number from the file name (see `mtzSerNo`), data as a JSON array of bytes
 * - `mapData`: serial number is the key name, data as a JSON array of bytes
 * - anything else (sessions): the key fields plus `data`, the serial number is the key's own `serNo`
 *
 * @example
 * el.backupStorage = createCallbackBackupStorage({ save, load, remove, list });
 */
export declare function createCallbackBackupStorage(callbacks: BackupStorageCallbacks): LocalStorageInstance;
//# sourceMappingURL=backupStorage.d.ts.map