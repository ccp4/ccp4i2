export { useWebComponentInstanceRef } from "./useWebComponentInstanceRef";
export { useMoorhenSelector } from "./webComponentSelector";
//# sourceMappingURL=entry.d.ts.map