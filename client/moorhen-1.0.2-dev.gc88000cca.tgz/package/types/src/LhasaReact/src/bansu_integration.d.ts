import './index.scss';
import './components.scss';
declare class BansuPopupProps {
    smiles_list: [number, string | null, string][];
    anchorEl?: HTMLElement | null;
    bansu_endpoint: string;
    dark_mode: boolean;
    bansu_callback?: (internal_id: number, id_from_prop: string | null, cif_text: string) => void;
    name_of_host_program?: string | null;
}
export declare function BansuButton(props: BansuPopupProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=bansu_integration.d.ts.map