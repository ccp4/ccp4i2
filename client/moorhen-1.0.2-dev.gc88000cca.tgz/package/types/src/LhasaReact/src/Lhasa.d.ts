import './index.scss';
import './components.scss';
import { MainModule } from './types';
export interface LhasaComponentProps {
    Lhasa: MainModule | any;
    show_top_panel?: boolean;
    show_footer?: boolean;
    icons_path_prefix?: string;
    rdkit_molecule_pickle_list?: {
        pickle: string;
        id: string;
    }[];
    name_of_host_program?: string | null;
    send_to_host_program_callback?: (internal_id: number, id_from_prop: string | null, smiles: string, rdkit_pickle_base64: string) => void;
    on_smiles_updated?: (smiles_array: [number, string | null, string, [string, string]?][]) => void;
    bansu_endpoint?: string | undefined;
    bansu_callback?: (internal_id: number, id_from_prop: string | null, cif_text: string) => void;
    data_path_prefix?: string;
    dark_mode?: boolean;
    width?: number | null;
    height?: number | null;
    max_width?: number | null;
    max_height?: number | null;
}
export declare function LhasaComponent({ Lhasa, show_top_panel, show_footer, icons_path_prefix, rdkit_molecule_pickle_list, name_of_host_program, send_to_host_program_callback, bansu_callback, on_smiles_updated, bansu_endpoint, data_path_prefix, dark_mode, width, height, max_width, max_height }: LhasaComponentProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Lhasa.d.ts.map