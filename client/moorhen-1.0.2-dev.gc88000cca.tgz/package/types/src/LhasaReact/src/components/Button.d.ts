export interface ButtonProps {
    onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
    disabled?: boolean;
    primary?: boolean;
    outlined?: boolean;
    /** Borderless, primary-colored button — MUI's default Button variant. Used for menu-bar triggers. */
    borderless?: boolean;
    children?: React.ReactNode;
}
export declare const Button: import("react").ForwardRefExoticComponent<ButtonProps & import("react").RefAttributes<HTMLButtonElement>>;
export interface IconButtonProps {
    onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
    'aria-label'?: string;
    children?: React.ReactNode;
}
export declare const IconButton: import("react").ForwardRefExoticComponent<IconButtonProps & import("react").RefAttributes<HTMLButtonElement>>;
//# sourceMappingURL=Button.d.ts.map