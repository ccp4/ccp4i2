import { registerPopup, unregisterPopup } from './hooks/popupRegistry';
interface MenuContextValue {
    registerPopup: typeof registerPopup;
    unregisterPopup: typeof unregisterPopup;
}
export declare const MenuContext: import("react").Context<MenuContextValue>;
export interface CustomMenuProps {
    open?: boolean;
    anchorEl?: HTMLElement | null;
    onClose?: () => void;
    className?: string;
    children?: React.ReactNode;
}
export declare function CustomMenu({ open, anchorEl, onClose, className, children }: CustomMenuProps): import("react").ReactPortal;
export interface CustomMenuItemProps {
    onClick?: (event: React.MouseEvent | React.KeyboardEvent) => void;
    children?: React.ReactNode;
    onMouseEnter?: (event: React.MouseEvent) => void;
}
export declare const CustomMenuItem: import("react").ForwardRefExoticComponent<CustomMenuItemProps & import("react").RefAttributes<HTMLDivElement>>;
export {};
//# sourceMappingURL=Menu.d.ts.map