export interface TabsProps {
    value?: number;
    onChange?: (event: React.SyntheticEvent, value: number) => void;
    children?: React.ReactNode;
}
export declare function Tabs({ value, onChange, children }: TabsProps): import("react/jsx-runtime").JSX.Element;
export interface TabProps {
    value?: number;
    label?: string;
}
export declare function Tab(_props: TabProps): any;
//# sourceMappingURL=Tabs.d.ts.map