export interface SelectProps {
    value?: number | string;
    onChange?: (event: React.ChangeEvent<HTMLSelectElement>) => void;
    disabled?: boolean;
    className?: string;
    style?: React.CSSProperties;
    children?: React.ReactNode;
}
export declare function Select({ value, onChange, disabled, className, style, children }: SelectProps): import("react/jsx-runtime").JSX.Element;
export interface MenuItemProps {
    value: number | string;
    children?: React.ReactNode;
}
export declare function SelectMenuItem({ value, children }: MenuItemProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Select.d.ts.map