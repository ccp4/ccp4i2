import { AnchorOrigin } from './hooks/usePortalPosition';
export type { AnchorOrigin } from './hooks/usePortalPosition';
export interface CustomPopoverProps {
    open?: boolean;
    anchorEl?: HTMLElement | null;
    positionAnchorEl?: HTMLElement | null;
    anchorOrigin?: AnchorOrigin;
    transformOrigin?: AnchorOrigin;
    onClose?: () => void;
    className?: string;
    children?: React.ReactNode;
}
export declare function CustomPopover({ open, anchorEl, positionAnchorEl, anchorOrigin, transformOrigin, onClose, className, children, }: CustomPopoverProps): import("react").ReactPortal;
//# sourceMappingURL=Popover.d.ts.map