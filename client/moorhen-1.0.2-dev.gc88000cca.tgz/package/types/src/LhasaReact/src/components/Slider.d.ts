export interface SliderProps {
    value?: number;
    min?: number;
    max?: number;
    step?: number;
    scale?: (value: number) => number;
    onChange?: (event: Event | React.SyntheticEvent, value: number) => void;
}
export declare function Slider({ value, min, max, step, scale, onChange }: SliderProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Slider.d.ts.map