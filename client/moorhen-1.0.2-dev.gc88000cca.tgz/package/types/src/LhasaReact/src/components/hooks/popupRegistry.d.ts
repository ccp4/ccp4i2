export declare function disposePopupRegistry(): void;
export declare function registerPopup(ref: HTMLElement, anchorEl: HTMLElement | null, onClose: () => void): number;
export declare function unregisterPopup(id: number): void;
//# sourceMappingURL=popupRegistry.d.ts.map