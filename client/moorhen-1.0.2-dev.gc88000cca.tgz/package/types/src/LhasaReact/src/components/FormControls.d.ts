export interface FormControlLabelProps {
    label: string | React.ReactNode;
    control: React.ReactNode;
    checked?: boolean;
    onChange?: (event: React.SyntheticEvent) => void;
    value?: string;
}
export declare function FormControlLabel({ label, control, checked, onChange, value }: FormControlLabelProps): import("react/jsx-runtime").JSX.Element;
export interface FormGroupProps {
    children?: React.ReactNode;
}
export declare function FormGroup({ children }: FormGroupProps): import("react/jsx-runtime").JSX.Element;
export interface FormControlProps {
    children?: React.ReactNode;
}
export declare function FormControl({ children }: FormControlProps): import("react/jsx-runtime").JSX.Element;
export interface RadioGroupProps {
    name?: string;
    value?: string;
    onChange?: (event: React.ChangeEvent<HTMLInputElement>, value: string) => void;
    children?: React.ReactNode;
}
export declare function RadioGroup({ name, value, onChange, children }: RadioGroupProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=FormControls.d.ts.map