export interface TextFieldProps {
    label?: string;
    id?: string;
    error?: string | null;
    value?: string | number;
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onFocus?: (event: React.FocusEvent<HTMLInputElement>) => void;
    onBlur?: (event: React.FocusEvent<HTMLInputElement>) => void;
    style?: React.CSSProperties;
    type?: string;
    disabled?: boolean;
    size?: 'small' | 'medium';
    standard?: boolean;
    min?: number;
    max?: number;
    defaultValue?: string;
    placeholder?: string;
}
export declare const TextField: import("react").ForwardRefExoticComponent<TextFieldProps & import("react").RefAttributes<HTMLInputElement>>;
export interface InputProps {
    defaultValue?: string;
    placeholder?: string;
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
}
export declare const Input: import("react").ForwardRefExoticComponent<InputProps & import("react").RefAttributes<HTMLInputElement>>;
export interface SwitchProps {
    checked?: boolean;
    onChange?: (event: React.MouseEvent<HTMLButtonElement> | React.ChangeEvent<HTMLInputElement>) => void;
    disabled?: boolean;
    style?: React.CSSProperties;
}
export declare function Switch({ checked, onChange, disabled, style }: SwitchProps): import("react/jsx-runtime").JSX.Element;
export interface CheckboxProps {
    checked?: boolean;
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
    disabled?: boolean;
    size?: 'small' | 'medium';
    style?: React.CSSProperties;
}
export declare function Checkbox({ checked, onChange, disabled, size, style }: CheckboxProps): import("react/jsx-runtime").JSX.Element;
export interface RadioProps {
    value?: string;
    checked?: boolean;
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
}
export declare function Radio({ value, checked, onChange }: RadioProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Inputs.d.ts.map