export interface GridProps {
    container?: boolean;
    columns?: number;
    size?: number;
    children?: React.ReactNode;
    style?: React.CSSProperties;
}
export declare function Grid({ container, columns, size, children, style }: GridProps): import("react/jsx-runtime").JSX.Element;
export interface CollapseProps {
    in?: boolean;
    children?: React.ReactNode;
    style?: React.CSSProperties;
}
export declare function Collapse({ in: open, children, style }: CollapseProps): import("react/jsx-runtime").JSX.Element;
export interface LinearProgressProps {
    variant?: 'determinate';
    value?: number;
}
export declare function LinearProgress({ variant: _variant, value }: LinearProgressProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Layout.d.ts.map