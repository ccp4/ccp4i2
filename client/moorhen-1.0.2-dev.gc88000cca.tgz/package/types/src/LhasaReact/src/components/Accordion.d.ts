export interface AccordionProps {
    defaultExpanded?: boolean;
    children?: React.ReactNode;
}
export declare function Accordion({ defaultExpanded, children }: AccordionProps): import("react/jsx-runtime").JSX.Element;
export interface AccordionSummaryProps {
    children?: React.ReactNode;
}
export declare function AccordionSummary({ children }: AccordionSummaryProps): import("react/jsx-runtime").JSX.Element;
export interface AccordionDetailsProps {
    children?: React.ReactNode;
    style?: React.CSSProperties;
}
export declare function AccordionDetails({ children, style }: AccordionDetailsProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Accordion.d.ts.map