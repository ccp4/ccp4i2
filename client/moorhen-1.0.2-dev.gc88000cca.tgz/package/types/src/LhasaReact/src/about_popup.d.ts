import './index.scss';
import './components.scss';
declare class AboutPopupProps {
    dark_mode: boolean;
    icons_path_prefix: string;
    open: boolean;
    anchorEl?: HTMLElement | null;
    onClose: () => void;
}
export declare function AboutPopup(props: AboutPopupProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=about_popup.d.ts.map