import type { QEDInfo } from './types';
type QedPropertyInfoboxProps = {
    property_name: string;
    display_value: string | number | undefined;
    progressbar_value: number | undefined;
};
type QEDTabsProps = {
    qedInfo: Map<number, QEDInfo>;
    currentTab: number;
    onTabChange: (value: number) => void;
};
export declare function QedPropertyInfobox(props: QedPropertyInfoboxProps): import("react/jsx-runtime").JSX.Element;
export declare function QEDTabs(props: QEDTabsProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=qed_property_infobox.d.ts.map