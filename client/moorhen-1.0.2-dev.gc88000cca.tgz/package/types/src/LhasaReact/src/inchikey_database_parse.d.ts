export declare function parseInchikeyDatabase(rawData: string): Map<string, [string, string]>;
//# sourceMappingURL=inchikey_database_parse.d.ts.map