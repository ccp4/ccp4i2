/** The element that really has focus, looking through open shadow roots (document.activeElement stops at the host) */
export declare const getDeepActiveElement: () => Element | null;
/** The element an event really started on, through shadow roots (event.target is retargeted at document level) */
export declare const getEventOrigin: (event: Event) => EventTarget | null;
//# sourceMappingURL=shadowDom.d.ts.map