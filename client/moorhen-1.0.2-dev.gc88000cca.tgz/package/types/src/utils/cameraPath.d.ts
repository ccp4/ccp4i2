/**
 * Where the camera is at a given moment in a movie.
 *
 * Pure arithmetic: no GL, no store, no React. Give it a movie and a time in seconds and it returns
 * a camera and the set of things visible. What to do with that is the renderer's problem.
 *
 * THE SHAPE OF A MOVIE
 *
 * Keyframes say where the camera is. Segments say what happens between two of them. CCP4MG's movie
 * editor puts both on one object - each checkpoint carries its view *and* the motion leading away
 * from it - which is why deleting and re-adding checkpoints there behaves badly: removing a view
 * also removes a motion, and the neighbours have to be renegotiated. Kept apart, a keyframe can be
 * deleted and the two segments either side merge into one.
 *
 * Spin and rock are motions applied around a held view rather than interpolations, so their two
 * endpoint keyframes are the same. That is what lets them compose with moves instead of being a
 * special case inside them.
 *
 * TURNING THE CORNER
 *
 * Interpolating A->B and B->C as separate eased segments makes the camera stop dead at B, which
 * reads as a slideshow. Avoiding that needs the path to be continuous in velocity through B, not
 * just position, so a run of consecutive `move` segments is treated as one curve:
 *
 *   - orientation by squad - slerp between slerps, with control quaternions derived from each
 *     keyframe's neighbours. Plain slerp per segment is continuous in position and not in velocity,
 *     which is exactly the corner problem.
 *   - everything else by centripetal Catmull-Rom. The uniform variety overshoots when the direction
 *     changes sharply, swinging the camera wide of a keyframe it was supposed to pass through.
 *
 * Easing is applied at the ends of a run, not at every keyframe. A spin or a hold breaks the run,
 * because there the camera really has stopped and should ease into and out of it.
 *
 * A caveat worth knowing: time maps linearly to the curve parameter within a segment, and equal
 * steps in parameter are not quite equal steps in distance on a curve. With keyframes spaced
 * roughly evenly the difference is not visible. It would need arc-length parameterisation to be
 * exactly right, which is a lot of machinery for a wobble nobody can see.
 */
import * as quat4 from "gl-matrix/quat";
export type Vec3 = [number, number, number];
/** Where the camera is, and how solid the things it looks at are. */
export interface Keyframe {
    /** View orientation, as the renderer's myQuat. */
    quat: quat4.quat;
    origin: Vec3;
    zoom: number;
    /**
     * The slab, as offsets from the view centre, matching CameraState.
     *
     * These were called clipStart/clipEnd/fogStart/fogEnd, which were the renderer's names for
     * absolute distances from the eye. They have always held offsets here; the names simply lied,
     * and a reader who believed them would place a movie's fog hundreds of angstroms adrift.
     */
    clipFront: number;
    clipBack: number;
    fogFront: number;
    fogBack: number;
    /**
     * How solid each object is at this keyframe, by unique id, from 0 to 1.
     *
     * Interpolated, which is what makes a fade possible - and once it is, visibility has no
     * separate existence: hidden is opacity 0, shown is 1, and an object that appears halfway
     * through is one that goes from 0 to 1. A boolean alongside this would only be a second way to
     * say the same thing, and they could disagree.
     *
     * An id missing from a keyframe is not animated by it rather than hidden by it, so a movie
     * that only moves the camera - a tour with no opacity map at all - leaves the scene's own
     * opacities alone. The authoring side keeps keyframes complete, adding new objects to earlier
     * keyframes at 0; this rule is what makes a hand-written movie behave sensibly anyway.
     */
    opacity?: Record<string, number>;
    /**
     * The rest of the scene at this keyframe, interpolated between keyframes like everything else.
     *
     * QUANTITIES LIVE HERE; MODES LIVE ON THE MOVIE
     *
     * A light's position and a background colour are quantities: halfway between two of them means
     * something, so they belong on a keyframe. Whether shadows are on is a mode - there is no
     * halfway between on and off - so it belongs to the movie as a whole, set once and applied
     * throughout. SSAO and edge detection go with it: their parameters are quantities, but they
     * describe a feature that is either running or not, and animating one while the other switches
     * is more confusion than anyone asked for.
     *
     * Blur splits along that line rather than against it. Whether the off-screen buffers are used
     * at all is the movie's; how deep and how wide the blur is are the keyframe's.
     */
    scene?: SceneKeyframe;
    /**
     * A small picture of this shot, as a data URL.
     *
     * Not camera path arithmetic, and it sits here anyway. The alternative - a parallel list of
     * images beside the keyframes - has to be kept in step by hand through every add, delete and
     * reorder, and the first time it slips the panel shows one shot and goes to another. Carried
     * on the keyframe it is simply part of the thing it depends on.
     *
     * Optional throughout: a hand-written movie has none, an older file has none, and a keyframe
     * whose picture could not be taken has none. Nothing but the panel reads it, and the panel
     * falls back to the numbers.
     */
    thumbnail?: string;
}
/** A colour or a position, as the store holds them. */
export type Vec4 = [number, number, number, number];
/**
 * The scene's quantities at a keyframe. Every field optional, and absent means not animated.
 *
 * That is the same rule as opacity, and for the same reason: a movie that only moves the camera
 * must leave the scene it is shown in alone, not assert a lighting rig it never chose. A keyframe
 * captured from a live scene fills all of these in; one written by hand or generated need not.
 */
export interface SceneKeyframe {
    backgroundColor?: Vec4;
    lightPosition?: Vec4;
    ambient?: Vec4;
    diffuse?: Vec4;
    specular?: Vec4;
    specularPower?: number;
    /**
     * Depth of field: where the focal plane sits.
     *
     * The radius is not here, though it is just as much a quantity. Setting it calls
     * makeBlurBuffers, which reallocates the blur framebuffers - cheap for a slider someone drags
     * now and then, ruinous sixty times a second. It lives in the movie's settings instead, and
     * the half that carries the expression anyway is this one: what is in focus, not how soft the
     * rest is.
     */
    blurDepth?: number;
}
/** What happens between one keyframe and the next. */
export type Motion = 
/** Interpolate from one keyframe to the next. */
{
    kind: "move";
}
/** Stay where you are. */
 | {
    kind: "hold";
}
/** Whole turns about an axis, ending where it began. */
 | {
    kind: "spin";
    turns?: number;
    axis?: "x" | "y" | "z";
}
/** Swing back and forth by `degrees` either side, completing a cycle every `periodSeconds`. */
 | {
    kind: "rock";
    degrees?: number;
    periodSeconds?: number;
    axis?: "x" | "y" | "z";
};
export interface Segment {
    seconds: number;
    motion: Motion;
}
export interface Movie {
    keyframes: Keyframe[];
    /** One per gap between keyframes, so there is always one fewer than there are keyframes. */
    segments: Segment[];
}
export interface MovieSample {
    quat: quat4.quat;
    origin: Vec3;
    zoom: number;
    /** Offsets from the view centre, as in Keyframe. */
    clipFront: number;
    clipBack: number;
    fogFront: number;
    fogBack: number;
    /** Only the objects this movie animates; anything absent is left as the scene has it. */
    opacity: Record<string, number>;
    /** Only the scene quantities this movie animates; likewise. */
    scene: SceneKeyframe;
}
export declare const movieDuration: (movie: Movie) => number;
/**
 * Smooth start and stop.
 *
 * The classic smoothstep: zero slope at both ends, so the camera neither jerks into motion nor
 * stops dead.
 */
export declare const easeInOut: (u: number) => number;
/**
 * The camera at a moment in the movie.
 *
 * @param seconds  from the start; clamped to the movie's length at both ends
 */
export declare function sampleMovie(movie: Movie, seconds: number): MovieSample;
//# sourceMappingURL=cameraPath.d.ts.map