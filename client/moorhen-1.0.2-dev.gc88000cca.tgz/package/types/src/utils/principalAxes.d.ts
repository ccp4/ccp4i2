/**
 * The natural axes of a group of atoms: which way is it long, which way is it wide.
 *
 * Used to frame something in the camera. "Align the ligand's long axis with the screen x axis" has
 * to start by deciding what the long axis is, and for an arbitrary ligand there is no bond or atom
 * name to read it off - unlike a residue, where centreAndAlignViewOn can use C, CA and O.
 *
 * This is principal component analysis of the atom positions: the first axis is the direction of
 * greatest spread, the second the greatest spread perpendicular to it, the third completes a
 * right-handed set. For a flat ring the third axis is the ring normal, which is why looking down
 * it shows the ring face on.
 *
 * The eigenvectors come from power iteration with deflation rather than a general eigensolver.
 * Three-by-three symmetric is a small enough problem that the simple method converges in a few
 * dozen iterations, and it has the property that matters here: it is deterministic. The same atoms
 * give the same axes every time, which a movie depends on.
 */
export type Vec3 = [number, number, number];
export interface Point3 {
    x: number;
    y: number;
    z: number;
}
export interface PrincipalAxes {
    /** The mean position. */
    centre: Vec3;
    /** Long, middle and short, right-handed, each a unit vector. */
    axes: [Vec3, Vec3, Vec3];
    /** Full width along each axis, so twice the furthest atom from the centre in that direction. */
    extents: Vec3;
}
export declare function principalAxes(points: ArrayLike<Point3>): PrincipalAxes;
//# sourceMappingURL=principalAxes.d.ts.map