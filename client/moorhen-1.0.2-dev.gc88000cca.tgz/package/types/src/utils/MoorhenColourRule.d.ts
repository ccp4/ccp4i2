import { moorhen } from "../types/moorhen";
import { CommandCentre } from "../InstanceManager/CommandCentre/MoorhenCommandCentre";
export type ColourRuleSelectionType = "chain" | "cid" | "ligands" | "molecule" | "neighbourhood" | "residue-range";
export type ColourRulePropertyType = "default" | "af2-plddt" | "b-factor" | "b-factor-norm" | "electrostatics" | "jones-rainbow" | "mol-symm" | "property" | "RMSF" | "secondary-structure";
export type ColourRuleType = ColourRuleSelectionType | ColourRulePropertyType;
/**
 * Represents a colour rule for a given representation
 * @property {ColourRuleType} ruleType - The type of this colour rule instance
 * @property {string} cid - The CID selection for this colour rule
 * @property {string} color - The colour for this rule in hexadecimal format
 * @property {string} multiColourData - Encoded CID/colour data for multi-colour rules
 * @property {string} label - Label displayed in the UI for this colour rule
 * @property {boolean} isMultiColourRule - Indicates whether this colour rule consists of multiple colours assigned to different residues
 * @property {moorhen.Molecule} parentMolecule - The molecule assigned to this colour rule
 * @property {moorhen.MoleculeRepresentation} parentRepresentation - The molecule representation assigned to this colour rule
 * @property {boolean} applyColourToNonCarbonAtoms - Indicates if the colour rule will also be applied to non carbon atoms
 * @property {string} uniqueId - A unique identifier for this colour rule
 * @constructor
 * @param {string} ruleType - The type of this colour rule instance
 * @param {string} cid - The CID selection for this colour rule
 * @param {string} color - The colour for this rule (hex format)
 * @param {CommandCentre | null} commandCentre - The command centre instance
 * @param {boolean} [isMultiColourRule=false] - Indicates whether this colour rule consists of multiple colours assigned to different residues
 * @param {boolean} [applyColourToNonCarbonAtoms=false] - Indicates if the colour rule will also be applied to non carbon atoms
 * @param {string} [multiColourData=""] - Encoded CID/colour data for multi-colour rules
 * @example
 * import { MoorhenMolecule, MoorhenColourRule } from 'moorhen';
 *
 * const example = async (ruleArgs) => {
 *    const molecule = new MoorhenMolecule(commandCentre, glRef, monomerLibraryPath);
 *
 *    const colourRule = new MoorhenColourRule(
 *      'molecule', "//", "#ffffff", commandCentre
 *    )
 *
 *    colourRule.setParentMolecule(molecule)
 * }
 */
export declare class ColourRule {
    ruleType: ColourRuleType;
    propertyType: ColourRulePropertyType;
    cid: string;
    color: string;
    multiColourData: string;
    label: string;
    isMultiColourRule: boolean;
    commandCentre: CommandCentre | null;
    parentMolecule: moorhen.Molecule;
    parentRepresentation: moorhen.MoleculeRepresentation;
    applyColourToNonCarbonAtoms: boolean;
    uniqueId: string;
    initFromString: (stringifiedObject: string, commandCentre: CommandCentre | null, molecule: moorhen.Molecule) => moorhen.ColourRule;
    initFromDataObject: (data: moorhen.ColourRuleObject, commandCentre: CommandCentre | null, molecule: moorhen.Molecule) => moorhen.ColourRule;
    parseHexToRgba: (hex: string) => [number, number, number, number];
    constructor(ruleType: ColourRuleType, cid: string, color: string, commandCentre: CommandCentre | null, isMultiColourRule?: boolean, applyColourToNonCarbonAtoms?: boolean, multiColourData?: string);
    /**
     * Static method that can be used to create a new colour rule from a JSON string representation of a colour rule data object
     * @param {string} stringifiedObject - The JSON string representation of a colour rule data object
    * @param {CommandCentre | null} commandCentre - The command centre instance
     * @param {moorhen.Molecule} molecule - The molecule that will be associated to this colour rule
     * @returns {moorhen.ColourRule} The new colour rule
     */
    static initFromString(stringifiedObject: string, commandCentre: CommandCentre | null, molecule: moorhen.Molecule): ColourRule;
    /**
     * Static method that can be used to create a new colour rule from a colour rule data object
     * @param {moorhen.ColourRuleObject} data - The colour rule data object
    * @param {CommandCentre | null} commandCentre - The command centre instance
     * @param {moorhen.Molecule} molecule - The molecule that will be associated to this colour rule
     * @returns {moorhen.ColourRule} The new colour rule
     */
    static initFromDataObject(data: moorhen.ColourRuleObject, commandCentre: CommandCentre | null, molecule: moorhen.Molecule): ColourRule;
    /**
     * Static method that can be used to parse a HEX string into RGBA
     * @param {string} hex - The HEX string
     * @returns {number[]} A list of numbers corresponding with RGBA
     */
    static parseHexToRgba(hex: string): [number, number, number, number];
    /**
     * Get a colour rule data object for this colour rule instance
     * @returns {moorhen.ColourRuleObject} The colour rule data object
     */
    objectify(): {
        cid: string;
        color: string;
        applyColourToNonCarbonAtoms: boolean;
        isMultiColourRule: boolean;
        ruleType: ColourRuleType;
        args: string[];
        label: string;
        uniqueId: string;
        parentMoleculeMolNo: number;
        parentRepresentationUniqueId: string;
    };
    /**
     * Get a JSON string representation of the colour rule data object for this colour rule instance
     * @returns {string} A JSON string representation of the colour rule data object
     */
    stringify(): string;
    /**
     * Set the label attribute for this colour rule instance
     * @param {string} label - The new label
     */
    setLabel(label: string): void;
    setColor(color: string): void;
    setMultiColourData(multiColourData: string): void;
    /**
     * Set the molecule instance associated to this colour rule instance
     * @param {moorhen.Molecule} molecule - The molecule instance
     */
    setParentMolecule(molecule: moorhen.Molecule): void;
    /**
     * Set the molecule representation associated to this colour rule instance
     * @param {moorhen.MoleculeRepresentation} representation - The molecule representation instance
     */
    setParentRepresentation(representation: moorhen.MoleculeRepresentation): void;
    /**
     * Set whether this colour rule should also be applied to non carbon atoms
     * @param {boolean} newVal The new attribute value
     */
    setApplyColourToNonCarbonAtoms(newVal: boolean): void;
    /**
     * Get a list of user-defined colour objects that can be passed directly to libcoot API based on this colour rule instance
     * @returns {object[]} The user-defined colour objects
     */
    getUserDefinedColours(): {
        cid: string;
        rgba: [number, number, number, number];
        applyColourToNonCarbonAtoms: boolean;
    }[];
    /** Get the colour-rule payload expected by Coot's non-bond commands. */
    getCootColourRuleArgs(): [string] | [string, string];
    /**
     * Use libcoot API to apply this colour rule
    * @param {string} [style] - The style of the molecule representation associated with this colour rule. Defaults to the parent representation's style.
     */
    apply(style?: string): Promise<void>;
}
//# sourceMappingURL=MoorhenColourRule.d.ts.map