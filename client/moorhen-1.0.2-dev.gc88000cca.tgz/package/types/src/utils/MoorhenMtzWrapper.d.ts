export declare class MoorhenMtzWrapper {
    reflectionData: null | Uint8Array;
    columns: {
        [colType: string]: string;
    };
    constructor();
    loadHeaderFromFile: (file: File) => Promise<{
        [colType: string]: string;
    }>;
}
//# sourceMappingURL=MoorhenMtzWrapper.d.ts.map