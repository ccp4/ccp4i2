/** One attribute as the decoder produced it: dequantised values, interleaved by component. */
export type DracoAttribute = {
    values: Float32Array;
    components: number;
};
/** What a decoder returns for one compressed blob. */
export type DracoDecoded = {
    /** Vertices in the decoded mesh, which becomes each rewritten accessor's count. */
    numPoints: number;
    /** Triangle indices, three per face. */
    indices: Uint32Array;
    /** Decoded attributes by their Draco unique id - the values the extension's map holds. */
    attributes: Map<number, DracoAttribute>;
};
/**
 * Decodes one Draco blob.
 *
 * @param compressed - The bytes of the bufferView the extension points at.
 * @param uniqueIds - The Draco attribute ids wanted, from the extension's attribute map.
 * @throws If the blob cannot be decoded. Callers treat that as the file being unreadable.
 */
export type DracoDecode = (compressed: Uint8Array, uniqueIds: number[]) => DracoDecoded;
/** A buffer file the rewritten glTF will need beside it. */
export type SyntheticSidecar = {
    name: string;
    data: Uint8Array;
};
export type DecompressedGltf = {
    /** The rewritten document, as .gltf text. */
    gltf: Uint8Array;
    /** Buffers the rewritten document refers to and that did not exist as files before. */
    sidecars: SyntheticSidecar[];
};
/**
 * Rewrite a Draco-compressed glTF as a plain one.
 *
 * @param bytes - The .gltf or .glb as read.
 * @param available - Buffer files already in hand, keyed by the URI the document uses. The
 *     compressed blob is often in one of these rather than in the document itself.
 * @param decode - The decoder.
 * @returns The rewritten document and the buffers it needs, or null if there was no Draco to
 *     undo - in which case the caller should use the original bytes untouched.
 * @throws If the file is compressed but cannot be rebuilt, with a reason worth showing.
 */
export declare const decompressDracoGltf: (bytes: ArrayBuffer, available: Map<string, Uint8Array>, decode: DracoDecode) => DecompressedGltf | null;
//# sourceMappingURL=gltfDraco.d.ts.map