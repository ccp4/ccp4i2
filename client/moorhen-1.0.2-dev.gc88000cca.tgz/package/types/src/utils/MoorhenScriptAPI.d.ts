import type { Store } from "@reduxjs/toolkit";
import { moorhen } from "../types/moorhen";
import { webGL } from "../types/mgWebGL";
export declare class MoorhenScriptApi {
    molecules: moorhen.Molecule[];
    maps: moorhen.Map[];
    commandCentre: React.RefObject<moorhen.CommandCentre>;
    glRef: React.RefObject<webGL.MGWebGL>;
    store: Store;
    constructor(commandCentre?: React.RefObject<moorhen.CommandCentre>, store?: Store, molecules?: moorhen.Molecule[], maps?: moorhen.Map[]);
    doRigidBodyFit: (molNo: number, cidsString: string, mapNo: number) => Promise<void>;
    doGenerateSelfRestraints: (molNo: number, maxRadius: number) => Promise<void>;
    doRefineResiduesUsingAtomCid: (molNo: number, cid: string, mode: string, ncyc: number) => Promise<void>;
    doClearExtraRestraints: (molNo: number) => Promise<void>;
    setGemanMcclureAlpha: (newValue: number) => Promise<void>;
    runCommand: (command: string, ...args: any[]) => Promise<void>;
    redraw_molecules: () => Promise<void>;
    exe(src: string): void;
}
//# sourceMappingURL=MoorhenScriptAPI.d.ts.map