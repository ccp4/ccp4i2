/**
 * Google's Draco decoder, loaded only when a compressed file actually turns up.
 *
 * The rebuilding of the glTF around the decoded geometry is in gltfDraco.ts and knows nothing
 * about this; all this does is satisfy that module's DracoDecode contract. Keeping them apart is
 * what lets the rebuilding - where the mistakes would be - be tested against known geometry
 * without a 190 KB WebAssembly module in the loop.
 *
 * Two things about how it is loaded are deliberate.
 *
 * It is loaded at runtime from Moorhen's own asset directory rather than imported through a
 * bundler. The npm package ships its glue as `draco_decoder_gltf_nodejs.js`, which is
 * misleading: the file detects its environment and runs perfectly well in a browser, with
 * `require("fs")` inside a branch a browser never takes. But a bundler reads that `require`
 * statically, and making Vite and the webpack webcomponent build both agree to ignore it is two
 * configurations to keep working.
 *
 * It is fetched as text and evaluated against a CommonJS shim, which is what three.js does with
 * the same files. That needs `unsafe-eval` in a Content Security Policy - which is worth knowing
 * and costs nothing here, because Moorhen already requires it: emscripten's embind builds every
 * method invoker with `new Function`, so Coot does not start at all without it. A page that can
 * run Moorhen can run this.
 *
 * The URL is resolved against the document rather than this module, because `urlPrefix` may be
 * relative - the web component defaults it to "MoorhenAssets" - and a bundle does not
 * necessarily sit beside the page that loaded it. That is the same resolution the web component
 * uses for moorhen.css.
 *
 * The WebAssembly binary is handed over as `wasmBinary` rather than left to be located, since an
 * emscripten module left to itself derives a URL from the script that loaded it. Fetching it
 * ourselves also means it arrives as an ArrayBuffer, so the server does not have to be serving
 * .wasm as application/wasm for instantiation to work.
 *
 * The decode happens on the main thread, like the winding correction on the way out. A large
 * compressed mesh will stall the page while it runs; if that becomes a problem the thing to move
 * is this module rather than its caller, since the contract it satisfies is one function.
 */
import type { DecoderModule } from "draco3d";
import type { DracoDecode } from "./gltfDraco";
/**
 * A decode function built on an already-loaded decoder module.
 *
 * Separate from the loading so that this - the part that uses Draco's API, and so the part where
 * a misunderstanding of it would live - can be exercised against the real library. The module is
 * fetched over HTTP in a browser, which a test cannot do, but the same module is a plain require
 * in Node.
 */
export declare const decodeWith: (draco: DecoderModule) => DracoDecode;
/**
 * A decode function for gltfDraco, with the decoder fetched on first use.
 *
 * @param urlPrefix - Moorhen's asset prefix, from moorhenInstance.paths.
 */
export declare const createDracoDecode: (urlPrefix: string) => Promise<DracoDecode>;
//# sourceMappingURL=gltfDracoDecoder.d.ts.map