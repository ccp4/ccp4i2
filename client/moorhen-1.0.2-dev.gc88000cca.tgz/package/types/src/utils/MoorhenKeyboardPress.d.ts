import { moorhen } from "../types/moorhen";
import { Shortcut } from '../InstanceManager/Preferences';
import { MoorhenInstance } from '../InstanceManager';
export declare const moorhenKeyPress: (event: KeyboardEvent, hoveredAtom: moorhen.HoveredAtom, activeMap: moorhen.Map, molecules: moorhen.Molecule[], viewOnly: boolean, moorhenInstance: MoorhenInstance, shortCuts: {
    [key: string]: Shortcut;
}, showShortcutToast: boolean, shortcutOnHoveredAtom: boolean) => boolean | Promise<boolean>;
//# sourceMappingURL=MoorhenKeyboardPress.d.ts.map