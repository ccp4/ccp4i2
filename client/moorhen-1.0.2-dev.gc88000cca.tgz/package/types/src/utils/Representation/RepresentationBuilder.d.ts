import { moorhen } from "@/types/moorhen";
import { ColourRule } from "../MoorhenColourRule";
import type { MoorhenMolecule } from "../MoorhenMolecule";
import { MoleculeRepresentation, RepresentationStyles, m2tParameters, residueEnvironmentOptions } from "./MoorhenMoleculeRepresentation";
/** The supported ways a representation selection can be built. */
export type RepresentationRuleType = "ligands" | "cid" | "molecule" | "chain" | "residue-range" | "neighbourhood";
export interface BuildCidSelectionParams {
    ruleType: "ligands" | "cid" | "molecule" | "chain" | "residue-range" | "neighbourhood";
    representationStyle: RepresentationStyles;
    molecule: MoorhenMolecule;
    chainName: string | null;
    notHOH: boolean;
    notH: boolean;
    sideChainOnly: boolean;
    restrictToNeighbours: boolean;
    excludeNeighbours: boolean;
    neighboursCid: string;
    neighboursDistance: number;
    sequenceResidueRange: [number, number] | null;
    cid: string;
}
/**
 * Build a CID selection string based on the rule type and other parameters.
 * Returns null if the selection is invalid.
 */
export declare function buildCidSelection(params: BuildCidSelectionParams): string | null;
export interface BuildColourRuleParams {
    useDefaultColours: boolean;
    colourMode: string;
    ruleType: string;
    cidSelection: string;
    colour: string;
    molecule: MoorhenMolecule;
    applyColourToNonCarbonAtoms: boolean;
    ncsColourRule: ColourRule | null;
    styleSelectValue: string;
}
/**
 * Build a ColourRule based on the colour mode and other parameters.
 * Returns undefined if default colours should be used.
 */
export declare function buildColourRule(params: BuildColourRuleParams): Promise<ColourRule | undefined>;
/**
 * Determine the non-custom alpha value based on the colour mode.
 * Returns null for custom colour mode.
 */
export declare function getNonCustomAlpha(colourMode: string, nonCustomOpacity: number): number | null;
export interface CreateRepresentationParams {
    representationStyle: RepresentationStyles;
    ruleType?: "ligands" | "cid" | "molecule" | "chain" | "residue-range" | "neighbourhood";
    molecule: MoorhenMolecule;
    /**
     * When provided, the existing representation is updated in place (edit mode)
     * instead of creating a brand-new one and committing it to the molecule.
     */
    existingRepresentation?: MoleculeRepresentation;
    /** CID-selection options (all optional, with sensible defaults) */
    chainName?: string | null;
    notHOH?: boolean;
    notH?: boolean;
    sideChainOnly?: boolean;
    restrictToNeighbours?: boolean;
    excludeNeighbours?: boolean;
    neighboursCid?: string;
    neighboursDistance?: number;
    sequenceResidueRange?: [number, number] | null;
    cid?: string;
    /** Colour-related options (default to default colours) */
    useDefaultColours?: boolean;
    colourMode?: string;
    colour?: string;
    applyColourToNonCarbonAtoms?: boolean;
    ncsColourRule?: ColourRule | null;
    /** Representation-related options */
    isCustom?: boolean;
    bondOptions?: moorhen.cootBondOptions | null;
    m2tParams?: m2tParameters | null;
    residueEnvironmentOptions?: residueEnvironmentOptions | null;
    nonCustomOpacity?: number | null;
    hbondedTo?: boolean;
}
/**
 * The parameters of a MoleculeRepresentation that can be extracted and reused
 * (e.g. to pre-populate the edit dialog, or as fallback defaults in edit mode).
 */
export interface ExtractedRepresentationParams {
    representationStyle: RepresentationStyles;
    ruleType: RepresentationRuleType;
    cid: string;
    chainName: string | null;
    sequenceResidueRange: [number, number] | null;
    notHOH: boolean;
    notH: boolean;
    sideChainOnly: boolean;
    restrictToNeighbours: boolean;
    excludeNeighbours: boolean;
    neighboursCid: string;
    neighboursDistance: number;
    hbondedTo: boolean;
    useDefaultColours: boolean;
    colourMode: string;
    colour: string;
    applyColourToNonCarbonAtoms: boolean;
    ncsColourRule: ColourRule | null;
    bondOptions: moorhen.cootBondOptions | null;
    m2tParams: m2tParameters | null;
    residueEnvironmentOptions: residueEnvironmentOptions | null;
    nonCustomOpacity: number | null;
}
/**
 * The subset of creation parameters that cannot be reconstructed exactly from a
 * representation's live state (they are encoded lossily in the built CID string
 * and colour rules). Snapshot onto the representation at build time so that
 * edit mode reuses the exact original values instead of re-deriving them.
 */
export interface BuildRepresentationParams {
    ruleType: RepresentationRuleType;
    colourMode: string;
    ncsColourRule: ColourRule | null;
    notHOH: boolean;
    notH: boolean;
    sideChainOnly: boolean;
    chainName: string | null;
    sequenceResidueRange: [number, number] | null;
}
/**
 * Read the parameters off an existing representation so they can be reused in
 * edit mode (pre-populating the edit dialog, or as defaults when some creation
 * options are omitted). Values stored in `representation.buildParams` (the
 * snapshot taken at build time) are preferred for fields that would otherwise
 * be lossy to reconstruct; all other fields are read from live state.
 */
export declare function extractRepresentationParams(representation: MoleculeRepresentation): ExtractedRepresentationParams;
/** Representation styles that are internal-only and not exposed on the public API surface. */
export declare const INTERNAL_REPRESENTATION_STYLES: readonly ["hover", "environment", "residueSelection", "transformation", "rama", "rotamer", "chemical_features", "ligand_validation", "glycoBlocks", "adaptativeBonds"];
/**
 * The representation styles accepted on the public API surface
 * (e.g. MoorhenInstance.newMoleculeRepresentation). Excludes internal-only
 * styles (hover highlights, validation/analysis tools, etc.) that don't make
 * sense as a user-facing creation request.
 */
export type PublicRepresentationStyles = Exclude<RepresentationStyles, (typeof INTERNAL_REPRESENTATION_STYLES)[number]>;
export declare function createRepresentation(params: CreateRepresentationParams): Promise<MoleculeRepresentation | null>;
//# sourceMappingURL=RepresentationBuilder.d.ts.map