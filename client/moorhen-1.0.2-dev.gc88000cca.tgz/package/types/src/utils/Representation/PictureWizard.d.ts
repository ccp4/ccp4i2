import type { MoorhenMolecule } from "../MoorhenMolecule";
import type { MoleculeRepresentation } from "./MoorhenMoleculeRepresentation";
import { Dispatch } from "@reduxjs/toolkit";
export type PictureWizardType = "site-and-ribbons" | "bonds" | "ribbons-and-ligands" | "ribbons-and-side-chains" | "catrace";
export type PictureWizardRuleType = "ligands" | "cid";
export interface RunPictureWizardParams {
    molecule: MoorhenMolecule;
    wizardType: PictureWizardType;
    ruleType?: PictureWizardRuleType;
    ligandSelection?: string | null;
    cid?: string;
    neighboursDistance?: number;
    deleteExisting?: boolean;
    onRepresentationAdded?: (representation: MoleculeRepresentation) => void;
    onRepresentationRemoved?: (representation: MoleculeRepresentation) => void;
    onApply?: () => void;
    dispatch: Dispatch;
}
export declare function runPictureWizard(params: RunPictureWizardParams): Promise<MoleculeRepresentation[]>;
//# sourceMappingURL=PictureWizard.d.ts.map