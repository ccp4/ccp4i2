/**
 * Getting at the bytes a glTF refers to.
 *
 * Both forms of the format, and all three places the data can be: a .glb's binary chunk, an
 * embedded data: URI, or a file beside the document. Every part of the glTF handling needs this -
 * finding which files are required, undoing Draco compression, decoding the images for textures -
 * and three copies of the same resolution would be three chances for them to disagree about, say,
 * whether a percent-encoded URI matches the file the person actually chose.
 */
export type Json = Record<string, unknown>;
export type GltfDocument = {
    json: Json;
    /** The .glb binary chunk, or null for a .gltf. */
    chunk: Uint8Array | null;
};
/** A property of a JSON object, when it is an array of objects; an empty array otherwise. */
export declare const arrayAt: (json: Json, key: string) => Json[];
/** The JSON and the binary chunk of either form of glTF, or null if it is neither. */
export declare const splitGltf: (bytes: ArrayBuffer) => GltfDocument | null;
/** The bytes of a base64 data: URI, or null if it is not one this can decode. */
export declare const dataUriBytes: (uri: string) => Uint8Array | null;
/**
 * Reads buffers and bufferViews of one document.
 *
 * @param document - From splitGltf.
 * @param available - Buffer and image files already in hand, keyed by the URI the document uses.
 * @throws If something referred to cannot be found, naming it - a missing file is the commonest
 *     case and the person can act on knowing which one.
 */
export declare const gltfBufferReader: (document: GltfDocument, available: Map<string, Uint8Array>) => {
    bufferBytes: (index: number) => Uint8Array;
    viewBytes: (index: unknown) => Uint8Array;
    buffers: Json[];
    bufferViews: Json[];
};
//# sourceMappingURL=gltfBuffers.d.ts.map