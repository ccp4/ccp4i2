/**
 * A worked example of a movie: fly in to a ligand, turn around it, fly back out.
 *
 * This exists to exercise cameraPath against a real molecule rather than against test fixtures -
 * the arithmetic can be right and the result still look wrong, and only a real ligand in a real
 * scene will say which. Nothing calls it now that the movie panel lets keyframes be placed by
 * hand, and it is kept because automatic tours are worth having, not because this one is finished.
 *
 * WHAT HAS TO CHANGE BEFORE IT IS A FEATURE
 *
 * It assumes it is starting from a wide view of the whole structure. Run it from one, and it reads
 * well: the camera flies in from a sensible distance and returns there. Run it when the view is
 * already zoomed in somewhere, and parts one and three become strange - the "fly in" starts closer
 * than it ends, and the return lands back on a close-up that tells the viewer nothing.
 *
 * The honest fix is not to capture the starting view at all. A tour should frame its own opening,
 * from the extent of the thing being toured, and treat the live camera as where to blend in from
 * rather than as the shot to return to.
 *
 * The three parts are:
 *
 *   1. move from wherever the camera is now to the ligand, framed so its long axis lies along the
 *      screen x axis and its second axis along y - so the molecule lies flat and wide on screen
 *      rather than at an arbitrary angle;
 *   2. half a turn about the vertical, to show the other side;
 *   3. move back out to exactly where it started.
 *
 * ORIENTING THE CAMERA
 *
 * The rotation is built the same way centreAndAlignViewOn builds its: three orthonormal world
 * vectors written into a mat3 as right, up and forward, then quat4.fromMat3. That function aligns
 * on a residue using C, CA and O, which a ligand has no equivalent of - so the principal axes of
 * the ligand's atoms stand in. Following its construction exactly rather than deriving one is
 * deliberate: the sign and handedness conventions are then whatever already works on screen,
 * instead of whatever I reasoned they should be.
 */
import * as quat4 from "gl-matrix/quat";
import { Keyframe, Movie, Vec3 } from "./cameraPath";
import { Point3 } from "./principalAxes";
export interface LigandTourOptions {
    /** Seconds to fly in, and the same again to fly back out. */
    approachSeconds?: number;
    /** Seconds spent turning around the ligand. */
    turnSeconds?: number;
    /** How far round to go. Half a turn shows the far side. */
    turns?: number;
    /**
     * How much of the frame the ligand should fill.
     *
     * The orthographic view is 48 world units tall at zoom 1, so a zoom of extent/48 would have
     * the ligand exactly touching the edges. A little more leaves some room around it.
     */
    marginFactor?: number;
}
/**
 * A view orientation that puts `right` along the screen x axis and `upInit` roughly along y.
 *
 * `upInit` only has to be in the right half-plane; it is orthogonalised against `right`, so the
 * caller can hand over two principal axes without worrying whether they are exactly perpendicular
 * after the numerics.
 */
export declare const orientationLookingAt: (right: Vec3, upInit: Vec3) => quat4.quat;
/** The keyframe that frames a group of atoms nicely. */
export declare const keyframeFacing: (atoms: ArrayLike<Point3>, template: Keyframe, marginFactor?: number) => Keyframe;
/**
 * Build the tour.
 *
 * @param current  where the camera is now, which is both the first and the last keyframe
 * @param atoms    the ligand
 */
export declare function buildLigandTour(current: Keyframe, atoms: ArrayLike<Point3>, options?: LigandTourOptions): Movie;
//# sourceMappingURL=ligandTour.d.ts.map