import { MoorhenInstance } from "../InstanceManager";
import { moorhen } from "../types/moorhen";
import { MoorhenMolecule } from "./MoorhenMolecule";
export declare const parseCifDict: (file: File) => Promise<{
    comp_id: string;
    dict_contents: string;
}[]>;
export declare const drawModels: (newMolecules: MoorhenMolecule[], moorhenInstance: MoorhenInstance) => Promise<void>;
export declare const loadCoordFiles: (files: File[], moorhenInstance: MoorhenInstance, backgroundColor: [number, number, number, number], defaultBondSmoothness: number | null) => Promise<Promise<moorhen.Molecule>[]>;
export declare const handleSessionUpload: (file: File, moorhenInstance: MoorhenInstance) => Promise<void>;
export declare const loadMrParseFiles: (files: File[], moorhenInstance: MoorhenInstance, backgroundColor: any, defaultBondSmoothness: any, dispatch: any) => Promise<void>;
export declare const loadMrParseUrl: (urlBase: any, moorhenInstance: MoorhenInstance, backgroundColor: any, defaultBondSmoothness: any, dispatch: any) => Promise<void>;
/**
 * Read a glTF or glb file and add it to the scene as a single 3D object.
 *
 * A mesh rather than a molecule: nothing is known about its chemistry, so it is not a
 * MoorhenMolecule and does not appear in the molecule list. It becomes one ThreeDObject, which
 * makes it one thing to select, centre on, recolour and delete - the same treatment a cavity
 * gets, and the reason the whole file is merged into one mesh on the way out of Coot.
 *
 * @param file - The .gltf or .glb file to read.
 * @param moorhenInstance - The instance to add the mesh to.
 * @param alsoSelected - The other files chosen at the same time, from which the buffers and
 *     images a .gltf refers to are taken. A self-contained .glb needs none of them.
 * @returns The uniqueId of the new object.
 */
export declare const loadGltfFile: (file: File, moorhenInstance: MoorhenInstance, alsoSelected?: File[]) => Promise<string>;
export declare const autoOpenFiles: (files: File[], moorhenInstance: MoorhenInstance, backgroundColor: [number, number, number, number], defaultBondSmoothness: number) => Promise<{
    type: "molecule" | "map";
    uniqueID: string;
    molNo: number;
    fileName: string;
}[]>;
//# sourceMappingURL=FileLoading.d.ts.map