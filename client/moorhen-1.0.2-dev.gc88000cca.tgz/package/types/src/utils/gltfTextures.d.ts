import { type TextureSource } from "../WebGLgComponents/textureRegistry";
/**
 * Decodes one encoded image into raw pixels.
 *
 * Injected so the rest of this can be tested: jsdom has neither createImageBitmap nor
 * OffscreenCanvas, and a test that had to provide both would be testing the browser.
 */
export type ImageDecode = (bytes: Uint8Array, mimeType: string) => Promise<TextureSource | null>;
/**
 * The browser's own decoder.
 *
 * Row 0 of what getImageData returns is the top row, which is the convention the texture registry
 * uploads to and the one glTF's coordinates assume, so nothing is flipped on the way through.
 */
export declare const decodeImageInBrowser: ImageDecode;
/**
 * A texture id for each material that has one.
 *
 * @param bytes - The .gltf or .glb as read.
 * @param available - Image and buffer files already in hand, keyed by the URI the document uses.
 * @param decode - How to turn encoded image bytes into pixels.
 * @returns material index -> texture id. Materials absent from it draw untextured.
 */
export declare const gltfMaterialTextures: (bytes: ArrayBuffer, available: Map<string, Uint8Array>, decode?: ImageDecode) => Promise<Map<number, string>>;
//# sourceMappingURL=gltfTextures.d.ts.map