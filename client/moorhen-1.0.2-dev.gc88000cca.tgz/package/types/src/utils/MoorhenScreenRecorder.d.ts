import { webGL } from "../types/mgWebGL";
import { RootState } from "../store/MoorhenReduxStore";
import { Store } from "redux";
import type { VideoQuality } from "./videoBitrate";
export interface ImageFrac2D {
    x: number;
    y: number;
    width: number;
    height: number;
    img: HTMLImageElement;
    zIndex: number;
}
/**
 * Re-exported so `import type { VideoQuality } from ".../MoorhenScreenRecorder"` keeps working.
 * The presets and the arithmetic now live in videoBitrate, shared with the movie export - see
 * there for why a bitrate has to scale with the frame.
 */
export type { VideoQuality } from "./videoBitrate";
export declare class ScreenRecorder {
    rec: MediaRecorder | null;
    chunks: Blob[];
    canvasRef: React.RefObject<HTMLCanvasElement>;
    glRef: React.RefObject<webGL.MGWebGL>;
    store: Store<RootState>;
    _isRecording: boolean;
    videoName: string;
    videoQuality: VideoQuality;
    private recordedMimeType;
    constructor(glRef: React.RefObject<webGL.MGWebGL>, canvasRef: React.RefObject<HTMLCanvasElement>, store: Store<RootState>);
    /** The first preferred type this browser will actually record, or "" to let it choose. */
    private pickMimeType;
    /** The file extension matching whatever was actually recorded. */
    private extensionForMimeType;
    /**
     * Build a recorder around the canvas as it is now.
     *
     * Done per recording rather than once at construction. captureStream binds to the canvas at
     * the size it has when called, and the canvas is resized whenever the window is - so a
     * recorder built on mount was working from a stale track for every recording after the first
     * resize, which browsers handle anywhere between gracefully and a truncated file.
     *
     * Resizing *during* a recording is still not survivable: the track changes size underneath an
     * encoder that has already written a header. Only a resize between recordings is fixed here.
     */
    private createRecorder;
    stopRecording: () => void;
    loadLatexImage: (latexObject: any) => Promise<ImageFrac2D>;
    loadImage: (url: any) => Promise<unknown>;
    isRecording: () => boolean;
    startRecording: () => void;
    setVideoName: (name: string) => void;
    /** So the popup can show the name the file will actually be given. */
    getVideoName: () => string;
    /** Takes effect from the next recording: the bitrate is fixed when a recording starts. */
    setVideoQuality: (quality: VideoQuality) => void;
    getVideoQuality: () => VideoQuality;
    downloadVideo: (blob: Blob) => Promise<void>;
    takeScreenShot: (filename: string, doTransparentBackground?: boolean) => Promise<void>;
}
//# sourceMappingURL=MoorhenScreenRecorder.d.ts.map