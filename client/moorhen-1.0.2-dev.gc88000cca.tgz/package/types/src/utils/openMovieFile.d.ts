/**
 * Opening a .mhm, from wherever it arrives.
 *
 * A movie file can be opened from the movie panel's own button, from File -> Open, or by being
 * dropped on the window, and all three have to do the same thing - restore the scene, load the
 * document, show the panel. This is that thing, written once: the alternative is three copies of
 * an ordering that matters, which drift until two of the three ways in are subtly wrong.
 *
 * WHY THE SESSION GOES FIRST
 *
 * The document names objects by id and tours a camera path built against a particular scene.
 * Loading it before the session would leave a movie whose keyframes refer to things that are not
 * there yet and whose path flies around whatever happened to be open - which looks like the file
 * being wrong rather than being early.
 */
import type { MoorhenInstance } from "../InstanceManager";
/** What happened, in words fit to show someone - in a status line or in a snackbar. */
export interface OpenedMovie {
    ok: boolean;
    message: string;
    /** Whether the file brought a scene with it, and so replaced what was open. */
    restoredScene: boolean;
}
/**
 * Open a movie file: restore its scene, load its document, and show the movie panel.
 *
 * @param onProgress - called with each step, for a caller that has somewhere to put it. Opening a
 *     movie means decompressing a session and rebuilding a scene, which on a large structure is
 *     long enough that silence reads as nothing having happened.
 */
export declare function openMovieFile(file: File, moorhenInstance: MoorhenInstance, onProgress?: (message: string) => void): Promise<OpenedMovie>;
//# sourceMappingURL=openMovieFile.d.ts.map