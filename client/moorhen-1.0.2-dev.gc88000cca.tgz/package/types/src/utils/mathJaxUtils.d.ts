export declare const getMathJaxSVG: (input: string) => Promise<{
    svg: any;
    whratio: number;
}>;
//# sourceMappingURL=mathJaxUtils.d.ts.map