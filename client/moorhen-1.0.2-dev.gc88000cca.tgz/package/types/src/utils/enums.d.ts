export declare const modalKeys: Readonly<{
    MODELS: "models";
    MAPS: "maps";
    ACEDRG: "acedrg";
    SEQ_QUERY: "query-seq";
    SCRIPTING: "scripting";
    SHOW_CONTROLS: "show-controls";
    FIT_LIGAND: "fit-ligand";
    RAMA_PLOT: "rama-plot";
    DIFF_MAP_PEAKS: "diff-map-peaks";
    VALIDATION_PLOT: "validation-plot";
    MMRRCC: "mmrrcc";
    WATER_VALIDATION: "water-validation";
    LIGAND_VALIDATION: "lig-validation";
    FILL_PART_RES: "fill-partial-residues";
    PEPTIDE_FLIPS: "pepflips";
    UNMODELLED_BLOBS: "unmodelled-blobs";
    CARB_VALIDATION: "carb-validation";
    SLICE_N_DICE: "slice-n-dice";
    SUPERPOSE_MODELS: "superpose";
    SCENE_SETTINGS: "scene-settings";
    LHASA: "lhasa";
    QSCORE: "qscore";
    JSON_VALIDATION: "json-validation";
    MRBUMP: "mrbump";
    MRPARSE: "mrparse";
    COLOR_MAP_BY_MAP: "colour-map-by-map";
    VECTORS: "vectors";
    OVERLAYS2D: "overlays-2d";
    PAEPLOT: "pae-plot";
    SCENE_SLIDERS: "scene-sliders";
    CONKIT: "conkit";
    NOE: "NOE";
    FSC: "fourier-shell-correlation";
}>;
export declare const representationLabelMapping: Readonly<{
    rama: "Ramachandran Balls";
    rotamer: "Rotamer Dodec.";
    CBs: "Bonds";
    CAs: "C-Alpha";
    CRs: "Ribbons";
    CDs: "Contact dots";
    MolecularSurface: "Mol Surface";
    gaussian: "Gaussian Surface";
    cavities: "Cavities";
    ligands: "Ligands";
    DishyBases: "Bases";
    VdwSpheres: "Spheres";
    allHBonds: "H-Bonds";
    glycoBlocks: "Glyco-Blocks";
    restraints: "Restraints";
    MetaBalls: "MetaBalls";
    adaptativeBonds: "Adaptive Bonds";
    residue_environment: "Res. Environment";
    environment: "Environment";
}>;
export declare const COOT_BOND_REPRESENTATIONS: string[];
export declare const M2T_REPRESENTATIONS: string[];
export declare const residueCodesOneToThree: Readonly<{
    C: "CYS";
    D: "ASP";
    S: "SER";
    Q: "GLN";
    K: "LYS";
    I: "ILE";
    P: "PRO";
    T: "THR";
    F: "PHE";
    N: "ASN";
    G: "GLY";
    H: "HIS";
    L: "LEU";
    R: "ARG";
    W: "TRP";
    A: "ALA";
    V: "VAL";
    E: "GLU";
    Y: "TYR";
    M: "MET";
    UNK: "UNKOWN";
    X: "UNKOWN";
    "-": "MISSING";
}>;
export declare const residueCodesThreeToOne: Readonly<{
    ALA: "A";
    ARG: "R";
    ASN: "N";
    ASP: "D";
    CYS: "C";
    GLN: "Q";
    GLU: "E";
    GLY: "G";
    HIS: "H";
    ILE: "I";
    LEU: "L";
    LYS: "K";
    MET: "M";
    PHE: "F";
    PRO: "P";
    SER: "S";
    THR: "T";
    TRP: "W";
    TYR: "Y";
    VAL: "V";
    UNK: "X";
}>;
export declare const nucleotideCodesOneToThree: Readonly<{
    A: "A";
    T: "T";
    G: "G";
    C: "C";
    U: "U";
    N: "N";
    I: "I";
    X: "UNKOWN";
    UNK: "UNKOWN";
    "-": "MISSING";
}>;
export declare const nucleotideCodesThreeToOne: Readonly<{
    A: "A";
    T: "T";
    G: "G";
    C: "C";
    U: "U";
    N: "N";
    I: "I";
    DT: "T";
    DG: "G";
    DC: "C";
    DA: "A";
    DU: "U";
    ADE: "A";
    THY: "T";
    GUA: "G";
    CYT: "C";
    URA: "U";
    PSU: "U";
    UNKOWN: "X";
    UNK: "X";
    MISSING: "-";
}>;
export declare const windowsFonts: string[];
export declare const macFonts: string[];
export declare const linuxFonts: string[];
export declare const webSafeFonts: string[];
export declare const allFontsSet: Set<string>;
export declare const railSpecies: string[];
/**
 * Tag scheme for mesh sections that stand for atoms:
 *
 *     <molecule uniqueId>|<chain id>|<residue number>|<atom cid>
 *
 * The first three fields are a normalised residue key, for matching; the fourth is a CID to hand
 * to the hover state, for display. Both are carried because CIDs come in more than one shape -
 * the sequence viewer writes "/0/A/36" while an atom hover writes "/5a3h/A/36(GLY)/CA" - so
 * matching on the CID itself would depend on where the hover came from. Parsing every tag to
 * compare them would be correct but costs a pass over every section each time the display
 * buffers are rebuilt, which is once a frame while a 3D object is being dragged.
 *
 * Lives here rather than with either end of it: the 3D object code must not know what an atom is,
 * and the molecular code must not know what a section is. The generator that labels a path and
 * the bridges that read the label are the only things that agree on this string.
 */
export declare const MOORHEN_ATOM_TAG_KIND = "moorhen-atom";
/** The residue key the first three fields of such a tag make up. */
export declare const moorhenAtomTagKey: (moleculeUniqueId: string, chainId: string, residueNumber: number | string) => string;
/**
 * Tag scheme for manipulation handles, written "<action>|<axis>" - "translate|x", "rotate|z".
 *
 * A separate scheme from the atom one so that the bridges which turn a section hover into an
 * atom hover pass over these without a second thought, which is what the kind field is for.
 */
export declare const MOORHEN_GIZMO_TAG_KIND = "moorhen-gizmo";
/**
 * Tag scheme naming a whole 3D object, written as its uniqueId.
 *
 * On the instance channel rather than the section one, and so able to sit alongside the atom
 * tags a path already carries: a path's sections say which residue each piece stands for, while
 * its instance says which object all of it belongs to. Clicking asks the second question.
 */
export declare const MOORHEN_3D_OBJECT_TAG_KIND = "moorhen-3d-object";
//# sourceMappingURL=enums.d.ts.map