import type { MoorhenInstance } from "../InstanceManager";
import type { LoadFilesResult } from "../InstanceManager/MoorhenInstance";
type RGB = {
    r: number;
    g: number;
    b: number;
};
/**
 * One map to read from an MTZ file with `MoorhenInstance.files.loadMtz`.
 * @property name - Map name, defaults to `${fileName}-${columns.F}`
 * @property columns - MTZ column labels; `Fobs`, `SigFobs` and `FreeR` are needed for `calcStructFact`
 * @property isDifference - Defaults to false
 * @property calcStructFact - Associate the reflection data with the map (R-factors, map updates).
 * Defaults to true when `Fobs`, `SigFobs` and `FreeR` are all given. If any of them is missing from the file,
 * the map is still loaded, without reflection data, and a warning is shown
 * @property style - Colours (0–1): `colour` for normal maps, `positiveColour`/`negativeColour` for difference maps
 * @property visible - Show the map once loaded, defaults to true
 * @property active - Make this the active map
 */
export type MtzMapRequest = {
    name?: string;
    columns: {
        F: string;
        PHI: string;
        Fobs?: string;
        SigFobs?: string;
        FreeR?: string;
    };
    isDifference?: boolean;
    calcStructFact?: boolean;
    style?: {
        colour?: RGB;
        positiveColour?: RGB;
        negativeColour?: RGB;
    };
    visible?: boolean;
    active?: boolean;
};
/**
 * Implementation of `MoorhenInstance.files.loadMtz`: fetch the file once, check the requested columns
 * against its header (only missing F/PHI columns are fatal), then read each map and add them all to the store together.
 */
export declare const loadMtzMaps: (instance: MoorhenInstance, source: string | URL | File, requests?: MtzMapRequest[]) => Promise<LoadFilesResult>;
export {};
//# sourceMappingURL=MtzLoading.d.ts.map