/**
 * Turning an inside-out glTF export the right way round.
 *
 * Coot's exporters do not agree with each other about winding, which is the thing to know before
 * using this. Measured on real exports of the same build:
 *
 *     export_metaballs_as_gltf                   signed volume -101.7   inside-out
 *     export_map_molecule_as_gltf                signed volume -227.0   inside-out
 *     export_molecular_representation_as_gltf    signed volume  822.6   standard
 *     export_model_molecule_as_gltf (bonds)      signed volume  166.6   standard
 *
 * All four measured, and they fall into two groups. The inside-out pair are the isosurface
 * generators - metaballs and map contours, both marching over a grid - while the two that come
 * out standard build their geometry from parts. That is a tidy enough split to be suggestive
 * rather than conclusive: the flag below is still set per path from the measurement, not
 * inferred from the grouping.
 *
 * So this is applied per export path, by the caller, and never to everything. An earlier version
 * applied it to every glTF export on the strength of one measurement, and inverted M2T - which
 * had been correct all along.
 *
 * (That first measurement was of a metaballs export misread as a molecular surface, and a whole
 * explanation was built on it about M2T's "mesh_perm3" compensation reaching the screen but not
 * the file. The observation was right and the attribution was wrong.)
 *
 * It is not obvious from looking, which is why it went unnoticed: a viewer that lights both faces
 * and culls neither shades a uniformly reversed surface quite plausibly, so such files look right
 * almost everywhere. They are wrong all the same, and anything that respects the convention -
 * Moorhen's own mesh import, for one - shows the inside.
 *
 * Both halves of the correction are needed. Measured on the metaballs export:
 *
 *     as exported                          volume   -101.7   agree 16916/16916
 *     reverse winding only                 volume    101.7   agree     0/16916
 *     negate normals only                  volume   -101.7   agree     0/16916
 *     reverse winding AND negate normals    volume   101.7   agree 16916/16916
 *
 * Either alone leaves the file internally inconsistent - the winding saying one thing and the
 * normals the other - which is worse than being uniformly reversed, because then no viewer can
 * paper over it.
 *
 * Done to the bytes here rather than in Coot: Coot's meshes have assorted histories and some of
 * their permutations exist for Moorhen's own sake, so which of them is "wrong" is not a question
 * to settle by changing Coot internals.
 *
 * outputs/wf/sel/gltfwinding.py measures any file, which is how each line above was obtained.
 */
/**
 * Reverse the winding and negate the normals of every triangle primitive in a .glb.
 *
 * The binary chunk is edited in place and the JSON is untouched, so the result is the same file
 * with the geometry turned the right way round - same length, same structure, same accessors.
 *
 * An accessor shared between primitives is handled once. Two primitives sharing one NORMAL
 * accessor would otherwise have it negated twice, which would quietly put it back as it was.
 *
 * @param bytes - The exported .glb.
 * @returns The corrected bytes, or the input unchanged if it is not a .glb this can edit.
 */
export declare const correctExportedGltf: (bytes: ArrayBuffer) => ArrayBuffer;
export declare const reverseExportedGltfWinding: (bytes: Uint8Array) => Uint8Array;
//# sourceMappingURL=gltfWinding.d.ts.map