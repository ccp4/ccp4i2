export declare const loadMathjax: (src: string) => Promise<void>;
//# sourceMappingURL=mathJaxLoader.d.ts.map