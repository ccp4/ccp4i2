/**
 * Editing a movie document.
 *
 * Every operation the panel offers, as a function from a document to a new document. No React, no
 * store, no renderer - so the rules below can be checked directly, and so the panel is left with
 * nothing but which button was pressed.
 *
 * WHY THESE ARE NOT ONE-LINERS
 *
 * Keyframes and segments are separate lists with an invariant between them: there is exactly one
 * segment per gap, so a movie with n keyframes has n-1 segments. CCP4MG's editor avoids the
 * invariant by hanging each motion off the keyframe before it, and pays for it every time a
 * checkpoint is deleted - removing a view also removes a motion, and the neighbours have to be
 * renegotiated. Keeping them apart means a deleted keyframe leaves its two segments to merge into
 * one, which is both what an author expects and something that has to be written down somewhere.
 *
 * Every function returns a new document and leaves the old one alone. The panel keeps its document
 * in Redux, which freezes state in development, so an operation that mutated in place would work
 * in a build and throw in a dev session - a failure worth designing out rather than remembering.
 */
import type { Keyframe, Motion, Segment } from "./cameraPath";
import type { MovieDocument, MovieSceneSettings } from "./movieDocument";
/** How long a newly added segment runs, before anyone has said otherwise. */
export declare const DEFAULT_SEGMENT_SECONDS = 3;
/**
 * Whether the movie ends with a motion that has nowhere to go.
 *
 * A segment describes what happens *from* the keyframe it starts at. For a move that means going
 * to the next one; for a hold, spin or rock the camera stays where it is and the movie cuts to the
 * next keyframe afterwards - which is how those have always behaved mid-path. Allowing one in the
 * last slot is therefore not a new idea, only the same one applied at the end: it is what lets a
 * movie be a single keyframe that spins, or a tour that finishes by turning on the spot.
 *
 * So `segments.length` is either `keyframes.length - 1` (every segment connects two keyframes) or
 * `keyframes.length` (the last one has no destination).
 */
export declare const hasTrailingSegment: (document: MovieDocument) => boolean;
/**
 * Add a keyframe, and the segment that reaches it.
 *
 * @param at  where to put it; appended when omitted. Inserting in the middle splits the segment
 *            that spanned the gap, and the two halves each take half its time - so the movie's
 *            total length does not change, which is what makes inserting a keyframe to adjust a
 *            path feel like adjusting rather than lengthening.
 */
export declare function addKeyframe(document: MovieDocument, keyframe: Keyframe, at?: number): MovieDocument;
/**
 * Remove a keyframe, leaving the movie continuous.
 *
 * The two segments either side become one, carrying the sum of their times, so what was a path
 * through three views becomes a path through two over the same stretch of movie. Removing an end
 * keyframe simply drops the segment that reached it, which does shorten the movie - there is
 * nothing else it could mean.
 */
export declare function deleteKeyframe(document: MovieDocument, index: number): MovieDocument;
/** Replace a keyframe in place - the "update this one to what I am looking at now" operation. */
export declare function replaceKeyframe(document: MovieDocument, index: number, keyframe: Keyframe): MovieDocument;
/** Move a keyframe to a different place in the order, keeping the segment times where they are. */
export declare function moveKeyframe(document: MovieDocument, from: number, to: number): MovieDocument;
/**
 * How long a segment runs, and what happens during it.
 *
 * Editing the slot just past the end creates the trailing motion. The panel shows that row for
 * every keyframe including the last, because "hold for three seconds here" was previously only
 * discoverable by adding a keyframe you did not want - and a movie that is one shot, spinning, had
 * no way to exist at all.
 */
export declare function setSegment(document: MovieDocument, index: number, change: Partial<Segment>): MovieDocument;
/**
 * A second keyframe exactly where one already is.
 *
 * The companion to a trailing motion. "Add keyframe from this view" captures wherever the camera
 * happens to be now; cloning says "start again from precisely here", which is what a shot that
 * spins and then carries on somewhere else needs - the spin ends where it began, so the next leg
 * has to start from the same place or the movie cuts.
 *
 * The thumbnail comes with it, since it is a picture of a view that has not changed.
 */
export declare function cloneKeyframe(document: MovieDocument, index: number): MovieDocument;
/**
 * Take the trailing motion away, leaving the movie to end on its last keyframe.
 *
 * The inverse of creating one through `setSegment`, and needed because the panel offers the
 * trailing slot as a dropdown: anything a choice adds, the same dropdown has to be able to remove,
 * or "spin at the end" becomes a decision that cannot be unmade without deleting the keyframe.
 *
 * A no-op when there is no trailing segment, so it can never eat a connector.
 */
export declare function removeTrailingSegment(document: MovieDocument): MovieDocument;
/** What happens during a segment, as the motion dropdown changes it. */
export declare const setMotion: (document: MovieDocument, index: number, motion: Motion) => MovieDocument;
/**
 * One keyframe's scene settings, given to all of them.
 *
 * The lighting, background and focal plane are per keyframe so that they *can* change during a
 * movie, but most movies do not want them to - they want one look, arrived at by fiddling with a
 * single frame until it is right. Without this that means repeating the fiddling, or capturing
 * every keyframe again.
 */
export declare function applySceneToAll(document: MovieDocument, index: number): MovieDocument;
/**
 * How solid an object is at one keyframe.
 *
 * Only this keyframe. An object absent from the others stays absent, and so stays untouched by
 * the movie there - which is the rule that lets a camera tour be played over a scene it was not
 * authored against.
 */
export declare function setObjectOpacity(document: MovieDocument, index: number, id: string, value: number): MovieDocument;
/**
 * Bring an object under the movie's control, everywhere.
 *
 * ALL the keyframes, which is the point. An object the movie mentions at one keyframe and not at
 * the next is not interpolated between them - it is animated at one and left alone at the other -
 * so an opacity set in a single frame does not produce a fade, it produces a jump followed by
 * whatever the scene happened to be doing.
 *
 * WHAT VALUE TO INTRODUCE IT AT
 *
 * The caller's choice, and the panel passes the opacity the object has right now - so bringing an
 * object under the movie's control changes nothing about how the movie looks, and the author then
 * edits the keyframes they care about. Zero was the original default, on the reasoning that a
 * molecule loaded after a movie was started should stay invisible until some keyframe says
 * otherwise. It reads badly in use: choosing an object from a picker made it disappear from every
 * keyframe but the one in front of you.
 *
 * Only the gaps are filled. A keyframe that already says something about this object keeps saying
 * it, which is what lets this be called defensively before setting a single keyframe's opacity -
 * the fades already authored are safe.
 */
export declare function introduceObject(document: MovieDocument, id: string, value?: number): MovieDocument;
/** Stop animating an object, at every keyframe. It goes back to being the scene's business. */
export declare function releaseObject(document: MovieDocument, id: string): MovieDocument;
/**
 * Every object this movie animates, in a stable order.
 *
 * Gathered across all keyframes rather than from one, so the list does not change as the selected
 * keyframe changes - a picker whose contents shift as you move through the movie is unusable.
 */
export declare function animatedObjects(document: MovieDocument): string[];
/** The movie's scene settings, which apply throughout rather than per keyframe. */
export declare const setSceneSettings: (document: MovieDocument, change: Partial<MovieSceneSettings>) => MovieDocument;
//# sourceMappingURL=movieEditing.d.ts.map