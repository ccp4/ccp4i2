import * as types from './graphql';
import { TypedDocumentNode as DocumentNode } from '@graphql-typed-document-node/core';
/**
 * Map of all GraphQL operations in the project.
 *
 * This map has several performance disadvantages:
 * 1. It is not tree-shakeable, so it will include all operations in the project.
 * 2. It is not minifiable, so the string of a GraphQL query will be multiple times inside the bundle.
 * 3. It does not support dead code elimination, so it will add unused operations.
 *
 * Therefore it is highly recommended to use the babel or swc plugin for production.
 * Learn more about it here: https://the-guild.dev/graphql/codegen/plugins/presets/preset-client#reducing-bundle-size
 */
type Documents = {
    "\nquery GetPolimerInfo ($entryIds: [String!]! $entityIds: [String!]!) {\n  entryInfo: entries(entry_ids: $entryIds) {\n    entryId: rcsb_id\n    info: rcsb_entry_info {\n      resolution: resolution_combined\n    }\n    accessionInfo:  rcsb_accession_info {\n      date: initial_release_date\n    }\n    compModelInfo: rcsb_comp_model_provenance {\n      db: source_db\n      url: source_url\n    }\n  }\n  entityInfo: polymer_entities (entity_ids: $entityIds) {\n    entityId: rcsb_id\n    entityIds: rcsb_polymer_entity_container_identifiers {\n      authId: auth_asym_ids\n    }\n  }\n}": typeof types.GetPolimerInfoDocument;
};
declare const documents: Documents;
/**
 * The gql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 *
 *
 * @example
 * ```ts
 * const query = gql(`query GetUser($id: ID!) { user(id: $id) { name } }`);
 * ```
 *
 * The query argument is unknown!
 * Please regenerate the types.
 */
export declare function gql(source: string): unknown;
/**
 * The gql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export declare function gql(source: "\nquery GetPolimerInfo ($entryIds: [String!]! $entityIds: [String!]!) {\n  entryInfo: entries(entry_ids: $entryIds) {\n    entryId: rcsb_id\n    info: rcsb_entry_info {\n      resolution: resolution_combined\n    }\n    accessionInfo:  rcsb_accession_info {\n      date: initial_release_date\n    }\n    compModelInfo: rcsb_comp_model_provenance {\n      db: source_db\n      url: source_url\n    }\n  }\n  entityInfo: polymer_entities (entity_ids: $entityIds) {\n    entityId: rcsb_id\n    entityIds: rcsb_polymer_entity_container_identifiers {\n      authId: auth_asym_ids\n    }\n  }\n}"): (typeof documents)["\nquery GetPolimerInfo ($entryIds: [String!]! $entityIds: [String!]!) {\n  entryInfo: entries(entry_ids: $entryIds) {\n    entryId: rcsb_id\n    info: rcsb_entry_info {\n      resolution: resolution_combined\n    }\n    accessionInfo:  rcsb_accession_info {\n      date: initial_release_date\n    }\n    compModelInfo: rcsb_comp_model_provenance {\n      db: source_db\n      url: source_url\n    }\n  }\n  entityInfo: polymer_entities (entity_ids: $entityIds) {\n    entityId: rcsb_id\n    entityIds: rcsb_polymer_entity_container_identifiers {\n      authId: auth_asym_ids\n    }\n  }\n}"];
export type DocumentType<TDocumentNode extends DocumentNode<any, any>> = TDocumentNode extends DocumentNode<infer TType, any> ? TType : never;
export {};
//# sourceMappingURL=gql.d.ts.map