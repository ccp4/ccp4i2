/**
 * A movie as a file.
 *
 * A movie is a description of how a scene should move, which is worthless without the scene. Save
 * only the description and reopening it a month later gives a camera path through nothing; save a
 * screen recording and the movie can never be edited again. So the file carries both: the movie
 * document, and the session it was authored against.
 *
 * WHY A ZIP RATHER THAN ONE MESSAGE
 *
 * The two halves have opposite natures. A session is large, binary, and written by machinery that
 * already exists and already has a schema - embedding coordinates, maps and representations
 * through protobuf. A movie document is small, text, and still changing shape week by week.
 * Putting the movie inside the session's schema would mean regenerating protobuf for every
 * keyframe field anyone thinks of, and putting the session inside JSON would mean base64 and a
 * third again in size for data that is already compact.
 *
 * A zip keeps each in the form that suits it. It also means the movie can be read, diffed, hand
 * edited and migrated without decoding a session at all, which matters for a format that will
 * change: `unzip -p movie.mhm moorhen-movie.json` is a debugging tool nobody has to write.
 *
 * THE SESSION IS OPTIONAL
 *
 * Two ways of working, and both are legitimate. A movie saved *with* its session is a complete
 * thing: it opens anywhere, including on a machine that has never seen the data. A movie saved
 * without one is a few kilobytes of camera path meant to be played over a scene you already have
 * - which is how a movie gets authored in the first place, saved repeatedly while being worked on,
 * and how a tour can be written once and applied to each of a series of structures.
 *
 * The manifest says which it is, so opening one can tell a movie that brought its own scene from
 * one that expects to find it already there, rather than discovering it halfway through a load.
 *
 * ON URLS
 *
 * CCP-EM's embedded Moorhen refers to data by URL, which would make for a very small movie file.
 * It is deliberately not the mechanism here: a URL needs something serving it, `file://` will not
 * do, and a movie that stops working when a server moves is not a saved movie. If a URL-referenced
 * variety is wanted later it belongs beside the embedded session as another manifest field, not
 * instead of it.
 */
import type { MovieDocument } from "./movieDocument";
/**
 * The format's version, for the manifest.
 *
 * Incremented when a change would make an older reader misunderstand a newer file - not when a
 * field is added that an older reader can safely ignore, which is most changes. A reader refuses
 * anything newer than it knows, because the alternative is loading half a movie and presenting it
 * as whole.
 */
export declare const MOVIE_FORMAT_VERSION = 1;
/** The movie description. Text, so it can be read without any of this code. */
export declare const MANIFEST_ENTRY = "moorhen-movie.json";
/** The session, exactly the bytes MoorhenTimeCapsule would have written on its own. */
export declare const SESSION_ENTRY = "session.pb";
/** The extension the file chooser should offer. */
export declare const MOVIE_EXTENSION = ".mhm";
export interface MovieContainer {
    movie: MovieDocument;
    /**
     * The session the movie was authored against, if the file carried one.
     *
     * Undefined is not an error - see the note on optional sessions above - but it does mean the
     * caller has to decide what scene to play the movie over, and should say so rather than
     * silently playing it over whatever happens to be loaded.
     */
    session?: Uint8Array;
}
/** What went wrong opening a file, in terms a person can act on. */
export declare class MovieFileError extends Error {
    constructor(message: string);
}
/**
 * A movie and its session, as the bytes of a file.
 *
 * @param type  "uint8array" for bytes, "blob" for something to hand to a download. The caller
 *              knows which it wants; this does not.
 */
export declare function packMovie(container: MovieContainer, options?: {
    type?: "uint8array" | "blob";
    writtenBy?: string;
}): Promise<Uint8Array | Blob>;
/**
 * A file, back into a movie and its session.
 *
 * Every way this can fail says which thing was wrong with the file. The alternative - one "could
 * not read movie" - is the failure mode that wastes an afternoon, because a truncated download, a
 * file from a newer Moorhen and a zip of something else entirely all need different responses.
 */
export declare function unpackMovie(data: ArrayBuffer | Uint8Array | Blob): Promise<MovieContainer>;
//# sourceMappingURL=movieContainer.d.ts.map