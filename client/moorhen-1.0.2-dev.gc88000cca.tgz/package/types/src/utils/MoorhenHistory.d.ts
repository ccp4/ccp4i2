import type { cootCommandKwargs } from '../InstanceManager/CommandCentre';
import { moorhen } from '../types/moorhen';
export interface HistoryEntry extends cootCommandKwargs {
    uniqueId: string;
    associatedBackupKey: string;
    label: string;
}
export declare class History {
    timeCapsule: React.RefObject<moorhen.TimeCapsule>;
    entries: HistoryEntry[];
    headId: string;
    headIsDetached: boolean;
    skipTracking: boolean;
    constructor(timeCapsule: React.RefObject<moorhen.TimeCapsule>);
    /**
     * Clear current history and start recording from the beginning
     */
    reset(): void;
    /**
     * If set to true then new entries will be ignored
     * @param {boolean} newVal - The new value
     */
    setSkipTracking(newVal: boolean): void;
    /**
     * Toggle the skipTracking attribute
     */
    toggleSkipTracking(): void;
    /**
     * Set the current head to a given history entry
     * @param {string} id - The ID of the history entry to be used as current head
     * @param {string} detach - Wether the history should enter a detached state
     */
    setCurrentHead(id: string, detach?: boolean): void;
    /**
     * Add an entry to the history
     * @param {moorhen.cootCommandKwargs} newEntry - The new entry that will be added
     */
    addEntry(newEntry: cootCommandKwargs): Promise<void>;
    /**
     * Get the history entries for a given molecule number
     * @param {number} molNo - The molecule number of interest
     * @returns {moorhen.cootCommandKwargs[]} - A list of history entries related to the molecule
     */
    getEntriesForMolNo(molNo: number): cootCommandKwargs[];
    /**
     * Get a list of modifed molecules
     * @returns {number[]} - A list of molecule numbers that had at least one modification
     */
    getModifiedMolNo(): number[];
    /**
     * Returns the imol that was last modified
     * @returns {number} - The imol of the molecule that was last modified
     */
    lastModifiedMolNo(): number;
    /**
     * Rebase the history to a given entry
     * @param {string} id - Unique ID for the entry used to rebase history
     */
    rebase(id: string): void;
}
//# sourceMappingURL=MoorhenHistory.d.ts.map