export declare function convertChemShiftDataframe(df: any): any;
export declare function loopReplaceProtons(rows: any, atomN?: string, nameN?: string): any[];
export declare function convertDataHeaders(restraintDict: any): any;
export declare function convertDataframe(df: any, pdbAtoms?: any): any[];
export declare const processNEFFileAutoLoader: (file: File, molecules: any[], dispatch: any) => Promise<any[]>;
//# sourceMappingURL=NEFFileAutoLoader.d.ts.map