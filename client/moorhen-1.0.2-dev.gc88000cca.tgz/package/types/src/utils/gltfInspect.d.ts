/**
 * Reading a glTF's JSON before handing it to the importer.
 *
 * Two questions are answered here, from one parse, both of which have to be answered on this
 * side of the worker:
 *
 *   Which other files does it need? A .gltf keeps its buffers and images in separate files named
 *   by relative URI - "scene.bin", "textures/wood.png" - and those have to be in the module's
 *   filesystem under those exact names before tinygltf looks for them. The only place they can
 *   come from is the selection the person made, so the names must be known here.
 *
 *   Is there something in it we cannot read at all? This one is here because of where tinygltf
 *   fails. Its post-parse pass over the primitives rejects an index accessor with no bufferView
 *   outright - "accessor[3] invalid bufferView" - and a Draco-compressed file is exactly that,
 *   since its indices live inside the compressed blob. So the whole load returns false and
 *   anything downstream of a successful parse never runs. The importer has the same checks in
 *   C++, and they are the backstop for LoadGltFromFile called from anywhere else, but they only
 *   see files that parse. This one sees the rest.
 *
 * What is deliberately not done here is fetching. A URI with a scheme - "https://...",
 * "file://..." - is returned like any other and left for the caller to refuse by name. Silently
 * going to the network for a file someone dragged in would be a surprising thing for a molecular
 * viewer to do, and the honest failure is a message saying which file was not supplied.
 */
/**
 * The external files a glTF refers to, in the order it refers to them.
 *
 * Only `buffers` and `images` can name another file. Embedded `data:` URIs are skipped, since
 * they are already in hand, and a buffer with no `uri` is the binary chunk.
 *
 * @param bytes - The .gltf or .glb as read.
 * @returns Relative URIs, de-duplicated, percent-decoding undone.
 */
export declare const gltfExternalUris: (bytes: ArrayBuffer) => string[];
/**
 * Whether this file needs decompressing before anything can read it.
 *
 * Asked before the decoder is loaded, so that a 190 KB WebAssembly module is fetched only for
 * the files that actually need it.
 *
 * @param bytes - The .gltf or .glb as read.
 */
export declare const gltfIsDracoCompressed: (bytes: ArrayBuffer) => boolean;
/**
 * Why this file cannot be read at all, or null if nothing stands in the way.
 *
 * The three cases are the ones where going ahead is worse than stopping. Draco and meshopt put
 * the geometry somewhere we cannot get at; sparse accessors we can read, but reading them
 * without applying the substitution the file asks for puts part of the mesh in the wrong place
 * and says nothing about it, which is the worst of the outcomes.
 *
 * Conservative by design. Nothing is reported on the strength of `extensionsRequired` alone,
 * because the commonest entry there is KHR_mesh_quantization - which the importer reads
 * perfectly - and refusing it would reject a large share of real files.
 *
 * @param bytes - The .gltf or .glb as read.
 * @returns A reason, worded for someone who is about to read it in a notification.
 */
export declare const gltfUnsupportedFeature: (bytes: ArrayBuffer) => string | null;
/** Whether a URI points somewhere Moorhen will not go to fetch it. */
export declare const isRemoteUri: (uri: string) => boolean;
//# sourceMappingURL=gltfInspect.d.ts.map