import { Store } from "@reduxjs/toolkit";
import { libcootApi } from "../types/libcoot";
import { moorhen } from "../types/moorhen";
import { MRCHeaderJson, MTZHeaderJson } from "./mapHeaders";
import { CommandCentre } from "../InstanceManager/CommandCentre";
import { MoorhenInstance } from "../InstanceManager";
export type BasicMapHeaderInfo = {};
export type mapHeaderInfo = {
    spacegroup: string;
    cell: libcootApi.mapCellJS;
    resolution: number;
};
export declare class MoorhenMap {
    type: "map";
    name: string;
    fileHeader: MRCHeaderJson | MTZHeaderJson | BasicMapHeaderInfo;
    headerInfo: mapHeaderInfo;
    isEM: boolean;
    molNo: number;
    store: Store;
    commandCentre: CommandCentre | null;
    isOriginLocked: boolean;
    drawOrigin: [number, number, number];
    mapCentre: [number, number, number];
    suggestedContourLevel: number;
    suggestedRadius: number;
    levelRange: [number, number];
    webMGContour: boolean;
    showOnLoad: boolean;
    displayObjects: any;
    cellCentre: [number, number, number];
    isDifference: boolean;
    hasReflectionData: boolean;
    selectedColumns: moorhen.selectedMtzColumns;
    associatedReflectionFileName: string;
    uniqueId: string;
    mapRmsd: number;
    mapMean: number;
    suggestedMapWeight: number;
    mapWeight: number;
    otherMapForColouring: {
        molNo: number;
        min: number;
        max: number;
    };
    diffMapColourBuffers: {
        positiveDiffColour: number[];
        negativeDiffColour: number[];
    };
    defaultMapColour: {
        r: number;
        g: number;
        b: number;
    };
    defaultPositiveMapColour: {
        r: number;
        g: number;
        b: number;
    };
    defaultNegativeMapColour: {
        r: number;
        g: number;
        b: number;
    };
    autoReadMtz: (source: File, commandCentre: React.RefObject<moorhen.CommandCentre | null>, store: Store) => Promise<moorhen.Map[]>;
    dataOrigin: "mtz" | "mapFile";
    originShift: [number, number, number];
    moorhenInstance: MoorhenInstance;
    constructor(moorhenInstance: MoorhenInstance);
    /**
     * Helper function to set this map instance as the "active" map for refinement
     */
    private _isActive;
    setActive(activate: boolean): Promise<void>;
    get active(): boolean;
    /**
     * Delete the map instance
     */
    delete(): Promise<void>;
    /**
     * Replace the current map with the contents of a MTZ file
     * @param {string} fileUrl - The uri to the MTZ file
     * @param {moorhen.selectedMtzColumns} selectedColumns - Object indicating the selected MTZ columns
     * @returns {Promise<void>}
     */
    replaceMapWithMtzFile(fileUrl: RequestInfo | URL, selectedColumns: moorhen.selectedMtzColumns): Promise<void>;
    /**
     * @deprecated This is used to direct load to coot worker for test only
     * Load map to moorhen using a MTZ url
     * @param {string} url - The url to the MTZ file
     * @param {string} name - The name that will be assigned to the map
     * @param {moorhen.selectedMtzColumns} selectedColumns - Object indicating the selected MTZ columns
     * @param {object} [options] - Options passed to fetch API
     * @returns {Pormise<moorhen.Map>} This moorhenMap instance
     */
    loadToCootFromMtzURL(url: RequestInfo | URL, name: string, selectedColumns: moorhen.selectedMtzColumns, options?: RequestInit): Promise<moorhen.Map>;
    /**
     * Load map to moorhen using MTZ data
     * @param {Uint8Array} data - The mtz data
     * @param {string} name - The name that will be assigned to the map
     * @param {moorhen.selectedMtzColumns} selectedColumns - Object indicating the selected MTZ columns
     * @returns {Pormise<moorhen.Map>} This moorhenMap instance
     */
    static loadToCootFromMtzData(data: Uint8Array, name: string, selectedColumns: moorhen.selectedMtzColumns, moorhenInstance: MoorhenInstance): Promise<moorhen.Map>;
    /**
     * Load map to moorhen from a MTZ file
     * @param {File} source - The MTZ file
     * @param {moorhen.selectedMtzColumns} selectedColumns - Object indicating the selected MTZ columns
     * @returns {Promise<moorhen.Map>} This moorhenMap instance
     */
    static loadToCootFromMtzFile: (source: File, selectedColumns: moorhen.selectedMtzColumns, moorhenInstance: MoorhenInstance) => Promise<moorhen.Map>;
    /**
     * Load map to moorhen from a map file url - prefer using MoorhenInstance.file.loadFiles() instead
     * @param {string} url - The url to the MTZ file
     * @param {string} name - The name that will be assigned to the map
     * @param {boolean} [isDiffMap=false] - Indicates whether the new map is a difference map
     * @param {boolean} [decompress=false] - Indicates whether the new map should be decompressed before being passed to libcoot api
     * @param {object} [options] - Options passed to fetch API
     * @returns {Promise<moorhen.Map>} This moorhenMap instance
     */
    static loadToCootFromMapURL(url: RequestInfo | URL, name: string, moorhenInstance: MoorhenInstance, isDiffMap?: boolean, decompress?: boolean, options?: RequestInit, uniqueId?: string): Promise<moorhen.Map>;
    /**
     * Load map to moorhen from map data
     * @param {ArrayBuffer | Uint8Array} data - The map data in the form of a array buffer
     * @param {string} name - The name that will be assigned to the map
     * @param {boolean} isDiffMap - Indicates whether the new map is a difference map
     * @returns {Promise<moorhen.Map>} This moorhenMap instance
     */
    static loadToCootFromMapData(data: ArrayBuffer | Uint8Array, name: string, isDiffMap: boolean, moorhenInstance: MoorhenInstance, uniqueId?: string): Promise<MoorhenMap>;
    /**
     * Load a map to moorhen from a map file data blob
     * @param {File} source - The map file
     * @param {boolean} [isDiffMap=false] - Indicates whether the new map is a difference map
     * @param {boolean} [decompress=false] - Indicates whether the new map should be decompressed before being passed to libcoot api
     * @returns {Promise<moorhen.Map>} This moorhenMap instance
     */
    static loadToCootFromMapFile(file: File, moorhenInstance: MoorhenInstance, isDiffMap?: boolean, decompress?: boolean): Promise<MoorhenMap>;
    /**
     * Static method used to automatically read multiple maps from a single mtz file
     * @param {File} source - The mtz file
     * @param {moorhenInstance} - The instance
     * @param {Store} store - The redux store
     * @returns {moorhen.Map[]} A list of maps resulting from reading the mtz file
     */
    static autoReadMtz(source: File, moorhenInstance: MoorhenInstance): Promise<moorhen.Map[]>;
    /**
     * Get the current map
     * @returns {Promise<moorhen.WorkerResponse>} A worker response with the map arrayBuffer
     */
    getMap(): Promise<moorhen.WorkerResponse>;
    /**
     * Set the map weight
     * @param {number} [weight=moorhen.Map.suggestedMapWeight] - The new map weight
     * @returns {Promise<moorhen.WorkerResponse>} Void worker response
     */
    setMapWeight(weight?: number): void;
    /**
     * Set the map weight
     * @param {number} [weight=moorhen.Map.suggestedMapWeight] - The new map weight
     * @returns {Promise<moorhen.WorkerResponse>} Void worker response
     */
    scaleMap(scale: number): Promise<moorhen.WorkerResponse>;
    /**
     * Get the current map weight
     * @returns {Promise<number>} The current map weight
     */
    getMapWeight(): Promise<number>;
    /**
     * Get map contour parameters from the redux store
     * @returns {object} A description of map contour parameters as described in the redux store
     */
    getMapContourParams(): {
        mapRadius: number;
        contourLevel: number;
        mapAlpha: number;
        mapStyle: "lines" | "solid" | "lit-lines";
        mapColour: {
            r: number;
            g: number;
            b: number;
        };
        positiveMapColour: {
            r: number;
            g: number;
            b: number;
        };
        negativeMapColour: {
            r: number;
            g: number;
            b: number;
        };
    };
    /**
     * Contour the map with parameters from the redux store
     */
    drawMapContour(): Promise<void>;
    /**
     * Hide the map contour
     */
    hideMapContour(): void;
    /**
     * Clear MGWebGL buffers of a given style for this map
     * @param {string} style - The map style that will be cleared
     */
    clearBuffersOfStyle(style: string, displayBuffers: any[]): any[];
    setupContourBuffers(objects: any[], keepCootColours?: boolean): void;
    /**
     * Draw the map contour around a given origin
     * @param {number} x - Origin coord. X
     * @param {number} y - Origin coord. Y
     * @param {number} z - Origin coord. Z
     * @param {number} radius - Radius around the origin that will be drawn
     * @param {number} contourLevel - The map contour level
     */
    doCootContour(x: number, y: number, z: number, radius: number, contourLevel: number, style: "solid" | "lines" | "lit-lines"): Promise<void>;
    /**
     * Set colouring for this map instance based on another map
     * @param {number} molNo - The imol for the other map
     * @param {number} min - The min value
     * @param {number} max - The max value
     */
    setOtherMapForColouring(molNo: number, min?: number, max?: number): void;
    /**
     * Fetch the colours for a difference map using values from redux store and redraw the map
     * @param {'positiveDiffColour' | 'negativeDiffColour'} type - Indicates whether the negative or positive colours will be set
     * @returns {Promise<void>}
     */
    fetchDiffMapColourAndRedraw(type: "positiveDiffColour" | "negativeDiffColour"): Promise<void>;
    /**
     * Set the colours for a non-difference map using values from redux store
     */
    fetchColourAndRedraw(): Promise<void>;
    /**
     * Fetch the map alpha (transparency) for this map using values from redux store and redraw the map
     */
    fetchMapAlphaAndRedraw(): Promise<void>;
    /**
     * Associate this map with a set of observed reflections
     * @param {moorhen.selectedMtzColumns} selectedColumns - Object indicating the selected MTZ columns
     * @param {Uint8Array} reflectionData - The reflection data that will be associates to this map
     * @returns {Promise<moorhen.WorkerResponse>} - Void promise
     */
    associateToReflectionData(selectedColumns: moorhen.selectedMtzColumns, reflectionData: Uint8Array | ArrayBuffer): Promise<void>;
    /**
     * Fetch the reflection data associated with this map
     * @returns {Promise<moorhen.WorkerResponse<Uint8Array>>} The reflection data
     */
    fetchReflectionData(): Promise<moorhen.WorkerResponse<Uint8Array>>;
    /**
     * Create a copy of the map
     * @returns {Promise<moorhen.Map>} New map instance
     */
    copyMap(): Promise<moorhen.Map>;
    private static readonly COPYABLE_KEYS;
    copyMapParametersTo(newMap: MoorhenMap): void;
    /**
     * Blur the map
     * @param {number} bFactor - The b-factor used for blurring
     * @returns {Promise<moorhen.WorkerResponse<number>>} Status (-1 if failure)
     */
    blur(bFactor: number): Promise<moorhen.WorkerResponse>;
    /**
     * Get the current map RMSD
     * @returns {number} The map RMSD
     */
    fetchMapRmsd(): Promise<number>;
    /**
     * Get the suggested level for this map instance (only for MX maps)
     * @returns {number} The suggested map contour level
     */
    fetchSuggestedLevelXtal(): Promise<number>;
    guessMapRangeAndLevel(): Promise<[number, number, number]>;
    /**
     * Get the suggested map centre for this map instance (it will also fetch suggested level for EM maps)
     * @returns {number[]} The map centre
     */
    fetchMapCentre(): Promise<[number, number, number]>;
    /**
     * Estimate the map weight based on the map rmsd
     */
    estimateMapWeight(): number;
    getSimpleHeaderInfo(): mapHeaderInfo;
    /**
     * Get suggested contour level, radius and map centre for this map instance
     */
    initialise(): Promise<void>;
    getMapBoundingSphere(thresold: number): Promise<{
        center: [number, number, number];
        radius: number;
    }>;
    get_map_density_center_of_mass(positive_only?: boolean): Promise<[number, number, number]>;
    fetchMapMean(): Promise<any>;
    /**
     * Set the view in the centre of this map instance
     */
    centreOnMap(): Promise<void>;
    /**
     * Get the histogram data for this map instance
     * @returns {object} - An object with the histogram data
     */
    getHistogram(nBins?: number, zoomFactor?: number): Promise<libcootApi.HistogramInfoJS>;
    0: any;
    getVerticesHistogram(map2: number, nBins?: number): Promise<libcootApi.HistogramInfoJS>;
    /**
     * Fetch whether this is a difference map
     * @returns {boolean} - True if this map instance is a difference map
     */
    fetchIsDifferenceMap(): Promise<boolean>;
    /**
     * Set the default colour for this map depending on the current number of maps loaded in the session
     */
    setDefaultColour(): Promise<void>;
    /**
     * Export the map as a gltf in binary format
     * @returns {ArrayBuffer} - The contents of the gltf file (binary format)
     */
    exportAsMeshFile(fileType: string): Promise<ArrayBuffer>;
    toggleOriginLock(val?: boolean): void;
}
//# sourceMappingURL=MoorhenMap.d.ts.map