/**
 * How big a molecule is, for deciding how far to zoom out when it is first shown.
 *
 * This replaces a call to coot's `get_molecule_diameter`, which is not a function of the molecule
 * alone. It samples a thousand random atom pairs and returns the tenth-largest distance:
 *
 *     for (unsigned int i=0; i<1000; i++) {
 *        float f1 = coot::util::random_f();
 *        float f2 = coot::util::random_f();
 *        ...
 *     }
 *     f = s.get_ith_highest(10);
 *
 * `random_f` reads the global `random()` stream, and nothing in coot seeds it, so the answer
 * depends on how many random numbers were drawn earlier in the same wasm instance. Anything else
 * that consumes randomness first - a different startup sequence, an extra representation built on
 * open - moves it.
 *
 * That mattered because the result divided by a constant becomes the initial zoom, and with "Reset
 * clip and fog on zoom" enabled the zoom sets clipStart to zoom * 8. Measured over twelve seeds on
 * 5a3h the estimate ranged 43.1 to 44.7 angstroms, which is a front clip plane anywhere in a 0.3
 * angstrom band - enough to slice the cap off an atom in one run and not the next. It made the
 * screenshot baselines unrepeatable, and it meant two people opening the same file could get
 * different clipping, which is unwelcome in a program used to make figures.
 *
 * WHAT IS MEASURED HERE, AND WHY NOT THE MAXIMUM
 *
 * Twice the 99.5th percentile of the atoms' distance from the centroid. The strict maximum was the
 * obvious first choice and it frames too wide: a single atom on a flexible terminus pushes the
 * whole view out, and measured against real structures it comes in well above the true extent.
 *
 *                        true max pair   2 x max radius   2 x P99.5 radius   coot's estimate
 *   5a3h   2,765 atoms        54.6            58.0              54.6           43.1 - 44.7
 *   1df7   1,549 atoms        51.3            56.2              51.1           37.2 - 40.7
 *   3j2w  30,928 atoms       214.4           237.9             218.0         160.9 - 169.7
 *   5fjj  30,056 atoms       164.0           191.5             152.9         115.3 - 120.8
 *
 * The percentile tracks the real extent closely while ignoring a handful of strays. Note also how
 * far coot's estimate sits below the truth, and that the gap widens with size - 21% on 5a3h, 30% on
 * 5fjj - because a thousand pairs drawn from a hundred million possible ones almost never catch the
 * extremities. That is why the divisor alone could not be retuned to match it: the bias is not a
 * constant.
 */
/** Anything with coordinates: moorhen.AtomInfo satisfies this, as does a bare vertex. */
export interface Point3 {
    x: number;
    y: number;
    z: number;
}
/**
 * Which radius counts as the edge of the molecule.
 *
 * 100 gives the strict maximum. 99.5 discards roughly one atom in two hundred, which on these
 * structures is the difference between measuring the molecule and measuring its most excitable
 * side chain.
 */
export declare const DIAMETER_PERCENTILE = 99.5;
/**
 * Divides the diameter to give the initial zoom.
 *
 * Calibrated so the view frames what it used to. Against coot's zoom values this gives 1.09 vs
 * 1.08-1.12 on 5a3h, 1.02 vs 0.93-1.02 on 1df7, 4.36 vs 4.02-4.24 on 3j2w and 3.06 vs 2.88-3.02 on
 * 5fjj - within a few percent across a twentyfold range of size. It was 40 when the diameter came
 * from coot's low estimate.
 */
export declare const ZOOM_DIVISOR = 50;
/** The mean position, which is what the view is centred on. */
export declare const centroidOf: (atoms: ArrayLike<Point3>) => [number, number, number];
/**
 * Twice the given percentile of the atoms' distance from the centroid.
 *
 * Zero for an empty selection and for a single atom, which are degenerate rather than small: the
 * caller decides what to do about them rather than being handed an arbitrary number.
 *
 * Never underestimates by more than one bin: the upper edge of the bin the percentile falls in is
 * returned, so the result is a small overestimate rather than a small clip.
 *
 * @param atoms      the atoms to measure, in any order
 * @param centre     optional precomputed centroid, to avoid walking the list twice
 * @param percentile 0 to 100; 100 is the strict maximum
 */
export declare const moleculeDiameter: (atoms: ArrayLike<Point3>, centre?: [number, number, number], percentile?: number) => number;
//# sourceMappingURL=moleculeExtent.d.ts.map