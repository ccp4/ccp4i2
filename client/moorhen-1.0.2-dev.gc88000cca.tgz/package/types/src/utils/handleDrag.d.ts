/**
 * Turning pointer movement into movement of an object, for the manipulation handles.
 *
 * Pure geometry, kept apart from both the renderer and React so that it can be reasoned about
 * and tested on its own: every function here takes numbers and returns numbers. The renderer
 * supplies the pointer as a ray through the scene - the same front and back pair it already
 * hands to the blob-fitting double click - and this works out what that means for the object.
 */
type Vec3 = [number, number, number];
/**
 * How far along an axis through `centre` the pointer is, as a distance from the centre.
 *
 * The pointer is a line, not a point, so "where along the axis" means the point on the axis
 * closest to that line. Null when the two are parallel, where the question has no answer - which
 * happens whenever a handle is pointing at or away from the viewer, and is why a drag has to
 * cope with being given nothing.
 */
export declare const distanceAlongAxis: (centre: number[], axis: number[], rayFrom: number[], rayTo: number[]) => number | null;
/**
 * Where the pointer crosses the plane through `centre` that `normal` is perpendicular to.
 *
 * Null when the pointer runs along that plane rather than through it, where there is no single
 * crossing to report - the ring seen edge on, for a rotation.
 */
export declare const pointOnPlane: (centre: number[], normal: number[], rayFrom: number[], rayTo: number[]) => Vec3 | null;
/**
 * The angle round an axis at which the pointer crosses the plane the axis is normal to.
 *
 * Null when the pointer runs along that plane rather than through it - the ring seen edge on,
 * where a rotation cannot be read off the screen at all.
 */
export declare const angleAboutAxis: (centre: number[], axis: number[], reference: number[], rayFrom: number[], rayTo: number[]) => number | null;
/** An angle difference brought into (-pi, pi], so that crossing the seam does not spin the object. */
export declare const shortestAngleBetween: (from: number, to: number) => number;
/**
 * An orientation turned by `angle` about a world axis.
 *
 * The rotation is applied on the left - R times M, not M times R - because the axis is one of
 * the world's, not one of the object's: the handles point along x, y and z however the object
 * itself is turned.
 *
 * Column-major throughout, as everything that reaches the shader is.
 */
export declare const rotatedOrientation: (orientation: number[], axis: number[], angle: number) => number[];
/**
 * The world axis a handle's label names, or null where it names no fixed axis.
 *
 * The free handle is the null case on purpose: it moves in whatever plane faces the viewer, so
 * the direction it works in is not known until the pointer supplies it.
 */
export declare const axisOfTag: (tag: string) => Vec3 | null;
/** Whether a handle's label asks for a move along an axis, a turn, or a free move. */
export declare const actionOfTag: (tag: string) => "translate" | "rotate" | "planar" | null;
export {};
//# sourceMappingURL=handleDrag.d.ts.map