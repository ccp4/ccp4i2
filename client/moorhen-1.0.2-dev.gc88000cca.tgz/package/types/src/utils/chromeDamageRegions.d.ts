/** A rectangle to clear, in CSS pixels. */
export type DamageRegion = {
    x: number;
    y: number;
    w: number;
    h: number;
};
/**
 * Conservative boxes covering the chrome drawn on layer 4 - axes, scale bar, crosshair.
 *
 * These canvases are software surfaces in Firefox, so clearing one costs a full-screen CPU fill and
 * then a copy and format conversion up to the compositor. The axes have to be redrawn whenever the
 * view rotates, which during a spin is every frame, and they occupy about 80 pixels in a corner of
 * a four megapixel canvas. Clearing only where something is drawn turns that from a whole-canvas
 * operation into three small ones.
 *
 * Returns null for the stereo, three-way and multi-view layouts, where the axes are repeated at
 * positions derived from a grid. Those are perfectly boundable too, but getting one of them wrong
 * leaves smeared trails on screen, and the common case is worth having without that risk.
 *
 * The numbers mirror the drawing code above and are padded. If a box is too small the old pixels
 * are not cleared and the drawing accumulates frame on frame, so every margin here errs outward.
 */
export declare const chromeDamageRegions: (width: number, height: number, scale: number, opts: {
    drawAxes: boolean;
    drawScaleBar: boolean;
    drawCrosshairs: boolean;
    simpleLayout: boolean;
}) => DamageRegion[] | null;
/**
 * What a partial clear has to cover: where the chrome is going, and where it was.
 *
 * Clearing only the boxes for this frame is not enough. Switch the axes off and their box simply
 * leaves the list - nothing then clears it, and the drawing code has nothing to draw over it with,
 * so the gizmo stays on screen. The same goes for any one item being turned off while others stay.
 *
 * Returns null when a full clear is needed: either side being null means the layout changed into or
 * out of stereo or multi-view, where the boxes are not known.
 */
export declare const regionsToClear: (previous: DamageRegion[] | null, current: DamageRegion[] | null) => DamageRegion[] | null;
//# sourceMappingURL=chromeDamageRegions.d.ts.map