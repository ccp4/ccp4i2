export type MRCHeaderJson = {
    dimensions: {
        nx: number;
        ny: number;
        nz: number;
        mode: number;
    };
    start: {
        nxstart: number;
        nystart: number;
        nzstart: number;
    };
    sampling: {
        mx: number;
        my: number;
        mz: number;
    };
    unitCell: {
        cella: {
            x: number;
            y: number;
            z: number;
        };
        cellb: {
            alpha: number;
            beta: number;
            gamma: number;
        };
    };
    axisMapping: {
        mapc: number;
        mapr: number;
        maps: number;
    };
    statistics: {
        dmin: number;
        dmax: number;
        dmean: number;
        rms: number;
    };
    spaceGroup: {
        ispg: number;
    };
    extendedHeader: {
        nSymbt: number;
        extType: string;
        extraWords: number[];
    };
    format: {
        map: string;
        nversion: number;
        machineStamp: number[];
        littleEndian: boolean;
    };
    labels: {
        nlabl: number;
        values: string[];
    };
};
export type MTZColumnHeader = {
    label: string;
    type: string;
    min?: number;
    max?: number;
    datasetId?: number;
};
export type MTZHeaderJson = {
    format: {
        magic: string;
        headerStartWord: number;
        headerStartByte: number;
        machineStamp: number[];
        littleEndian: boolean;
    };
    records: {
        version?: string;
        title?: string;
        ncol?: number;
        nref?: number;
        nbatch?: number;
        cell?: number[];
        sort?: number[];
        syminf?: {
            nSymOps?: number;
            nPrimitiveOps?: number;
            latticeType?: string;
            spaceGroupNumber?: number;
            spaceGroupName?: string;
            pointGroupName?: string;
            raw: string;
        };
        symm: string[];
        reso?: {
            low?: number;
            high?: number;
            raw: string;
        };
        valm?: number;
        nDif?: number;
        columns: MTZColumnHeader[];
        projects: {
            id: number;
            name: string;
        }[];
        crystals: {
            id: number;
            name: string;
        }[];
        datasets: {
            id: number;
            name: string;
        }[];
        dcell: {
            id: number;
            cell: number[];
        }[];
        dwavel: {
            id: number;
            wavelength: number;
        }[];
        batches: number[];
        history: string[];
        otherRecords: string[];
    };
};
export declare const readMTZHeader: (file: File | ArrayBuffer | Uint8Array) => Promise<MTZHeaderJson | number>;
export declare const readMRCHeader: (file: ArrayBuffer | Uint8Array) => Promise<MRCHeaderJson>;
//# sourceMappingURL=mapHeaders.d.ts.map