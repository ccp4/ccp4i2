/**
 * Playing a movie - to the screen, or to a file.
 *
 * Both are the same traversal of the same movie at two different clocks, and keeping that true is
 * what makes a preview worth trusting. previewMovie runs on the wall clock and draws whatever
 * frames it can; recordMovieToMp4 steps the clock by 1/fps and draws every one. Neither computes
 * a camera: the movie's sampler says where the camera is at a given second, the camera controller
 * is handed that second, and drawScene does the rest.
 *
 * WHY NOT THE EXISTING RECORDER
 *
 * File -> Record the screen uses canvas.captureStream(30) into a MediaRecorder, which samples the
 * canvas on the browser's own clock. Nothing says "this is frame 7". If a ribosome frame takes
 * 400ms, that frame occupies 400ms of the video, and a heavy scene produces a lurching file that
 * no amount of patience fixes. Here each frame is handed to the encoder with a timestamp chosen
 * in advance, so render time and playback time are unrelated. That is the whole point of having a
 * movie feature rather than a screen recorder, and it is the one thing MediaRecorder cannot do.
 *
 * KNOWN LIMITATIONS
 *
 * - Only the WebGL canvas is captured. The axes, scale bar and other 2D chrome live on separate
 *   overlay canvases stacked above it, which takeScreenShot composites by hand; this does not.
 * - Everything is held in memory until the end, so a long movie at a large output size will be
 *   unhappy. ArrayBufferTarget is the simplest target; StreamTarget exists for later.
 *
 * WHAT MEDIABUNNY TOOK OVER
 *
 * The first version drove WebCodecs directly: a VideoEncoder, a VideoFrame per frame with an
 * explicit microsecond timestamp, manual close() to release GPU memory, a loop watching
 * encodeQueueSize for backpressure, and mp4-muxer to assemble the file. Mediabunny's CanvasSource
 * does all of that behind one call - `add(timestampInSeconds, durationInSeconds)`, whose returned
 * promise is the backpressure signal. Timestamps are seconds here, not microseconds.
 *
 * What is lost is the explicit codec string: mediabunny takes 'avc' and chooses the profile and
 * level itself. That matters because Chrome refused H.264 Main and Baseline at 2826 pixels wide
 * while accepting High - a level ceiling, not a missing codec - so onEncoderConfig is logged below
 * to show what it actually picked.
 */
import { VideoCodec } from "mediabunny";
import { Movie, MovieSample } from "./cameraPath";
import type { VideoQuality } from "./videoBitrate";
import type { webGL } from "../types/mgWebGL";
export interface MovieRenderOptions {
    /**
     * Called with each sampled frame, for everything that is not the camera. The export runs on
     * a fixed cadence rather than the wall clock, so this is called once per encoded frame - which
     * is what makes a fade land on exactly the frames it was authored for.
     */
    onSample?: (sample: MovieSample) => void;
    /** Frames per second of the finished file. */
    fps?: number;
    /** How many frames to render. The default is one degree per frame, so a full turn. */
    frames?: number;
    /** Degrees of rotation per frame. */
    degreesPerFrame?: number;
    /**
     * Encoder bitrate in bits per second. Given explicitly it is used as it stands; otherwise it
     * is derived from `quality` and the frame, which is almost always what you want - see
     * videoBitrate for why a flat number cannot suit both a window and a 4K render.
     */
    bitrate?: number;
    /** Which preset to derive the bitrate from, when `bitrate` is not given. */
    quality?: VideoQuality;
    /**
     * Which codec family to encode with. 'avc' is H.264, which is the only one supported on every
     * browser tested so far - Safari refuses av1 - and the only one that plays in PowerPoint.
     */
    codec?: VideoCodec;
    /**
     * Output size. Defaults to the canvas, which is whatever size the window happens to be.
     *
     * Setting it makes the movie independent of the window, which is what a real feature wants:
     * nobody should get a different resolution because they had their browser arranged
     * differently. Mediabunny scales the frames, so asking for more pixels than the canvas has
     * will not invent detail - rendering offscreen at the target size would, and is the better
     * answer eventually.
     */
    width?: number;
    height?: number;
    /**
     * How opaque the panel covering the page is while rendering, 0 to 1.
     *
     * Solid by default. Lowering it is for judging whether the live canvas behaves itself during
     * an export - it used to lurch, because the camera was being fought over, and seeing that is
     * the only way to tell whether it still does.
     */
    coverOpacity?: number;
    /** Called after each frame, for a progress bar or a console log. */
    onProgress?: (framesDone: number, framesTotal: number) => void;
}
export interface MovieRenderResult {
    blob: Blob;
    width: number;
    height: number;
    frames: number;
    fps: number;
    codec: string;
    /** Wall-clock seconds the whole export took, which is not the length of the movie. */
    elapsedSeconds: number;
}
export declare const webCodecsAvailable: () => boolean;
/**
 * Whether this machine will encode at this size.
 *
 * Worth calling before anything else: support depends on the hardware encoder and the OS, not just
 * the browser, so a compatibility table cannot answer it and neither can I.
 */
export declare const describeEncoderSupport: (width: number, height: number, codec?: VideoCodec, fps?: number, bitrate?: number) => Promise<{
    supported: boolean;
    detail: string;
}>;
/**
 * Render a movie at a fixed cadence and encode it.
 *
 * Timestamps are chosen rather than observed, and the drawing buffer is sized to the output, so
 * the file's timing is the movie's own rather than whatever the machine managed while rendering.
 * That is the whole difference between an export and a screen recording.
 */
export declare function recordMovieToMp4(glRef: React.RefObject<webGL.MGWebGL>, movie: Movie, options?: MovieRenderOptions): Promise<MovieRenderResult>;
export interface PreviewHandle {
    /** Stop early. Safe to call after it has finished by itself. */
    stop: () => void;
    /** Resolves when the movie ends or is stopped, with what actually got drawn. */
    finished: Promise<{
        drawnFrames: number;
        elapsedSeconds: number;
        stopped: boolean;
    }>;
}
/**
 * Play a movie on screen, in real time.
 *
 * The opposite trade from the export, and deliberately so. Export keeps every frame and ignores
 * the clock: frame i is stamped at i/fps however long it took to draw, so the file is smooth even
 * when rendering is slower than playback. Preview keeps the clock and drops frames: it asks where
 * the camera should be *now* and draws that, so a scene too heavy to render at speed looks
 * stuttery - which is honest, because it tells you about your machine rather than about the movie.
 *
 * The two disagreeing is the point. Preview answers "does this look right"; export answers "is
 * every frame there".
 *
 * Driven by requestAnimationFrame so the browser's refresh sets the pace. There is no cover here,
 * for the obvious reason.
 */
export declare function previewMovie(glRef: React.RefObject<webGL.MGWebGL>, movie: Movie, options?: {
    onProgress?: (seconds: number, total: number) => void;
    /**
     * Put the view back where it was when the preview started.
     *
     * True for a preview button, whose whole contract is "show me this and give me my view
     * back". False when the playing *is* the work - a movie panel, where landing on the last
     * keyframe is the point, and being yanked back to wherever Play was pressed looks like
     * the movie undoing itself.
     */
    restoreView?: boolean;
    /**
     * Called with each sampled frame, for everything that is not the camera - the object
     * fades, and in time the scene's quantities.
     *
     * The player does not know what a fade is, deliberately: it hands over the sample and the
     * caller decides what in the scene it describes.
     */
    onSample?: (sample: MovieSample) => void;
}): PreviewHandle;
/** Hand the finished file to the browser's downloader. */
export declare const downloadMovie: (blob: Blob, filename?: string) => void;
//# sourceMappingURL=moviePlayer.d.ts.map