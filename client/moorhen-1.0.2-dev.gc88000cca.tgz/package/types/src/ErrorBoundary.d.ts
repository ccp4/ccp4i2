import React, { ErrorInfo } from "react";
export type ErrorBoundaryPropsType = {
    urlPrefix: string;
    children: React.JSX.Element;
};
type ErrorBoundaryStateType = {
    hasError: boolean;
};
export declare class ErrorBoundary extends React.Component<ErrorBoundaryPropsType, ErrorBoundaryStateType> {
    static defaultProps: Partial<ErrorBoundaryPropsType>;
    constructor(props: any);
    static getDerivedStateFromError(error: Error): {
        hasError: boolean;
    };
    componentDidCatch(error: Error, errorInfo: ErrorInfo): void;
    doAsyncDownload(data: BlobPart[], targetName: string): Promise<unknown>;
    handleBackupDownload(): Promise<void>;
    render(): import("react/jsx-runtime").JSX.Element;
}
export {};
//# sourceMappingURL=ErrorBoundary.d.ts.map