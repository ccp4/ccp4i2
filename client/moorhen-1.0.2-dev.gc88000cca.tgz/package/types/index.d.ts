import { libcootApi } from "./libcoot";

export {};

declare global {
    declare module "*.module.css";
    namespace JSX {}
    interface Window {
        _cootModuleLoading: boolean;
        _gemmiModuleLoading: boolean;
        _mathJaxLoading: boolean;
        CCP4Module: libcootApi.CCP4ModuleType;
        cootModule: libcootApi.CCP4ModuleType;
        gemmiModule: any; //FIXME !!!
        MathJax: any;
    }
    declare module "*.svg" {
        const SVGComponent: React.FC<React.SVGProps<SVGSVGElement>>;
        export default SVGComponent;
    }
    declare module "*.css";
    declare module "*.scss";
}
