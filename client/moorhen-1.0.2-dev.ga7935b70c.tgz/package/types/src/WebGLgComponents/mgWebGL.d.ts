import React from 'react';
import * as quat4 from 'gl-matrix/quat';
import * as mat4 from 'gl-matrix/mat4';
import { moorhen } from "../types/moorhen";
import { webGL } from "../types/mgWebGL";
import { TextCanvasTexture } from './textCanvasTexture';
import { DisplayBuffer } from './displayBuffer';
import type { CameraController, CameraTarget, MoveResult, Transition } from './cameraController';
import { Dispatch, Store } from '@reduxjs/toolkit';
import { RootState } from '../store/MoorhenReduxStore';
export declare function getOffsetRect(elem: any): {
    top: number;
    left: number;
};
export declare function initGL(canvas: any): {
    gl: any;
    WEBGL2: boolean;
};
export declare class MGWebGL extends React.Component implements webGL.MGWebGL {
    props: webGL.MGWebGLPropsInterface;
    store: Store<RootState>;
    dispatch: Dispatch<any>;
    private _camera;
    /**
     * Whether objects can be faded in and out.
     *
     * The fade is a shader uniform, and only the WebGL2 shaders declare it - so on a WebGL1
     * context an object stays solid however its opacity is animated. Asked rather than
     * inferred, so a movie's UI can say that plainly instead of appearing to work.
     */
    get supportsObjectFading(): boolean;
    /** The camera controller. Nothing drives it yet; see mgWebGLParts/camera.ts. */
    get cameraController(): CameraController;
    get myQuat(): quat4;
    set myQuat(q: quat4);
    get zoom(): number;
    set zoom(z: number);
    get origin(): [number, number, number];
    set origin(o: [number, number, number]);
    get fogClipOffset(): number;
    set fogClipOffset(v: number);
    draggableMolecule: moorhen.Molecule;
    activeMolecule: moorhen.Molecule;
    specularPower: number;
    atomLabelDepthMode: boolean;
    clipCapPerfectSpheres: boolean;
    useOffScreenBuffers: boolean;
    blurSize: number;
    /** Depth-peel layers; see setDepthPeelLayers. */
    depthPeelLayers: number;
    /**
     * Whether the opaque scene is drawn once into peel layer 0 instead of into every layer.
     *
     * A switch rather than simply the new behaviour, because the two paths should produce
     * the same picture and the only way to be sure of that is to look at them side by side.
     */
    peelOpaqueSeparately: boolean;
    /**
     * What the current peel layer accepts: true for transparent buffers, false for opaque,
     * null when not peeling and everything is drawn as usual.
     */
    peelTransparentOnly: boolean | null;
    blurDepth: number;
    gl_fog_start: null | number;
    doDrawClickedAtomLines: boolean;
    gl_clipPlane0: null | Float32Array;
    gl_clipPlane1: null | Float32Array;
    gl_fog_end: number;
    light_colours_specular: Float32Array;
    light_colours_diffuse: Float32Array;
    light_positions: Float32Array;
    light_colours_ambient: Float32Array;
    background_colour: [number, number, number, number];
    drawEnvBOcc: boolean;
    environmentAtoms: {
        atom: webGL.clickAtom;
        label: string;
    }[][];
    labelledAtoms: webGL.clickAtom[][];
    measuredAtoms: webGL.clickAtom[][];
    pixel_data: Uint8Array;
    screenshotBuffersReady: boolean;
    save_pixel_data: boolean;
    renderToTexture: boolean;
    transparentScreenshotBackground: boolean;
    showShortCutHelp: string[];
    WEBGL2: boolean;
    currentlyDraggedAtom: null | {
        atom: moorhen.AtomInfo;
        buffer: DisplayBuffer;
    };
    canvas: HTMLCanvasElement;
    rttFramebuffer: webGL.MGWebGLFrameBuffer;
    doPerspectiveProjection: boolean;
    labelsTextCanvasTexture: TextCanvasTexture;
    texturedShapes: any[];
    circleTex: WebGLTexture;
    clipChangedEvent: Event;
    context2d: CanvasRenderingContext2D;
    doShadow: boolean;
    doSSAO: boolean;
    doEdgeDetect: boolean;
    depthThreshold: number;
    normalThreshold: number;
    scaleDepth: number;
    scaleNormal: number;
    occludeDiffuse: boolean;
    doPeel: boolean;
    doShadowDepthDebug: boolean;
    doSpin: boolean;
    doStenciling: boolean;
    doMultiView: boolean;
    multiViewRowsColumns: number[];
    specifyMultiViewRowsColumns: boolean;
    threeWayViewOrder: string;
    doThreeWayView: boolean;
    doSideBySideStereo: boolean;
    doCrossEyedStereo: boolean;
    doAnaglyphStereo: boolean;
    doneEvents: boolean;
    destroyTouchGestures?: () => void;
    fpsText: string;
    measurePointsArray: any[];
    mspfArray: number[];
    renderStatsText: string;
    ssaoRadius: number;
    ssaoBias: number;
    radius: number;
    reContourMapOnlyOnMouseUp: boolean;
    showAxes: boolean;
    showCrosshairs: boolean;
    showScaleBar: boolean;
    showFPS: boolean;
    state: {
        width: number;
        height: number;
        hover_point: number;
        hoveridx: number;
        hoverIndices: number[];
    };
    displayBuffers: any[];
    gl: any;
    canvasRef: any;
    animating: boolean;
    /**
     * The outstanding requestAnimationFrame of the camera pump, or null when nothing is moving.
     * Held so that overlapping requests do not pump the scene at twice the frame rate.
     */
    cameraPumpHandle: number | null;
    /**
     * The time, in seconds, the camera is advanced to on the next draw. Null means wall clock.
     *
     * A movie export sets it to i/fps before asking for each frame, so every frame is kept and
     * the output runs at its authored speed however long rendering took. Nothing else sets it.
     */
    cameraTime: number | null;
    /** Detaches the store echo on unmount. */
    unsubscribeCamera: (() => void) | null;
    doDepthPeelPass: boolean;
    environmentRadius: number;
    edgeDetectFramebufferSize: number;
    ssaoFramebufferSize: number;
    gBuffersFramebufferSize: number;
    doRedraw: boolean;
    circleCanvasInitialized: boolean;
    textCanvasInitialized: boolean;
    gl_cursorPos: Float32Array;
    textCtx: CanvasRenderingContext2D;
    circleCtx: CanvasRenderingContext2D;
    atom_span: number;
    /**
     * How far back the shadow camera's eye was put, in angstrom.
     *
     * Kept apart from atom_span because the two stopped being the same thing when the shadow
     * frustum was fitted to the view: the eye now sits at whatever distance clears the casters,
     * not at the structure's diagonal. setMatrixUniforms needs this one, not that one.
     */
    shadowEyeDistance: number;
    axesColourBuffer: WebGLBuffer;
    axesIndexBuffer: WebGLBuffer;
    axesNormalBuffer: WebGLBuffer;
    axesPositionBuffer: WebGLBuffer;
    axesTextColourBuffer: WebGLBuffer;
    axesTextIndexesBuffer: WebGLBuffer;
    axesTextNormalBuffer: WebGLBuffer;
    axesTextPositionBuffer: WebGLBuffer;
    axesTextTexCoordBuffer: WebGLBuffer;
    backColour: string | number[];
    blurXTexture: WebGLTexture;
    blurYTexture: WebGLTexture;
    simpleBlurXTexture: WebGLTexture;
    simpleBlurYTexture: WebGLTexture;
    calculatingShadowMap: boolean;
    cancelMouseTrack: boolean;
    diskBuffer: DisplayBuffer;
    diskVertices: number[];
    dx: number;
    dy: number;
    fogChangedEvent: Event;
    framebufferDrawBuffersReady: boolean;
    framebufferDrawIndexesBuffer: WebGLBuffer;
    framebufferDrawPositionBuffer: WebGLBuffer;
    framebufferDrawTexCoordBuffer: WebGLBuffer;
    glTextFont: string;
    gl_clipPlane2: Float32Array;
    gl_clipPlane3: Float32Array;
    gl_clipPlane4: Float32Array;
    gl_clipPlane5: Float32Array;
    gl_clipPlane6: Float32Array;
    gl_clipPlane7: Float32Array;
    gl_nClipPlanes: number;
    hitchometerColourBuffer: WebGLBuffer;
    hitchometerIndexBuffer: WebGLBuffer;
    hitchometerNormalBuffer: WebGLBuffer;
    hitchometerPositionBuffer: WebGLBuffer;
    doOrderIndependentTransparency: boolean;
    imageVertices: number[];
    init_x: number;
    init_y: number;
    mapLineWidth: number;
    measureCylinderBuffers: DisplayBuffer[];
    measureTextCanvasTexture: TextCanvasTexture;
    measureText2DCanvasTexture: TextCanvasTexture;
    mouseDown: boolean;
    measureHit: any;
    imageBuffer: DisplayBuffer;
    measureButton: number;
    measureDownPos: any;
    mouseDown_x: number;
    mouseDown_y: number;
    mouseDownedAt: number;
    mouseMoved: boolean;
    mouseTrackColourBuffer: WebGLBuffer;
    mouseTrackIndexBuffer: WebGLBuffer;
    mouseTrackNormalBuffer: WebGLBuffer;
    mouseTrackPoints: number[][];
    mouseTrackPositionBuffer: WebGLBuffer;
    moveFactor: number;
    pointsArray: number[];
    mvInvMatrix: Float32Array;
    mvMatrix: Float32Array;
    nAnimationFrames: number;
    nFrames: number;
    nPrevFrames: number;
    offScreenDepthTexture: WebGLTexture;
    offScreenFramebuffer: webGL.MGWebGLFrameBuffer;
    depthPeelFramebuffers: webGL.MGWebGLFrameBuffer[];
    depthPeelColorTextures: WebGLTexture[];
    depthPeelDepthTextures: WebGLTexture[];
    ssaoFramebuffer: webGL.MGWebGLFrameBuffer;
    edgeDetectFramebuffer: webGL.MGWebGLFrameBuffer;
    gFramebuffer: webGL.MGWebGLFrameBuffer;
    gBufferRenderbufferNormal: WebGLRenderbuffer;
    gBufferRenderbufferPosition: WebGLRenderbuffer;
    gBufferPositionTexture: WebGLTexture;
    gBufferDepthTexture: WebGLTexture;
    gBufferNormalTexture: WebGLTexture;
    ssaoTexture: WebGLTexture;
    edgeDetectTexture: WebGLTexture;
    offScreenFramebufferBlurX: webGL.MGWebGLFrameBuffer;
    offScreenFramebufferBlurY: webGL.MGWebGLFrameBuffer;
    offScreenFramebufferSimpleBlurX: webGL.MGWebGLFrameBuffer;
    offScreenFramebufferSimpleBlurY: webGL.MGWebGLFrameBuffer;
    offScreenFramebufferColor: webGL.MGWebGLFrameBuffer;
    offScreenReady: boolean;
    offScreenRenderbufferColor: WebGLRenderbuffer;
    offScreenRenderbufferDepth: WebGLRenderbuffer;
    depthPeelRenderbufferColor: WebGLRenderbuffer[];
    depthPeelRenderbufferDepth: WebGLRenderbuffer[];
    /** The multisampled buffer the opaque peel layer is drawn into; see ensureDepthPeelResolveBuffer. */
    depthPeelMSAAFramebuffer: webGL.MGWebGLFrameBuffer | null;
    depthPeelMSAAColor: WebGLRenderbuffer | null;
    depthPeelMSAADepth: WebGLRenderbuffer | null;
    depthPeelMSAASamples: number;
    depthPeelMSAASupported: number[] | null;
    depthPeelMSAAFailed: string | null;
    offScreenTexture: WebGLTexture;
    pMatrix: Float32Array;
    pmvMatrix: Float32Array;
    prevTime: number;
    ready: boolean;
    renderSilhouettesToTexture: boolean;
    rttFramebufferColor: webGL.MGWebGLFrameBuffer;
    rttFramebufferDepth: webGL.MGWebGLFrameBuffer;
    rttTexture: WebGLTexture;
    rttDepthTexture: WebGLTexture;
    rttTextureDepth: WebGLTexture;
    /** Kept so they can be freed when the render-to-texture buffers are rebuilt at a new size. */
    rttRenderbuffers: WebGLRenderbuffer[];
    screenZ: number;
    shaderProgramTextured: webGL.MGWebGLTextureQuadShader;
    shaderProgramDepthPeelAccum: webGL.MGWebGLShaderDepthPeelAccum;
    /**
     * The triangle program currently in use: one of the two variants below.
     *
     * Swapped once per frame in drawScene rather than at each of the three dozen places
     * that reach for it, because the choice is a property of the whole pass - the
     * projection mode and whether depth peeling is running - and never varies within one.
     */
    shaderProgram: webGL.ShaderTriangles;
    /** With the clip and peel discards. Correct under any projection. */
    shaderProgramClip: webGL.ShaderTriangles;
    /** Without them. Only valid when the projection itself clips the slab. */
    shaderProgramFast: webGL.ShaderTriangles;
    shaderProgramGBuffers: webGL.ShaderGBuffersTriangles;
    shaderProgramGBuffersInstanced: webGL.ShaderGBuffersTrianglesInstanced;
    shaderProgramGBuffersPerfectSpheres: webGL.ShaderGBuffersPerfectSpheres;
    shaderProgramGBuffersThickLinesNormal: webGL.ShaderGBuffersThickLinesNormal;
    shaderProgramSSAO: webGL.ShaderSSAO;
    shaderProgramEdgeDetect: webGL.ShaderEdgeDetect;
    shaderProgramBlurX: webGL.ShaderBlurX;
    shaderProgramBlurY: webGL.ShaderBlurY;
    shaderProgramSimpleBlurX: webGL.ShaderSimpleBlurX;
    shaderProgramSimpleBlurY: webGL.ShaderSimpleBlurY;
    shaderProgramCircles: webGL.ShaderCircles;
    shaderProgramImages: webGL.ShaderImages;
    shaderProgramInstanced: webGL.ShaderTrianglesInstanced;
    shaderProgramInstancedClip: webGL.ShaderTrianglesInstanced;
    shaderProgramInstancedFast: webGL.ShaderTrianglesInstanced;
    shaderProgramInstancedOutline: webGL.ShaderTrianglesInstanced;
    shaderProgramInstancedShadow: webGL.ShaderTrianglesInstanced;
    shaderProgramLines: webGL.MGWebGLShader;
    shaderProgramOutline: webGL.ShaderOutLine;
    shaderProgramOverlay: webGL.ShaderOverlay;
    shaderProgramPerfectSpheres: webGL.ShaderPerfectSpheres;
    shaderProgramPerfectSpheresOutline: webGL.ShaderPerfectSpheres;
    shaderProgramPointSpheres: webGL.ShaderPointSpheres;
    shaderProgramPointSpheresShadow: webGL.ShaderPointSpheres;
    shaderProgramRenderFrameBuffer: webGL.ShaderFrameBuffer;
    shaderProgramShadow: webGL.MGWebGLShader;
    shaderProgramTextBackground: webGL.ShaderTextBackground;
    shaderProgramTextInstanced: webGL.ShaderTextInstanced;
    shaderProgramThickLines: webGL.ShaderThickLines;
    shaderProgramThickLinesNormal: webGL.ShaderThickLinesNormal;
    shaderProgramThickLinesNormalClip: webGL.ShaderThickLinesNormal;
    shaderProgramThickLinesNormalFast: webGL.ShaderThickLinesNormal;
    shaderProgramTwoDShapes: webGL.ShaderTwodShapes;
    shaderDepthShadowProgramPerfectSpheres: webGL.ShaderPerfectSpheres;
    shinyBack: boolean;
    silhouetteBufferReady: boolean;
    silhouetteDepthTexture: WebGLTexture;
    silhouetteFramebuffer: webGL.MGWebGLFrameBuffer;
    silhouetteRenderbufferColor: WebGLRenderbuffer;
    silhouetteRenderbufferDepth: WebGLRenderbuffer;
    silhouetteTexture: WebGLTexture;
    sphereBuffer: DisplayBuffer;
    stencilPass: boolean;
    stenciling: boolean;
    textHeightScaling: number;
    textTex: WebGLTexture;
    ssaoNoiseTexture: WebGLTexture;
    blurUBOBuffer: WebGLBuffer;
    ssaoKernelBuffer: WebGLBuffer;
    ssaoKernel: number[];
    trackMouse: boolean;
    extraFontCtxs: webGL.Dictionary<HTMLCanvasElement>;
    mouseDownButton: number;
    keysDown: webGL.Dictionary<number>;
    textLegends: any;
    textureMatrix: mat4;
    depth_texture: any;
    frag_depth_ext: any;
    drawBuffersExt: any;
    instanced_ext: any;
    ext: any;
    newTextLabels: any;
    axesTexture: any;
    drawingGBuffers: boolean;
    max_elements_indices: number;
    hoverSize: number;
    currentViewport: number[];
    currentAnaglyphColor: number[];
    threeWayViewports: number[][];
    stereoViewports: number[][];
    threeWayQuats: quat4[];
    stereoQuats: quat4[];
    multiWayViewports: number[][];
    multiViewOrigins: number[][];
    multiWayQuats: quat4[];
    multiWayRatio: number;
    currentMultiViewGroup: number;
    hoverBuffer: WebGLBuffer;
    setupStereoTransformations(): void;
    getCanvasRef(): React.RefObject<HTMLCanvasElement>;
    getPixelData(doTransparentBackground?: boolean): Uint8Array;
    setupMultiWayTransformations(nmols: number): {
        rows: number;
        cols: number;
    };
    setupThreeWayTransformations(): void;
    /**
     * Render at a given size without changing how large the canvas looks on the page.
     *
     * A canvas has two sizes: the CSS box it occupies, and the drawing buffer WebGL actually
     * renders into. resize() ties them together, because for normal use they should agree. A movie
     * wants them apart: the output resolution should not depend on how the user happened to arrange
     * their browser, but the window should stay where it is while the export runs.
     *
     * Everything else follows from the buffer size by itself - the projection takes its aspect from
     * gl.viewportWidth/Height, so the frame is composed for the output rather than cropped or
     * stretched to it, and frames can be captured straight off the canvas with no read back.
     *
     * While this is in effect the canvas on screen shows the movie's shape squeezed into the
     * window's box, which looks distorted. That is the browser scaling the buffer into the CSS box,
     * not a fault in the frames.
     */
    setDrawingBufferSize(width: number, height: number): void;
    resize(width: number, height: number): void;
    constructor(props: webGL.MGWebGLPropsInterface);
    render(): import("react/jsx-runtime").JSX.Element;
    draw(): void;
    setSSAORadius(radius: any): void;
    setSSAOBias(bias: any): void;
    setBlurSize(blurSize: any): void;
    /**
     * How many depth-peel layers transparency is resolved with.
     *
     * The buffers are not rebuilt here. drawPeel asks for the layers it wants on the next frame
     * that needs them, and recreateDepthPeelBuffers reallocates when the count or the size has
     * changed - so a scene with nothing transparent in it pays nothing for a change to this.
     */
    setDepthPeelLayers(layers: number): void;
    makeBlurBuffers(blurSize: any): void;
    startSpinTest(): void;
    stopSpinTest(): void;
    doSpinTestFrame(): void;
    setDrawEnvBOcc(drawEnvBOcc: any): void;
    setSpinTestState(doSpin: any): void;
    setDoTransparentScreenshotBackground(transparentScreenshotBackground: any): void;
    setDoAnaglyphStereo(doAnaglyphStereo: any): void;
    setDoCrossEyedStereo(doCrossEyedStereo: any): void;
    setDoSideBySideStereo(doSideBySideStereo: boolean): void;
    setDoRestrictDrawElements(elementsIndicesRestrict: boolean): void;
    setDoMultiView(doMultiView: any): void;
    setThreeWayViewOrder(threeWayViewOrder: string): void;
    setSpecifyMultiViewRowsColumns(specifyMultiViewRowsColumns: boolean): void;
    setMultiViewRowsColumns(multiViewRowsColumns: number[]): void;
    setDoThreeWayView(doThreeWayView: any): void;
    setDoOrderIndependentTransparency(doOrderIndependentTransparency: any): void;
    setOutlinesOn(doOutline: any): void;
    setShadowsOn(doShadow: any): void;
    setSSAOOn(doSSAO: any): void;
    setEdgeDetectDepthThreshold(depthThreshold: number): void;
    setEdgeDetectNormalThreshold(normalThreshold: number): void;
    setEdgeDetectDepthScale(depthScale: any): void;
    setEdgeDetectNormalScale(normalScale: any): void;
    setEdgeDetectOn(doEdgeDetect: any): void;
    setOccludeDiffuse(doOccludeDiffuse: any): void;
    /**
     * Rebuild the shadow map at whatever size the current quality asks for.
     *
     * The map is allocated with the other render-to-texture buffers rather than per pass, so
     * changing its size means dropping the lot and letting the next render build them again -
     * which is exactly what deleteTextureFramebuffer plus a cleared screenshotBuffersReady does.
     */
    rebuildShadowMap(): void;
    /**
     * Show the shadow map itself instead of the scene.
     *
     * No UI reaches this - it is set from a preference, or from the console - and that is
     * deliberate. It is a debugging view, and an invaluable one: it is what finally localised a
     * shadow bug that three plausible explanations had failed to, by showing that the map was
     * simply empty.
     *
     * The body of this was missing, so the preference and the MoorhenWebMG effect that reads it
     * both ran and did nothing.
     *
     * Shadows have to be on for there to be a map to look at, which drawScene's gate already
     * requires. Switching them on here would be the convenient thing and the wrong one: a
     * debugging view should not quietly change the setting it is there to inspect.
     */
    setShadowDepthDebug(doShadowDebug: boolean): void;
    componentDidUpdate(oldProps: any): void;
    lerp(a: any, b: any, f: any): any;
    initializeSSAOBuffers(): void;
    bindSSAOBuffers(): void;
    /**
     * Move the eye towards or away from the view centre.
     *
     * Both sides of this merge fix the same bug, and the other side's diagnosis was exactly right:
     * clip and fog were stored as absolute distances from the eye, so moving the eye left them
     * behind and sliced the molecule open. It compensated by shifting the clip planes by however
     * far the eye had moved - clipPlanesAfterEyeMove - which put clip back where it belonged.
     *
     * This side removes the need for the compensation instead. The camera holds all four
     * boundaries as offsets from the view centre, so nothing is left behind when the eye moves and
     * there is nothing to shift: the absolute distances the shaders want are re-derived from those
     * offsets on every frame. It also covers fog, which the shifting fixed only for clip - fog was
     * still absolute, so it still slid 150A forward when the eye went from 250 to 400.
     *
     * clipPlanesAfterEyeMove therefore has nothing left to compensate for and no callers. It is
     * left in projection.ts with its tests rather than deleted here, because removing it is a
     * decision about the other branch's code and not a merge resolution.
     */
    setFogClipOffset(fogClipOffset: number): void;
    componentDidMount(): void;
    componentWillUnmount(): void;
    /**
     * Tell the store where the slab ended up.
     *
     * The camera owns the slab now, so the store's copy is an echo kept for the things that read it
     * rather than drive it: the two slider modals, and the session writer. Without this they would
     * describe a slab the renderer stopped using the moment auto-clip re-derived it.
     *
     * It fires when the camera comes to rest, not per frame - a move settles once on arrival, a
     * zoom settles immediately - so there is no React cost during motion.
     *
     * The equality guard is what stops it looping. The store's clip and fog feed two effects in
     * MoorhenWebMG that write straight back here, and converting absolute fog to an offset and back
     * is not always exact to the last bit. Comparing before dispatching means a value that differs
     * only in its last place is left alone rather than chasing itself around the loop.
     */
    echoSlabToStore(): void;
    /**
     * Tell the store where the view ended up.
     *
     * The companion to echoSlabToStore, and for the same reason: the camera owns the view, the
     * store keeps a copy, and the copy has to stay current or MoorhenWebMG's reconciling effect
     * will see a disagreement and resolve it the wrong way - easing the camera back to a stale
     * value a moment after something put it somewhere.
     *
     * THIS REPLACES A RULE NOBODY COULD KNOW
     *
     * The copy used to be kept current by individual movers calling onOriginChanged,
     * onZoomChanged and onQuatChanged by hand. Every mover written since had to rediscover that
     * rule by watching the view slide away, and three features found it the hard way. Subscribed
     * here it applies to any way of moving the camera, including ones not yet written.
     *
     * The decision is in viewEcho, so the equality guard that stops the store and the camera
     * chasing each other can be reasoned about and tested without a renderer.
     */
    echoViewToStore(): void;
    initializeShaders(): void;
    setActiveMolecule(molecule: moorhen.Molecule): void;
    appendOtherData(jsondata: any, skipRebuild?: boolean, name?: string): any;
    /**
     * Write the camera's slab into the four values the shaders read.
     *
     * The camera holds offsets from the view centre; `gl_clipPlane0[3]`, `gl_clipPlane1[3]`,
     * `gl_fog_start` and `gl_fog_end` are the same slab measured from the eye, which is what the
     * uniforms want. They are derived, not stored: nothing should assign them directly any more,
     * because the next frame would overwrite it. Write the camera instead.
     *
     * Called on every draw, and by each setter below so that code reading the absolutes between a
     * setter and the next draw sees the new slab rather than the old one.
     */
    applySlabToRenderer(): void;
    setFog(fog: any): void;
    setSlab(slab: any): void;
    /**
     * Put part of the slab on the camera and re-derive. The one way the slab is written.
     *
     * Not through `settle`, which stands aside for an active driver: these are the renderer's own
     * direct writes and have always landed unconditionally.
     *
     * A write that names clip or fog stands, even under auto-clip. The policy only re-derives when
     * the zoom moves, which is what "reset clip and fog on zoom" says and what it did before the
     * camera work. This comment used to claim the opposite and to explain why the settings sliders
     * were disabled under auto-clip; they were disabled because the policy was overreaching, and
     * both the overreach and the disabling are gone.
     */
    private setCameraSlab;
    /**
     * Point the view in a given direction.
     *
     * Through the camera rather than through the `myQuat` setter, which writes the live state
     * silently - no notify, so no subscriber hears it. That used not to matter: drawScene echoed
     * the orientation to the store once per frame, so the store caught up on the next draw
     * whatever had written it. That per-frame echo has gone, replaced by echoViewToStore on the
     * camera's own subscription, and a silent write reaches neither.
     *
     * The consequence of getting this wrong is not a stale number. MoorhenWebMG reconciles from
     * the store, and resolves a disagreement by easing the camera *back* - so a setQuat that did
     * not notify would turn the view and have it drift away again a moment later, which is a
     * maddening thing to debug and has already been found three times in other guises.
     */
    setQuat(q: quat4): void;
    setTextFont(family: string, size: number): void;
    setBackground(col: [number, number, number, number]): void;
    setOrientationAndZoomAnimated(q: any, z: any): void;
    setOrientationAnimated(q: any): void;
    handleOriginUpdated(doDispatch: boolean): void;
    /**
     * Put the camera somewhere, over whatever time the caller asks for.
     *
     * `{ kind: "instant" }` is the operation that did not exist before. See moveCameraTo.
     */
    moveCameraTo(target: CameraTarget, transition: Transition): Promise<MoveResult>;
    /**
     * Turn the view by a relative rotation. What a mouse drag does.
     *
     * Goes through the camera rather than multiplying `myQuat` in place, so that a drag arriving
     * during a centring move accumulates and is applied on arrival instead of being overwritten by
     * the move's next frame.
     */
    turnCameraBy(delta: [number, number, number, number]): void;
    setViewAnimated(o: any, q: any, z: any): void;
    setOriginOrientationAndZoomAnimated(o: number[], q: quat4, z: number): void;
    calculateOriginDelta(newOrigin: [number, number, number], oldOrigin: [number, number, number], nFrames: number): [number, number, number];
    setOriginAndZoomAnimated(newOrigin: [number, number, number], newZoom: number): void;
    setOriginAnimated(oldOrigin: number[]): void;
    setOrigin(o: [number, number, number], doDrawScene?: boolean, dispatchEvent?: boolean): void;
    setAmbientLightNoUpdate(r: number, g: number, b: number): void;
    setSpecularLightNoUpdate(r: number, g: number, b: number): void;
    setSpecularPowerNoUpdate(p: any): void;
    setDiffuseLightNoUpdate(r: number, g: number, b: number): void;
    setLightPositionNoUpdate(x: number, y: number, z: number): void;
    setAmbientLight(r: number, g: number, b: number): void;
    setSpecularLight(r: number, g: number, b: number): void;
    setSpecularPower(p: number): void;
    setDiffuseLight(r: number, g: number, b: number): void;
    setLightPosition(x: number, y: number, z: number): void;
    setWheelContour(contourFactor: number, drawScene: boolean): void;
    setZoomAnimated(newZoom: number): void;
    setZoom(z: number, drawScene?: boolean): void;
    setShowAxes(a: any): void;
    recreateSilhouetteBuffers(): void;
    createEdgeDetectFramebufferBuffer(width: number, height: number): void;
    createGBuffers(width: number, height: number): void;
    createSSAOFramebufferBuffer(): void;
    createSimpleBlurOffScreeenBuffers(): void;
    recreateDepthPeelBuffers(width: any, height: any, layers?: number): void;
    ensureOffScreeenBuffers(width: any, height: any): void;
    recreateOffScreeenBuffers(width: any, height: any): void;
    initTextureFramebuffer(): void;
    initTextBuffersBuffer(buffer: any): void;
    initTextBuffers(): void;
    set_clip_range(clipStart: number, clipEnd: number, update?: boolean): void;
    set_fog_range(fogStart: number, fogEnd: number, update?: boolean): void;
    setLightUniforms(program: any, transform?: boolean): void;
    setMatrixUniforms(program: any): void;
    buildBuffers(): void;
    drawTransformMatrixInteractive(transformMatrix: number[], transformOrigin: number[], buffer: any, shader: webGL.MGWebGLShader, vertexType: number, bufferIdx: number, specialDrawBuffer?: number): void;
    applySymmetryMatrix(theShader: any, symmetryMatrix: any, tempMVMatrix: any, tempMVInvMatrix: any, doTransform?: boolean): void;
    drawBuffer(theBuffer: any, theShaderIn: webGL.MGWebGLShader | webGL.ShaderTrianglesInstanced, j: number, vertexType: number, specialDrawBuffer?: any): void;
    drawMaxElementsUInt(vertexType: any, numItems: any): void;
    setupModelViewTransformMatrixInteractive(transformMatrix: any, transformOrigin: any, buffer: any, shader: any, vertexType: any, bufferIdx: any, specialDrawBuffer: any): void;
    drawTransformMatrix(transformMatrix: number[], buffer: any, shader: any, vertexType: number, bufferIdx: number, specialDrawBuffer?: any): void;
    drawTransformMatrixInteractivePMV(transformMatrix: number[], transformOrigin: number[], buffer: any, shader: any, vertexType: number, bufferIdx: number): void;
    drawTransformMatrixPMV(transformMatrix: number[], buffer: any, shader: any, vertexType: number, bufferIdx: number): void;
    drawPeel(theShaders: any, doClear?: boolean, ratioMult?: number): any;
    drawScene(): void;
    bindFramebufferDrawBuffers(): void;
    drawTriangles(calculatingShadowMap: any, invMat: any): void;
    drawTransparent(theMatrix: any): void;
    drawImagesAndText(invMat: any): void;
    clearTextPositionBuffers(): void;
    drawTexturedShapes(invMat: any): void;
    drawTextLabels(up: any, right: any): void;
    isWebGL2(): boolean;
    drawDistancesAndLabels(): void;
    drawCircles(up: any, right: any): void;
    getFrontAndBackPos(event: KeyboardEvent): [number[], number[], number, number];
    doRightClick(event: any, self: any): void;
    doClick(event: any, self: any): void;
    updateLabels(): void;
    clearMeasureCylinderBuffers(): void;
    getThreeWayMatrixAndViewPort(x: any, yp: any, quats: any, viewports: any): {
        mat: any[];
        viewport: any[];
        quat: any;
    };
    getAtomFomMouseXY(event: any, self: any): number[];
    hoverDebounceTimeout: NodeJS.Timeout | null;
    /**
     * The label a buffer claimed the pointer with, while a drag on it is in progress.
     *
     * Opaque here. The renderer's only interest is that while this is set, the pointer belongs
     * to whoever claimed it and must not turn the camera.
     */
    pointerClaim: {
        tag: string;
        bufferId: string;
    } | null;
    /**
     * How much of a sectioned mesh counts as one thing at the current zoom.
     *
     * Written once per draw and read by the highlight and by the pick, so that the two never
     * disagree. It also carries the hysteresis: the decision depends on what it was last time,
     * which is why it is remembered here rather than worked out afresh at each use.
     */
    pickLevel: number;
    doHover(event: any, self: any): void;
    doWheel(event: any): void;
    drawLineMeasures(invMat: any): void;
    drawCrosshairs(invMat: any, ratioMult?: number): void;
    drawMouseTrack(): void;
    drawFPSMeter(): void;
    drawTextOverlays(invMat: any, ratioMult?: number, font_scale?: number): void;
    canvasPointToGLPoint(point: any): {
        x: number;
        y: number;
    };
    getMouseXYGL(evt: any, canvas: any): {
        x: number;
        y: number;
    };
    doMouseUpMeasure(evt: any, self: any): void;
    doMouseDownMeasure(evt: any, self: any): void;
    doMouseMoveMeasure(evt: any, self: any): void;
    doMouseUp(event: any, self: any): void;
    drawSceneDirty(): void;
    drawSceneIfDirty(): void;
    reContourMaps(): void;
    doMiddleClick(evt: any, self: any): void;
    doDoubleClick(event: any, self: any): void;
    setDraggableMolecule(molecule: moorhen.Molecule): void;
    mouseMoveAnimateTrack(force: any, count: any): void;
    calculate3DVectorFrom2DVector(inp: any): any;
    doMouseMove(event: any, self: any): void;
    doMouseDown(event: any, self: any): void;
    handleKeyUp(event: any, self: any): void;
    handleKeyDown(event: any, self: any): void;
    makeCircleCanvas(text: any, width: any, height: any, circleColour: any): void;
    makeTextCanvas(text: string, width: number, height: number, textColour: string, font?: string): [number, CanvasRenderingContext2D];
}
//# sourceMappingURL=mgWebGL.d.ts.map