import { MGWebGL } from '../mgWebGL';
/**
 * Pointer / keyboard event handlers for the MGWebGL canvas. These were methods
 * on MGWebGL and are already written in "collaborator" style — each takes the
 * live instance as an explicit `self`/`event` pair and is registered on the
 * canvas as `self.doMouseDown(evt, self)` etc. Moving them here (following the
 * viewTransforms/framebuffers pattern) keeps all of the interaction state and
 * the helper methods they call (getAtomFomMouseXY, updateLabels, drawScene,
 * getThreeWayMatrixAndViewPort, …) on the instance, reached through `self`.
 *
 * This is the natural seam a future gesture-recognizer library would sit above:
 * it would consume normalized input and call these as the action verbs.
 *
 * The class methods on MGWebGL become thin delegators. `self` is the live
 * instance (type-only-ish import; getOffsetRect is a real runtime import).
 */
export declare function doRightClick(self: MGWebGL, event: any): void;
export declare function doClick(self: MGWebGL, event: any): void;
export declare function doHover(self: MGWebGL, event: any): void;
export declare function doWheel(self: MGWebGL, event: any): void;
export declare function doMouseUpMeasure(self: MGWebGL, evt: any): void;
export declare function doMouseDownMeasure(self: MGWebGL, evt: any): void;
export declare function doMouseMoveMeasure(self: MGWebGL, evt: any): void;
export declare function doMouseUp(self: MGWebGL, event: any): void;
export declare function doMiddleClick(self: MGWebGL, evt: any): void;
export declare function doDoubleClick(self: MGWebGL, event: any): void;
/**
 * Whether camera-style drags should move the active molecule instead of the view.
 */
export declare function isActiveMoleculeMotion(self: MGWebGL): boolean;
/**
 * Translate in the screen plane by (dx, dy) pixels, already scaled by mouseSensitivityFactor.
 * Moves the view origin, or the active molecule when there is one (see isActiveMoleculeMotion).
 * Shared by the mouse pan (alt+shift / middle drag) and the two-finger touch pan. Does not draw.
 */
export declare function panBy(self: MGWebGL, dx: number, dy: number): void;
export declare function doMouseMove(self: MGWebGL, event: any): void;
export declare function doMouseDown(self: MGWebGL, event: any): void;
export declare function handleKeyUp(self: MGWebGL, event: any): void;
export declare function handleKeyDown(self: MGWebGL, event: any): void;
//# sourceMappingURL=eventHandlers.d.ts.map