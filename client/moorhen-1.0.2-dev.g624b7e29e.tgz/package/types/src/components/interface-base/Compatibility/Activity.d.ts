import React from "react";
export declare const ActivityCompat: React.FC<{
    mode: string;
    children: React.ReactNode;
}>;
//# sourceMappingURL=Activity.d.ts.map